"use strict";

function giftMenuItemHtml() {
  return '<button class="chat-action-item" data-act="open-gift-send" type="button">🎁 <span>Regalos</span></button>';
}

var giftSendCtx = null;

function openGiftSend(contextType, contextId, recipientId, recipientName) {
  giftSendCtx = {
    contextType: contextType,
    contextId: contextId,
    recipientId: recipientId || null,
    recipientName: recipientName || null
  };
  $("giftSendBackdrop").classList.add("open");
  if (recipientId) {
    renderGiftTypeStep();
  } else if (contextType === "wallet") {
    renderGiftRecipientStep();
  } else {
    renderGiftTypeStep();
  }
}

$("giftSendClose").addEventListener("click", function() {
  $("giftSendBackdrop").classList.remove("open");
});

$("giftSendBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

function renderGiftRecipientStep() {
  var body = $("giftSendBody");
  var canGoOpen = giftSendCtx.contextType === "community" || giftSendCtx.contextType === "group";
  var backHtml = canGoOpen ? '<button type="button" class="link-btn" id="giftRecipientBack">← Mejor, soltarlo abierto en el chat</button>' : "";
  function wireBack() {
    var backBtn = $("giftRecipientBack");
    if (backBtn) backBtn.addEventListener("click", function() {
      giftSendCtx.recipientId = null;
      giftSendCtx.recipientName = null;
      renderGiftTypeStep();
    });
  }
  if (giftSendCtx.contextType === "wallet") {
    body.innerHTML = backHtml + "<h4>¿A quién le regalas?</h4>" + '<label class="field"><span>Busca por usuario</span><input type="text" id="giftSearchInput" placeholder="@usuario"></label>' + '<div class="social-list" id="giftSearchResults"></div>';
    wireBack();
    var results = $("giftSearchResults");
    $("giftSearchInput").addEventListener("input", function() {
      var q = this.value.trim();
      if (q.length < 2) {
        results.innerHTML = "";
        return;
      }
      supabase.from("profiles").select("id, username, avatar_url").ilike("username", "%" + q + "%").limit(15).then(function(res) {
        var rows = (res.error ? [] : res.data || []).filter(function(r) {
          return r.id !== currentUser.id;
        });
        results.innerHTML = rows.map(function(p) {
          return '<div class="social-list-row gift-recipient-row" data-uid="' + escapeHtml(p.id) + '" data-name="' + escapeHtml(p.username || "usuario") + '">' + avatarSpanHtml(p.username, p.avatar_url, "avatar-md", p.id) + '<div class="social-list-row-info"><div class="social-list-row-name">' + escapeHtml(p.username || "usuario") + "</div></div>" + "</div>";
        }).join("");
        qsa(".gift-recipient-row", results).forEach(function(row) {
          row.addEventListener("click", function() {
            giftSendCtx.recipientId = row.getAttribute("data-uid");
            giftSendCtx.recipientName = row.getAttribute("data-name");
            renderGiftTypeStep();
          });
        });
      });
    });
    return;
  }
  body.innerHTML = backHtml + '<p class="profile-empty-hint">Cargando miembros...</p>';
  wireBack();
  var query = giftSendCtx.contextType === "community" ? supabase.from("community_members").select("user_id, profiles(username, avatar_url)").eq("community_id", giftSendCtx.contextId) : supabase.from("private_group_members").select("user_id, profiles(username, avatar_url)").eq("group_id", giftSendCtx.contextId);
  query.then(function(res) {
    var rows = (res.error ? [] : res.data || []).filter(function(r) {
      return r.user_id !== currentUser.id;
    });
    if (!rows.length) {
      body.innerHTML = backHtml + '<p class="profile-empty-hint">No hay a quién regalarle aquí todavía.</p>';
      wireBack();
      return;
    }
    body.innerHTML = backHtml + '<h4>¿A quién le regalas?</h4><div class="social-list">' + rows.map(function(r) {
      var p = r.profiles || {};
      return '<div class="social-list-row gift-recipient-row" data-uid="' + escapeHtml(r.user_id) + '" data-name="' + escapeHtml(p.username || "usuario") + '">' + avatarSpanHtml(p.username, p.avatar_url, "avatar-md", r.user_id) + '<div class="social-list-row-info"><div class="social-list-row-name">' + escapeHtml(p.username || "usuario") + "</div></div>" + "</div>";
    }).join("") + "</div>";
    wireBack();
    qsa(".gift-recipient-row", body).forEach(function(row) {
      row.addEventListener("click", function() {
        giftSendCtx.recipientId = row.getAttribute("data-uid");
        giftSendCtx.recipientName = row.getAttribute("data-name");
        renderGiftTypeStep();
      });
    });
  });
}

function renderGiftTypeStep() {
  var body = $("giftSendBody");
  var ctx = giftSendCtx;
  var canTargetSomeone = ctx.contextType === "community" || ctx.contextType === "group";
  var headerHtml, toggleHtml = "";
  if (ctx.recipientId) {
    headerHtml = "<h4>Regalar a @" + escapeHtml(ctx.recipientName || "") + "</h4>";
    if (canTargetSomeone) toggleHtml = '<button type="button" class="link-btn" id="giftTargetToggle">🎉 Mejor, soltarlo abierto en el chat</button>';
  } else {
    headerHtml = '<h4>🎁 Regalo para el chat</h4><p class="profile-empty-hint">Va suelto en el chat: se lo queda el primero que lo abra.</p>';
    toggleHtml = '<button type="button" class="link-btn" id="giftTargetToggle">🎯 Dirigirlo a alguien en particular</button>';
  }
  body.innerHTML = headerHtml + '<div class="gift-type-grid">' + '<button type="button" class="gift-type-btn" data-type="stars">' + coinIconHtml("stars") + "<span>Diamantes</span></button>" + '<button type="button" class="gift-type-btn" data-type="coin">' + coinIconHtml("coin") + "<span>Z-Coins</span></button>" + '<button type="button" class="gift-type-btn" data-type="frame">🖼️<span>Marco</span></button>' + '<button type="button" class="gift-type-btn" data-type="bubble">💬<span>Burbuja</span></button>' + "</div>" + toggleHtml;
  qsa(".gift-type-btn", body).forEach(function(btn) {
    btn.addEventListener("click", function() {
      var type = btn.getAttribute("data-type");
      if (type === "stars" || type === "coin") renderGiftCurrencyStep(type); else renderGiftItemStep(type);
    });
  });
  var toggleBtn = $("giftTargetToggle");
  if (toggleBtn) toggleBtn.addEventListener("click", function() {
    if (ctx.recipientId) {
      ctx.recipientId = null;
      ctx.recipientName = null;
      renderGiftTypeStep();
    } else {
      renderGiftRecipientStep();
    }
  });
}

function giftTargetLabel() {
  return giftSendCtx.recipientId ? "para @" + escapeHtml(giftSendCtx.recipientName || "") : "para el chat";
}

function renderGiftCurrencyStep(currency) {
  var body = $("giftSendBody");
  var label = currency === "coin" ? coinIconHtml("coin") + " Z-Coins" : coinIconHtml("stars") + " Diamantes";
  body.innerHTML = "<h4>" + label + " " + giftTargetLabel() + "</h4>" + '<label class="field"><span>Cantidad</span><input type="number" id="giftCurrencyAmount" min="1" step="1" placeholder="100"></label>' + '<button type="button" class="terminal-btn full-width" id="giftCurrencyConfirm">Enviar regalo</button>';
  $("giftCurrencyConfirm").addEventListener("click", function() {
    var amount = parseInt($("giftCurrencyAmount").value, 10);
    if (!amount || amount <= 0) {
      toast("Pon una cantidad válida.");
      return;
    }
    confirmSendGift(currency, amount, null, null);
  });
}

function renderGiftItemStep(type) {
  var body = $("giftSendBody");
  body.innerHTML = '<p class="profile-empty-hint">Cargando lo que tienes...</p>';
  var ownedQuery = type === "frame" ? supabase.from("user_frames").select("frame_id, frames(name, thumbnail_url)").eq("user_id", currentUser.id) : supabase.from("user_chat_bubbles").select("bubble_id, chat_bubbles(name, thumbnail_url)").eq("user_id", currentUser.id);
  var stockQuery = type === "frame" ? supabase.from("frames").select("id, name, thumbnail_url, creator_stock").eq("creator_id", currentUser.id).gt("creator_stock", 0) : supabase.from("chat_bubbles").select("id, name, thumbnail_url, creator_stock").eq("creator_id", currentUser.id).gt("creator_stock", 0);
  Promise.all([ ownedQuery, stockQuery ]).then(function(results) {
    var ownedRows = results[0].error ? [] : results[0].data || [];
    var stockRows = results[1].error ? [] : results[1].data || [];
    if (!ownedRows.length && !stockRows.length) {
      body.innerHTML = '<p class="profile-empty-hint">Todavía no tienes ' + (type === "frame" ? "marcos" : "burbujas") + " para regalar. Cómpralos o créalos primero en la tienda.</p>";
      return;
    }
    function cardHtml(id, name, thumb, fromStock) {
      return '<button type="button" class="gift-item-card" data-id="' + escapeHtml(id) + '" data-stock="' + (fromStock ? "1" : "0") + '">' + '<span class="gift-item-thumb" style="background-image:url(&quot;' + escapeHtml(thumb || "") + '&quot;)"></span>' + '<span class="gift-item-name">' + escapeHtml(name) + (fromStock ? " <em>(de tu monedero)</em>" : "") + "</span>" + "</button>";
    }
    var ownedHtml = ownedRows.map(function(r) {
      var item = type === "frame" ? r.frames : r.chat_bubbles;
      var id = type === "frame" ? r.frame_id : r.bubble_id;
      return cardHtml(id, item.name, item.thumbnail_url, false);
    }).join("");
    var stockHtml = stockRows.map(function(r) {
      return cardHtml(r.id, r.name + " — " + r.creator_stock + " sin vender", r.thumbnail_url, true);
    }).join("");
    body.innerHTML = "<h4>Elige qué regalar " + giftTargetLabel() + '</h4><div class="gift-item-grid">' + ownedHtml + stockHtml + "</div>";
    qsa(".gift-item-card", body).forEach(function(card) {
      card.addEventListener("click", function() {
        var id = card.getAttribute("data-id");
        var fromStock = card.getAttribute("data-stock") === "1";
        if (fromStock) confirmSendGiftFromStock(type, id); else confirmSendGift(type, null, type === "frame" ? id : null, type === "bubble" ? id : null);
      });
    });
  });
}

function giftCardMessageHtml(giftId) {
  return '<button type="button" class="gift-card-msg" data-gift-id="' + escapeHtml(giftId) + '">' + '<img loading=lazy decoding=async src="assets/gifts/gift-closed.webp" alt="Regalo" class="gift-card-msg-img">' + '<span class="gift-card-msg-label">Toca para abrir</span>' + "</button>";
}

document.addEventListener("click", function(e) {
  var card = e.target.closest(".gift-card-msg");
  if (!card) return;
  openGiftById(card.getAttribute("data-gift-id"));
});

function openGiftById(giftId) {
  supabase.from("gifts").select("*, profiles!gifts_sender_id_fkey(username, name)").eq("id", giftId).single().then(function(res) {
    if (res.error || !res.data) {
      toast("🎁 Ese regalo ya no está disponible (alguien más lo abrió).");
      return;
    }
    var gift = res.data;
    if (gift.opened) {
      toast(gift.recipient_id === currentUser.id ? "Ya abriste este regalo." : "🎁 Ya se lo llevó alguien más.");
      return;
    }
    if (gift.recipient_id && gift.recipient_id !== currentUser.id) {
      toast("🎁 Regalo enviado.");
      return;
    }
    giftOpenQueue = [ gift ];
    showNextGift();
  });
}

function postGiftMessage(giftId) {
  var ctx = giftSendCtx;
  if (ctx.contextType === "community") {
    return supabase.rpc("send_community_gift_message", {
      p_community_id: ctx.contextId,
      p_gift_id: giftId
    });
  } else if (ctx.contextType === "group") {
    return supabase.rpc("send_group_gift_message", {
      p_group_id: ctx.contextId,
      p_gift_id: giftId
    });
  } else if (ctx.contextType === "dm") {
    return supabase.rpc("send_dm_gift_message", {
      p_conversation_id: ctx.contextId,
      p_gift_id: giftId
    });
  }
  return Promise.resolve();
}

function confirmSendGift(giftType, amount, frameId, bubbleId) {
  supabase.rpc("send_gift", {
    p_recipient: giftSendCtx.recipientId,
    p_context: giftSendCtx.contextType,
    p_context_id: giftSendCtx.contextId,
    p_gift_type: giftType,
    p_amount: amount,
    p_frame_id: frameId,
    p_bubble_id: bubbleId
  }).then(function(res) {
    if (res.error) {
      toast("No se pudo enviar el regalo (revisa tu saldo).");
      return;
    }
    postGiftMessage(res.data).then(function(msgRes) {
      if (msgRes && msgRes.error) {
        toast("El regalo se envió pero no se pudo mostrar en el chat: " + msgRes.error.message);
        return;
      }
      if (giftSendCtx.contextType === "community" && typeof loadCommunityMessages === "function") loadCommunityMessages(); else if (giftSendCtx.contextType === "group" && typeof loadGroupMessages === "function") loadGroupMessages(); else if (giftSendCtx.contextType === "dm" && typeof loadDmMessages === "function") loadDmMessages();
    });
    toast(giftSendCtx.recipientId ? "🎁 ¡Regalo enviado a @" + (giftSendCtx.recipientName || "") + "!" : "🎁 ¡Regalo soltado en el chat!");
    $("giftSendBackdrop").classList.remove("open");
  });
}

function confirmSendGiftFromStock(itemType, itemId) {
  if (!giftSendCtx.recipientId) {
    toast("Elige a quién se lo regalas.");
    return;
  }
  supabase.rpc("gift_from_creator_stock", {
    p_recipient: giftSendCtx.recipientId,
    p_context: giftSendCtx.contextType,
    p_context_id: giftSendCtx.contextId,
    p_item_type: itemType,
    p_item_id: itemId
  }).then(function(res) {
    if (res.error) {
      toast("No se pudo enviar el regalo: " + res.error.message);
      return;
    }
    postGiftMessage(res.data).then(function(msgRes) {
      if (msgRes && msgRes.error) {
        toast("El regalo se envió pero no se pudo mostrar en el chat: " + msgRes.error.message);
        return;
      }
      if (giftSendCtx.contextType === "community" && typeof loadCommunityMessages === "function") loadCommunityMessages(); else if (giftSendCtx.contextType === "group" && typeof loadGroupMessages === "function") loadGroupMessages(); else if (giftSendCtx.contextType === "dm" && typeof loadDmMessages === "function") loadDmMessages();
    });
    toast("🎁 ¡Regalo enviado a @" + (giftSendCtx.recipientName || "") + "!");
    $("giftSendBackdrop").classList.remove("open");
  });
}

var giftPollTimer = null;

var giftOpenQueue = [];

var giftOpenTaps = 0;

function checkPendingGifts() {
  if (!currentUser) return;
  supabase.from("gifts").select("*, profiles!gifts_sender_id_fkey(username, name)").eq("recipient_id", currentUser.id).eq("opened", false).order("created_at", {
    ascending: true
  }).then(function(res) {
    if (res.error) return;
    giftOpenQueue = res.data || [];
    if (giftOpenQueue.length && !$("giftOpenBackdrop").classList.contains("open")) showNextGift();
  });
}

function showNextGift() {
  var gift = giftOpenQueue.shift();
  if (!gift) return;
  giftOpenTaps = 0;
  var boxImg = $("giftOpenBoxImg");
  if (boxImg) boxImg.src = "assets/gifts/gift-closed.webp";
  $("giftOpenBox").classList.remove("gift-shaking");
  $("giftOpenBox").style.transform = "";
  $("giftOpenReveal").hidden = true;
  $("giftOpenBox").hidden = false;
  $("giftOpenHint").hidden = false;
  $("giftOpenConfetti").innerHTML = "";
  var senderName = gift.profiles && (gift.profiles.name || gift.profiles.username) || "alguien";
  $("giftOpenFrom").textContent = gift.context === "admin" ? "El equipo de Z3T te manda:" : senderName + " te manda un regalo:";
  $("giftOpenBackdrop").classList.add("open");
  $("giftOpenBox").onclick = function() {
    tapGiftBox(gift);
  };
}

function tapGiftBox(gift) {
  giftOpenTaps++;
  $("giftOpenBox").classList.add("gift-shaking");
  $("giftOpenBox").style.transform = "scale(" + (1 + Math.min(giftOpenTaps, 6) * .04) + ") rotate(" + (giftOpenTaps % 2 ? 1 : -1) * 4 + "deg)";
  burstConfettiBit();
  if (giftOpenTaps >= 6) revealGift(gift);
}

function burstConfettiBit() {
  var wrap = $("giftOpenConfetti");
  var bits = [ "🎉", "✨", "🎊", "💜", "⭐" ];
  for (var i = 0; i < 6; i++) {
    var span = document.createElement("span");
    span.className = "confetti-bit";
    span.textContent = bits[Math.floor(Math.random() * bits.length)];
    span.style.left = 45 + Math.random() * 10 + "%";
    span.style.setProperty("--dx", (Math.random() * 2 - 1).toFixed(2));
    span.style.animationDuration = .7 + Math.random() * .6 + "s";
    wrap.appendChild(span);
    (function(el) {
      setTimeout(function() {
        el.remove();
      }, 1500);
    })(span);
  }
}

function revealGift(gift) {
  var boxImg = $("giftOpenBoxImg");
  if (boxImg) boxImg.src = "assets/gifts/gift-open.webp";
  $("giftOpenBox").classList.remove("gift-shaking");
  setTimeout(function() {
    $("giftOpenBox").hidden = true;
    $("giftOpenHint").hidden = true;
    supabase.rpc("open_gift", {
      p_gift_id: gift.id
    }).then(function(res) {
      var claimed = !res.error && res.data;
      if (!claimed) {
        $("giftOpenRevealIcon").innerHTML = "💨";
        $("giftOpenRevealText").textContent = "Uy, alguien más fue más rápido y ya se lo llevó.";
        $("giftOpenReveal").hidden = false;
        return;
      }
      for (var i = 0; i < 24; i++) setTimeout(burstConfettiBit, i * 60);
      var g = res.data;
      var icon = "🎁", text = "";
      if (g.gift_type === "stars") {
        icon = coinIconHtml("stars");
        text = "+" + g.amount + " Diamantes";
      } else if (g.gift_type === "coin") {
        icon = coinIconHtml("coin");
        text = "+" + g.amount + " Z-Coins";
      } else if (g.gift_type === "frame") {
        icon = "🖼️";
        text = "Un marco de perfil nuevo";
      } else if (g.gift_type === "bubble") {
        icon = "💬";
        text = "Una burbuja de chat nueva";
      }
      $("giftOpenRevealIcon").innerHTML = icon;
      $("giftOpenRevealText").textContent = text;
      $("giftOpenReveal").hidden = false;
    });
  }, 420);
}

$("giftOpenDoneBtn").addEventListener("click", function() {
  if (giftOpenQueue.length) {
    showNextGift();
  } else {
    $("giftOpenBackdrop").classList.remove("open");
  }
});

function startGiftPolling() {
  checkPendingGifts();
  if (giftPollTimer) clearInterval(giftPollTimer);
  giftPollTimer = setInterval(function() {
    if (!document.hidden) checkPendingGifts();
  }, 6e4);
}