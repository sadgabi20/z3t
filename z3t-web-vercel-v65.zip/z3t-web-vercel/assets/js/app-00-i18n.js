"use strict";

var I18N = function() {
  var currentLang = "es";
  var DICT = {
    "nav.search_placeholder": {
      es: "Buscar...",
      pt: "Pesquisar..."
    },
    "nav.new_post": {
      es: "+ Nueva publicación",
      pt: "+ Nova publicação"
    },
    "nav.communities": {
      es: "Comunidades",
      pt: "Comunidades"
    },
    "nav.operative_network": {
      es: "RED OPERATIVA",
      pt: "REDE OPERACIONAL"
    },
    "nav.store": {
      es: "Tienda",
      pt: "Loja"
    },
    "nav.notifications": {
      es: "Notificaciones",
      pt: "Notificações"
    },
    "nav.chats": {
      es: "Chats",
      pt: "Conversas"
    },
    "nav.profile": {
      es: "Mi perfil",
      pt: "Meu perfil"
    },
    "nav.settings": {
      es: "Configuración",
      pt: "Configurações"
    },
    "nav.logout": {
      es: "Cerrar sesión",
      pt: "Sair"
    },
    "landing.title": {
      es: "Z3T",
      pt: "Z3T"
    },
    "landing.join": {
      es: "Únete a la sociedad",
      pt: "Junte-se à sociedade"
    },
    "register.title": {
      es: "Únete a la sociedad",
      pt: "Junte-se à sociedade"
    },
    "register.subtitle": {
      es: "Crea tu cuenta para empezar",
      pt: "Crie sua conta para começar"
    },
    "register.email": {
      es: "Correo electrónico",
      pt: "E-mail"
    },
    "register.username": {
      es: "Usuario",
      pt: "Usuário"
    },
    "register.password": {
      es: "Contraseña",
      pt: "Senha"
    },
    "register.password2": {
      es: "Confirmar contraseña",
      pt: "Confirmar senha"
    },
    "register.region": {
      es: "Región",
      pt: "Região"
    },
    "register.region_hint": {
      es: "Separa tu feed, publicaciones y comunidades del resto — puedes cambiarla después en Ajustes.",
      pt: "Separa seu feed, publicações e comunidades do resto — você pode mudar depois nas Configurações."
    },
    "register.submit": {
      es: "Crear cuenta",
      pt: "Criar conta"
    },
    "register.already_have": {
      es: "¿Ya tienes cuenta?",
      pt: "Já tem uma conta?"
    },
    "register.login_link": {
      es: "Inicia sesión",
      pt: "Entrar"
    },
    "register.username_hint": {
      es: "Tu @ (identificador único de tu URL) se genera solo a partir de tu nombre.",
      pt: "Seu @ (identificador único da sua URL) é gerado automaticamente a partir do seu nome."
    },
    "register.oauth_divider": {
      es: "o continúa con",
      pt: "ou continue com"
    },
    "register.oauth_google": {
      es: "Continuar con Google",
      pt: "Continuar com Google"
    },
    "register.oauth_github": {
      es: "Continuar con GitHub",
      pt: "Continuar com GitHub"
    },
    "register.oauth_discord": {
      es: "Continuar con Discord",
      pt: "Continuar com Discord"
    },
    "login.title": {
      es: "Bienvenido de nuevo",
      pt: "Bem-vindo de volta"
    },
    "login.subtitle": {
      es: "Ingresa a tu cuenta para continuar",
      pt: "Entre na sua conta para continuar"
    },
    "login.email": {
      es: "Correo electrónico",
      pt: "E-mail"
    },
    "login.password": {
      es: "Contraseña",
      pt: "Senha"
    },
    "login.submit": {
      es: "Acceder",
      pt: "Entrar"
    },
    "login.forgot": {
      es: "¿Olvidaste tu contraseña?",
      pt: "Esqueceu sua senha?"
    },
    "login.no_account": {
      es: "¿No tienes cuenta?",
      pt: "Não tem uma conta?"
    },
    "login.register_link": {
      es: "Regístrate",
      pt: "Cadastre-se"
    },
    "settings.title": {
      es: "Configuración",
      pt: "Configurações"
    },
    "settings.change_avatar": {
      es: "Cambiar foto de perfil",
      pt: "Mudar foto de perfil"
    },
    "settings.change_banner": {
      es: "Cambiar foto de fondo",
      pt: "Mudar foto de fundo"
    },
    "settings.change_zcard": {
      es: "Cambiar foto de la Z-Card",
      pt: "Mudar foto do Z-Card"
    },
    "settings.name": {
      es: "Nombre",
      pt: "Nome"
    },
    "settings.username": {
      es: "Tu @ (identificador único)",
      pt: "Seu @ (identificador único)"
    },
    "settings.bio": {
      es: "Bio",
      pt: "Bio"
    },
    "settings.location": {
      es: "Ubicación",
      pt: "Localização"
    },
    "settings.region": {
      es: "Región",
      pt: "Região"
    },
    "settings.region_br": {
      es: "Brasil",
      pt: "Brasil"
    },
    "settings.region_hint": {
      es: "Separa el feed, las publicaciones y las comunidades por región para que no se mezclen. Se detectó sola al registrarte — cámbiala aquí si no es correcta.",
      pt: "Separa o feed, as publicações e as comunidades por região para não se misturarem. Foi detectada automaticamente no seu cadastro — mude aqui se não estiver correta."
    },
    "settings.name_color": {
      es: "Color de tu nombre",
      pt: "Cor do seu nome"
    },
    "settings.reset": {
      es: "Restablecer",
      pt: "Restaurar"
    },
    "settings.save": {
      es: "Guardar cambios",
      pt: "Salvar alterações"
    },
    "forum.stats_active_users": {
      es: "usuarios activos",
      pt: "usuários ativos"
    },
    "forum.stats_active_posts": {
      es: "publicaciones activas",
      pt: "publicações ativas"
    },
    "forum.stats_warroom": {
      es: "en sala de guerra ahora",
      pt: "na sala de guerra agora"
    },
    "forum.toast_published": {
      es: "Publicación creada.",
      pt: "Publicação criada."
    },
    "forum.err_threads": {
      es: "No se pudieron cargar las publicaciones.",
      pt: "Não foi possível carregar as publicações."
    },
    "forum.login_react": {
      es: "Inicia sesión para reaccionar.",
      pt: "Entre na sua conta para reagir."
    },
    "forum.err_replies": {
      es: "No se pudieron cargar las respuestas.",
      pt: "Não foi possível carregar as respostas."
    },
    "forum.err_thread_gone": {
      es: "Esa publicación ya no existe.",
      pt: "Essa publicação não existe mais."
    },
    "forum.err_profile_gone": {
      es: "Ese perfil no existe.",
      pt: "Esse perfil não existe."
    },
    "forum.login_comment": {
      es: "Inicia sesión para comentar.",
      pt: "Entre na sua conta para comentar."
    },
    "forum.err_comment_post": {
      es: "No se pudo publicar el comentario.",
      pt: "Não foi possível publicar o comentário."
    },
    "forum.btn_publish_comment": {
      es: "Publicar comentario",
      pt: "Publicar comentário"
    },
    "forum.toast_comment_posted": {
      es: "Comentario publicado.",
      pt: "Comentário publicado."
    },
    "forum.err_attachments": {
      es: 'No se pudieron subir los adjuntos. Revisa que el bucket "attachments" exista.',
      pt: 'Não foi possível enviar os anexos. Verifique se o bucket "attachments" existe.'
    },
    "forum.err_thread_save": {
      es: "No se pudo guardar la publicación.",
      pt: "Não foi possível salvar a publicação."
    },
    "forum.btn_save": {
      es: "Guardar",
      pt: "Salvar"
    },
    "forum.err_content_save": {
      es: "No se pudo guardar el contenido.",
      pt: "Não foi possível salvar o conteúdo."
    },
    "forum.toast_thread_updated": {
      es: "Publicación actualizada.",
      pt: "Publicação atualizada."
    },
    "forum.err_thread_delete": {
      es: "No se pudo eliminar la publicación.",
      pt: "Não foi possível excluir a publicação."
    },
    "forum.toast_thread_deleted": {
      es: "Publicación eliminada.",
      pt: "Publicação excluída."
    },
    "forum.err_comment_save": {
      es: "No se pudo guardar el comentario.",
      pt: "Não foi possível salvar o comentário."
    },
    "forum.toast_comment_updated": {
      es: "Comentario actualizado.",
      pt: "Comentário atualizado."
    },
    "forum.err_comment_delete": {
      es: "No se pudo eliminar el comentario.",
      pt: "Não foi possível excluir o comentário."
    },
    "forum.toast_comment_deleted": {
      es: "Comentario eliminado.",
      pt: "Comentário excluído."
    },
    "forum.pick_image_first": {
      es: "Elige una imagen primero.",
      pt: "Escolha uma imagem primeiro."
    },
    "forum.err_image_upload": {
      es: "No se pudo subir la imagen.",
      pt: "Não foi possível enviar a imagem."
    },
    "forum.toast_bg_updated": {
      es: "Fondo actualizado.",
      pt: "Plano de fundo atualizado."
    },
    "forum.toast_bg_removed": {
      es: "Fondo quitado.",
      pt: "Plano de fundo removido."
    },
    "forum.login_create_community": {
      es: "Inicia sesión para crear una comunidad.",
      pt: "Entre na sua conta para criar uma comunidade."
    },
    "forum.login_create_circle": {
      es: "Inicia sesión para crear un círculo.",
      pt: "Entre na sua conta para criar um círculo."
    },
    "forum.login_publish": {
      es: "Inicia sesión para publicar.",
      pt: "Entre na sua conta para publicar."
    },
    "forum.toast_offline_queued": {
      es: "ya se subió (estaba pendiente por falta de internet).",
      pt: "já foi enviada (estava pendente por falta de internet)."
    },
    "forum.toast_offline_publish": {
      es: "Sin internet: se publicará solo en cuanto vuelva la conexión.",
      pt: "Sem internet: será publicada sozinha assim que a conexão voltar."
    },
    "forum.info_needs_image": {
      es: "Las publicaciones informativas necesitan una imagen de portada. Adjunta una.",
      pt: "As publicações informativas precisam de uma imagem de capa. Anexe uma."
    },
    "forum.uploading_attachments": {
      es: "Subiendo adjuntos...",
      pt: "Enviando anexos..."
    },
    "forum.publishing": {
      es: "Publicando...",
      pt: "Publicando..."
    },
    "forum.btn_publish": {
      es: "Publicar",
      pt: "Publicar"
    },
    "forum.err_publish": {
      es: "No se pudo publicar.",
      pt: "Não foi possível publicar."
    },
    "community.err_load_list": {
      es: "No se pudieron cargar las comunidades.",
      pt: "Não foi possível carregar as comunidades."
    },
    "community.err_gone": {
      es: "Esa comunidad ya no existe.",
      pt: "Essa comunidade não existe mais."
    },
    "community.err_save": {
      es: "No se pudo guardar:",
      pt: "Não foi possível salvar:"
    },
    "community.toast_saved": {
      es: "Guardado.",
      pt: "Salvo."
    },
    "community.toast_deleted": {
      es: "Comunidad eliminada.",
      pt: "Comunidade excluída."
    },
    "community.toast_info_updated": {
      es: "Info actualizada.",
      pt: "Informações atualizadas."
    },
    "community.err_flag_remove": {
      es: "No se pudo quitar la bandera.",
      pt: "Não foi possível remover a etiqueta."
    },
    "community.err_banner_upload": {
      es: "No se pudo subir el banner.",
      pt: "Não foi possível enviar o banner."
    },
    "community.err_bg_upload": {
      es: "No se pudo subir el fondo.",
      pt: "Não foi possível enviar o plano de fundo."
    },
    "community.toast_appearance_updated": {
      es: "Apariencia actualizada.",
      pt: "Aparência atualizada."
    },
    "community.err_unblock": {
      es: "No se pudo desbloquear:",
      pt: "Não foi possível desbloquear:"
    },
    "community.toast_unblocked": {
      es: "Usuario desbloqueado.",
      pt: "Usuário desbloqueado."
    },
    "community.err_turn_off": {
      es: "No se pudo apagar:",
      pt: "Não foi possível desativar:"
    },
    "community.toast_off": {
      es: "Comunidad apagada.",
      pt: "Comunidade desativada."
    },
    "community.err_turn_on": {
      es: "No se pudo encender:",
      pt: "Não foi possível ativar:"
    },
    "community.toast_on": {
      es: "Comunidad encendida.",
      pt: "Comunidade ativada."
    },
    "community.err_video_upload": {
      es: "No se pudo subir el video:",
      pt: "Não foi possível enviar o vídeo:"
    },
    "community.err_audio_upload": {
      es: "No se pudo subir el audio:",
      pt: "Não foi possível enviar o áudio:"
    },
    "community.err_unknown": {
      es: "error desconocido",
      pt: "erro desconhecido"
    },
    "community.err_role_change": {
      es: "No se pudo cambiar el rol:",
      pt: "Não foi possível mudar o cargo:"
    },
    "community.err_banned": {
      es: "No puedes unirte: fuiste baneado de esta comunidad.",
      pt: "Você não pode entrar: foi banido desta comunidade."
    },
    "community.err_join": {
      es: "No se pudo unir:",
      pt: "Não foi possível entrar:"
    },
    "community.toast_joined": {
      es: "Te uniste a",
      pt: "Você entrou em"
    },
    "community.err_invite": {
      es: "No se pudo invitar:",
      pt: "Não foi possível convidar:"
    },
    "community.btn_invite": {
      es: "Invitar",
      pt: "Convidar"
    },
    "community.err_delete": {
      es: "No se pudo eliminar:",
      pt: "Não foi possível excluir:"
    },
    "community.err_leave": {
      es: "No se pudo salir:",
      pt: "Não foi possível sair:"
    },
    "community.toast_left": {
      es: "Saliste de la comunidad.",
      pt: "Você saiu da comunidade."
    },
    "community.err_poll_create": {
      es: "No se pudo crear la encuesta:",
      pt: "Não foi possível criar a enquete:"
    },
    "community.toast_uploading_image": {
      es: "Subiendo imagen...",
      pt: "Enviando imagem..."
    },
    "community.err_image_upload": {
      es: "No se pudo subir la imagen.",
      pt: "Não foi possível enviar a imagem."
    },
    "community.err_send": {
      es: "No se pudo enviar:",
      pt: "Não foi possível enviar:"
    },
    "community.err_image_upload2": {
      es: "No se pudo subir la imagen:",
      pt: "Não foi possível enviar a imagem:"
    },
    "community.err_no_audio_support": {
      es: "Tu navegador no soporta grabar audio.",
      pt: "Seu navegador não suporta gravação de áudio."
    },
    "community.err_no_audio_format": {
      es: "Este navegador no puede grabar audio en un formato compatible.",
      pt: "Este navegador não consegue gravar áudio em um formato compatível."
    },
    "community.err_recording_short": {
      es: "La grabación fue muy corta y se descartó. Mantén el audio un poco más.",
      pt: "A gravação foi muito curta e foi descartada. Segure o áudio um pouco mais."
    },
    "community.toast_sending_audio": {
      es: "Enviando audio...",
      pt: "Enviando áudio..."
    },
    "community.err_audio_upload2": {
      es: "No se pudo subir el audio.",
      pt: "Não foi possível enviar o áudio."
    },
    "community.err_audio_upload3": {
      es: "No se pudo subir el audio:",
      pt: "Não foi possível enviar o áudio:"
    },
    "community.toast_recording": {
      es: "Grabando... toca de nuevo para enviar.",
      pt: "Gravando... toque de novo para enviar."
    },
    "community.err_mic_access": {
      es: "No se pudo acceder al micrófono. Revisa los permisos.",
      pt: "Não foi possível acessar o microfone. Verifique as permissões."
    },
    "community.toast_called_all": {
      es: "Llamaste a todos los miembros.",
      pt: "Você chamou todos os membros."
    },
    "community.toast_notified_waiting": {
      es: "Le avisamos que lo estás esperando aquí.",
      pt: "Avisamos que você está esperando aqui."
    },
    "community.login_cuy": {
      es: "Inicia sesión para dar un cuy.",
      pt: "Entre na sua conta para dar um cuy."
    },
    "community.err_cuy_limit": {
      es: "Ya diste tus 10 cuys de hoy en esta comunidad. Vuelve mañana 🌙",
      pt: "Você já deu seus 10 cuys de hoje nesta comunidade. Volte amanhã 🌙"
    },
    "community.err_cuy_give": {
      es: "No se pudo dar el cuy:",
      pt: "Não foi possível dar o cuy:"
    },
    "community.portal_title": {
      es: "Portal del Admin",
      pt: "Portal do Admin"
    },
    "community.portal_general": {
      es: "General",
      pt: "Geral"
    },
    "community.portal_info": {
      es: "Info de la Comunidad",
      pt: "Informações da Comunidade"
    },
    "community.portal_appearance": {
      es: "Apariencia",
      pt: "Aparência"
    },
    "community.portal_affiliates": {
      es: "Afiliados",
      pt: "Afiliados"
    },
    "community.portal_members_can_send": {
      es: "Permisos: los miembros pueden enviar mensajes",
      pt: "Permissões: os membros podem enviar mensagens"
    },
    "community.portal_auto_offline": {
      es: "Auto Offline",
      pt: "Auto Offline"
    },
    "community.portal_auto_offline_hint": {
      es: "Las comunidades pasarán a modo offline solas si el equipo de admins no está presente por más de 180 minutos.",
      pt: "As comunidades vão para o modo offline sozinhas se a equipe de admins não estiver presente por mais de 180 minutos."
    },
    "community.portal_members_section": {
      es: "Miembros",
      pt: "Membros"
    },
    "community.portal_members_of": {
      es: "Miembros de esta Comunidad",
      pt: "Membros desta Comunidade"
    },
    "community.portal_blocked": {
      es: "Miembros Bloqueados",
      pt: "Membros Bloqueados"
    },
    "community.portal_staff_section": {
      es: "Equipo de gestión",
      pt: "Equipe de gestão"
    },
    "community.portal_audit_log": {
      es: "Historial de Operaciones de Gestión",
      pt: "Histórico de Operações de Gestão"
    },
    "community.portal_danger_zone": {
      es: "Zona de peligro",
      pt: "Zona de perigo"
    },
    "community.portal_delete": {
      es: "Eliminar Comunidad",
      pt: "Excluir Comunidade"
    },
    "community.blocked_title": {
      es: "Miembros bloqueados",
      pt: "Membros bloqueados"
    },
    "dm.mark_read": {
      es: "Marcar como leído",
      pt: "Marcar como lida"
    },
    "dm.err_leave_group": {
      es: "No se pudo salir del grupo.",
      pt: "Não foi possível sair do grupo."
    },
    "dm.toast_left_group": {
      es: "Saliste de",
      pt: "Você saiu de"
    },
    "dm.err_delete": {
      es: "No se pudo eliminar.",
      pt: "Não foi possível excluir."
    },
    "dm.toast_conv_deleted": {
      es: "Conversación eliminada.",
      pt: "Conversa excluída."
    },
    "dm.err_start_conv": {
      es: "No se pudo iniciar la conversación.",
      pt: "Não foi possível iniciar a conversa."
    },
    "dm.err_conv_gone": {
      es: "Esa conversación ya no existe.",
      pt: "Essa conversa não existe mais."
    },
    "dm.err_image_upload": {
      es: "No se pudo subir la imagen.",
      pt: "Não foi possível enviar a imagem."
    },
    "dm.err_accept": {
      es: "No se pudo aceptar:",
      pt: "Não foi possível aceitar:"
    },
    "dm.err_reject": {
      es: "No se pudo rechazar:",
      pt: "Não foi possível recusar:"
    },
    "dm.toast_rejected": {
      es: "Rechazaste la solicitud de chat.",
      pt: "Você recusou o pedido de conversa."
    },
    "dm.err_activity_change": {
      es: "No se pudo cambiar la actividad:",
      pt: "Não foi possível mudar a atividade:"
    },
    "dm.err_video_set": {
      es: "No se pudo poner el video:",
      pt: "Não foi possível colocar o vídeo:"
    },
    "dm.err_send": {
      es: "No se pudo enviar:",
      pt: "Não foi possível enviar:"
    },
    "dm.err_leave_community": {
      es: "No se pudo salir de la comunidad.",
      pt: "Não foi possível sair da comunidade."
    },
    "dm.toast_left_community": {
      es: "Saliste de",
      pt: "Você saiu de"
    },
    "dm.err_accept2": {
      es: "No se pudo aceptar.",
      pt: "Não foi possível aceitar."
    },
    "dm.toast_joined_community": {
      es: "¡Te uniste a",
      pt: "Você entrou em"
    },
    "dm.err_reject2": {
      es: "No se pudo rechazar.",
      pt: "Não foi possível recusar."
    },
    "group.err_create": {
      es: "No se pudo crear el grupo:",
      pt: "Não foi possível criar o grupo:"
    },
    "group.btn_create": {
      es: "Crear grupo",
      pt: "Criar grupo"
    },
    "group.err_admin_add": {
      es: "Grupo creado, pero no se pudo agregarte como admin:",
      pt: "Grupo criado, mas não foi possível te adicionar como admin:"
    },
    "group.toast_created": {
      es: "Grupo",
      pt: "Grupo"
    },
    "group.toast_created_suffix": {
      es: "creado.",
      pt: "criado."
    },
    "group.err_images": {
      es: "No se pudieron subir las imágenes del grupo:",
      pt: "Não foi possível enviar as imagens do grupo:"
    },
    "group.err_unknown": {
      es: "error desconocido",
      pt: "erro desconhecido"
    },
    "group.err_not_found": {
      es: "No se encontró ese grupo.",
      pt: "Esse grupo não foi encontrado."
    },
    "group.err_image_upload": {
      es: "No se pudo subir la imagen.",
      pt: "Não foi possível enviar a imagem."
    },
    "group.err_activity_perm": {
      es: "Solo un admin o co-admin puede cambiar la actividad.",
      pt: "Só um admin ou co-admin pode mudar a atividade."
    },
    "group.err_activity_change": {
      es: "No se pudo cambiar la actividad:",
      pt: "Não foi possível mudar a atividade:"
    },
    "group.err_video_set": {
      es: "No se pudo poner el video:",
      pt: "Não foi possível colocar o vídeo:"
    },
    "group.err_user_not_found": {
      es: "No se encontró a",
      pt: "Não foi possível encontrar"
    },
    "group.err_invite": {
      es: "No se pudo invitar:",
      pt: "Não foi possível convidar:"
    },
    "group.err_send": {
      es: "No se pudo enviar:",
      pt: "Não foi possível enviar:"
    },
    "profile.err_file_not_found": {
      es: "No se encontró ese archivo.",
      pt: "Esse arquivo não foi encontrado."
    },
    "profile.err_load": {
      es: "No se pudo cargar ese perfil.",
      pt: "Não foi possível carregar esse perfil."
    },
    "profile.err_version_mismatch": {
      es: "No se pudo cargar el perfil: el HTML desplegado no coincide con esta versión (revisa la consola).",
      pt: "Não foi possível carregar o perfil: o HTML publicado não corresponde a esta versão (verifique o console)."
    },
    "profile.err_update": {
      es: "No se pudo actualizar.",
      pt: "Não foi possível atualizar."
    },
    "profile.err_flag_save": {
      es: "No se pudo guardar la bandera.",
      pt: "Não foi possível salvar a etiqueta."
    },
    "profile.err_flag_remove": {
      es: "No se pudo quitar la bandera.",
      pt: "Não foi possível remover a etiqueta."
    },
    "profile.err_flag_max": {
      es: "Ya tienes el máximo de 35 banderas.",
      pt: "Você já tem o máximo de 35 etiquetas."
    },
    "profile.err_flag_add": {
      es: "No se pudo agregar la bandera.",
      pt: "Não foi possível adicionar a etiqueta."
    },
    "profile.err_no_session": {
      es: "Tu sesión no está activa. Vuelve a iniciar sesión.",
      pt: "Sua sessão não está ativa. Entre novamente."
    },
    "profile.err_claim": {
      es: "No se pudo reclamar:",
      pt: "Não foi possível resgatar:"
    },
    "profile.btn_claim": {
      es: "Reclamar",
      pt: "Resgatar"
    },
    "profile.err_achievements_max": {
      es: "Ya tienes 3 logros equipados. Quita uno primero.",
      pt: "Você já tem 3 conquistas equipadas. Remova uma primeiro."
    },
    "profile.err_equip": {
      es: "No se pudo equipar:",
      pt: "Não foi possível equipar:"
    },
    "profile.err_note_delete": {
      es: "No se pudo borrar.",
      pt: "Não foi possível excluir."
    },
    "profile.err_note_publish": {
      es: "No se pudo publicar la nota.",
      pt: "Não foi possível publicar a nota."
    },
    "profile.err_pick_image": {
      es: "Elige un archivo de imagen.",
      pt: "Escolha um arquivo de imagem."
    },
    "profile.err_image_too_big": {
      es: "La imagen supera 5MB.",
      pt: "A imagem passa de 5MB."
    },
    "profile.toast_offline_avatar": {
      es: "Sin internet: tu foto de perfil se subirá sola en cuanto vuelva la conexión.",
      pt: "Sem internet: sua foto de perfil será enviada sozinha assim que a conexão voltar."
    },
    "profile.err_avatar_upload": {
      es: 'No se pudo subir la foto. Revisa que el bucket "avatars" exista.',
      pt: 'Não foi possível enviar a foto. Verifique se o bucket "avatars" existe.'
    },
    "profile.err_zcard_upload": {
      es: "No se pudo subir la foto de la Z-Card.",
      pt: "Não foi possível enviar a foto do Z-Card."
    },
    "profile.btn_change_zcard": {
      es: "Cambiar foto de la Z-Card",
      pt: "Mudar foto do Z-Card"
    },
    "profile.err_zcard_save": {
      es: "No se pudo guardar la foto de la Z-Card.",
      pt: "Não foi possível salvar a foto do Z-Card."
    },
    "profile.toast_zcard_updated": {
      es: "Foto de la Z-Card actualizada.",
      pt: "Foto do Z-Card atualizada."
    },
    "profile.err_banner_upload": {
      es: "No se pudo subir la foto de fondo.",
      pt: "Não foi possível enviar a foto de fundo."
    },
    "profile.err_banner_save": {
      es: "No se pudo guardar la foto de fondo.",
      pt: "Não foi possível salvar a foto de fundo."
    },
    "profile.toast_banner_updated": {
      es: "Foto de fondo actualizada.",
      pt: "Foto de fundo atualizada."
    },
    "profile.err_handle_invalid": {
      es: "Tu @ debe tener de 3 a 16 caracteres: letras, números y guion bajo.",
      pt: "Seu @ deve ter de 3 a 16 caracteres: letras, números e underline."
    },
    "profile.err_handle_taken": {
      es: "Ese @ ya existe. Usa otro.",
      pt: "Esse @ já existe. Use outro."
    },
    "profile.err_handle_check": {
      es: "No se pudo comprobar el @. Intenta de nuevo.",
      pt: "Não foi possível verificar o @. Tente de novo."
    },
    "profile.toast_logged_out": {
      es: "Sesión cerrada.",
      pt: "Sessão encerrada."
    },
    "meet.filters_soon": {
      es: "🔧 Los filtros de preferencias para Voice Meet llegan pronto.",
      pt: "🔧 Os filtros de preferências do Voice Meet chegam em breve."
    },
    "meet.err_connect": {
      es: "No se pudo conectar:",
      pt: "Não foi possível conectar:"
    },
    "meet.btn_connect_chats": {
      es: "Conectarnos en Chats",
      pt: "Conectar nas Conversas"
    },
    "meet.toast_connected": {
      es: "Conectados. Ya pueden verse el perfil y seguir hablando en Chats.",
      pt: "Conectados. Já podem ver o perfil um do outro e continuar conversando."
    },
    "meet.toast_vote_saved": {
      es: "Listo, tu voto quedó guardado. Falta que la otra persona también acepte.",
      pt: "Pronto, seu voto foi salvo. Falta a outra pessoa também aceitar."
    },
    "meet.err_photo_upload": {
      es: "No se pudo subir la foto.",
      pt: "Não foi possível enviar a foto."
    },
    "meet.err_send": {
      es: "No se pudo enviar:",
      pt: "Não foi possível enviar:"
    },
    "meet.toast_ended": {
      es: "Terminaste el Meet.",
      pt: "Você encerrou o Meet."
    },
    "meet.err_save": {
      es: "No se pudo guardar:",
      pt: "Não foi possível salvar:"
    },
    "meet.err_image_upload": {
      es: "No se pudo subir la imagen.",
      pt: "Não foi possível enviar a imagem."
    },
    "meet.err_update": {
      es: "No se pudo actualizar:",
      pt: "Não foi possível atualizar:"
    },
    "meet.err_name_length": {
      es: "El nombre debe tener al menos 3 caracteres.",
      pt: "O nome precisa ter pelo menos 3 caracteres."
    },
    "meet.toast_community_updated": {
      es: "Comunidad actualizada.",
      pt: "Comunidade atualizada."
    },
    "meet.err_pick_image": {
      es: "Elige un archivo de imagen.",
      pt: "Escolha um arquivo de imagem."
    },
    "meet.err_image_too_big": {
      es: "La imagen supera 10MB.",
      pt: "A imagem passa de 10MB."
    },
    "meet.err_pick_category": {
      es: "Elige a qué categoría pertenece tu comunidad.",
      pt: "Escolha a categoria da sua comunidade."
    },
    "meet.err_community_create": {
      es: "No se pudo crear la comunidad:",
      pt: "Não foi possível criar a comunidade:"
    },
    "meet.err_community_admin": {
      es: "Comunidad creada, pero no se pudo asignarte como admin:",
      pt: "Comunidade criada, mas não foi possível te definir como admin:"
    },
    "meet.toast_community_created": {
      es: "Comunidad creada. Ya eres el admin.",
      pt: "Comunidade criada. Você já é o admin."
    },
    "meet.err_community_unknown": {
      es: "Ocurrió un error al crear la comunidad.",
      pt: "Ocorreu um erro ao criar a comunidade."
    },
    "meet.err_login": {
      es: "No se pudo iniciar sesión:",
      pt: "Não foi possível entrar:"
    },
    "meet.err_profile_load": {
      es: "No se pudo cargar tu perfil.",
      pt: "Não foi possível carregar seu perfil."
    },
    "meet.toast_welcome_back": {
      es: "Bienvenido de vuelta,",
      pt: "Bem-vindo de volta,"
    },
    "activity.toast_reconnecting": {
      es: "Reconectando el chat de voz...",
      pt: "Reconectando o chat de voz..."
    },
    "activity.toast_voice_off": {
      es: "Se apagó el chat de voz.",
      pt: "O chat de voz foi desativado."
    },
    "activity.err_no_perm_on": {
      es: "No tienes permiso para encender el chat de voz aquí.",
      pt: "Você não tem permissão para ativar o chat de voz aqui."
    },
    "activity.err_no_perm_off": {
      es: "No tienes permiso para apagar el chat de voz aquí.",
      pt: "Você não tem permissão para desativar o chat de voz aqui."
    },
    "activity.err_join_first": {
      es: "Únete primero para poder hablar.",
      pt: "Entre primeiro para poder falar."
    },
    "activity.err_admin_must_start": {
      es: "Un admin debe encender el chat de voz primero.",
      pt: "Um admin precisa ativar o chat de voz primeiro."
    },
    "activity.err_connect": {
      es: "No se pudo conectar al chat de voz.",
      pt: "Não foi possível conectar ao chat de voz."
    },
    "activity.err_mic": {
      es: "No se pudo activar tu micrófono. Revisa los permisos del navegador.",
      pt: "Não foi possível ativar seu microfone. Verifique as permissões do navegador."
    },
    "roleplay.err_char_save": {
      es: "No se pudo guardar el personaje:",
      pt: "Não foi possível salvar o personagem:"
    },
    "roleplay.err_photo_upload": {
      es: "No se pudo subir la foto del personaje.",
      pt: "Não foi possível enviar a foto do personagem."
    },
    "roleplay.err_char_delete": {
      es: "No se pudo eliminar:",
      pt: "Não foi possível excluir:"
    },
    "roleplay.toast_char_deleted": {
      es: "Personaje eliminado.",
      pt: "Personagem excluído."
    },
    "roleplay.err_char_taken": {
      es: "Ese personaje ya lo está usando alguien más.",
      pt: "Esse personagem já está sendo usado por outra pessoa."
    },
    "roleplay.toast_now_speaking_as": {
      es: "Ahora estás hablando como",
      pt: "Agora você está falando como"
    },
    "roleplay.that_character": {
      es: "ese personaje",
      pt: "esse personagem"
    },
    "roleplay.err_char_release": {
      es: "No se pudo soltar el personaje:",
      pt: "Não foi possível liberar o personagem:"
    },
    "roleplay.toast_char_released": {
      es: "Dejaste el personaje.",
      pt: "Você liberou o personagem."
    },
    "roleplay.err_audio_change": {
      es: "No se pudo cambiar el audio del Roleplay:",
      pt: "Não foi possível mudar o áudio do Roleplay:"
    },
    "contacts.menu_item": {
      es: "Buscar contactos",
      pt: "Buscar contatos"
    },
    "contacts.title": {
      es: "Buscar contactos",
      pt: "Buscar contatos"
    },
    "contacts.my_phone": {
      es: "Tu número de teléfono",
      pt: "Seu número de telefone"
    },
    "contacts.my_phone_hint": {
      es: "Solo se guarda un código (hash) de tu número, nunca el número en texto plano — así otros usuarios te pueden encontrar si te tienen en sus contactos.",
      pt: "Só é salvo um código (hash) do seu número, nunca o número em texto simples — assim outros usuários podem te encontrar se tiverem seu contato salvo."
    },
    "contacts.btn_save_phone": {
      es: "Guardar mi número",
      pt: "Salvar meu número"
    },
    "contacts.btn_sync": {
      es: "Buscar en mis contactos",
      pt: "Buscar nos meus contatos"
    },
    "contacts.sync_hint": {
      es: "Se compara por código (hash), nunca se sube tu lista de contactos a la vista de nadie más — ni siquiera nosotros vemos los números reales.",
      pt: "A comparação é feita por código (hash), sua lista de contatos nunca fica visível para mais ninguém — nem nós vemos os números reais."
    },
    "contacts.err_invalid_phone": {
      es: "Escribe un número de teléfono válido.",
      pt: "Digite um número de telefone válido."
    },
    "contacts.err_save_phone": {
      es: "No se pudo guardar tu número.",
      pt: "Não foi possível salvar seu número."
    },
    "contacts.toast_phone_saved": {
      es: "Tu número quedó guardado.",
      pt: "Seu número foi salvo."
    },
    "contacts.no_matches": {
      es: "Ninguno de tus contactos está registrado todavía.",
      pt: "Nenhum dos seus contatos está registrado ainda."
    },
    "contacts.saved_as": {
      es: "guardado como",
      pt: "salvo como"
    },
    "contacts.err_native_only": {
      es: "Esta función solo está disponible dentro de la app instalada.",
      pt: "Essa função só está disponível dentro do app instalado."
    },
    "contacts.syncing": {
      es: "Buscando...",
      pt: "Buscando..."
    },
    "contacts.err_sync": {
      es: "No se pudo sincronizar tus contactos.",
      pt: "Não foi possível sincronizar seus contatos."
    },
    "shop.toast_bought": {
      es: "¡Comprado! Ya está en tu monedero.",
      pt: "Comprado! Já está na sua carteira."
    },
    "shop.toast_unlisted": {
      es: "Quitado de la reventa.",
      pt: "Removido da revenda."
    },
    "shop.err_frame_not_found": {
      es: "No se encontró ese marco.",
      pt: "Essa moldura não foi encontrada."
    },
    "shop.err_bubble_not_found": {
      es: "No se encontró esa burbuja.",
      pt: "Esse balão não foi encontrado."
    },
    "shop.toast_yours": {
      es: "¡Listo! Ya es tuyo.",
      pt: "Pronto! Já é seu."
    },
    "shop.err_no_stock": {
      es: "No te quedan existencias tuyas para usar.",
      pt: "Você não tem mais estoque para usar."
    },
    "shop.err_equip": {
      es: "No se pudo equipar (revisa los permisos en la base).",
      pt: "Não foi possível equipar (verifique as permissões no banco)."
    },
    "shop.toast_equipped": {
      es: "Equipado.",
      pt: "Equipado."
    },
    "shop.toast_link_copied": {
      es: "Enlace copiado.",
      pt: "Link copiado."
    },
    "shop.err_wait_upload": {
      es: "Espera a que termine de subir.",
      pt: "Espere o envio terminar."
    },
    "shop.err_name_needed": {
      es: "Ponle un nombre.",
      pt: "Coloque um nome."
    },
    "shop.err_save": {
      es: "No se pudo guardar:",
      pt: "Não foi possível salvar:"
    },
    "shop.toast_saved": {
      es: "Cambios guardados.",
      pt: "Alterações salvas."
    },
    "shop.err_create": {
      es: "No se pudo crear.",
      pt: "Não foi possível criar."
    },
    "shop.toast_created": {
      es: "Creado. Ahora acúñalo desde tu monedero para publicarlo en la tienda.",
      pt: "Criado. Agora cunhe pela sua carteira para publicar na loja."
    },
    "shop.err_login_first": {
      es: "Inicia sesión primero.",
      pt: "Entre na sua conta primeiro."
    },
    "shop.toast_opening_payment": {
      es: "Abriendo pago...",
      pt: "Abrindo pagamento..."
    },
    "shop.err_session_expired": {
      es: "Tu sesión expiró, vuelve a iniciar sesión.",
      pt: "Sua sessão expirou, entre novamente."
    },
    "shop.err_payment_create": {
      es: "No se pudo crear el pago:",
      pt: "Não foi possível criar o pagamento:"
    },
    "shop.toast_banner_updated": {
      es: "Banner actualizado.",
      pt: "Banner atualizado."
    },
    "shop.toast_bg_updated": {
      es: "Fondo actualizado.",
      pt: "Plano de fundo atualizado."
    },
    "shop.err_creation_not_found": {
      es: "No se encontró esa creación.",
      pt: "Essa criação não foi encontrada."
    },
    "shop.err_only_creator": {
      es: "Solo el creador puede acuñar esto.",
      pt: "Só quem criou pode cunhar isso."
    },
    "shop.err_qty_invalid": {
      es: "Pon una cantidad válida.",
      pt: "Coloque uma quantidade válida."
    },
    "shop.toast_minted": {
      es: "¡Acuñado! Ya está en tu monedero. Ahora ponlo a la venta.",
      pt: "Cunhado! Já está na sua carteira. Agora coloque à venda."
    },
    "shop.err_no_wallet_stock": {
      es: "No tienes esa cantidad en tu monedero.",
      pt: "Você não tem essa quantidade na carteira."
    },
    "shop.toast_listed": {
      es: "¡Puesto a la venta! Ya aparece en la tienda.",
      pt: "À venda! Já aparece na loja."
    },
    "shop.err_no_sale_stock": {
      es: "No tienes esa cantidad puesta a la venta.",
      pt: "Você não tem essa quantidade à venda."
    },
    "shop.toast_unlisted2": {
      es: "Ya lo quitaste de la venta y volvió a tu monedero.",
      pt: "Você já removeu da venda e voltou para sua carteira."
    },
    "shop.err_price_invalid": {
      es: "Pon un precio válido.",
      pt: "Coloque um preço válido."
    },
    "shop.toast_resale_listed": {
      es: "¡Puesto en reventa! Ya aparece en la pestaña Reventa de la tienda.",
      pt: "Colocado para revenda! Já aparece na aba Revenda da loja."
    }
  };
  function langForRegion(region) {
    return region === "BR" ? "pt" : "es";
  }
  function t(key) {
    var entry = DICT[key];
    if (!entry) return key;
    return entry[currentLang] || entry.es || key;
  }
  function applyLanguage(langOrRegion) {
    currentLang = langOrRegion === "pt" || langOrRegion === "BR" ? "pt" : "es";
    document.documentElement.setAttribute("lang", currentLang === "pt" ? "pt-BR" : "es");
    qsa("[data-i18n]").forEach(function(el) {
      el.textContent = t(el.getAttribute("data-i18n"));
    });
    qsa("[data-i18n-placeholder]").forEach(function(el) {
      el.setAttribute("placeholder", t(el.getAttribute("data-i18n-placeholder")));
    });
    qsa("[data-i18n-aria-label]").forEach(function(el) {
      el.setAttribute("aria-label", t(el.getAttribute("data-i18n-aria-label")));
    });
  }
  return {
    t: t,
    applyLanguage: applyLanguage,
    langForRegion: langForRegion,
    getLang: function() {
      return currentLang;
    }
  };
}();

function t(key) {
  return I18N.t(key);
}