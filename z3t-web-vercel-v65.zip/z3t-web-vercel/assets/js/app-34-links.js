"use strict";

/* ================= Enlaces con palabra: [palabra](https://enlace) ================= */

function z3tRichText(text, withBreaks) {
  var html = escapeHtml(text == null ? "" : String(text));
  html = html.replace(/\[([^\]\n]{1,80})\]\((https?:\/\/[^\s)]+)\)|(https?:\/\/[^\s<]+)/gi, function(m, label, linkUrl, bare) {
    if (linkUrl) {
      return '<a class="rt-link" href="' + linkUrl + '" target="_blank" rel="noopener noreferrer nofollow ugc">' + label + "</a>";
    }
    var tail = "";
    var m2 = bare.match(/[.,;:!?]+$/);
    if (m2) {
      tail = m2[0];
      bare = bare.slice(0, -tail.length);
    }
    return '<a class="rt-link" href="' + bare + '" target="_blank" rel="noopener noreferrer nofollow ugc">' + bare + "</a>" + tail;
  });
  return withBreaks ? html.replace(/\n/g, "<br>") : html;
}

function z3tStripLinks(text) {
  return String(text == null ? "" : text).replace(/\[([^\]\n]{1,80})\]\((https?:\/\/[^\s)]+)\)/gi, "$1");
}

var z3tLinkTarget = null;

function z3tNormalizeUrl(raw) {
  var u = String(raw || "").trim();
  if (!u) return null;
  if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = "https://" + u;
  try {
    var parsed = new URL(u);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return null;
    if (!parsed.hostname || parsed.hostname.indexOf(".") === -1 && parsed.hostname !== "localhost") return null;
    return parsed.href.replace(/\)/g, "%29");
  } catch (e) {
    return null;
  }
}

function z3tOpenLinkDialog(el) {
  var back = document.getElementById("linkInsertBackdrop");
  if (!el || !back) return;
  var start = typeof el.selectionStart === "number" ? el.selectionStart : el.value.length;
  var end = typeof el.selectionEnd === "number" ? el.selectionEnd : el.value.length;
  z3tLinkTarget = {
    el: el,
    start: start,
    end: end
  };
  document.getElementById("linkInsertUrl").value = "";
  document.getElementById("linkInsertWord").value = el.value.slice(start, end).replace(/[\[\]\n]/g, " ").trim().slice(0, 80);
  back.classList.add("open");
  setTimeout(function() {
    document.getElementById("linkInsertUrl").focus();
  }, 30);
}

function z3tCloseLinkDialog() {
  var back = document.getElementById("linkInsertBackdrop");
  if (back) back.classList.remove("open");
  z3tLinkTarget = null;
}

function z3tApplyLinkDialog() {
  if (!z3tLinkTarget) return;
  var url = z3tNormalizeUrl(document.getElementById("linkInsertUrl").value);
  if (!url) {
    toast("Escribe un enlace válido (por ejemplo https://ejemplo.com)");
    return;
  }
  var word = document.getElementById("linkInsertWord").value.replace(/[\[\]\n]/g, " ").trim().slice(0, 80);
  if (!word) {
    try {
      word = new URL(url).hostname.replace(/^www\./, "");
    } catch (e) {
      word = "enlace";
    }
  }
  var el = z3tLinkTarget.el;
  var snippet = "[" + word + "](" + url + ")";
  var v = el.value;
  el.value = v.slice(0, z3tLinkTarget.start) + snippet + v.slice(z3tLinkTarget.end);
  var pos = z3tLinkTarget.start + snippet.length;
  z3tCloseLinkDialog();
  try {
    el.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    el.focus();
    if (el.setSelectionRange) el.setSelectionRange(pos, pos);
  } catch (e) {}
}

document.addEventListener("click", function(e) {
  var btn = e.target.closest && e.target.closest("[data-link-for]");
  if (btn) {
    e.preventDefault();
    e.stopPropagation();
    z3tOpenLinkDialog(document.getElementById(btn.getAttribute("data-link-for")));
    return;
  }
  var id = e.target && e.target.id;
  if (id === "linkInsertOk") z3tApplyLinkDialog(); else if (id === "linkInsertCancel" || id === "linkInsertBackdrop") z3tCloseLinkDialog();
}, true);

document.addEventListener("keydown", function(e) {
  var back = document.getElementById("linkInsertBackdrop");
  if (!back || !back.classList.contains("open")) return;
  if (e.key === "Enter") {
    e.preventDefault();
    z3tApplyLinkDialog();
  } else if (e.key === "Escape") z3tCloseLinkDialog();
});

/* ================= Tiempo real (reemplaza consultas repetidas) ================= */

var Z3T_RT = {};

function z3tRealtimeStop(key) {
  if (!Z3T_RT[key]) return;
  try {
    supabase.removeChannel(Z3T_RT[key]);
  } catch (e) {}
  delete Z3T_RT[key];
}

function z3tRealtimeStopAll() {
  Object.keys(Z3T_RT).forEach(z3tRealtimeStop);
}

function z3tRealtime(key, table, filter, onChange, event) {
  z3tRealtimeStop(key);
  try {
    var ch = supabase.channel("z3t-" + key + "-" + Math.random().toString(36).slice(2, 7)).on("postgres_changes", {
      event: event || "INSERT",
      schema: "public",
      table: table,
      filter: filter
    }, function(payload) {
      try {
        onChange(payload);
      } catch (e) {}
    }).subscribe();
    Z3T_RT[key] = ch;
  } catch (e) {}
}

/* ================= Publicaciones del círculo (ya no dependen de cargar todo el feed) ================= */

var Z3T_CIRCLE_THREADS = {};

function z3tCircleThreads(circleId) {
  var entry = Z3T_CIRCLE_THREADS[circleId];
  if (entry && entry.rows) return entry.rows.slice();
  if (!entry) {
    Z3T_CIRCLE_THREADS[circleId] = {
      rows: null,
      loading: true
    };
    supabase.from("threads").select("*").eq("circle_id", circleId).order("created_at", {
      ascending: false
    }).limit(60).then(function(res) {
      var rows = res.error ? [] : (res.data || []).map(mapThreadRow);
      var ids = rows.map(function(r) {
        return r.authorId;
      }).filter(function(id, i, a) {
        return id && a.indexOf(id) === i;
      });
      var done = function(profiles) {
        var pm = {};
        (profiles || []).forEach(function(p) {
          pm[p.id] = p;
        });
        rows.forEach(function(t) {
          var p = pm[t.authorId];
          if (p) {
            t.author = p.name || p.username;
            t.authorAvatar = p.avatar_url;
            t.authorNameColor = p.name_color;
            t.authorRole = p.role;
            t.authorVerified = p.verified;
          }
        });
        Z3T_CIRCLE_THREADS[circleId] = {
          rows: rows,
          loading: false
        };
        setTimeout(function() {
          Z3T_CIRCLE_THREADS[circleId] = null;
        }, 60e3);
        if (typeof renderCircleTabContent === "function") renderCircleTabContent();
      };
      if (!ids.length) return done([]);
      supabase.from("profiles").select("id, username, name, avatar_url, name_color, role, verified").in("id", ids).then(function(r) {
        done(r.error ? [] : r.data);
      });
    });
  }
  return THREADS.filter(function(t) {
    return t.circleId === circleId;
  });
}

/* ================= Feed paginado: botón "Ver más" ================= */

var Z3T_THREADS_HAS_MORE = false;

(function wrapThreadList() {
  var base = window.renderThreadList;
  if (typeof base !== "function") return;
  window.renderThreadList = function() {
    base.apply(this, arguments);
    var listEl = document.getElementById("threadList");
    if (!listEl) return;
    var old = document.getElementById("threadMoreBtn");
    if (old) old.remove();
    if (!Z3T_THREADS_HAS_MORE) return;
    var b = document.createElement("button");
    b.type = "button";
    b.id = "threadMoreBtn";
    b.className = "terminal-btn full-width";
    b.textContent = "Ver más publicaciones";
    b.addEventListener("click", function() {
      b.disabled = true;
      b.textContent = "Cargando…";
      state.threadLimit = (state.threadLimit || 30) + 30;
      loadThreads().then(function() {
        renderThreadList();
      });
    });
    listEl.appendChild(b);
  };
})();
