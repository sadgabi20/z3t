/* Z3T · personalización guardada en la CUENTA (no en el dispositivo)
   Guarda tema personalizado, tema base e ícono de la app en user_metadata.z3t_prefs.
   Las imágenes (fondo / logo) se suben al bucket "avatars" y solo se guarda su URL. */
(function () {
  "use strict";
  var C = window.Z3TCustom;
  if (!C || typeof supabase === "undefined") return;

  var BUCKET = "avatars";
  var LOCAL_KEYS = [C.KEY, "app_theme", "app_icon"];
  var pushTimer = null;
  var busy = false;
  var again = false;
  var pulling = false;

  function uid() { return (typeof currentUser !== "undefined" && currentUser && currentUser.id) || null; }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }

  function dataUrlToBlob(d) {
    var m = /^data:([^;,]+)(;base64)?,(.*)$/.exec(d);
    if (!m) return null;
    var bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]);
    var arr = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: m[1] });
  }

  /* sube una imagen (data URL) y devuelve su URL pública */
  function uploadImage(dataUrl, kind, userId) {
    var blob = dataUrlToBlob(dataUrl);
    if (!blob) return Promise.reject(new Error("imagen inválida"));
    var ext = blob.type === "image/png" ? "png" : blob.type === "image/webp" ? "webp" : "jpg";
    var path = userId + "/theme_" + kind + "_" + Date.now() + "." + ext;
    return supabase.storage.from(BUCKET).upload(path, blob, { upsert: true, contentType: blob.type }).then(function (r) {
      if (r.error) throw r.error;
      return supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
    });
  }

  /* convierte data: -> URL en el estado local y avisa a la UI */
  function localizeImages(userId) {
    var s = C.load();
    var jobs = [];
    ["bg", "logo"].forEach(function (k) {
      var v = s[k];
      if (typeof v === "string" && v.indexOf("data:") === 0) {
        jobs.push(uploadImage(v, k, userId).then(function (url) { return { k: k, old: v, url: url }; })["catch"](function (e) {
          console.warn("[prefs] no se pudo subir", k, e);
          return null;
        }));
      }
    });
    if (!jobs.length) return Promise.resolve(s);
    return Promise.all(jobs).then(function (res) {
      var cur = C.load(), changed = false;
      res.forEach(function (r) {
        if (r && cur[r.k] === r.old) { cur[r.k] = r.url; changed = true; }
      });
      if (changed) {
        lsSet(C.KEY, JSON.stringify(cur));
        if (window.Z3TTheme && window.Z3TTheme.reload) window.Z3TTheme.reload();
        C.apply(cur);
      }
      return cur;
    });
  }

  function collect() {
    var c = C.load();
    return {
      v: 1,
      custom: {
        enabled: !!c.enabled, accent: c.accent, text: c.text, surface: c.surface, dim: c.dim,
        fontHead: c.fontHead, fontBody: c.fontBody, preset: c.preset,
        bg: (c.bg && c.bg.indexOf("data:") !== 0) ? c.bg : null,
        logo: (c.logo && c.logo.indexOf("data:") !== 0) ? c.logo : null
      },
      app_theme: lsGet("app_theme") || "default",
      app_icon: lsGet("app_icon") || "default"
    };
  }

  function pushNow() {
    var id = uid();
    if (!id) return Promise.resolve();
    if (busy) { again = true; return Promise.resolve(); }
    busy = true;
    return localizeImages(id).then(function () {
      return supabase.auth.updateUser({ data: { z3t_prefs: collect() } });
    }).then(function (r) {
      if (r && r.error) console.warn("[prefs] no se pudo guardar en la cuenta", r.error);
    })["catch"](function (e) {
      console.warn("[prefs] error al guardar", e);
    }).then(function () {
      busy = false;
      if (again) { again = false; return pushNow(); }
    });
  }

  function queuePush() {
    if (pulling || !uid()) return;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(pushNow, 900);
  }

  function applyAll() {
    var s = C.load();
    C.apply(s); C.applyLogo(s);
    if (typeof applyTheme === "function") applyTheme(lsGet("app_theme") || "default");
    if (typeof applyAppIcon === "function") applyAppIcon(lsGet("app_icon") || "default");
    if (window.Z3TTheme && window.Z3TTheme.reload) window.Z3TTheme.reload();
  }

  /* cuenta -> dispositivo (al iniciar sesión) */
  function pull() {
    return supabase.auth.getUser().then(function (res) {
      var u = res && res.data && res.data.user;
      if (!u) return;
      var p = u.user_metadata && u.user_metadata.z3t_prefs;
      var owner = lsGet("z3t_prefs_owner");
      if (p) {
        pulling = true;
        try {
          lsSet(C.KEY, JSON.stringify(Object.assign({}, C.DEF, p.custom || {})));
          lsSet("app_theme", p.app_theme || "default");
          lsSet("app_icon", p.app_icon || "default");
          lsSet("z3t_prefs_owner", u.id);
          applyAll();
        } finally { pulling = false; }
      } else {
        /* cuenta sin preferencias: si lo local es de otra cuenta, se limpia; si no, se migra a esta cuenta */
        if (owner && owner !== u.id) {
          clearLocal();
        } else {
          lsSet("z3t_prefs_owner", u.id);
          var c = C.load();
          if (c.enabled || (lsGet("app_theme") || "default") !== "default" || (lsGet("app_icon") || "default") !== "default") pushNow();
        }
      }
    })["catch"](function (e) { console.warn("[prefs] no se pudo leer la cuenta", e); });
  }

  /* al cerrar sesión no se deja nada de la cuenta en el dispositivo */
  function clearLocal() {
    clearTimeout(pushTimer);
    pulling = true;
    try {
      LOCAL_KEYS.concat(["z3t_prefs_owner"]).forEach(lsDel);
      applyAll();
    } finally { pulling = false; }
  }

  supabase.auth.onAuthStateChange(function (event) {
    if (event === "SIGNED_OUT") clearLocal();
  });

  window.Z3TAccountPrefs = { pull: pull, push: pushNow, queuePush: queuePush, clearLocal: clearLocal };

  /* sesión ya abierta al cargar la página */
  setTimeout(function () { if (uid()) pull(); }, 600);
})();
