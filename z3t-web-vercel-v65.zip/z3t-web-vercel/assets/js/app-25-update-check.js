"use strict";

(function() {
  var APP_VERSION_ENDPOINT = SUPABASE_URL + "/functions/v1/app-version?platform=android";
  var lastCheckResult = null;
  function isNative() {
    return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  }
  function getInstalledVersionCode() {
    if (!isNative() || !window.Capacitor.Plugins || !window.Capacitor.Plugins.App) {
      return Promise.resolve(null);
    }
    return window.Capacitor.Plugins.App.getInfo().then(function(info) {
      return parseInt(info.build, 10);
    })["catch"](function() {
      return null;
    });
  }
  function checkForUpdate() {
    return Promise.all([ fetch(APP_VERSION_ENDPOINT).then(function(res) {
      if (!res.ok) throw new Error("No se pudo consultar la versión disponible.");
      return res.json();
    }), getInstalledVersionCode() ]).then(function(results) {
      var remote = results[0];
      var installedCode = results[1];
      lastCheckResult = {
        remote: remote,
        installedCode: installedCode,
        hasUpdate: installedCode != null && remote.version_code > installedCode
      };
      return lastCheckResult;
    });
  }
  function renderUpToDate() {
    $("updateModalBody").innerHTML = '<p class="profile-empty-hint">✓ Ya tienes la última versión.</p>';
  }
  function renderError(msg) {
    $("updateModalBody").innerHTML = '<p class="profile-empty-hint">' + escapeHtml(msg) + "</p>";
  }
  function renderUpdateAvailable(result) {
    var r = result.remote;
    var sizeMb = (r.file_size / (1024 * 1024)).toFixed(1);
    $("updateModalBody").innerHTML = "<p><strong>Nueva versión disponible: " + escapeHtml(r.version_name) + "</strong></p>" + (r.is_required ? '<p class="update-required-note">Esta actualización es obligatoria.</p>' : "") + (r.requires_reinstall ? '<p class="update-required-note">Esta actualización necesita que desinstales la app anterior antes de instalar la nueva (vas a perder los datos guardados solo en el celular; tu cuenta sigue intacta porque vive en el servidor).</p>' : "") + (r.release_notes ? '<div class="update-release-notes">' + escapeHtml(r.release_notes).replace(/\n/g, "<br>") + "</div>" : "") + '<p class="profile-empty-hint">Tamaño: ' + sizeMb + " MB</p>" + '<button class="terminal-btn full-width" id="btnDownloadUpdate" type="button">Descargar actualización</button>';
    $("btnDownloadUpdate").addEventListener("click", function() {
      window.open(r.download_url, "_blank");
    });
  }
  function openUpdateModal() {
    $("updateModalBackdrop").classList.add("open");
    $("updateModalBody").innerHTML = '<p class="profile-empty-hint">Buscando actualizaciones...</p>';
    checkForUpdate().then(function(result) {
      if (result.hasUpdate) renderUpdateAvailable(result); else renderUpToDate();
    })["catch"](function(err) {
      renderError("No se pudo comprobar si hay actualizaciones. Revisa tu conexión e intenta de nuevo.");
    });
  }
  var btnUpdateMenuEl = $("btnProfileMenuUpdate");
  if (btnUpdateMenuEl) {
    btnUpdateMenuEl.hidden = !isNative();
    btnUpdateMenuEl.addEventListener("click", function() {
      if (typeof closeProfileMenu === "function") closeProfileMenu();
      openUpdateModal();
    });
  }
  var closeBtnEl = $("updateModalClose");
  if (closeBtnEl) closeBtnEl.addEventListener("click", function() {
    $("updateModalBackdrop").classList.remove("open");
  });
  var backdropEl = $("updateModalBackdrop");
  if (backdropEl) backdropEl.addEventListener("click", function(e) {
    if (e.target === backdropEl) backdropEl.classList.remove("open");
  });
  var btnUpdateRequiredOpenEl = $("btnUpdateRequiredOpen");
  if (btnUpdateRequiredOpenEl) btnUpdateRequiredOpenEl.addEventListener("click", openUpdateModal);
  if (isNative()) {
    window.addEventListener("load", function() {
      setTimeout(function() {
        checkForUpdate().then(function(result) {
          if (result.hasUpdate && result.remote.is_required) {
            $("updateRequiredText").textContent = "Hay una actualización obligatoria disponible (v" + result.remote.version_name + ").";
            $("updateRequiredBanner").hidden = false;
          }
        })["catch"](function() {});
      }, 3e3);
    });
  }
})();