"use strict";

var CIRCLES = [];

var currentCircle = null;

var myCircleIds = {};

var circleSelectMode = false;

var circleSelectCommunityId = null;

var circleSelectIds = {};

var CIRCLE_CATEGORIES = [ {
  id: "mascotas",
  label: "Mascotas",
  icon: "🐾"
}, {
  id: "juegos",
  label: "Videojuegos",
  icon: "🎮"
}, {
  id: "charlas",
  label: "Charlas",
  icon: "💬"
}, {
  id: "arte",
  label: "Arte y estética",
  icon: "🎨"
}, {
  id: "deportes",
  label: "Deportes",
  icon: "⚽"
}, {
  id: "anime",
  label: "Anime y manga",
  icon: "🌸"
}, {
  id: "estilo",
  label: "Estilo de vida",
  icon: "🌿"
}, {
  id: "hobbies",
  label: "Hobbies",
  icon: "🧩"
} ];

var CIRCLE_CATEGORY_MAP = CIRCLE_CATEGORIES.reduce(function(m, c) {
  m[c.id] = c;
  return m;
}, {});

function circleCategoryOptionsHtml(selected) {
  return '<option value="">Sin categoría</option>' + CIRCLE_CATEGORIES.map(function(cat) {
    return '<option value="' + cat.id + '"' + (selected === cat.id ? " selected" : "") + ">" + cat.icon + " " + escapeHtml(cat.label) + "</option>";
  }).join("");
}

if ($("circleCreateCategory")) $("circleCreateCategory").innerHTML = circleCategoryOptionsHtml(null);

var circleCategoryFilter = null;

var circleSortMode = "recomendado";

var circleSearchQuery = "";

function loadCircles() {
  if (!currentUser) return Promise.resolve();
  return Promise.all([ supabase.from("circles").select("*").order("created_at", {
    ascending: false
  }), supabase.from("circle_members").select("circle_id").eq("user_id", currentUser.id) ]).then(function(results) {
    var cRes = results[0], mRes = results[1];
    CIRCLES = cRes.error ? [] : cRes.data || [];
    myCircleIds = {};
    (mRes.data || []).forEach(function(r) {
      myCircleIds[r.circle_id] = true;
    });
    renderCircleCategoryGrid();
    renderCircleSortTabs();
    renderCircleGrid();
    if (typeof renderExploreCircles === "function") renderExploreCircles();
  });
}

function renderCircleCategoryGrid() {
  var wrap = $("circleCategoryGrid");
  if (!wrap) return;
  var allBtn = '<button type="button" class="circle-category-item' + (circleCategoryFilter === null ? " active" : "") + '" data-cat="">' + '<span class="circle-category-icon">✺</span><span class="circle-category-label">Todas</span></button>';
  wrap.innerHTML = allBtn + CIRCLE_CATEGORIES.map(function(cat) {
    return '<button type="button" class="circle-category-item' + (circleCategoryFilter === cat.id ? " active" : "") + '" data-cat="' + cat.id + '">' + '<span class="circle-category-icon">' + cat.icon + '</span><span class="circle-category-label">' + escapeHtml(cat.label) + "</span></button>";
  }).join("");
  qsa(".circle-category-item", wrap).forEach(function(btn) {
    btn.addEventListener("click", function() {
      circleCategoryFilter = btn.getAttribute("data-cat") || null;
      renderCircleCategoryGrid();
      renderCircleGrid();
    });
  });
}

var CIRCLE_SORT_TABS = [ {
  id: "recomendado",
  label: "Recomendado"
}, {
  id: "popular",
  label: "Popular"
}, {
  id: "reciente",
  label: "Reciente"
} ];

function renderCircleSortTabs() {
  var wrap = $("circleSortTabs");
  if (!wrap) return;
  wrap.innerHTML = CIRCLE_SORT_TABS.map(function(t) {
    return '<button type="button" class="tab' + (circleSortMode === t.id ? " active" : "") + '" data-sort="' + t.id + '">' + t.label + "</button>";
  }).join("");
  qsa(".tab", wrap).forEach(function(btn) {
    btn.addEventListener("click", function() {
      circleSortMode = btn.getAttribute("data-sort");
      renderCircleSortTabs();
      renderCircleGrid();
    });
  });
}

$("circleSearchInput").addEventListener("input", function() {
  circleSearchQuery = this.value.trim().toLowerCase();
  renderCircleGrid();
});

function renderCircleGrid() {
  var grid = $("circleGrid");
  if (!grid) return;
  var list = CIRCLES.slice();
  if (circleCategoryFilter) list = list.filter(function(c) {
    return c.category === circleCategoryFilter;
  });
  if (circleSearchQuery) list = list.filter(function(c) {
    return (c.name || "").toLowerCase().indexOf(circleSearchQuery) !== -1;
  });
  if (circleSortMode === "reciente") {
    list.sort(function(a, b) {
      return new Date(b.created_at) - new Date(a.created_at);
    });
  } else if (circleSortMode === "recomendado") {
    list.sort(function(a, b) {
      var aMine = myCircleIds[a.id] ? 1 : 0, bMine = myCircleIds[b.id] ? 1 : 0;
      if (aMine !== bMine) return aMine - bMine;
      return (b.member_count || 0) - (a.member_count || 0);
    });
  } else {
    list.sort(function(a, b) {
      return (b.member_count || 0) - (a.member_count || 0);
    });
  }
  $("circleEmptyState").hidden = list.length > 0;
  grid.innerHTML = list.map(function(c) {
    var catInfo = CIRCLE_CATEGORY_MAP[c.category];
    var iconStyle = c.icon_url ? ' style="background-image:url(&quot;' + encodeURI(c.icon_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
    var fallback = c.icon_url ? "" : catInfo ? catInfo.icon : "🚩";
    var mine = !!myCircleIds[c.id];
    var checked = circleSelectMode && !!circleSelectIds[c.id];
    var tags = [];
    if (catInfo) tags.push(catInfo.icon + " " + catInfo.label);
    if (Array.isArray(c.tags)) c.tags.forEach(function(t) {
      if (t) tags.push(String(t));
    });
    var tagsHtml = tags.length ? '<div class="circle-row-tags">' + tags.slice(0, 4).map(function(t) {
      return '<span class="circle-row-tag">' + escapeHtml(t) + "</span>";
    }).join("") + "</div>" : "";
    return '<div class="circle-row' + (checked ? " circle-row-checked" : "") + '" data-slug="' + escapeHtml(c.slug) + '" data-id="' + escapeHtml(c.id) + '">' + (circleSelectMode ? '<div class="circle-row-check">' + (checked ? "✓" : "") + "</div>" : "") + '<div class="circle-row-thumb"' + iconStyle + ">" + fallback + "</div>" + '<div class="circle-row-main">' + '<div class="circle-row-top"><div class="circle-row-name">' + escapeHtml(c.name) + "</div>" + (mine ? '<span class="circle-row-mine">✓ tuyo</span>' : "") + "</div>" + '<span class="circle-row-id">@' + escapeHtml(c.slug) + "</span>" + '<div class="circle-row-meta"><span>' + (c.member_count || 0) + " miembros</span><i></i><span>" + circleLanguageLabel(c.language) + "</span></div>" + tagsHtml + (c.description ? '<div class="circle-row-desc">' + escapeHtml(c.description) + "</div>" : "") + "</div>" + "</div>";
  }).join("");
  qsa(".circle-row", grid).forEach(function(card) {
    card.addEventListener("click", function() {
      if (circleSelectMode) {
        var id = card.getAttribute("data-id");
        var selectedCount = Object.keys(circleSelectIds).length;
        if (circleSelectIds[id]) {
          delete circleSelectIds[id];
        } else if (selectedCount >= 5) {
          toast("Máximo 5 círculos por comunidad.");
          return;
        } else {
          circleSelectIds[id] = true;
        }
        renderCircleGrid();
        updateCircleSelectBar();
        return;
      }
      openCircle(card.getAttribute("data-slug"));
    });
  });
}

function showCirclesList() {
  minimizeActiveContexts();
  exitAllImmersive();
  activatePanel("panel-circles");
  renderCircleGrid();
  loadCircles();
  if (!state.suppressPush && location.pathname !== "/circulos") {
    history.pushState({
      view: "circles"
    }, "", "/circulos");
  }
  state.suppressPush = false;
}

function updateCircleSelectBar() {
  var count = Object.keys(circleSelectIds).length;
  $("circleSelectCount").textContent = count + " / 5 círculos elegidos";
}

function openCircleSelectionMode(communityId, preselectedIds) {
  circleSelectMode = true;
  circleSelectCommunityId = communityId;
  circleSelectIds = {};
  (preselectedIds || []).forEach(function(id) {
    circleSelectIds[id] = true;
  });
  $("circleSelectBar").hidden = false;
  activatePanel("panel-circles");
  if (!CIRCLES.length) loadCircles(); else renderCircleGrid();
  updateCircleSelectBar();
}

function exitCircleSelectionMode() {
  circleSelectMode = false;
  circleSelectCommunityId = null;
  circleSelectIds = {};
  $("circleSelectBar").hidden = true;
}

window.exitCircleSelectionMode = exitCircleSelectionMode;

var btnConfirmCircleAffiliationEl = $("btnConfirmCircleAffiliation");

if (btnConfirmCircleAffiliationEl) btnConfirmCircleAffiliationEl.addEventListener("click", function() {
  var communityId = circleSelectCommunityId;
  var chosenIds = Object.keys(circleSelectIds);
  btnConfirmCircleAffiliationEl.disabled = true;
  supabase.from("community_circles").select("circle_id").eq("community_id", communityId).then(function(res) {
    var current = (res.data || []).map(function(r) {
      return r.circle_id;
    });
    var toRemove = current.filter(function(id) {
      return chosenIds.indexOf(id) === -1;
    });
    var toAdd = chosenIds.filter(function(id) {
      return current.indexOf(id) === -1;
    });
    var ops = [];
    if (toRemove.length) ops.push(supabase.from("community_circles").delete().eq("community_id", communityId).in("circle_id", toRemove));
    if (toAdd.length) ops.push(supabase.from("community_circles").insert(toAdd.map(function(id) {
      return {
        community_id: communityId,
        circle_id: id
      };
    })));
    return Promise.all(ops);
  }).then(function(results) {
    btnConfirmCircleAffiliationEl.disabled = false;
    var failed = (results || []).find(function(r) {
      return r && r.error;
    });
    if (failed) {
      toast("No se pudo guardar: " + failed.error.message);
      return;
    }
    toast("Círculos afiliados actualizados.");
    exitCircleSelectionMode();
    goBack("panel-community-detail");
    if (typeof refreshCommunityAffiliateCircles === "function") refreshCommunityAffiliateCircles(communityId);
  });
});

$("btnCirclesBack").addEventListener("click", function() {
  if (circleSelectMode) exitCircleSelectionMode();
  goBack("panel-list");
});

$("circleCreateClose").addEventListener("click", function() {
  $("circleCreateBackdrop").classList.remove("open");
  $("circleCreateForm").reset();
});

$("btnPickCircleBanner").addEventListener("click", function() {
  openBackgroundPicker("circleCreateBanner");
});

$("pollCreateClose").addEventListener("click", function() {
  $("pollCreateBackdrop").classList.remove("open");
});

$("pollCreateBackdrop").addEventListener("click", function(e) {
  if (e.target === this) $("pollCreateBackdrop").classList.remove("open");
});

$("pollCreateForm").addEventListener("submit", function(e) {
  e.preventDefault();
  if (!currentUser || !currentCommunity) return;
  var question = $("pollQuestion").value.trim();
  var options = qsa(".poll-option-input").map(function(i) {
    return i.value.trim();
  }).filter(function(v) {
    return v;
  });
  if (!question || options.length < 2) {
    toast("Escribe la pregunta y al menos 2 opciones.");
    return;
  }
  submitCommunityPoll(question, options);
});

$("circleCreateBackdrop").addEventListener("click", function(e) {
  if (e.target === this) {
    $("circleCreateBackdrop").classList.remove("open");
    $("circleCreateForm").reset();
  }
});

$("circleCreateForm").addEventListener("submit", function(e) {
  e.preventDefault();
  if (!currentUser) return;
  var name = $("circleCreateName").value.trim();
  if (!name) return;
  var iconFile = $("circleCreateIcon").files[0];
  var bannerFile = $("circleCreateBanner").files[0];
  var info = $("circleCreateInfo").value.trim();
  var category = $("circleCreateCategory") ? $("circleCreateCategory").value || null : null;
  var btn = $("circleCreateForm").querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Creando...";
  var uploadIcon = iconFile ? uploadFiles([ iconFile ], "circles/" + currentUser.id) : Promise.resolve([]);
  var uploadBanner = bannerFile ? uploadFiles([ bannerFile ], "circles/" + currentUser.id) : Promise.resolve([]);
  Promise.all([ uploadIcon, uploadBanner ]).then(function(results) {
    var iconUrl = results[0][0] ? results[0][0].url : null;
    var bannerUrl = results[1][0] ? results[1][0].url : null;
    var slug = slugify(name);
    return supabase.from("circles").insert({
      slug: slug,
      name: name,
      icon_url: iconUrl,
      banner_url: bannerUrl,
      description: info || null,
      category: category,
      created_by: currentUser.id
    }).select().single().then(function(res) {
      btn.disabled = false;
      btn.textContent = "Crear círculo";
      if (res.error) {
        toast("No se pudo crear el círculo: " + res.error.message);
        return;
      }
      var flagTexts = typeof flagFieldGet === "function" ? flagFieldGet("circleCreateFlag") : [];
      if (flagTexts.length && typeof tagEntityWithFlags === "function") tagEntityWithFlags(flagTexts, "circle", res.data.id);
      if (typeof flagFieldSet === "function") flagFieldSet("circleCreateFlag", []);
      return supabase.from("circle_members").insert({
        circle_id: res.data.id,
        user_id: currentUser.id,
        role: "admin"
      }).then(function() {
        myCircleIds[res.data.id] = true;
        $("circleCreateBackdrop").classList.remove("open");
        $("circleCreateForm").reset();
        toast('Círculo "' + name + '" creado.');
        awardAchievement(currentUser.id, "own_circle");
        openCircle(slug);
      });
    });
  }).catch(function() {
    btn.disabled = false;
    btn.textContent = "Crear círculo";
    toast("No se pudo subir las imágenes.");
  });
});

var circleMembers = [];

var circleActiveTab = "explore";

var CIRCLE_THEMES = [ {
  id: "ember",
  label: "Ámbar",
  color: "#a855f7"
}, {
  id: "teal",
  label: "Verdeazul",
  color: "#2dd4bf"
}, {
  id: "rose",
  label: "Rosa",
  color: "#fb7185"
}, {
  id: "sky",
  label: "Cielo",
  color: "#38bdf8"
}, {
  id: "gold",
  label: "Dorado",
  color: "#eab308"
} ];

function circleThemeColor(id) {
  var t = CIRCLE_THEMES.filter(function(x) {
    return x.id === id;
  })[0];
  return t ? t.color : CIRCLE_THEMES[0].color;
}

function myCircleRole() {
  if (!currentUser || !currentCircle) return null;
  if (currentCircle.created_by === currentUser.id) return "admin";
  if ((currentCircle.co_admin_ids || []).indexOf(currentUser.id) !== -1) return "co_admin";
  var isMember = circleMembers.some(function(m) {
    return m.id === currentUser.id;
  });
  return isMember ? "member" : null;
}

function openCircle(slug) {
  supabase.from("circles").select("*").eq("slug", slug).single().then(function(res) {
    if (res.error || !res.data) {
      toast("No se encontró ese círculo.");
      resetToFeedOnMissingRoute("/circulos/");
      return;
    }
    currentCircle = res.data;
    circleActiveTab = "explore";
    supabase.from("circle_members").select("role, joined_at, profiles(id, username, avatar_url, name_color, role, verified)").eq("circle_id", currentCircle.id).order("joined_at", {
      ascending: true
    }).then(function(mRes) {
      circleMembers = (mRes.data || []).filter(function(r) {
        return r.profiles;
      }).map(function(r) {
        var p = r.profiles;
        return {
          id: p.id,
          username: p.username,
          avatar_url: p.avatar_url,
          name_color: p.name_color,
          role: p.role,
          verified: p.verified,
          circleRole: r.role,
          joined_at: r.joined_at
        };
      });
      renderCircleDetail();
      enterImmersive("circle");
      activatePanel("panel-circle-detail");
      if (!state.suppressPush) history.pushState({
        view: "circle",
        slug: slug
      }, "", "/circulos/" + encodeURIComponent(slug));
      state.suppressPush = false;
    });
  }).catch(function(err) {
    console.error("[openCircle] fallo consultando el círculo:", err);
    toast("No se encontró ese círculo.");
    resetToFeedOnMissingRoute("/circulos/");
  });
}

function closeCircle() {
  currentCircle = null;
  exitImmersive("circle");
  goBack("panel-circles");
  loadCircles();
}

function circleLanguageLabel(lang) {
  var map = {
    es: "Español",
    en: "English",
    pt: "Português",
    fr: "Français"
  };
  return map[lang] || "Español";
}

function renderCircleDetail() {
  var c = currentCircle;
  var members = circleMembers;
  var role = myCircleRole();
  var mine = !!role;
  var isStaff = role === "admin" || role === "co_admin";
  var notifyOn = currentUser && (currentUser.notifyCircleIds || []).indexOf(c.id) !== -1;
  var bannerStyle = c.banner_url ? ' style="background-image:url(&quot;' + encodeURI(c.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
  var iconStyle = c.icon_url ? ' style="background-image:url(&quot;' + encodeURI(c.icon_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
  var shellStyle = c.background_url ? ' style="background-image:linear-gradient(rgba(7,6,10,.78), rgba(7,6,10,.92)), url(&quot;' + encodeURI(c.background_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
  var memberStackHtml = members.slice(0, 5).map(function(m) {
    return avatarSpanHtml(m.username, m.avatar_url, "circle-stack-avatar", m.id);
  }).join("");
  var actionsHtml = '<button class="icon-btn circle-bell-btn' + (notifyOn ? " active" : "") + '" id="btnCircleNotify" type="button" aria-label="Notificaciones">' + '<svg viewBox="0 0 24 24" fill="' + (notifyOn ? "currentColor" : "none") + '" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>' + "</button>";
  if (isStaff) {
    actionsHtml += '<button class="icon-btn" id="btnCircleSettings" type="button" aria-label="Ajustes del círculo">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>' + "</button>";
  }
  var customTabs = Array.isArray(c.custom_tabs) ? c.custom_tabs : [];
  if (circleActiveTab === "posts") circleActiveTab = "explore";
  function cssUrl(u) {
    return 'url(&quot;' + encodeURI(u).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)';
  }
  function tabBtnHtml(id, label, color) {
    return '<button class="circle-v2-tab' + (circleActiveTab === id ? " active" : "") + '" data-circletab="' + escapeHtml(id) + '" type="button"' + (color ? ' style="--tab-color:' + color + '"' : "") + ">" + escapeHtml(label) + "</button>";
  }
  var tabsHtml = tabBtnHtml("info", "Información") + tabBtnHtml("explore", "Explorar") + tabBtnHtml("comunidades", "Comunidades") + customTabs.map(function(t) {
    return tabBtnHtml(t.id, t.name, circleThemeColor(t.theme));
  }).join("");
  var heroBgUrl = c.banner_url || c.background_url || c.icon_url || "";
  var heroBgStyle = heroBgUrl ? ' style="background-image:' + cssUrl(heroBgUrl) + '"' : "";
  var stackHtml = members.slice(0, 4).map(function(m) {
    return avatarSpanHtml(m.username, m.avatar_url, "circle-stack-avatar", m.id);
  }).join("") + (members.length > 4 ? '<span class="avatar circle-stack-more">…</span>' : "");
  var html = '<div class="community-shell circle-shell circle-v2" id="circleShell"' + shellStyle + ">" + '<div class="circle-v2-topbar">' + '<button class="icon-btn circle-v2-back" id="btnCircleBack" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + '<div class="circle-v2-topbar-title">' + escapeHtml(c.name) + "</div>" + '<div class="circle-v2-actions">' + actionsHtml + "</div>" + "</div>" + '<div class="circle-v2-scroll" id="circleScroll">' + '<div class="circle-v2-hero">' + '<div class="circle-v2-hero-bg"' + heroBgStyle + "></div>" + '<div class="circle-v2-main">' + '<div class="circle-v2-icon"' + iconStyle + ">" + (c.icon_url ? "" : "🚩") + "</div>" + '<div class="circle-v2-info">' + "<h3>" + escapeHtml(c.name) + "</h3>" + '<div class="circle-v2-sub">' + members.length + " miembros<i></i>" + circleLanguageLabel(c.language) + "</div>" + '<div class="circle-v2-stack">' + stackHtml + "</div>" + "</div>" + "</div>" + (c.description ? '<p class="circle-v2-desc">' + escapeHtml(c.description) + "</p>" : "") + "</div>" + '<div class="circle-v2-tabs" id="circleTabs">' + tabsHtml + "</div>" + '<div class="circle-main" id="circleTabContent"></div>' + "</div>" + (mine ? "" : '<div class="community-join-bar"><span>Únete para hacer publicaciones y participar en este círculo.</span>' + '<button class="terminal-btn" id="btnCircleJoinBar" type="button">Unirme</button>' + "</div>") + "</div>";
  $("circleDetail").innerHTML = html;
  $("btnCircleBack").addEventListener("click", closeCircle);
  var notifyBtn = $("btnCircleNotify");
  if (notifyBtn) notifyBtn.addEventListener("click", toggleCircleNotify);
  var settingsBtn = $("btnCircleSettings");
  if (settingsBtn) settingsBtn.addEventListener("click", openCircleSettings);
  var joinBarBtn = $("btnCircleJoinBar");
  if (joinBarBtn) joinBarBtn.addEventListener("click", toggleCircleMembership);
  qsa(".circle-stack-avatar", $("circleDetail")).forEach(function(av) {
    av.addEventListener("click", function() {
      openProfile(av.getAttribute("data-uid"));
    });
  });
  var scrollEl = $("circleScroll"), shellEl = $("circleShell");
  scrollEl.addEventListener("scroll", function() {
    shellEl.classList.toggle("scrolled", scrollEl.scrollTop > 90);
  });
  qsa(".circle-v2-tab", $("circleTabs")).forEach(function(tabBtn) {
    tabBtn.addEventListener("click", function() {
      circleActiveTab = tabBtn.getAttribute("data-circletab");
      qsa(".circle-v2-tab", $("circleTabs")).forEach(function(b) {
        b.classList.toggle("active", b === tabBtn);
      });
      renderCircleTabContent();
    });
  });
  renderCircleTabContent();
}

function toggleCircleMembership() {
  if (!currentUser || !currentCircle) return;
  var c = currentCircle;
  var mine = circleMembers.some(function(m) {
    return m.id === currentUser.id;
  });
  var action = mine ? supabase.from("circle_members").delete().eq("circle_id", c.id).eq("user_id", currentUser.id) : supabase.from("circle_members").insert({
    circle_id: c.id,
    user_id: currentUser.id,
    role: "member"
  });
  action.then(function(res) {
    if (res.error) {
      toast("No se pudo actualizar: " + res.error.message);
      return;
    }
    if (mine) {
      delete myCircleIds[c.id];
    } else {
      myCircleIds[c.id] = true;
    }
    toast(mine ? 'Saliste de "' + c.name + '".' : 'Ahora eres parte de "' + c.name + '".');
    openCircle(c.slug);
  });
}

function toggleCircleNotify() {
  if (!currentUser || !currentCircle) return;
  var ids = (currentUser.notifyCircleIds || []).slice();
  var idx = ids.indexOf(currentCircle.id);
  var turningOn = idx === -1;
  if (turningOn) ids.push(currentCircle.id); else ids.splice(idx, 1);
  supabase.from("profiles").update({
    notify_circle_ids: ids
  }).eq("id", currentUser.id).then(function(res) {
    if (res.error) {
      toast("No se pudo actualizar: " + res.error.message);
      return;
    }
    currentUser.notifyCircleIds = ids;
    toast(turningOn ? "Te avisaremos de la actividad de este círculo." : "Ya no te avisaremos de este círculo.");
    renderCircleDetail();
  });
}

function shareCircle() {
  var c = currentCircle;
  if (!c) return;
  var url = siteOrigin() + "/circulos/" + encodeURIComponent(c.slug);
  if (navigator.share) {
    navigator.share({
      title: c.name,
      url: url
    }).catch(function() {});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(url).then(function() {
      toast("Enlace copiado al portapapeles.");
    });
  } else {
    toast(url);
  }
}

function renderCircleInfoTab(wrap) {
  var c = currentCircle;
  var role = myCircleRole();
  var catInfo = CIRCLE_CATEGORY_MAP[c.category];
  var coIds = c.co_admin_ids || [];
  var team = circleMembers.filter(function(m) {
    return m.id === c.created_by || coIds.indexOf(m.id) !== -1;
  });
  var teamHtml = team.length ? '<div class="circle-info-card"><h4>Equipo</h4>' + team.map(function(m) {
    var isOwner = m.id === c.created_by;
    return '<div class="community-member-row circle-info-member" data-uid="' + escapeHtml(m.id) + '">' + avatarSpanHtml(m.username, m.avatar_url, null, m.id) + '<div class="community-member-name">@' + escapeHtml(m.username) + '</div><span class="role-tag ' + (isOwner ? "admin" : "co_admin") + '">' + (isOwner ? "Creador" : "Co-admin") + "</span></div>";
  }).join("") + "</div>" : "";
  wrap.innerHTML = '<div class="circle-info-card">' + "<h4>Sobre este círculo</h4>" + '<p class="circle-info-desc">' + (c.description ? escapeHtml(c.description) : "Este círculo todavía no tiene una descripción.") + "</p>" + "</div>" + '<div class="circle-info-card">' + '<div class="circle-info-stats">' + '<div class="circle-info-stat"><span>ID</span><b>@' + escapeHtml(c.slug) + "</b></div>" + '<div class="circle-info-stat"><span>Miembros</span><b>' + circleMembers.length + "</b></div>" + '<div class="circle-info-stat"><span>Idioma</span><b>' + circleLanguageLabel(c.language) + "</b></div>" + '<div class="circle-info-stat"><span>Categoría</span><b>' + (catInfo ? catInfo.icon + " " + escapeHtml(catInfo.label) : "Sin categoría") + "</b></div>" + '<div class="circle-info-stat"><span>Creado</span><b>' + timeAgo(c.created_at) + "</b></div>" + "</div>" + "</div>" + teamHtml + '<div class="circle-info-actions">' + '<button class="link-btn" id="btnCircleShare" type="button">Compartir círculo</button>' + (role ? '<button class="link-btn danger" id="btnCircleLeave" type="button">Salir de este círculo</button>' : "") + "</div>";
  $("btnCircleShare").addEventListener("click", shareCircle);
  var leaveBtn = $("btnCircleLeave");
  if (leaveBtn) leaveBtn.addEventListener("click", function() {
    if (confirm('¿Salir de "' + c.name + '"?')) toggleCircleMembership();
  });
  qsa(".circle-info-member", wrap).forEach(function(row) {
    row.addEventListener("click", function() {
      openProfile(row.getAttribute("data-uid"));
    });
  });
}

function normalizeWebUrl(url) {
  url = String(url || "").trim();
  if (!url) return "";
  if (/^(javascript|data|vbscript|file|blob):/i.test(url)) return "";
  if (/^\/\//.test(url)) url = "https:" + url;
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  return url.replace(/^http:\/\//i, "https://");
}

function toEmbeddableUrl(url) {
  var m;
  url = normalizeWebUrl(url);
  m = url.match(/youtube\.com\/playlist\?(?:[^#]*&)?list=([a-zA-Z0-9_-]+)/);
  if (m) return "https://www.youtube.com/embed/videoseries?list=" + m[1];
  m = url.match(/(?:youtube(?:-nocookie)?\.com\/(?:watch\?(?:[^#]*&)?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([a-zA-Z0-9_-]{6,})/);
  if (m) return "https://www.youtube.com/embed/" + m[1];
  m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (m) return "https://player.vimeo.com/video/" + m[1];
  m = url.match(/dailymotion\.com\/video\/([a-zA-Z0-9]+)/);
  if (m) return "https://www.dailymotion.com/embed/video/" + m[1];
  m = url.match(/open\.spotify\.com\/(?:intl-[a-z]+\/)?(track|album|playlist|episode|show|artist)\/([a-zA-Z0-9]+)/);
  if (m) return "https://open.spotify.com/embed/" + m[1] + "/" + m[2];
  m = url.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (m) return "https://drive.google.com/file/d/" + m[1] + "/preview";
  m = url.match(/^https?:\/\/(?:www\.)?twitch\.tv\/([a-zA-Z0-9_]+)\/?$/);
  if (m) return "https://player.twitch.tv/?channel=" + m[1] + "&parent=" + location.hostname;
  return url;
}

function renderCircleTabContent() {
  var wrap = $("circleTabContent");
  if (!wrap) return;
  var c = currentCircle;
  if (circleActiveTab === "info") {
    renderCircleInfoTab(wrap);
    return;
  }
  if (circleActiveTab === "comunidades") {
    var tabCircleId = c.id;
    wrap.innerHTML = '<p class="empty-state">Cargando comunidades…</p>';
    supabase.from("community_circles").select("community_id").eq("circle_id", tabCircleId).then(function(res) {
      if (circleActiveTab !== "comunidades" || !currentCircle || currentCircle.id !== tabCircleId) return;
      var ids = {};
      (res && res.data || []).forEach(function(r) { ids[r.community_id] = true; });
      COMMUNITIES.forEach(function(comm) { if (comm.circle_id === tabCircleId) ids[comm.id] = true; });
      var known = {};
      COMMUNITIES.forEach(function(comm) { known[comm.id] = comm; });
      var missing = Object.keys(ids).filter(function(id) { return !known[id]; });
      var extra = missing.length ? supabase.from("communities").select("*").in("id", missing) : Promise.resolve({ data: [] });
      return Promise.resolve(extra).then(function(er) {
        if (circleActiveTab !== "comunidades" || !currentCircle || currentCircle.id !== tabCircleId) return;
        (er && er.data || []).forEach(function(comm) { known[comm.id] = comm; });
        var affiliated = Object.keys(ids).map(function(id) { return known[id]; }).filter(Boolean);
        if (!affiliated.length) {
          wrap.innerHTML = '<p class="empty-state">Todavía ninguna comunidad está afiliada a este círculo.</p>';
          return;
        }
        wrap.innerHTML = '<div class="community-grid" style="padding:1rem;">' + affiliated.map(function(comm) {
          var bannerStyle = comm.banner_url ? ' style="background-image:url(&quot;' + encodeURI(comm.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
          var fallback = comm.banner_url ? "" : '<span class="community-card-fallback">' + escapeHtml((comm.name || "?").charAt(0).toUpperCase()) + "</span>";
          return '<div class="community-card" data-slug="' + escapeHtml(comm.slug) + '"><div class="community-card-banner"' + bannerStyle + ">" + fallback + '</div><div class="community-card-body"><div class="community-card-name">' + escapeHtml(comm.name) + "</div></div></div>";
        }).join("") + "</div>";
        qsa(".community-card", wrap).forEach(function(card) {
          card.addEventListener("click", function() {
            closeCircle();
            openCommunity(card.getAttribute("data-slug"));
          });
        });
      });
    });
    return;
  }
  var customTabs = Array.isArray(c.custom_tabs) ? c.custom_tabs : [];
  var customTab = customTabs.filter(function(t) {
    return t.id === circleActiveTab;
  })[0];
  if (customTab) {
    if (customTab.url) {
      var safeTabUrl = normalizeWebUrl(customTab.url);
      var embedUrl = toEmbeddableUrl(customTab.url);
      if (!safeTabUrl) {
        wrap.innerHTML = '<p class="empty-state">La dirección de esta pestaña no es válida. Edítala en los ajustes del círculo.</p>';
        return;
      }
      wrap.innerHTML = '<div class="circle-custom-embed-wrap">' + '<div class="circle-custom-embed-notice">Algunos sitios no permiten mostrarse dentro de otras apps por seguridad. Si ves un bloqueo, usa este botón. <a href="' + escapeHtml(safeTabUrl) + '" target="_blank" rel="noopener noreferrer">Abrir en pestaña nueva ↗</a></div>' + '<iframe class="circle-custom-iframe" src="' + escapeHtml(embedUrl) + '" title="' + escapeHtml(customTab.name) + '" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-presentation allow-modals" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>' + "</div>";
    } else {
      wrap.innerHTML = '<div class="circle-custom-placeholder" style="border-color:' + circleThemeColor(customTab.theme) + '55;">' + '<div class="circle-custom-placeholder-dot" style="background:' + circleThemeColor(customTab.theme) + ';"></div>' + '<p>Esta es la pestaña "' + escapeHtml(customTab.name) + '". Agrégale una URL en los ajustes del círculo para mostrar contenido aquí.</p>' + "</div>";
    }
    return;
  }
  var posts = z3tCircleThreads(c.id).sort(function(a, b) {
    return new Date(b.time) - new Date(a.time);
  });
  var postsHtml = posts.length ? posts.map(function(t) {
    return '<article class="thread-card" data-id="' + escapeHtml(t.id) + '">' + avatarSpanHtml(t.author, t.authorAvatar, null, t.authorId) + '<div class="thread-main">' + '<div class="thread-title">' + escapeHtml(t.title) + "</div>" + '<div class="thread-excerpt">' + escapeHtml(t.excerpt) + "</div>" + '<div class="thread-meta"><span><span class="user-link" data-uid="' + escapeHtml(t.authorId) + '">@' + escapeHtml(t.author) + "</span> · " + timeAgo(t.time) + "</span></div>" + "</div>" + "</article>";
  }).join("") : '<p class="empty-state">Todavía no hay publicaciones en este círculo.</p>';
  var pinnedHtml = c.announcement ? '<div class="circle-pinned"><span class="circle-pinned-icon">📌</span><span class="circle-pinned-text">' + escapeHtml(c.announcement) + "</span></div>" : "";
  var activeHtml = circleMembers.length ? '<h4 class="circle-section-title">Miembros</h4><div class="circle-active-strip">' + circleMembers.slice(0, 20).map(function(m) {
    return '<button type="button" class="circle-active-user" data-uid="' + escapeHtml(m.id) + '">' + avatarSpanHtml(m.username, m.avatar_url, null, null) + '<span class="n">' + escapeHtml(m.username) + "</span></button>";
  }).join("") + "</div>" : "";
  wrap.innerHTML = pinnedHtml + activeHtml + '<h4 class="circle-section-title">Publicaciones</h4>' + '<div class="thread-list" style="padding:0 1rem 1rem;">' + postsHtml + "</div>";
  qsa(".circle-active-user", wrap).forEach(function(b) {
    b.addEventListener("click", function() {
      openProfile(b.getAttribute("data-uid"));
    });
  });
  qsa(".thread-card", wrap).forEach(function(card) {
    card.addEventListener("click", function() {
      closeCircle();
      openThread(card.getAttribute("data-id"));
    });
  });
}

var pickedCircleIcon = null, pickedCircleBanner = null, pickedCircleBackground = null;

function openCircleSettings() {
  var settTitleEl = $("communitySettingsTitle");
  if (settTitleEl) settTitleEl.textContent = "Configurar círculo";
  var c = currentCircle;
  var isOwner = c.created_by === currentUser.id;
  pickedCircleIcon = pickedCircleBanner = pickedCircleBackground = null;
  var themeOptionsHtml = CIRCLE_THEMES.map(function(t) {
    return '<option value="' + t.id + '">' + t.label + "</option>";
  }).join("");
  var customTabs = Array.isArray(c.custom_tabs) ? c.custom_tabs : [];
  var tabsListHtml = customTabs.length ? customTabs.map(function(t) {
    return '<div class="circle-customtab-row" data-tabid="' + escapeHtml(t.id) + '">' + '<span class="circle-customtab-dot" style="background:' + circleThemeColor(t.theme) + ';"></span>' + '<span class="circle-customtab-name">' + escapeHtml(t.name) + (t.url ? " 🔗" : "") + "</span>" + '<button type="button" class="link-btn danger circle-customtab-del" data-tabid="' + escapeHtml(t.id) + '">Quitar</button>' + "</div>";
  }).join("") : '<p class="settings-hint">Todavía no agregas pestañas personalizadas.</p>';
  var html = '<div class="community-settings-section"><h4>Apariencia</h4>' + '<label class="field"><span>Nombre</span><input type="text" id="circleSettName" value="' + escapeHtml(c.name) + '" maxlength="60"></label>' + '<label class="field"><span>Descripción</span><textarea id="circleSettDesc" maxlength="300" rows="2">' + escapeHtml(c.description || "") + "</textarea></label>" + '<label class="field"><span>Anuncio (aparece debajo del encabezado)</span><input type="text" id="circleSettAnnouncement" maxlength="140" value="' + escapeHtml(c.announcement || "") + '"></label>' + '<label class="field"><span>Idioma</span><select id="circleSettLanguage">' + [ "es", "en", "pt", "fr" ].map(function(l) {
    return '<option value="' + l + '"' + (c.language === l ? " selected" : "") + ">" + circleLanguageLabel(l) + "</option>";
  }).join("") + "</select></label>" + '<label class="field"><span>Categoría</span><select id="circleSettCategory">' + circleCategoryOptionsHtml(c.category || null) + "</select></label>" + '<div class="image-setting-row"><span>Ícono del círculo</span>' + '<div class="image-setting-preview" id="circleSettIconPreview">' + (c.icon_url ? '<img loading=lazy decoding=async src="' + escapeHtml(c.icon_url) + '" alt="">' : '<span class="image-setting-empty">Sin foto</span>') + "</div>" + '<input type="file" id="circleSettIconFile" accept="image/*" hidden>' + '<button class="link-btn" id="btnPickCircleIcon" type="button">Cambiar ícono</button>' + "</div>" + '<div class="image-setting-row"><span>Banner (arriba)</span>' + '<div class="image-setting-preview" id="circleSettBannerPreview">' + (c.banner_url ? '<img loading=lazy decoding=async src="' + escapeHtml(c.banner_url) + '" alt="">' : '<span class="image-setting-empty">Sin foto</span>') + "</div>" + '<input type="file" id="circleSettBannerFile" accept="image/*" hidden>' + '<button class="link-btn" id="btnPickCircleBanner" type="button">Cambiar banner</button>' + "</div>" + '<div class="image-setting-row"><span>Fondo de pantalla (dentro del círculo)</span>' + '<div class="image-setting-preview" id="circleSettBackgroundPreview">' + (c.background_url ? '<img loading=lazy decoding=async src="' + escapeHtml(c.background_url) + '" alt="">' : '<span class="image-setting-empty">Sin foto</span>') + "</div>" + '<input type="file" id="circleSettBackgroundFile" accept="image/*" hidden>' + '<button class="link-btn" id="btnPickCircleBackground" type="button">Cambiar fondo</button>' + "</div>" + '<button class="terminal-btn full-width" id="btnSaveCircleSettings" type="button">Guardar cambios</button>' + "</div>" + '<div class="community-settings-section"><h4>Notificaciones y compartir</h4>' + '<div class="toggle-row"><span>Avisarme de la actividad de este círculo</span><input type="checkbox" id="circleSettNotify" ' + ((currentUser.notifyCircleIds || []).indexOf(c.id) !== -1 ? "checked" : "") + "></div>" + '<button class="link-btn" id="btnCircleSettShare" type="button">Compartir círculo</button>' + "</div>" + '<div class="community-settings-section"><h4>Pestañas personalizadas</h4>' + '<p class="settings-hint">Agrega una pestaña con su propio tema y, si quieres, una página web (URL) que se muestre adentro.</p>' + '<div id="circleCustomTabsList">' + tabsListHtml + "</div>" + '<label class="field"><span>Nombre de la pestaña</span><input type="text" id="circleNewTabName" maxlength="24" placeholder="Ej. Galería"></label>' + '<label class="field"><span>Tema</span><select id="circleNewTabTheme">' + themeOptionsHtml + "</select></label>" + '<label class="field"><span>URL (opcional)</span><input type="url" id="circleNewTabUrl" placeholder="https://..."></label>' + '<button class="terminal-btn full-width" id="btnAddCircleTab" type="button">Agregar pestaña</button>' + "</div>";
  if (isOwner) {
    html += '<div class="community-settings-section"><h4>Co-administradores</h4>' + '<p class="settings-hint">Elige quién más puede moderar y editar este círculo.</p>' + '<div id="circleSettCoAdminList"></div>' + "</div>";
    html += '<div class="community-settings-section"><h4>Zona peligrosa</h4>' + '<button class="link-btn danger" id="btnDeleteCircle" type="button">Eliminar círculo permanentemente</button>' + "</div>";
  }
  $("communitySettingsBody").innerHTML = html;
  $("btnSaveCircleSettings").addEventListener("click", saveCircleSettings);
  $("btnCircleSettShare").addEventListener("click", shareCircle);
  $("circleSettNotify").addEventListener("change", function() {
    toggleCircleNotify();
  });
  $("btnPickCircleIcon").addEventListener("click", function() {
    $("circleSettIconFile").click();
  });
  $("circleSettIconFile").addEventListener("change", function() {
    handleCircleSettingsImageChange(this, "icon", "circleSettIconPreview");
  });
  $("btnPickCircleBanner").addEventListener("click", function() {
    $("circleSettBannerFile").click();
  });
  $("circleSettBannerFile").addEventListener("change", function() {
    handleCircleSettingsImageChange(this, "banner", "circleSettBannerPreview");
  });
  $("btnPickCircleBackground").addEventListener("click", function() {
    $("circleSettBackgroundFile").click();
  });
  $("circleSettBackgroundFile").addEventListener("change", function() {
    handleCircleSettingsImageChange(this, "background", "circleSettBackgroundPreview");
  });
  $("btnAddCircleTab").addEventListener("click", addCircleCustomTab);
  qsa(".circle-customtab-del", $("communitySettingsBody")).forEach(function(btn) {
    btn.addEventListener("click", function() {
      removeCircleCustomTab(btn.getAttribute("data-tabid"));
    });
  });
  if (isOwner) renderCircleSettCoAdminList();
  var delBtn = $("btnDeleteCircle");
  if (delBtn) delBtn.addEventListener("click", function() {
    if (!confirm("¿Eliminar este círculo para siempre? Se les quitará la facción a todos sus miembros.")) return;
    supabase.from("circles").delete().eq("id", c.id).then(function(res) {
      if (res.error) {
        toast("No se pudo eliminar: " + res.error.message);
        return;
      }
      toast("Círculo eliminado.");
      $("communitySettingsBackdrop").classList.remove("open");
      closeCircle();
    });
  });
  $("communitySettingsBackdrop").classList.add("open");
}

function handleCircleSettingsImageChange(inputEl, kind, previewId) {
  var file = inputEl.files && inputEl.files[0];
  inputEl.value = "";
  if (!file || !currentCircle) return;
  var previewEl = $(previewId);
  if (previewEl) previewEl.innerHTML = '<span class="image-setting-empty">Subiendo...</span>';
  uploadFiles([ file ], "circles/" + currentCircle.id).then(function(results) {
    var url = results[0] ? results[0].url : null;
    if (!url) throw new Error("no-url");
    var patch = {};
    patch[kind === "icon" ? "icon_url" : kind === "banner" ? "banner_url" : "background_url"] = url;
    return supabase.from("circles").update(patch).eq("id", currentCircle.id);
  }).then(function(res) {
    if (res && res.error) {
      toast("No se pudo guardar: " + res.error.message);
      openCircleSettings();
      return;
    }
    return supabase.from("circles").select("*").eq("id", currentCircle.id).single();
  }).then(function(res) {
    if (res && res.data) currentCircle = res.data;
    toast("Imagen actualizada.");
    openCircleSettings();
    renderCircleDetail();
  }).catch(function() {
    toast("No se pudo subir la imagen.");
    openCircleSettings();
  });
}

function renderCircleSettCoAdminList() {
  var wrap = $("circleSettCoAdminList");
  if (!wrap) return;
  var c = currentCircle;
  var others = circleMembers.filter(function(m) {
    return m.id !== c.created_by;
  });
  if (!others.length) {
    wrap.innerHTML = '<p class="settings-hint">Todavía no hay más miembros en este círculo.</p>';
    return;
  }
  wrap.innerHTML = others.map(function(m) {
    var checked = (c.co_admin_ids || []).indexOf(m.id) !== -1;
    return '<label class="toggle-row"><span>' + escapeHtml(m.username) + '</span><input type="checkbox" data-uid="' + escapeHtml(m.id) + '" class="circle-coadmin-toggle" ' + (checked ? "checked" : "") + "></label>";
  }).join("");
  qsa(".circle-coadmin-toggle", wrap).forEach(function(cb) {
    cb.addEventListener("change", function() {
      var uid = cb.getAttribute("data-uid");
      var ids = (c.co_admin_ids || []).slice();
      var idx = ids.indexOf(uid);
      if (cb.checked && idx === -1) ids.push(uid);
      if (!cb.checked && idx !== -1) ids.splice(idx, 1);
      supabase.from("circles").update({
        co_admin_ids: ids
      }).eq("id", c.id).then(function(res) {
        if (res.error) {
          toast("No se pudo actualizar: " + res.error.message);
          cb.checked = !cb.checked;
          return;
        }
        c.co_admin_ids = ids;
        toast(cb.checked ? "Ahora es Co-Admin." : "Ya no es Co-Admin.");
      });
    });
  });
}

function saveCircleSettings() {
  var name = $("circleSettName").value.trim();
  if (name.length < 3) {
    toast("El nombre debe tener al menos 3 caracteres.");
    return;
  }
  var payload = {
    name: name,
    description: $("circleSettDesc").value.trim() || null,
    announcement: $("circleSettAnnouncement").value.trim() || null,
    language: $("circleSettLanguage").value,
    category: $("circleSettCategory") ? $("circleSettCategory").value || null : null
  };
  supabase.from("circles").update(payload).eq("id", currentCircle.id).then(function(res) {
    if (res.error) {
      toast("No se pudo guardar: " + res.error.message);
      return;
    }
    toast("Círculo actualizado.");
    $("communitySettingsBackdrop").classList.remove("open");
    openCircle(currentCircle.slug);
  });
}

function addCircleCustomTab() {
  var name = $("circleNewTabName").value.trim();
  if (!name) {
    toast("Ponle un nombre a la pestaña.");
    return;
  }
  var theme = $("circleNewTabTheme").value;
  var url = $("circleNewTabUrl").value.trim();
  if (url && !/^https?:\/\//i.test(url)) {
    toast("La URL debe empezar con http:// o https://");
    return;
  }
  var tabs = Array.isArray(currentCircle.custom_tabs) ? currentCircle.custom_tabs.slice() : [];
  tabs.push({
    id: "tab_" + Date.now().toString(36),
    name: name,
    theme: theme,
    url: url || null
  });
  supabase.from("circles").update({
    custom_tabs: tabs
  }).eq("id", currentCircle.id).then(function(res) {
    if (res.error) {
      toast("No se pudo agregar: " + res.error.message);
      return;
    }
    currentCircle.custom_tabs = tabs;
    toast("Pestaña agregada.");
    openCircleSettings();
  });
}

function removeCircleCustomTab(tabId) {
  if (!confirm("¿Quitar esta pestaña?")) return;
  var tabs = (currentCircle.custom_tabs || []).filter(function(t) {
    return t.id !== tabId;
  });
  supabase.from("circles").update({
    custom_tabs: tabs
  }).eq("id", currentCircle.id).then(function(res) {
    if (res.error) {
      toast("No se pudo quitar: " + res.error.message);
      return;
    }
    currentCircle.custom_tabs = tabs;
    if (circleActiveTab === tabId) circleActiveTab = "explore";
    toast("Pestaña eliminada.");
    openCircleSettings();
  });
}