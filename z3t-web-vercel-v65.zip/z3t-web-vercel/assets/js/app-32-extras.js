/* Z3T · utilidades compartidas: grabador de audio y fondo de comunidad en pantallas internas */
var z3tAudioRec = null;

function z3tToggleAudioRecording(btn, onFile) {
  if (z3tAudioRec && z3tAudioRec.state === "recording") {
    z3tAudioRec.stop();
    return;
  }
  if (!navigator.mediaDevices || !window.MediaRecorder) {
    toast("Tu navegador no permite grabar audio.");
    return;
  }
  navigator.mediaDevices.getUserMedia({ audio: true }).then(function(stream) {
    var mimes = [ "audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg" ];
    var chosen = "";
    for (var i = 0; i < mimes.length; i++) {
      if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(mimes[i])) { chosen = mimes[i]; break; }
    }
    var chunks = [];
    var rec;
    try { rec = chosen ? new MediaRecorder(stream, { mimeType: chosen }) : new MediaRecorder(stream); }
    catch (e) { stream.getTracks().forEach(function(t) { t.stop(); }); toast("Tu navegador no permite grabar audio."); return; }
    z3tAudioRec = rec;
    rec.addEventListener("dataavailable", function(e) { if (e.data.size > 0) chunks.push(e.data); });
    rec.addEventListener("stop", function() {
      stream.getTracks().forEach(function(t) { t.stop(); });
      if (btn) btn.classList.remove("recording");
      z3tAudioRec = null;
      var mime = rec.mimeType || chosen || "audio/webm";
      var blob = new Blob(chunks, { type: mime });
      if (blob.size < 500) { toast("La grabación fue muy corta."); return; }
      var ext = mime.indexOf("mp4") !== -1 ? "m4a" : mime.indexOf("ogg") !== -1 ? "ogg" : "webm";
      onFile(new File([ blob ], "audio-" + Date.now() + "." + ext, { type: mime }));
    });
    rec.start();
    if (btn) btn.classList.add("recording");
    toast("Grabando… toca de nuevo para enviar.");
  }).catch(function() {
    toast("No se pudo acceder al micrófono.");
  });
}

/* Fondo de la comunidad en una pantalla (panel) interna */
function z3tSetCommunityPanelBg(panelId, community) {
  var panel = document.getElementById(panelId);
  if (!panel) return;
  var url = community && community.background_url;
  if (url) {
    panel.style.setProperty("--comm-bg", 'url("' + encodeURI(url).replace(/"/g, "%22").replace(/'/g, "%27") + '")');
    panel.classList.add("has-comm-bg");
  } else {
    panel.style.removeProperty("--comm-bg");
    panel.classList.remove("has-comm-bg");
  }
}


/* Reproductor de audio Z3T: boton play/pausa + ondas (animadas mientras suena) */
var z3tCurrentAudio = null;
document.addEventListener("click", function(e) {
  var btn = e.target.closest && e.target.closest(".z3t-audio-btn");
  if (!btn) return;
  e.preventDefault();
  e.stopPropagation();
  var box = btn.closest(".z3t-audio");
  var au = box && box.querySelector("audio");
  if (!au) return;
  if (au.paused) {
    if (z3tCurrentAudio && z3tCurrentAudio !== au) z3tCurrentAudio.pause();
    z3tCurrentAudio = au;
    box.classList.add("loading");
    var pr = au.play();
    if (pr && pr.catch) pr.catch(function() {
      box.classList.remove("loading", "playing");
      toast("No se pudo reproducir el audio.");
    });
  } else {
    au.pause();
  }
}, true);
[ "playing", "pause", "ended", "waiting", "error" ].forEach(function(evt) {
  document.addEventListener(evt, function(e) {
    var au = e.target;
    if (!au || au.tagName !== "AUDIO") return;
    var box = au.closest && au.closest(".z3t-audio");
    if (!box) return;
    if (evt === "playing") { box.classList.remove("loading"); box.classList.add("playing"); }
    else if (evt === "waiting") box.classList.add("loading");
    else { box.classList.remove("loading", "playing"); if (evt === "ended") au.currentTime = 0; }
  }, true);
});
