(function() {
  "use strict";
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var isCoarsePointer = window.matchMedia("(pointer:coarse)").matches;
  var isSmallScreen = Math.min(window.innerWidth, window.innerHeight) < 560;
  var lowPower = isCoarsePointer || isSmallScreen || navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4;
  var items = [ "COMUNIDAD ACTIVA: 4.213 USUARIOS CONECTADOS", "NUEVOS CÍRCULOS CADA SEMANA", "CHATS DE VOZ EN VIVO 24/7", "SALA DE CINE: PRÓXIMA FUNCIÓN EL VIERNES", "CREA TU COMUNIDAD EN SEGUNDOS", "RANKING SEMANAL ACTUALIZADO" ];
  var track = document.getElementById("tickerTrack");
  var html = items.map(function(t) {
    return "<span>" + t + "</span>";
  }).join("");
  track.innerHTML = html + html;
  var headline = document.getElementById("headline");
  if (!reduceMotion) {
    headline.classList.add("glitching");
  }
  var container = document.getElementById("scene");
  var scene = new THREE.Scene;
  var camera = new THREE.PerspectiveCamera(42, window.innerWidth / window.innerHeight, .1, 1e3);
  camera.position.set(0, 0, 8.2);
  var renderer = new THREE.WebGLRenderer({
    antialias: !lowPower,
    alpha: true,
    powerPreference: lowPower ? "low-power" : "high-performance"
  });
  renderer.setPixelRatio(lowPower ? 1 : Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setClearColor(0, 0);
  container.appendChild(renderer.domElement);
  function buildStars(count, radius, size, colorFn) {
    var geo = new THREE.BufferGeometry;
    var positions = new Float32Array(count * 3);
    var colors = new Float32Array(count * 3);
    for (var i = 0; i < count; i++) {
      var r = radius * (.6 + Math.random() * .4);
      var theta = Math.random() * Math.PI * 2;
      var phi = Math.acos(Math.random() * 2 - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);
      var c = colorFn();
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    var mat = new THREE.PointsMaterial({
      size: size,
      vertexColors: true,
      transparent: true,
      opacity: .9,
      sizeAttenuation: true
    });
    return new THREE.Points(geo, mat);
  }
  var starColor = new THREE.Color;
  var stars = buildStars(lowPower ? 900 : 2600, 60, .055, function() {
    var t = Math.random();
    if (t < .08) {
      starColor.setRGB(1, .55, .35);
    } else {
      var v = .6 + Math.random() * .4;
      starColor.setRGB(v, v, v * .98);
    }
    return starColor;
  });
  scene.add(stars);
  function buildEarthTextures() {
    var w = 1024, h = 512;
    var canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    var ctx = canvas.getContext("2d");
    var lightCanvas = document.createElement("canvas");
    lightCanvas.width = w;
    lightCanvas.height = h;
    var lctx = lightCanvas.getContext("2d");
    lctx.fillStyle = "#000000";
    lctx.fillRect(0, 0, w, h);
    var oceanGrad = ctx.createLinearGradient(0, 0, 0, h);
    oceanGrad.addColorStop(0, "#150a10");
    oceanGrad.addColorStop(.5, "#1e0b12");
    oceanGrad.addColorStop(1, "#0c0810");
    ctx.fillStyle = oceanGrad;
    ctx.fillRect(0, 0, w, h);
    var seed = 1337;
    function rand() {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    }
    function blob(cx, cy, r, points) {
      ctx.beginPath();
      for (var i = 0; i <= points; i++) {
        var ang = i / points * Math.PI * 2;
        var jitter = .65 + rand() * .55;
        var rr = r * jitter;
        var x = cx + Math.cos(ang) * rr;
        var y = cy + Math.sin(ang) * rr * .72;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.closePath();
    }
    var continents = [ {
      x: 180,
      y: 190,
      r: 95
    }, {
      x: 120,
      y: 290,
      r: 70
    }, {
      x: 260,
      y: 340,
      r: 60
    }, {
      x: 430,
      y: 150,
      r: 80
    }, {
      x: 470,
      y: 250,
      r: 110
    }, {
      x: 560,
      y: 330,
      r: 55
    }, {
      x: 700,
      y: 170,
      r: 120
    }, {
      x: 820,
      y: 260,
      r: 90
    }, {
      x: 900,
      y: 150,
      r: 60
    }, {
      x: 640,
      y: 400,
      r: 50
    }, {
      x: 320,
      y: 110,
      r: 55
    } ];
    continents.forEach(function(c) {
      var g = ctx.createRadialGradient(c.x, c.y, c.r * .1, c.x, c.y, c.r);
      g.addColorStop(0, "#7a2410");
      g.addColorStop(.55, "#5a180f");
      g.addColorStop(1, "#2c0d10");
      ctx.fillStyle = g;
      blob(c.x, c.y, c.r, 14);
      ctx.fill();
      var g2 = ctx.createRadialGradient(c.x, c.y, 0, c.x, c.y, c.r * .6);
      g2.addColorStop(0, "rgba(255,120,60,0.18)");
      g2.addColorStop(1, "rgba(255,120,60,0)");
      ctx.fillStyle = g2;
      blob(c.x, c.y, c.r * .7, 10);
      ctx.fill();
    });
    continents.forEach(function(c) {
      var nodes = 22 + Math.floor(rand() * 18);
      for (var i = 0; i < nodes; i++) {
        var ang = rand() * Math.PI * 2;
        var rr = rand() * c.r * .75;
        var x = c.x + Math.cos(ang) * rr;
        var y = c.y + Math.sin(ang) * rr * .72;
        var s = .6 + rand() * 1.4;
        ctx.fillStyle = "rgba(255,180,110," + (.5 + rand() * .4) + ")";
        ctx.beginPath();
        ctx.arc(x, y, s, 0, Math.PI * 2);
        ctx.fill();
        lctx.fillStyle = "rgba(255,150,80," + (.7 + rand() * .3) + ")";
        lctx.beginPath();
        lctx.arc(x, y, s * 1.3, 0, Math.PI * 2);
        lctx.fill();
      }
    });
    ctx.globalAlpha = .05;
    ctx.strokeStyle = "#ff6a30";
    for (var y = 0; y < h; y += 3) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    var tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    var lightTex = new THREE.CanvasTexture(lightCanvas);
    lightTex.wrapS = THREE.RepeatWrapping;
    return {
      map: tex,
      emissive: lightTex
    };
  }
  var mouseX = 0, mouseY = 0;
  var targetRotX = 0, targetRotY = 0;
  window.addEventListener("mousemove", function(e) {
    mouseX = e.clientX / window.innerWidth * 2 - 1;
    mouseY = e.clientY / window.innerHeight * 2 - 1;
  }, {
    passive: true
  });
  var sceneLastWidth = window.innerWidth;
  window.addEventListener("resize", function() {
    if (window.innerWidth === sceneLastWidth) return;
    sceneLastWidth = window.innerWidth;
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
  var clock = new THREE.Clock;
  var rotSpeed = reduceMotion ? .02 : .09;
  var sceneRunning = true;
  var frameBudget = lowPower ? 1e3 / 30 : 0;
  var lastFrameTime = 0;
  function animate(now) {
    if (!sceneRunning) return;
    requestAnimationFrame(animate);
    if (frameBudget && now && now - lastFrameTime < frameBudget) return;
    lastFrameTime = now || 0;
    var dt = clock.getDelta();
    stars.rotation.y += dt * rotSpeed * .3 + dt * .004;
    targetRotY += (mouseX * .25 - targetRotY) * .03;
    targetRotX += (mouseY * .15 - targetRotX) * .03;
    camera.position.x = targetRotY;
    camera.position.y = -targetRotX + .1;
    camera.lookAt(0, -.3, 0);
    renderer.render(scene, camera);
  }
  animate();
  document.addEventListener("visibilitychange", function() {
    if (document.hidden) {
      sceneRunning = false;
    } else if (!sceneRunning) {
      sceneRunning = true;
      clock.getDelta();
      animate();
    }
  });
})();