/* Z3T · motor del tema Personalizado (se ejecuta antes de pintar para evitar parpadeos) */
(function () {
  "use strict";
  var KEY = "z3t_custom_theme";
  var FONTS = {
    default: { label: "Original", css: null, stack: null },
    gothic:  { label: "Gótica", css: "UnifrakturCook:wght@700", stack: "'UnifrakturCook','Pirata One',serif", head: true },
    pirata:  { label: "Pirata", css: null, stack: "'Pirata One','Chakra Petch',sans-serif", head: true },
    cinzel:  { label: "Cinzel", css: "Cinzel:wght@500;700", stack: "'Cinzel',serif" },
    metal:   { label: "Metal", css: "Metal+Mania", stack: "'Metal Mania',cursive", head: true },
    orbit:   { label: "Neón", css: "Orbitron:wght@500;700", stack: "'Orbitron',sans-serif" },
    retro:   { label: "Retro", css: "Press+Start+2P", stack: "'Press Start 2P',monospace", head: true },
    play:    { label: "Elegante", css: "Playfair+Display:wght@500;700", stack: "'Playfair Display',serif" },
    quick:   { label: "Suave", css: "Quicksand:wght@500;700", stack: "'Quicksand',sans-serif" },
    sora:    { label: "Moderna", css: null, stack: "'Sora',sans-serif" },
    mono:    { label: "Terminal", css: null, stack: "'IBM Plex Mono',monospace" }
  };
  var DEF = { enabled: false, accent: "#a855f7", text: "#f1ecfa", surface: "#0a0713", bg: null, dim: 45, logo: null, fontHead: "default", fontBody: "default", preset: "violeta" };

  function load() {
    try { var o = JSON.parse(localStorage.getItem(KEY) || "null"); if (o) return Object.assign({}, DEF, o); } catch (e) {}
    return Object.assign({}, DEF);
  }
  function save(s) { var ok = false; try { localStorage.setItem(KEY, JSON.stringify(s)); ok = true; } catch (e) {} if (window.Z3TAccountPrefs) window.Z3TAccountPrefs.queuePush(); return ok; }

  function hexToRgb(h) {
    h = String(h || "").replace("#", "");
    if (h.length === 3) h = h.split("").map(function (c) { return c + c; }).join("");
    var n = parseInt(h, 16); if (isNaN(n) || h.length !== 6) return [168, 85, 247];
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, h = 0, s = 0, d = mx - mn;
    if (d) {
      s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
      h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
      h *= 60;
    }
    return [h, s * 100, l * 100];
  }
  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360; s /= 100; l /= 100;
    var c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2, r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
  }
  function toHex(rgb) { return "#" + rgb.map(function (v) { return ("0" + v.toString(16)).slice(-2); }).join(""); }
  function hsl(h, s, l) { return hslToRgb(h, s, Math.max(4, Math.min(96, l))); }

  var VARS = ["--c300", "--c400", "--c500", "--c600", "--c700", "--c900", "--c300-rgb", "--c400-rgb", "--c500-rgb", "--c600-rgb", "--c700-rgb", "--c900-rgb",
    "--ember", "--ember-dim", "--crimson", "--bone", "--ash", "--void", "--void-2", "--glass-1", "--glass-2", "--glass-border", "--nav-bg", "--nav-border", "--wallpaper", "--wallpaper-dim", "--c-font-head", "--c-font-body"];

  function loadFont(key) {
    var f = FONTS[key]; if (!f || !f.css) return;
    var id = "z3t-font-" + key; if (document.getElementById(id)) return;
    var l = document.createElement("link"); l.id = id; l.rel = "stylesheet";
    l.href = "https://fonts.googleapis.com/css2?family=" + f.css + "&display=swap";
    document.head.appendChild(l);
  }

  function clear() {
    var r = document.documentElement;
    r.classList.remove("custom-theme", "custom-has-bg", "custom-font-head", "custom-font-body");
    VARS.forEach(function (v) { r.style.removeProperty(v); });
  }

  function apply(s) {
    s = s || load();
    var r = document.documentElement;
    if (!s.enabled) { clear(); return; }
    var a = hexToRgb(s.accent), H = rgbToHsl(a[0], a[1], a[2]), h = H[0], sat = Math.max(H[1], 25), l = H[2];
    var c = {
      300: hsl(h, sat, Math.max(l + 30, 84)), 400: hsl(h, sat, Math.min(l + 14, 78)), 500: a,
      600: hsl(h, sat, l - 9), 700: hsl(h, sat, l - 21), 900: hsl(h, sat * .9, l - 36)
    };
    [300, 400, 500, 600, 700, 900].forEach(function (k) {
      r.style.setProperty("--c" + k, toHex(c[k]));
      r.style.setProperty("--c" + k + "-rgb", c[k].join(","));
    });
    var tx = hexToRgb(s.text), sf = hexToRgb(s.surface), sfH = rgbToHsl(sf[0], sf[1], sf[2]);
    var sf2 = hsl(sfH[0], sfH[1], Math.min(sfH[2] + 4, 40));
    var ash = [0, 1, 2].map(function (i) { return Math.round(tx[i] * .68 + sf[i] * .32); });
    var set = function (k, v) { r.style.setProperty(k, v); };
    set("--ember", s.accent); set("--ember-dim", toHex(c[700])); set("--crimson", toHex(c[900]));
    set("--bone", s.text); set("--ash", toHex(ash));
    set("--void", s.surface); set("--void-2", toHex(sf2));
    set("--glass-1", "rgba(" + sf.join(",") + ",.62)"); set("--glass-2", "rgba(" + sf2.join(",") + ",.78)");
    set("--glass-border", "rgba(" + a.join(",") + ",.30)");
    set("--nav-bg", "rgba(" + sf.join(",") + ",.62)"); set("--nav-border", "rgba(" + a.join(",") + ",.30)");
    set("--wallpaper-dim", String(Math.max(0, Math.min(90, s.dim)) / 100));
    r.classList.add("custom-theme");
    if (s.bg) { set("--wallpaper", 'url("' + s.bg + '")'); r.classList.add("custom-has-bg"); }
    var fh = FONTS[s.fontHead], fb = FONTS[s.fontBody];
    if (fh && fh.stack) { loadFont(s.fontHead); set("--c-font-head", fh.stack); r.classList.add("custom-font-head"); }
    if (fb && fb.stack) { loadFont(s.fontBody); set("--c-font-body", fb.stack); r.classList.add("custom-font-body"); }
    var tc = document.querySelector('meta[name="theme-color"]'); if (tc) tc.setAttribute("content", s.surface);
    applyLogo(s);
  }

  function applyLogo(s) {
    s = s || load();
    var on = s.enabled && s.logo;
    ["planetLogoImg", "sidebarCrestLogo", "appLoadingLogo"].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      if (on) { if (!el.dataset.z3tOrig) el.dataset.z3tOrig = el.getAttribute("src") || ""; el.src = s.logo; }
      else if (el.dataset.z3tOrig) { el.src = el.dataset.z3tOrig; delete el.dataset.z3tOrig; }
    });
  }

  window.Z3TCustom = { KEY: KEY, FONTS: FONTS, DEF: DEF, load: load, save: save, apply: apply, applyLogo: applyLogo,
    hexToRgb: hexToRgb, rgbToHsl: rgbToHsl, hslToRgb: hslToRgb, toHex: toHex };
  try { apply(load()); } catch (e) {}
})();
