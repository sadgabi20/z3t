"use strict";

var PRIVATE_GROUPS = [];

var currentGroup = null;

var groupMembers = [];

var GROUP_MESSAGES = [];

var groupMessagesPollTimer = null;

function myGroupRole() {
  if (!currentUser || !currentGroup) return null;
  var m = groupMembers.filter(function(x) {
    return x.user_id === currentUser.id;
  })[0];
  if (m) return m.role;
  return currentGroup.created_by === currentUser.id ? "admin" : null;
}

function loadPrivateGroups() {
  if (!currentUser) return Promise.resolve();
  return supabase.from("private_group_members").select("group_id, role, private_groups(*)").eq("user_id", currentUser.id).then(function(res) {
    if (res.error) {
      PRIVATE_GROUPS = [];
      renderMergedPrivadoList();
      return;
    }
    PRIVATE_GROUPS = (res.data || []).filter(function(r) {
      return r.private_groups;
    }).map(function(r) {
      var g = r.private_groups;
      return {
        id: g.id,
        slug: g.slug,
        name: g.name,
        avatarUrl: g.avatar_url,
        bannerUrl: g.banner_url,
        myRole: r.role,
        lastActivityAt: g.last_message_at || g.updated_at || g.created_at || null
      };
    });
    renderMergedPrivadoList();
  });
}

function groupCardHtml(g) {
  return '<article class="dm-card" data-kind="group" data-slug="' + escapeHtml(g.slug) + '">' + avatarSpanHtml(g.name, g.avatarUrl) + '<div class="dm-card-main">' + '<div class="dm-card-top"><span class="dm-card-name">' + escapeHtml(g.name) + ' <span class="dm-card-kind-tag">Grupo</span></span></div>' + '<div class="dm-card-preview">' + (g.myRole === "admin" ? "Admin" : g.myRole === "co_admin" ? "Co-Admin" : "Miembro") + "</div>" + "</div>" + "</article>";
}

$("btnNewGroupHeader").addEventListener("click", function() {
  $("groupCreateBackdrop").classList.add("open");
});

$("groupCreateClose").addEventListener("click", closeCreateGroup);

$("groupCreateBackdrop").addEventListener("click", function(e) {
  if (e.target === this) closeCreateGroup();
});

function closeCreateGroup() {
  $("groupCreateBackdrop").classList.remove("open");
  $("groupCreateForm").reset();
}

$("btnPickGroupBanner").addEventListener("click", function() {
  openBackgroundPicker("groupCreateBanner");
});

$("groupCreateForm").addEventListener("submit", function(e) {
  e.preventDefault();
  if (!currentUser) return;
  var name = $("groupCreateName").value.trim();
  if (!name) return;
  var avatarFile = $("groupCreateAvatar").files[0];
  var bannerFile = $("groupCreateBanner").files[0];
  var btn = $("groupCreateForm").querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Creando...";
  var uploadAvatar = avatarFile ? uploadFiles([ avatarFile ], "groups/" + currentUser.id) : Promise.resolve([]);
  var uploadBanner = bannerFile ? uploadFiles([ bannerFile ], "groups/" + currentUser.id) : Promise.resolve([]);
  Promise.all([ uploadAvatar, uploadBanner ]).then(function(results) {
    var avatarUrl = results[0][0] ? results[0][0].url : null;
    var bannerUrl = results[1][0] ? results[1][0].url : null;
    var slug = slugify(name);
    return supabase.from("private_groups").insert({
      slug: slug,
      name: name,
      avatar_url: avatarUrl,
      banner_url: bannerUrl,
      created_by: currentUser.id
    }).select().single().then(function(res) {
      if (res.error) {
        toast(t("group.err_create") + " " + res.error.message);
        btn.disabled = false;
        btn.textContent = t("group.btn_create");
        return;
      }
      return supabase.from("private_group_members").insert({
        group_id: res.data.id,
        user_id: currentUser.id,
        role: "admin"
      }).then(function(memRes) {
        btn.disabled = false;
        btn.textContent = "Crear grupo";
        if (memRes.error) {
          toast(t("group.err_admin_add") + " " + memRes.error.message);
          return;
        }
        closeCreateGroup();
        toast(t("group.toast_created") + ' "' + name + '" ' + t("group.toast_created_suffix"));
        awardAchievement(currentUser.id, "own_group");
        openGroup(slug);
      });
    });
  }).catch(function(err) {
    toast(t("group.err_images") + " " + (err && err.message ? err.message : t("group.err_unknown")));
    btn.disabled = false;
    btn.textContent = "Crear grupo";
  });
});

function loadGroupMembers() {
  if (!currentGroup) return Promise.resolve();
  return supabase.from("private_group_members").select("*, profiles(username, avatar_url, name_color, role, verified)").eq("group_id", currentGroup.id).order("joined_at", {
    ascending: true
  }).then(function(res) {
    groupMembers = res.error ? [] : res.data || [];
  });
}

function openGroup(slug) {
  supabase.from("private_groups").select("*").eq("slug", slug).single().then(function(res) {
    if (res.error || !res.data) {
      toast(t("group.err_not_found"));
      resetToFeedOnMissingRoute("/grupos/");
      return;
    }
    currentGroup = res.data;
    if (typeof activityVoiceMinimized !== "undefined" && activityVoiceMinimized && activityVoiceKind === "group" && activityVoiceRoomId === currentGroup.id) {
      activityVoiceMinimized = false;
      activityVoiceReopenFn = null;
      if (typeof renderActivityVoiceFloat === "function") renderActivityVoiceFloat();
    }
    loadGroupMembers().then(function() {
      renderGroupDetail();
      enterImmersive("group");
      activatePanel("panel-group-detail");
      loadGroupMessages();
      if (groupMessagesPollTimer) clearInterval(groupMessagesPollTimer);
      groupMessagesPollTimer = setInterval(function() {
        if (!document.hidden) loadGroupMessages();
      }, 25e3);
      z3tRealtime("gmsg", "private_group_messages", "group_id=eq." + currentGroup.id, function() {
        loadGroupMessages();
      });
      if (!state.suppressPush) history.pushState({
        view: "group",
        slug: slug
      }, "", "/grupos/" + encodeURIComponent(slug));
      state.suppressPush = false;
    });
  }).catch(function(err) {
    console.error("[openGroup] fallo consultando el grupo:", err);
    toast(t("group.err_not_found"));
    resetToFeedOnMissingRoute("/grupos/");
  });
}

function closeGroup() {
  z3tRealtimeStop("gmsg");
  if (groupMessagesPollTimer) {
    clearInterval(groupMessagesPollTimer);
    groupMessagesPollTimer = null;
  }
  if (groupCinemaPollTimer) {
    clearInterval(groupCinemaPollTimer);
    groupCinemaPollTimer = null;
  }
  stopRoleplayPanel();
  var slugToReopen = currentGroup ? currentGroup.slug : null;
  minimizeActivityVoice(slugToReopen ? function() {
    openGroup(slugToReopen);
  } : null);
  currentGroup = null;
  exitImmersive("group");
  goBack("panel-messages");
  loadPrivateGroups();
}

function renderGroupDetail() {
  var g = currentGroup;
  var role = myGroupRole();
  var isStaff = role === "admin" || role === "co_admin";
  var bannerStyle = g.banner_url ? ' style="background-image:url(&quot;' + encodeURI(g.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
  var avatarStyle = g.avatar_url ? ' style="background-image:url(&quot;' + encodeURI(g.avatar_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
  var membersHtml = groupMembers.map(function(m) {
    var name = m.profiles ? m.profiles.username : "usuario";
    var nameColor = m.profiles ? m.profiles.name_color : null;
    var acctRole = m.profiles ? m.profiles.role : null;
    var acctVerified = m.profiles ? m.profiles.verified : null;
    return '<div class="voice-participant" data-uid="' + escapeHtml(m.user_id) + '">' + avatarSpanHtml(name, m.profiles ? m.profiles.avatar_url : null, null, m.user_id) + '<span class="voice-participant-name"' + (nameColor ? ' style="color:' + escapeHtml(nameColor) + '"' : "") + ">" + escapeHtml(name) + "</span>" + roleBadgeHtml(acctRole, acctVerified) + "</div>";
  }).join("");
  $("groupDetail").innerHTML = '<div class="community-shell">' + '<div class="community-fixed-top">' + '<div class="community-header">' + '<div class="community-banner-strip"' + bannerStyle + "></div>" + '<div class="community-header-bar">' + '<button class="icon-btn" id="btnGroupBack" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + '<div class="community-header-avatar"' + avatarStyle + ">" + (g.avatar_url ? "" : escapeHtml(g.name.charAt(0).toUpperCase())) + "</div>" + '<div class="community-header-name">' + "<h3>" + escapeHtml(g.name) + "</h3>" + '<div class="community-header-sub">Grupo privado · ' + groupMembers.length + " miembros" + (role ? " · " + (role === "admin" ? "Admin" : role === "co_admin" ? "Co-Admin" : "Miembro") : "") + "</div>" + "</div>" + '<div class="compose-icon-wrap">' + '<button class="icon-btn" id="btnGroupActivities" type="button" aria-label="Actividades">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 20h16z"/><line x1="12" y1="9" x2="12" y2="14"/><line x1="9" y1="6" x2="6" y2="2"/><line x1="15" y1="6" x2="18" y2="2"/></svg>' + "</button>" + '<div class="chat-actions-popup popup-below" id="groupActivitiesPopup">' + '<div class="chat-actions-panel">' + '<button class="chat-action-item" id="btnGroupActivityCinema" type="button">' + activityIconHtml("cinema") + " <span>" + (g.active_activity === "cinema" ? "Apagar Sala de Cine" : "Sala de Cine") + "</span></button>" + '<button class="chat-action-item" id="btnGroupActivityRoleplay" type="button">' + activityIconHtml("roleplay") + " <span>" + (g.active_activity === "roleplay" ? "Apagar Roleplay" : "Roleplay") + "</span></button>" + giftMenuItemHtml() + "</div>" + "</div>" + "</div>" + (isStaff ? '<button class="icon-btn" id="btnGroupInvite" type="button" aria-label="Invitar">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>' + "</button>" : "") + (isStaff ? '<button class="icon-btn" id="btnGroupRoleColors" type="button" aria-label="Colores de roles" title="Colores de roles">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.8-.8 1.8-1.7 0-.5-.2-.9-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1 .8-1.7 1.8-1.7H17a4 4 0 0 0 4-4c0-4.4-4-8-9-8z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10.5" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/></svg>' + "</button>" : "") + "</div>" + "</div>" + '<div class="community-members-strip" id="groupMembersStrip"' + (g.active_activity ? " hidden" : "") + ">" + '<div class="community-avatar-stack">' + membersHtml + "</div>" + "</div>" + '<div class="community-voice-bar" id="groupVoiceBar" hidden></div>' + (g.active_activity === "cinema" ? '<div class="cinema-player-wrap" id="groupCinemaWrap">' + '<div class="cinema-player-inner" id="groupCinemaPlayer"></div>' + '<div class="cinema-corner-controls">' + (g.cinema_video_url ? '<button class="icon-btn" id="btnGroupCinemaPlayPause" type="button" aria-label="Reproducir/Pausar">' + (g.cinema_is_playing ? pauseSvg() : playSvg()) + "</button>" : "") + (isStaff ? '<button class="icon-btn" id="btnGroupCinemaOptionsToggle" type="button" aria-label="Opciones de video">' + cinemaGearSvg() + "</button>" : "") + '<button class="icon-btn" id="btnGroupCinemaExpandToggle" type="button" aria-label="Agrandar/Achicar">' + stageExpandSvg() + "</button>" + (isStaff ? '<button class="icon-btn" id="btnGroupCinemaClose" type="button" aria-label="Apagar Sala de Cine" title="Apagar Sala de Cine">' + closeXSvg() + "</button>" : "") + "</div>" + (isStaff ? '<div class="cinema-options-popup" id="groupCinemaOptionsPopup">' + "<label>Video por URL</label>" + '<form class="cinema-option-row" id="groupCinemaVideoForm">' + '<input type="text" id="groupCinemaUrlInput" placeholder="Pega una URL de YouTube o de video...">' + '<button class="icon-btn" type="submit" aria-label="Poner video">' + playSvg() + "</button>" + "</form>" + "</div>" : "") + "</div>" : "") + (g.active_activity === "roleplay" ? '<div class="roleplay-wrap" id="groupRoleplayWrap"></div>' : "") + "</div>" + '<div class="community-chat" id="groupChat"></div>' + '<form class="community-chat-input-row" id="groupChatForm">' + '<input type="file" id="groupImageInput" accept="image/*" multiple hidden>' + '<button class="icon-btn z3t-link-btn" type="button" data-link-for="groupChatInput" aria-label="Insertar enlace" title="Enlace">🔗</button>' + '<button class="icon-btn" id="btnGroupAttachImage" type="button" aria-label="Enviar imagen">' + '<img loading=lazy decoding=async src="assets/icons/ic-upload.png" alt="" class="upload-icon-img">' + "</button>" + '<div class="compose-icon-wrap">' + '<button class="icon-btn" id="btnGroupEmoji" type="button" aria-label="Emojis">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>' + "</button>" + '<div class="chat-actions-popup" id="groupEmojiPopup"></div>' + "</div>" + '<input type="text" id="groupChatInput" placeholder="Escribe un mensaje..." autocomplete="off">' + '<button class="icon-btn" type="submit" aria-label="Enviar">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>' + "</button>" + "</form>" + "</div>";
  $("btnGroupBack").addEventListener("click", closeGroup);
  if ($("btnGroupRoleColors")) $("btnGroupRoleColors").addEventListener("click", z3tOpenGroupRoleColors);
  $("groupChatForm").addEventListener("submit", sendGroupMessage);
  var gEmojiBtn = $("btnGroupEmoji"), gEmojiPopup = $("groupEmojiPopup");
  if (gEmojiBtn && gEmojiPopup) {
    gEmojiPopup.innerHTML = '<div class="emoji-grid">' + COMMON_EMOJIS.map(function(em) {
      return '<button type="button" data-emoji="' + em + '">' + em + "</button>";
    }).join("") + "</div>";
    gEmojiBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      gEmojiPopup.classList.toggle("open");
    });
    gEmojiPopup.addEventListener("click", function(e) {
      e.stopPropagation();
      var btn = e.target.closest("[data-emoji]");
      if (!btn) return;
      var input = $("groupChatInput");
      input.value += btn.getAttribute("data-emoji");
      input.focus();
      gEmojiPopup.classList.remove("open");
    });
  }
  var groupImageInput = $("groupImageInput"), groupAttachBtn = $("btnGroupAttachImage");
  if (groupAttachBtn && groupImageInput) {
    groupAttachBtn.addEventListener("click", function() {
      groupImageInput.click();
    });
    groupImageInput.addEventListener("change", function() {
      if (!groupImageInput.files || !groupImageInput.files.length) return;
      groupAttachBtn.setAttribute("disabled", "true");
      uploadFiles(groupImageInput.files, "group/" + currentGroup.id).then(function(attachments) {
        groupImageInput.value = "";
        groupAttachBtn.removeAttribute("disabled");
        sendGroupMessage(null, encodeAttachments(attachments));
      }).catch(function() {
        groupAttachBtn.removeAttribute("disabled");
        toast(t("group.err_image_upload"));
      });
    });
  }
  var inviteBtn = $("btnGroupInvite");
  if (inviteBtn) inviteBtn.addEventListener("click", function() {
    var username = prompt("¿A quién quieres invitar? Escribe su nombre de usuario exacto:");
    if (username) inviteToGroup(username.trim().replace(/^@/, ""));
  });
  applyChatBackground($("groupChat"));
  var rpActiveHere = g.active_activity === "roleplay";
  var rpVoiceBlocked = rpActiveHere && g.roleplay_voice_enabled === false;
  if (rpVoiceBlocked) {
    leaveActivityVoice();
    var vb = $("groupVoiceBar");
    if (vb) {
      vb.hidden = false;
      vb.innerHTML = '<div class="voice-bar-empty">' + voiceIconSvg() + " El chat de voz está apagado en este Roleplay" + (isStaff ? " — actívalo en Ajustes" : "") + "</div>";
    }
  } else if (rpActiveHere) {
    if (typeof activityVoiceRoom !== "undefined" && activityVoiceRoom && activityVoiceKind === "group" && activityVoiceRoomId === currentGroup.id) leaveActivityVoice();
    var rpVb = $("groupVoiceBar");
    if (rpVb) {
      rpVb.hidden = true;
      rpVb.innerHTML = "";
    }
  } else {
    ensureActivityVoiceConnected("group", currentGroup.id, myGroupRole);
  }
  var activitiesBtn = $("btnGroupActivities"), activitiesPopup = $("groupActivitiesPopup");
  if (activitiesBtn) activitiesBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    activitiesPopup.classList.toggle("open");
  });
  if (activitiesPopup) activitiesPopup.addEventListener("click", function(e) {
    e.stopPropagation();
  });
  var cinemaPick = $("btnGroupActivityCinema");
  if (cinemaPick) cinemaPick.addEventListener("click", function() {
    activitiesPopup.classList.remove("open");
    setGroupActivity(g.active_activity === "cinema" ? null : "cinema");
  });
  var roleplayPick = $("btnGroupActivityRoleplay");
  if (roleplayPick) roleplayPick.addEventListener("click", function() {
    activitiesPopup.classList.remove("open");
    setGroupActivity(g.active_activity === "roleplay" ? null : "roleplay");
  });
  var groupGiftBtn = activitiesPopup ? activitiesPopup.querySelector('[data-act="open-gift-send"]') : null;
  if (groupGiftBtn) groupGiftBtn.addEventListener("click", function() {
    activitiesPopup.classList.remove("open");
    openGiftSend("group", currentGroup.id, null, null);
  });
  var playPauseBtn = $("btnGroupCinemaPlayPause");
  if (playPauseBtn) playPauseBtn.addEventListener("click", toggleGroupCinemaPlayPause);
  var expandBtn = $("btnGroupCinemaExpandToggle");
  if (expandBtn) expandBtn.addEventListener("click", function() {
    var wrap = $("groupCinemaWrap");
    if (wrap) {
      wrap.classList.toggle("cinema-expanded");
      expandBtn.innerHTML = wrap.classList.contains("cinema-expanded") ? stageCompressSvg() : stageExpandSvg();
    }
  });
  var groupCinemaCloseBtn = $("btnGroupCinemaClose");
  if (groupCinemaCloseBtn) groupCinemaCloseBtn.addEventListener("click", function() {
    setGroupActivity(null);
  });
  var cinemaOptionsToggle = $("btnGroupCinemaOptionsToggle"), cinemaOptionsPopup = $("groupCinemaOptionsPopup");
  if (cinemaOptionsToggle) cinemaOptionsToggle.addEventListener("click", function(e) {
    e.stopPropagation();
    cinemaOptionsPopup.classList.toggle("open");
  });
  if (cinemaOptionsPopup) cinemaOptionsPopup.addEventListener("click", function(e) {
    e.stopPropagation();
  });
  var cinemaForm = $("groupCinemaVideoForm");
  if (cinemaForm) cinemaForm.addEventListener("submit", function(e) {
    e.preventDefault();
    var url = $("groupCinemaUrlInput").value.trim();
    if (url) {
      setGroupCinemaVideo(url);
      if (cinemaOptionsPopup) cinemaOptionsPopup.classList.remove("open");
    }
  });
  if (g.active_activity === "cinema") mountGroupCinemaPlayer();
  if (groupCinemaPollTimer) clearInterval(groupCinemaPollTimer);
  groupCinemaPollTimer = setInterval(pollGroupCinemaState, 4e3);
  if (g.active_activity === "roleplay") {
    initRoleplayPanel(g, role, "group");
  } else {
    stopRoleplayPanel();
  }
}

var groupCinemaPollTimer = null;

var groupYtPlayer = null;

function postGroupSystemMessage(body) {
  if (!currentUser || !currentGroup) return;
  supabase.from("private_group_messages").insert({
    group_id: currentGroup.id,
    sender_id: currentUser.id,
    body: body,
    type: "system"
  }).then(function() {
    loadGroupMessages();
  });
}

function setGroupActivity(mode) {
  if (!currentUser || !currentGroup) return;
  var role = myGroupRole();
  if (role !== "admin" && role !== "co_admin") {
    toast(t("group.err_activity_perm"));
    return;
  }
  var prevMode = currentGroup.active_activity;
  var newMode = mode === null ? null : prevMode === mode ? null : mode;
  var closedMode = newMode ? null : mode || prevMode;
  var patch = {
    active_activity: newMode
  };
  patch.voice_active = newMode === "voice";
  if (newMode === "cinema" && prevMode !== "cinema") {
    patch.cinema_video_url = null;
    patch.cinema_is_playing = false;
    patch.cinema_position_seconds = 0;
  }
  supabase.from("private_groups").update(patch).eq("id", currentGroup.id).select().single().then(function(res) {
    if (res.error) {
      toast(t("group.err_activity_change") + " " + res.error.message);
      return;
    }
    currentGroup = res.data;
    postGroupSystemMessage(currentUser.username + " (" + roleLabel(role) + ") " + (newMode ? "activó " + activityLabelFor(newMode) : "cerró " + activityLabelFor(closedMode)) + ".");
    renderGroupDetail();
  });
}

function groupCinemaPosition(g) {
  var base = Number(g.cinema_position_seconds) || 0;
  if (g.cinema_is_playing && g.cinema_updated_at) {
    base += (Date.now() - new Date(g.cinema_updated_at).getTime()) / 1e3;
  }
  return Math.max(0, base);
}

function mountGroupCinemaPlayer() {
  var wrap = $("groupCinemaPlayer");
  if (!wrap) return;
  var g = currentGroup;
  if (!g.cinema_video_url) {
    wrap.innerHTML = '<div class="cinema-player-empty">Todavía no hay ningún video puesto.</div>';
    return;
  }
  var startPos = groupCinemaPosition(g);
  if (g.cinema_video_type === "youtube") {
    var parsed = parseVideoUrl(g.cinema_video_url);
    wrap.innerHTML = '<div id="groupYtPlayerMount"></div>';
    loadYouTubeApi().then(function(YT) {
      if (!$("groupYtPlayerMount")) return;
      groupYtPlayer = new YT.Player("groupYtPlayerMount", {
        videoId: parsed.id,
        playerVars: {
          autoplay: g.cinema_is_playing ? 1 : 0,
          start: Math.floor(startPos)
        },
        events: {
          onReady: function(ev) {
            if (g.cinema_is_playing) ev.target.playVideo(); else ev.target.pauseVideo();
          }
        }
      });
    });
  } else {
    wrap.innerHTML = '<video id="groupDirectVideoEl" src="' + safeUrlAttr(g.cinema_video_url) + '" ' + (g.cinema_is_playing ? "autoplay" : "") + " controls></video>";
    var v = $("groupDirectVideoEl");
    if (v) {
      v.currentTime = startPos;
      if (!g.cinema_is_playing) v.pause();
    }
  }
}

function setGroupCinemaVideo(url) {
  if (!currentUser || !currentGroup) return;
  var parsed = parseVideoUrl(url);
  supabase.from("private_groups").update({
    cinema_video_url: url,
    cinema_video_type: parsed.type,
    cinema_is_playing: true,
    cinema_position_seconds: 0,
    cinema_updated_at: (new Date).toISOString()
  }).eq("id", currentGroup.id).select().single().then(function(res) {
    if (res.error) {
      toast(t("group.err_video_set") + " " + res.error.message);
      return;
    }
    currentGroup = res.data;
    renderGroupDetail();
  });
}

function toggleGroupCinemaPlayPause() {
  if (!currentUser || !currentGroup) return;
  var g = currentGroup;
  var newPlaying = !g.cinema_is_playing;
  var pos = groupCinemaPosition(g);
  supabase.from("private_groups").update({
    cinema_is_playing: newPlaying,
    cinema_position_seconds: pos,
    cinema_updated_at: (new Date).toISOString()
  }).eq("id", g.id).select().single().then(function(res) {
    if (res.error) return;
    currentGroup = res.data;
    applySyncedGroupCinemaState(res.data);
    var btn = $("btnGroupCinemaPlayPause");
    if (btn) btn.innerHTML = res.data.cinema_is_playing ? pauseSvg() : playSvg();
  });
}

function applySyncedGroupCinemaState(g) {
  var pos = groupCinemaPosition(g);
  if (g.cinema_video_type === "youtube" && groupYtPlayer && groupYtPlayer.seekTo) {
    groupYtPlayer.seekTo(pos, true);
    if (g.cinema_is_playing) groupYtPlayer.playVideo(); else groupYtPlayer.pauseVideo();
  } else {
    var v = $("groupDirectVideoEl");
    if (v) {
      v.currentTime = pos;
      if (g.cinema_is_playing) v.play().catch(function() {}); else v.pause();
    }
  }
}

function pollGroupCinemaState() {
  if (!currentGroup) return;
  supabase.from("private_groups").select("*").eq("id", currentGroup.id).single().then(function(res) {
    if (res.error || !res.data) return;
    var g = res.data;
    var changed = g.cinema_updated_at !== currentGroup.cinema_updated_at || g.active_activity !== currentGroup.active_activity;
    var videoChanged = g.cinema_video_url !== currentGroup.cinema_video_url;
    currentGroup = g;
    if (!changed) return;
    if (videoChanged || g.active_activity !== "cinema") {
      renderGroupDetail();
    } else {
      applySyncedGroupCinemaState(g);
      var btn = $("btnGroupCinemaPlayPause");
      if (btn) btn.innerHTML = g.cinema_is_playing ? pauseSvg() : playSvg();
    }
  });
}

document.addEventListener("click", function() {
  var p = $("groupActivitiesPopup");
  if (p) p.classList.remove("open");
  var c = $("groupCinemaOptionsPopup");
  if (c) c.classList.remove("open");
});

function inviteToGroup(username) {
  if (!currentGroup || !username) return;
  supabase.from("profiles").select("id, username, name").ilike("username", username).limit(1).then(function(res) {
    if (res.error || !res.data || !res.data.length) {
      toast(t("group.err_user_not_found") + " @" + username + ".");
      return;
    }
    var target = res.data[0];
    supabase.from("private_group_members").insert({
      group_id: currentGroup.id,
      user_id: target.id,
      role: "member"
    }).then(function(insRes) {
      if (insRes.error) {
        toast(t("group.err_invite") + " " + insRes.error.message);
        return;
      }
      toast((target.name || target.username) + " fue agregado al grupo.");
      loadGroupMembers().then(renderGroupDetail);
    });
  });
}

function loadGroupMessages() {
  if (!currentGroup) return Promise.resolve();
  return supabase.from("private_group_messages").select("*, profiles(username, name, avatar_url, name_color, role, verified)").eq("group_id", currentGroup.id).order("created_at", {
    ascending: false
  }).limit(150).then(function(res) {
    if (res.error) {
      console.error("Error cargando mensajes de grupo:", res.error);
      return;
    }
    GROUP_MESSAGES = z3tProcessReplies((res.data || []).slice().reverse());
    renderGroupMessages();
  });
}

function renderGroupMessages() {
  var chat = $("groupChat");
  if (!chat) return;
  if (!GROUP_MESSAGES.length) {
    chat.innerHTML = '<p class="empty-state">Todavía no hay mensajes. ¡Sé el primero en escribir!</p>';
    chat.dataset.msgSig = "";
    return;
  }
  var sig = messagesSignature(GROUP_MESSAGES);
  if (chat.dataset.msgSig === sig) return;
  var lastGm = GROUP_MESSAGES[GROUP_MESSAGES.length - 1];
  var lastIsMine = !!(lastGm && currentUser && lastGm.sender_id === currentUser.id && lastGm.type !== "system");
  var wasNearBottom = !chat.dataset.msgSig || isNearBottom(chat, chat.clientHeight + 240) || lastIsMine && chat.dataset.lastMineId !== String(lastGm.id);
  chat.dataset.lastMineId = lastIsMine ? String(lastGm.id) : chat.dataset.lastMineId || "";
  chat.innerHTML = GROUP_MESSAGES.map(function(m) {
    if (m.type === "system") return '<div class="chat-system-msg">' + escapeHtml(m.body) + "</div>";
    var realName = m.profiles ? m.profiles.name || m.profiles.username : "usuario";
    var realHandle = m.profiles ? m.profiles.username : "";
    var rpm = typeof rpDecodeMessage === "function" ? rpDecodeMessage(m) : null;
    var isCharacter = !!(m.roleplay_character_name || rpm);
    var name = m.roleplay_character_name ? m.roleplay_character_name : rpm ? rpm.name : realName;
    var avatarUrl = m.roleplay_character_name ? (m.roleplay_character_avatar || (m.roleplay_character_id && typeof rpCharacterById === "function" && rpCharacterById(m.roleplay_character_id) ? rpCharacterById(m.roleplay_character_id).avatar_url : null)) : rpm ? rpm.avatar : m.profiles ? m.profiles.avatar_url : null;
    var nameColor = isCharacter ? null : m.profiles ? m.profiles.name_color : null;
    var acctRole = m.profiles ? m.profiles.role : null;
    var acctVerified = m.profiles ? m.profiles.verified : null;
    var bodyHtml;
    if (m.type === "gift") {
      bodyHtml = giftCardMessageHtml(m.body);
    } else {
      var parsedGm = parseAttachments(rpm ? rpm.body : m.body);
      bodyHtml = (parsedGm.text ? '<div class="chat-msg-text">' + z3tRichText(parsedGm.text) + "</div>" : "") + renderAttachments(parsedGm.attachments);
    }
    var rpc = isCharacter && typeof rpMsgColor === "function" ? rpMsgColor(m, name) : null;
    var ra = z3tMsgRoleAttrs("group", m.sender_id);
    return '<div class="chat-msg' + ra.cls + '"' + ra.style + z3tMsgAttrs("group", m, name) + '>' + rpTintAvatar(avatarSpanHtml(name, avatarUrl, null, isCharacter ? null : m.sender_id), rpc) + '<div class="chat-msg-col">' + '<div class="chat-msg-name" data-uid="' + escapeHtml(m.sender_id || "") + '" title="' + escapeHtml(isCharacter ? "@" + realHandle : "") + '"' + (nameColor ? ' style="color:' + escapeHtml(nameColor) + '"' : "") + ">" + escapeHtml(name) + (isCharacter ? '<span class="rp-char-badge">' + activityIconHtml("roleplay") + " personaje</span>" : roleBadgeHtml(acctRole, acctVerified)) + (isCharacter ? "" : z3tRoleTagHtml(ra.role, z3tChatEntity("group"))) + "</div>" + z3tReplyQuoteHtml(m) + chatMsgBodyOpenTag(m.sender_id, rpc) + bodyHtml + "</div>" + z3tReactionsSlotHtml(m) + "</div>" + "</div>";
  }).join("");
  chat.dataset.msgSig = sig;
  if (wasNearBottom) chat.scrollTop = chat.scrollHeight;
  z3tAfterRender("group");
}

function sendGroupMessage(e, attachSuffix) {
  if (e && e.preventDefault) e.preventDefault();
  if (!currentUser || !currentGroup) return;
  var input = $("groupChatInput");
  var body = input.value.trim() + (attachSuffix || "");
  if (!body.trim()) return;
  input.disabled = true;
  var msgRow = {
    group_id: currentGroup.id,
    sender_id: currentUser.id,
    body: z3tWithReply("group", body),
    type: "message"
  };
  var myChar = currentGroup.active_activity === "roleplay" && typeof myActiveRoleplayCharacter === "function" ? myActiveRoleplayCharacter() : null;
  var sendP = myChar && typeof rpInsertMessage === "function" ? rpInsertMessage("private_group_messages", msgRow, myChar) : supabase.from("private_group_messages").insert(msgRow);
  sendP.then(function(res) {
    input.disabled = false;
    if (res.error) {
      console.error("Error enviando mensaje de grupo:", res.error);
      toast(t("group.err_send") + " " + res.error.message);
      return;
    }
    input.value = "";
    z3tClearReply();
    input.focus();
    var gp = loadGroupMessages();
    if (gp && gp.then) gp.then(function() {
      var c = $("groupChat");
      if (c) c.scrollTop = c.scrollHeight;
    });
  }).catch(function() {
    input.disabled = false;
    toast(t("group.err_send"));
  });
}