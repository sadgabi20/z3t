"use strict";

var STORE_TAB = "frames";

var STORE_SORT = "popular";

var STORE_ITEMS = [];

var STORE_MY_FRAME_IDS = [];

var STORE_MY_BUBBLE_IDS = [];

var STORE_SORT_TABS = [ {
  id: "popular",
  label: "Populares"
}, {
  id: "reciente",
  label: "Recientes"
}, {
  id: "precio",
  label: "Precio"
}, {
  id: "gratis",
  label: "GRATIS"
} ];

function renderStoreSortTabs() {
  var wrap = $("storeSortTabs");
  if (!wrap) return;
  wrap.innerHTML = STORE_SORT_TABS.map(function(t) {
    return '<button type="button" class="store-tag-pill' + (STORE_SORT === t.id ? " active" : "") + '" data-sort="' + t.id + '">' + t.label + "</button>";
  }).join("");
  qsa(".store-tag-pill", wrap).forEach(function(btn) {
    btn.addEventListener("click", function() {
      STORE_SORT = btn.getAttribute("data-sort");
      renderStoreSortTabs();
      renderStoreGridFromCache();
    });
  });
}

function openStore() {
  if (typeof minimizeActiveContexts === "function") minimizeActiveContexts();
  if (typeof exitAllImmersive === "function") exitAllImmersive();
  activatePanel("panel-store");
  refreshWalletDisplay();
  renderStoreSortTabs();
  loadStoreOwnership().then(loadStoreGrid);
  if (!state.suppressPush) {
    history.pushState({
      view: "store"
    }, "", "/tienda");
  }
  state.suppressPush = false;
}

if ($("btnStore")) $("btnStore").addEventListener("click", openStore);

$("storeTabFrames").addEventListener("click", function() {
  setStoreTab("frames");
});

$("storeTabBubbles").addEventListener("click", function() {
  setStoreTab("bubbles");
});

$("storeTabResale").addEventListener("click", function() {
  setStoreTab("resale");
});

function setStoreTab(tab) {
  STORE_TAB = tab;
  $("storeTabFrames").classList.toggle("active", tab === "frames");
  $("storeTabBubbles").classList.toggle("active", tab === "bubbles");
  $("storeTabResale").classList.toggle("active", tab === "resale");
  if (tab === "resale") loadResaleGrid(); else loadStoreGrid();
}

function loadResaleGrid() {
  $("storeGrid").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  $("storeEmpty").hidden = true;
  supabase.from("item_resale_listings").select("*").order("created_at", {
    ascending: false
  }).then(function(res) {
    var listings = res.data || [];
    if (!listings.length) {
      $("storeGrid").innerHTML = "";
      $("storeEmpty").hidden = false;
      return;
    }
    var frameIds = listings.filter(function(l) {
      return l.item_type === "frame";
    }).map(function(l) {
      return l.item_id;
    });
    var bubbleIds = listings.filter(function(l) {
      return l.item_type === "bubble";
    }).map(function(l) {
      return l.item_id;
    });
    var sellerIds = listings.map(function(l) {
      return l.seller_id;
    });
    Promise.all([ frameIds.length ? supabase.from("frames").select("id,name,thumbnail_url").in("id", frameIds) : Promise.resolve({
      data: []
    }), bubbleIds.length ? supabase.from("chat_bubbles").select("id,name,thumbnail_url").in("id", bubbleIds) : Promise.resolve({
      data: []
    }), supabase.from("profiles").select("id,username,name").in("id", sellerIds) ]).then(function(results) {
      var frameMap = {};
      (results[0].data || []).forEach(function(f) {
        frameMap[f.id] = f;
      });
      var bubbleMap = {};
      (results[1].data || []).forEach(function(b) {
        bubbleMap[b.id] = b;
      });
      var sellerMap = {};
      (results[2].data || []).forEach(function(p) {
        sellerMap[p.id] = p;
      });
      $("storeEmpty").hidden = true;
      $("storeGrid").innerHTML = listings.map(function(l) {
        var item = l.item_type === "frame" ? frameMap[l.item_id] : bubbleMap[l.item_id];
        if (!item) return "";
        var seller = sellerMap[l.seller_id];
        var sellerName = seller ? seller.name || seller.username : "alguien";
        var mine = currentUser && l.seller_id === currentUser.id;
        return '<div class="community-card store-card">' + '<div class="community-card-banner" style="background-image:url(&quot;' + escapeHtml(item.thumbnail_url || "") + '&quot;)"></div>' + '<div class="community-card-name">' + escapeHtml(item.name) + "</div>" + '<div class="store-card-foot"><span>' + coinIconHtml(l.currency) + " " + l.price + " · vende " + escapeHtml(sellerName) + "</span>" + (mine ? '<button type="button" class="link-btn danger sc-resale-cancel" data-id="' + escapeHtml(l.id) + '">Quitar</button>' : '<button type="button" class="link-btn sc-resale-buy" data-id="' + escapeHtml(l.id) + '">Comprar</button>') + "</div>" + "</div>";
      }).join("");
      qsa(".sc-resale-buy", $("storeGrid")).forEach(function(btn) {
        btn.addEventListener("click", function() {
          supabase.rpc("buy_resale_item", {
            p_listing_id: btn.getAttribute("data-id")
          }).then(function(res2) {
            if (res2.error) {
              showErrorAlert(res2.error.message);
              return;
            }
            toast(t("shop.toast_bought"));
            refreshWalletDisplay();
            loadResaleGrid();
          });
        });
      });
      qsa(".sc-resale-cancel", $("storeGrid")).forEach(function(btn) {
        btn.addEventListener("click", function() {
          supabase.rpc("cancel_resale_listing", {
            p_listing_id: btn.getAttribute("data-id")
          }).then(function(res2) {
            if (res2.error) {
              showErrorAlert(res2.error.message);
              return;
            }
            toast(t("shop.toast_unlisted"));
            loadResaleGrid();
          });
        });
      });
    });
  });
}

function refreshWalletDisplay() {
  if (!currentUser) return;
  supabase.rpc("rpc_get_my_wallet").then(function(res) {
    var row = res.data && res.data[0];
    if (res.error || !row) return;
    currentUser.starsBalance = row.stars_balance;
    currentUser.coinBalance = row.coin_balance;
    $("storeWallet").innerHTML = coinIconHtml("stars") + " " + row.stars_balance + "   " + coinIconHtml("coin") + " " + row.coin_balance;
  });
}

function loadStoreOwnership() {
  if (!currentUser) return Promise.resolve();
  return Promise.all([ supabase.from("user_frames").select("frame_id").eq("user_id", currentUser.id), supabase.from("user_chat_bubbles").select("bubble_id").eq("user_id", currentUser.id) ]).then(function(results) {
    STORE_MY_FRAME_IDS = (results[0].data || []).map(function(r) {
      return r.frame_id;
    });
    STORE_MY_BUBBLE_IDS = (results[1].data || []).map(function(r) {
      return r.bubble_id;
    });
  });
}

function loadStoreGrid() {
  var grid = $("storeGrid");
  grid.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  var table = STORE_TAB === "frames" ? "frames" : "chat_bubbles";
  return supabase.from(table).select("*").eq("status", "published").gt("store_stock", 0).order("created_at", {
    ascending: false
  }).then(function(res) {
    STORE_ITEMS = res.error ? [] : res.data || [];
    renderStoreGridFromCache();
  });
}

function renderStoreGridFromCache() {
  var grid = $("storeGrid");
  var list = STORE_ITEMS.slice();
  if (STORE_SORT === "gratis") {
    list = list.filter(function(i) {
      return i.is_free;
    });
  } else if (STORE_SORT === "reciente") {
    list.sort(function(a, b) {
      return new Date(b.created_at) - new Date(a.created_at);
    });
  } else if (STORE_SORT === "precio") {
    list.sort(function(a, b) {
      var pa = a.is_free ? 0 : a.price_stars || a.price_coin || 0;
      var pb = b.is_free ? 0 : b.price_stars || b.price_coin || 0;
      return pa - pb;
    });
  } else {
    list.sort(function(a, b) {
      return (b.minted_count || 0) - (a.minted_count || 0);
    });
  }
  $("storeEmpty").hidden = !!list.length;
  grid.innerHTML = list.map(storeCardHtml).join("");
  qsa(".store-card", grid).forEach(function(card) {
    card.addEventListener("click", function() {
      openStoreDetail(card.getAttribute("data-id"));
    });
  });
}

function storeCardHtml(item) {
  var owned = STORE_TAB === "frames" ? STORE_MY_FRAME_IDS.indexOf(item.id) > -1 : STORE_MY_BUBBLE_IDS.indexOf(item.id) > -1;
  if (currentUser && currentUser.id === item.creator_id && (item.creator_stock || 0) > 0) owned = true;
  var soldOut = (item.store_stock || 0) <= 0;
  var priceHtml;
  if (item.is_free) priceHtml = '<span class="store-card-price store-card-free">GRATIS</span>'; else {
    var bits = [];
    if (item.price_stars) bits.push(coinIconHtml("stars") + " " + item.price_stars);
    if (item.price_coin) bits.push(coinIconHtml("coin") + " " + item.price_coin);
    priceHtml = '<span class="store-card-price">' + (bits.join(" / ") || "—") + "</span>";
  }
  return '<div class="community-card store-card" data-id="' + escapeHtml(item.id) + '">' + '<div class="community-card-banner" style="background-image:url(&quot;' + escapeHtml(item.thumbnail_url || "") + '&quot;)">' + (owned ? '<span class="store-card-owned-tag">Tuyo</span>' : "") + (soldOut ? '<span class="store-card-soldout-tag">Agotado</span>' : "") + "</div>" + '<div class="community-card-name">' + escapeHtml(item.name) + "</div>" + '<div class="store-card-foot">' + priceHtml + '<span class="store-card-supply">' + item.minted_count + "/" + item.max_supply + "</span></div>" + "</div>";
}

function openStoreDetail(itemId) {
  var item = STORE_ITEMS.filter(function(i) {
    return i.id === itemId;
  })[0];
  if (!item) return;
  activatePanel("panel-store-detail");
  if (STORE_TAB === "frames") renderFrameDetail(item); else renderBubbleDetail(item);
}

function openStoreFrameById(frameId) {
  STORE_TAB = "frames";
  $("storeTabFrames").classList.add("active");
  $("storeTabBubbles").classList.remove("active");
  activatePanel("panel-store");
  refreshWalletDisplay();
  loadStoreOwnership().then(function() {
    loadStoreGrid();
    return supabase.from("frames").select("*").eq("id", frameId).single();
  }).then(function(res) {
    if (res.error || !res.data) {
      toast(t("shop.err_frame_not_found"));
      loadStoreGrid();
      return;
    }
    var item = res.data;
    STORE_ITEMS = [ item ];
    activatePanel("panel-store-detail");
    renderFrameDetail(item);
  });
}

function openStoreBubbleById(bubbleId) {
  STORE_TAB = "bubbles";
  $("storeTabFrames").classList.remove("active");
  $("storeTabBubbles").classList.add("active");
  activatePanel("panel-store");
  refreshWalletDisplay();
  loadStoreOwnership().then(function() {
    loadStoreGrid();
    return supabase.from("chat_bubbles").select("*").eq("id", bubbleId).single();
  }).then(function(res) {
    if (res.error || !res.data) {
      toast(t("shop.err_bubble_not_found"));
      loadStoreGrid();
      return;
    }
    var item = res.data;
    STORE_ITEMS = [ item ];
    activatePanel("panel-store-detail");
    renderBubbleDetail(item);
  });
}

function frameDetailStageHtml(item) {
  var hasBg = !!item.background_url;
  var bg;
  if (hasBg) {
    bg = item.background_type === "video" ? '<video class="frame-detail-bg" src="' + escapeHtml(item.background_url) + '" autoplay loop muted playsinline></video>' : '<div class="frame-detail-bg" style="background-image:url(&quot;' + escapeHtml(item.background_url) + '&quot;)"></div>';
  } else {
    bg = '<div class="frame-detail-bg frame-detail-bg-default"></div>';
  }
  var pedestal = '<div class="frame-detail-pedestal' + (item.pedestal_url ? "" : " frame-detail-pedestal-default") + '"' + (item.pedestal_url ? ' style="background-image:url(&quot;' + escapeHtml(item.pedestal_url) + '&quot;)"' : "") + "></div>";
  var frame = item.frame_png_url ? '<div class="frame-detail-frame" style="background-image:url(&quot;' + escapeHtml(item.frame_png_url) + '&quot;)"></div>' : "";
  return bg + pedestal + frame;
}

function frameDetailFullHtml(item, owned, soldOut, isCreation) {
  var backSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>';
  var label = owned ? "Equipar" : soldOut ? "Agotado" : item.is_free ? "Obtener gratis" : "Comprar";
  return '<div class="frame-detail-shell frame-detail-full">' + '<div class="frame-detail-stage frame-detail-stage-nft">' + frameDetailStageHtml(item) + "</div>" + '<div class="frame-detail-top">' + '<button class="icon-btn" id="btnStoreDetailBack" type="button" aria-label="Volver">' + backSvg + "</button>" + '<div class="frame-detail-creator" id="frameDetailCreator"><p class="profile-empty-hint">Cargando creador...</p></div>' + "</div>" + '<div class="frame-detail-bottom">' + '<h3 class="frame-detail-name">' + escapeHtml(item.name) + "</h3>" + '<div class="frame-detail-foot">' + '<button class="terminal-btn" id="btnStoreDetailAction" type="button">' + label + "</button>" + (owned && !isCreation ? '<button class="terminal-btn" id="btnStoreDetailResell" type="button">Revender</button>' : "") + "</div>" + "</div>" + "</div>";
}

function renderFrameDetail(item) {
  var owned = STORE_MY_FRAME_IDS.indexOf(item.id) > -1;
  var isCreation = !!(currentUser && currentUser.id === item.creator_id && (item.creator_stock || 0) > 0);
  if (isCreation) owned = true;
  var soldOut = (item.store_stock || 0) <= 0;
  $("storeDetail").innerHTML = frameDetailFullHtml(item, owned, soldOut, isCreation);
  document.body.classList.add("frame-immersive");
  supabase.from("profiles").select("username, avatar_url").eq("id", item.creator_id).single().then(function(res) {
    var p = res.data || {
      username: "usuario"
    };
    var isOwner = !!(currentUser && currentUser.id === item.creator_id);
    $("frameDetailCreator").innerHTML = avatarSpanHtml(p.username, p.avatar_url, "avatar-md", item.creator_id) + '<div class="social-list-row-info"><div class="social-list-row-name">' + escapeHtml(p.username) + "</div></div>" + (typeof kebabMenuHtml === "function" ? kebabMenuHtml("frame", item.id, isOwner) : "");
  });
  $("btnStoreDetailBack").addEventListener("click", function() {
    activatePanel("panel-store");
  });
  wireStoreActionButton(item, "frame", owned, soldOut, isCreation);
  var resellBtnEl = $("btnStoreDetailResell");
  if (resellBtnEl) resellBtnEl.addEventListener("click", function() {
    openResellModal("frame", item);
  });
}

function renderBubbleDetail(item) {
  document.body.classList.remove("frame-immersive");
  var owned = STORE_MY_BUBBLE_IDS.indexOf(item.id) > -1;
  var isCreation = !!(currentUser && currentUser.id === item.creator_id && (item.creator_stock || 0) > 0);
  if (isCreation) owned = true;
  var soldOut = (item.store_stock || 0) <= 0;
  $("storeDetail").innerHTML = '<div class="frame-detail-shell">' + '<button class="icon-btn" id="btnStoreDetailBack" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + '<div class="frame-detail-creator" id="frameDetailCreator"><p class="profile-empty-hint">Cargando creador...</p></div>' + '<div class="frame-detail-stage bubble-detail-stage">' + '<div class="chat-bubble-preview-msg" style="border-image-source:url(&quot;' + escapeHtml(item.bubble_png_url || "") + '&quot;)">Así se ve tu burbuja</div>' + "</div>" + '<h3 class="frame-detail-name">' + escapeHtml(item.name) + "</h3>" + '<div class="frame-detail-foot">' + '<button class="terminal-btn" id="btnStoreDetailAction" type="button">' + (owned ? "Equipar" : soldOut ? "Agotado" : item.is_free ? "Obtener gratis" : "Comprar") + "</button>" + '<button class="terminal-btn" id="btnBubblePreview" type="button">Ver cómo se vería</button>' + (owned && !isCreation ? '<button class="terminal-btn" id="btnStoreDetailResell" type="button">Revender</button>' : "") + "</div>" + "</div>";
  supabase.from("profiles").select("username, avatar_url").eq("id", item.creator_id).single().then(function(res) {
    var p = res.data || {
      username: "usuario"
    };
    var isOwnerBubble = !!(currentUser && currentUser.id === item.creator_id);
    $("frameDetailCreator").innerHTML = avatarSpanHtml(p.username, p.avatar_url, "avatar-md", item.creator_id) + '<div class="social-list-row-info"><div class="social-list-row-name">' + escapeHtml(p.username) + "</div></div>" + (typeof kebabMenuHtml === "function" ? kebabMenuHtml("bubble", item.id, isOwnerBubble) : "");
  });
  $("btnStoreDetailBack").addEventListener("click", function() {
    activatePanel("panel-store");
  });
  wireStoreActionButton(item, "bubble", owned, soldOut, isCreation);
  $("btnBubblePreview").addEventListener("click", function() {
    openBubblePreview(item);
  });
  var resellBtnBubbleEl = $("btnStoreDetailResell");
  if (resellBtnBubbleEl) resellBtnBubbleEl.addEventListener("click", function() {
    openResellModal("bubble", item);
  });
}

function wireStoreActionButton(item, type, owned, soldOut, isCreation) {
  var btn = $("btnStoreDetailAction");
  if (owned) {
    btn.addEventListener("click", function() {
      equipStoreItem(item, type, isCreation);
    });
    return;
  }
  if (soldOut) {
    btn.disabled = true;
    return;
  }
  btn.addEventListener("click", function() {
    var currency = item.is_free ? null : item.price_stars ? "stars" : "coin";
    supabase.rpc("purchase_item", {
      p_item_type: type,
      p_item_id: item.id,
      p_currency: currency
    }).then(function(res) {
      if (res.error) {
        showErrorAlert("No se pudo completar la compra (revisa tu saldo o si ya se agotó). " + res.error.message);
        return;
      }
      toast(t("shop.toast_yours"));
      loadStoreOwnership().then(function() {
        openStoreDetail(item.id);
        refreshWalletDisplay();
      });
    });
  });
}

function equipStoreItem(item, type, isCreation) {
  var table = type === "frame" ? "user_frames" : "user_chat_bubbles";
  var col = type === "frame" ? "frame_id" : "bubble_id";
  var ensureOwned = isCreation ? supabase.rpc("claim_own_creation", {
    p_item_type: type,
    p_item_id: item.id
  }) : Promise.resolve({
    error: null
  });
  ensureOwned.then(function(claimRes) {
    if (claimRes && claimRes.error) {
      toast(t("shop.err_no_stock"));
      return;
    }
    supabase.from(table).update({
      equipped: false
    }).eq("user_id", currentUser.id).then(function() {
      supabase.from(table).update({
        equipped: true
      }).eq("user_id", currentUser.id).eq(col, item.id).select().then(function(res) {
        if (res.error || !res.data || !res.data.length) {
          toast(t("shop.err_equip"));
          return;
        }
        toast(t("shop.toast_equipped"));
        if (type === "frame") {
          if (typeof loadProfileAvatarFrame === "function") loadProfileAvatarFrame(currentUser.id);
          var url = item.frame_png_url || null;
          frameCache[currentUser.id] = url;
          applyFrameToDom(currentUser.id, url);
        } else {
          var burl = item.bubble_png_url || null;
          bubbleCache[currentUser.id] = burl;
          applyBubbleToDom(currentUser.id, burl);
        }
      });
    });
  });
}

function shareStoreItem(item, type) {
  var url = siteOrigin() + location.pathname + "#" + type + "=" + item.id;
  if (navigator.share) {
    navigator.share({
      title: item.name,
      url: url
    }).catch(function() {});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(url).then(function() {
      toast(t("shop.toast_link_copied"));
    });
  } else toast(url);
}

function openBubblePreview(item) {
  var demoTexts = [ "Hola! 👋", "Mira cómo se estira esta burbuja cuando escribo bastante texto, se ve bien padre la verdad" ];
  var html = '<div class="bubble-preview-chat">' + demoTexts.map(function(t, i) {
    return '<div class="bubble-preview-row' + (i % 2 ? " me" : "") + '"><span class="chat-bubble-preview-msg" style="border-image-source:url(&quot;' + escapeHtml(item.bubble_png_url || "") + '&quot;)">' + escapeHtml(t) + "</span></div>";
  }).join("") + '<div class="bubble-preview-row me"><textarea id="bubblePreviewInput" placeholder="Escribe algo para probar..." rows="1"></textarea></div>' + '<div class="bubble-preview-row me"><span class="chat-bubble-preview-msg" id="bubblePreviewLive" style="border-image-source:url(&quot;' + escapeHtml(item.bubble_png_url || "") + '&quot;)"></span></div>' + "</div>";
  $("storeDetail").insertAdjacentHTML("beforeend", '<div class="modal-backdrop open" id="bubblePreviewBackdrop"><div class="modal"><div class="modal-head"><h3>Vista previa</h3><button class="icon-btn" id="bubblePreviewClose" type="button">✕</button></div><div class="profile-body">' + html + "</div></div></div>");
  $("bubblePreviewClose").addEventListener("click", function() {
    $("bubblePreviewBackdrop").remove();
  });
  $("bubblePreviewInput").addEventListener("input", function() {
    $("bubblePreviewLive").textContent = this.value;
  });
}

$("btnMyStoreNewFrame").addEventListener("click", function() {
  openStoreCreate("frame");
});

$("btnMyStoreNewBubble").addEventListener("click", function() {
  openStoreCreate("bubble");
});

$("storeCreateClose").addEventListener("click", function() {
  $("storeCreateBackdrop").classList.remove("open");
});

$("storeCreateBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

var SC_STEPS_FRAME = [ "name", "background", "frame", "pedestal", "price" ];

var SC_STEPS_BUBBLE = [ "name", "bubble", "price" ];

var scDraft = null;

var scStep = 0;

var scUploading = false;

function scSteps() {
  return scDraft.type === "frame" ? SC_STEPS_FRAME : SC_STEPS_BUBBLE;
}

function openStoreCreate(type) {
  scDraft = {
    type: type,
    name: "",
    thumbnail_url: null,
    flagTexts: [],
    frame_png_url: null,
    background_url: null,
    background_type: "image",
    pedestal_url: null,
    bubble_png_url: null,
    is_free: false,
    price_stars: null,
    price_coin: null
  };
  scStep = 0;
  flagFieldSet("scFlag", []);
  $("storeCreateTitle").textContent = type === "frame" ? "Nuevo marco" : "Nueva burbuja";
  if (typeof refreshFlagOptionsList === "function") refreshFlagOptionsList();
  renderScStep();
  $("storeCreateBackdrop").classList.add("open");
}

function openStoreEdit(type, item) {
  scDraft = {
    id: item.id,
    type: type,
    name: item.name || "",
    thumbnail_url: item.thumbnail_url || null,
    flagTexts: [],
    frame_png_url: item.frame_png_url || null,
    background_url: item.background_url || null,
    background_type: item.background_type || "image",
    pedestal_url: item.pedestal_url || null,
    bubble_png_url: item.bubble_png_url || null,
    is_free: !!item.is_free,
    price_stars: item.price_stars || null,
    price_coin: item.price_coin || null
  };
  scStep = 0;
  flagFieldSet("scFlag", []);
  var editDraft = scDraft;
  loadEntityFlagTexts(type, item.id).then(function(rows) {
    if (scDraft !== editDraft) return;
    var texts = rows.map(function(r) {
      return r.flags.display_text;
    });
    scDraft.flagTexts = texts;
    scDraft.flagsLoaded = true;
    flagFieldSet("scFlag", texts);
  });
  $("storeCreateTitle").textContent = type === "frame" ? "Editar marco" : "Editar burbuja";
  if (typeof refreshFlagOptionsList === "function") refreshFlagOptionsList();
  renderScStep();
  $("storeCreateBackdrop").classList.add("open");
}

function scLayerAttrs(part, activeKey, hint) {
  return part === activeKey ? ' data-sc-part="' + part + '" title="' + hint + '"' : "";
}

function scLayerClass(base, part, activeKey) {
  return part === activeKey ? base + " sc-tap-target" : base;
}

function scStagePreviewHtml(activeKey) {
  if (scDraft.type === "frame") {
    var bg;
    if (scDraft.background_url) {
      var bgCls = scLayerClass("frame-detail-bg", "background", activeKey);
      var bgAttrs = scLayerAttrs("background", activeKey, "Toca para cambiar el fondo");
      bg = scDraft.background_type === "video" ? '<video src="' + escapeHtml(scDraft.background_url) + '" autoplay loop muted playsinline class="' + bgCls + '"' + bgAttrs + "></video>" : '<div class="' + bgCls + '"' + bgAttrs + ' style="background-image:url(&quot;' + escapeHtml(scDraft.background_url) + '&quot;)"></div>';
    } else {
      var bgEmptyCls = scLayerClass("frame-detail-bg sc-empty-bg", "background", activeKey);
      bg = '<div class="' + bgEmptyCls + '"' + scLayerAttrs("background", activeKey, "Toca para subir el fondo") + ">" + (activeKey === "background" ? "+ Toca para subir el fondo" : "Fondo") + "</div>";
    }
    var pedestal = "";
    if (scDraft.pedestal_url) {
      pedestal = '<div class="' + scLayerClass("frame-detail-pedestal", "pedestal", activeKey) + '"' + scLayerAttrs("pedestal", activeKey, "Toca para cambiar el pedestal") + ' style="background-image:url(&quot;' + escapeHtml(scDraft.pedestal_url) + '&quot;)"></div>';
    } else if (activeKey === "pedestal") {
      pedestal = '<div class="frame-detail-pedestal sc-empty-layer sc-tap-target"' + scLayerAttrs("pedestal", activeKey, "Toca para subir el pedestal") + ">+ Pedestal (opcional)</div>";
    }
    var frame = "";
    if (scDraft.frame_png_url) {
      frame = '<div class="' + scLayerClass("frame-detail-frame", "frame", activeKey) + '"' + scLayerAttrs("frame", activeKey, "Toca para cambiar el marco") + ' style="background-image:url(&quot;' + escapeHtml(scDraft.frame_png_url) + '&quot;)"></div>';
    } else if (activeKey === "frame") {
      frame = '<div class="frame-detail-frame sc-empty-layer sc-tap-target"' + scLayerAttrs("frame", activeKey, "Toca para subir el marco") + ">+ Toca para subir el marco</div>";
    }
    return '<div class="frame-detail-stage sc-stage">' + bg + pedestal + frame + "</div>";
  }
  var bubbleCls = scLayerClass("chat-bubble-preview-msg", "bubble", activeKey);
  var bubbleAttrs = scLayerAttrs("bubble", activeKey, "Toca para subir la burbuja");
  var bubbleText = scDraft.name || (activeKey === "bubble" ? "+ Toca para subir la burbuja" : "Así se ve tu burbuja");
  return '<div class="frame-detail-stage bubble-detail-stage sc-stage">' + '<span class="' + bubbleCls + '"' + bubbleAttrs + ' style="border-image-source:url(&quot;' + escapeHtml(scDraft.bubble_png_url || "") + '&quot;)">' + escapeHtml(bubbleText) + "</span>" + "</div>";
}

var SC_PART_MAP = {
  background: {
    field: "background_url",
    prefix: "store-frame-bg"
  },
  frame: {
    field: "frame_png_url",
    prefix: "store-frame-png",
    accept: "image/png,image/apng,image/gif,image/webp,image/avif,.png,.apng,.gif,.webp,.avif"
  },
  pedestal: {
    field: "pedestal_url",
    prefix: "store-pedestal"
  },
  bubble: {
    field: "bubble_png_url",
    prefix: "store-bubble"
  },
  thumbnail: {
    field: "thumbnail_url",
    prefix: "store-thumbs"
  }
};

function scUploadTo(field, file, prefix) {
  if (!file) return;
  if (field === "frame_png_url" && typeof sniffImageInfo === "function") {
    sniffImageInfo(file).then(function(info) {
      if (info && info.mime === "image/jpeg") toast("Ese archivo es JPG: no tiene transparencia ni animación. Usa PNG, GIF, WebP o AVIF.");
    });
  }
  scUploading = true;
  var holder = document.getElementById("scUploadStatus");
  if (holder) holder.innerHTML = 'Subiendo...<span class="sc-progress-bar"><span class="sc-progress-bar-fill"></span></span>';
  scSetNextDisabled(true);
  uploadFiles([ file ], prefix).then(function(uploaded) {
    scDraft[field] = uploaded[0].url;
    scUploading = false;
    renderScStep();
  }).catch(function() {
    scUploading = false;
    if (holder) holder.textContent = "No se pudo subir, intenta de nuevo.";
    scSetNextDisabled(false);
  });
}

function scSetNextDisabled(disabled) {
  var btn = $("scNextBtn");
  if (btn) btn.disabled = disabled;
}

function renderScStep() {
  var steps = scSteps();
  var key = steps[scStep];
  var body = $("storeCreateBody");
  var fieldHtml = "";
  if (key === "name") {
    var thumbCls = scDraft.thumbnail_url ? "sc-thumb-tap has-img sc-tap-target" : "sc-thumb-tap sc-tap-target";
    var thumbInner = scDraft.thumbnail_url ? '<img loading=lazy decoding=async src="' + escapeHtml(scDraft.thumbnail_url) + '" alt="">' : "<span>+ Miniatura para la tienda</span>";
    fieldHtml = '<label class="field"><span>Nombre</span><input type="text" id="scName" value="' + escapeHtml(scDraft.name || "") + '" placeholder="Nombre del ' + (scDraft.type === "frame" ? "marco" : "burbuja") + '"></label>' + '<div class="' + thumbCls + '" data-sc-part="thumbnail" title="Toca para subir la miniatura">' + thumbInner + "</div>" + '' + flagFieldHtml("scFlag", "Banderas (opcional)");
  } else if (key === "background") {
    fieldHtml = '<label class="field"><span>Tipo de fondo</span><select id="scBgType"><option value="image"' + (scDraft.background_type === "image" ? " selected" : "") + '>Imagen</option><option value="video"' + (scDraft.background_type === "video" ? " selected" : "") + ">Video</option></select></label>" + '<p class="sc-tap-hint">Toca el fondo de la vista previa de arriba para subirlo.</p>';
  } else if (key === "frame") {
    fieldHtml = '<p class="sc-tap-hint">Toca la vista previa de arriba para subir el marco (PNG, APNG, GIF, WebP o AVIF, animados o no, con fondo transparente).</p>';
  } else if (key === "pedestal") {
    fieldHtml = '<p class="sc-tap-hint">Toca la vista previa de arriba para subir el pedestal (opcional).</p>';
  } else if (key === "bubble") {
    fieldHtml = '<p class="sc-tap-hint">Toca la vista previa de arriba para subir la imagen de la burbuja.</p>';
  } else if (key === "price") {
    fieldHtml = '<label class="field checkbox-field"><input type="checkbox" id="scIsFree" ' + (scDraft.is_free ? "checked" : "") + "> <span>Es gratis</span></label>" + '<label class="field"><span>Precio en Diamantes (opcional)</span><input type="number" id="scPriceStars" min="0" value="' + (scDraft.price_stars || "") + '"></label>' + '<label class="field"><span>Precio en Z-Coins (opcional)</span><input type="number" id="scPriceCoin" min="0" value="' + (scDraft.price_coin || "") + '"></label>' + '<p class="sc-tap-hint">Se crea sin existencias. Después, desde tu monedero o tocando "Acuñar" en tu creación, eliges cuántas unidades acuñar.</p>';
  }
  body.innerHTML = '<div class="sc-progress">Paso ' + (scStep + 1) + " de " + steps.length + "</div>" + scStagePreviewHtml(key) + '<p class="sc-upload-status" id="scUploadStatus"></p>' + fieldHtml + '<input type="file" id="scHiddenFile" class="sc-hidden-file">' + '<div class="sc-nav">' + (scStep > 0 ? '<button type="button" class="terminal-btn" id="scPrevBtn">Atrás</button>' : "") + '<button type="button" class="terminal-btn" id="scNextBtn"' + (scUploading ? " disabled" : "") + ">" + (scStep === steps.length - 1 ? scDraft.id ? "Guardar" : "Crear" : "Siguiente") + "</button>" + "</div>";
  if ($("scPrevBtn")) $("scPrevBtn").addEventListener("click", function() {
    scStep--;
    renderScStep();
  });
  $("scNextBtn").addEventListener("click", function() {
    handleScNext(key, steps);
  });
  if (key === "background" && $("scBgType")) $("scBgType").addEventListener("change", function() {
    scDraft.background_type = this.value;
    renderScStep();
  });
  var hiddenFile = $("scHiddenFile");
  qsa(".sc-tap-target", body).forEach(function(el) {
    el.addEventListener("click", function() {
      if (scUploading) {
        toast(t("shop.err_wait_upload"));
        return;
      }
      var part = el.getAttribute("data-sc-part");
      var conf = SC_PART_MAP[part];
      if (!conf) return;
      hiddenFile.accept = conf.accept || (part === "background" && scDraft.background_type === "video" ? "image/*,video/*" : "image/*");
      hiddenFile.onchange = function() {
        scUploadTo(conf.field, hiddenFile.files[0], conf.prefix);
      };
      hiddenFile.click();
    });
  });
}

function handleScNext(key, steps) {
  if (scUploading) {
    toast(t("shop.err_wait_upload"));
    return;
  }
  if (key === "name") {
    var v = $("scName").value.trim();
    if (!v) {
      toast(t("shop.err_name_needed"));
      return;
    }
    scDraft.name = v;
    scDraft.flagTexts = flagFieldGet("scFlag");
  } else if (key === "price") {
    scDraft.is_free = $("scIsFree").checked;
    scDraft.price_stars = parseInt($("scPriceStars").value, 10) || null;
    scDraft.price_coin = parseInt($("scPriceCoin").value, 10) || null;
  }
  if (scStep === steps.length - 1) {
    finalizeScCreate();
    return;
  }
  scStep++;
  renderScStep();
}

function finalizeScCreate() {
  var payload = {
    name: scDraft.name,
    thumbnail_url: scDraft.thumbnail_url,
    is_free: scDraft.is_free,
    price_stars: scDraft.price_stars,
    price_coin: scDraft.price_coin
  };
  var table;
  if (scDraft.type === "frame") {
    table = "frames";
    payload.frame_png_url = scDraft.frame_png_url;
    payload.background_url = scDraft.background_url;
    payload.background_type = scDraft.background_type;
    payload.pedestal_url = scDraft.pedestal_url;
  } else {
    table = "chat_bubbles";
    payload.bubble_png_url = scDraft.bubble_png_url;
  }
  if (scDraft.id) {
    supabase.from(table).update(payload).eq("id", scDraft.id).select().single().then(function(res) {
      if (res.error) {
        toast(t("shop.err_save") + " " + res.error.message);
        return;
      }
      if (scDraft.flagsLoaded) syncEntityFlags(scDraft.type, scDraft.id, scDraft.flagTexts || []); else if (scDraft.flagTexts && scDraft.flagTexts.length) tagEntityWithFlags(scDraft.flagTexts, scDraft.type, scDraft.id);
      toast(t("shop.toast_saved"));
      $("storeCreateBackdrop").classList.remove("open");
      loadMyStore();
      loadStoreGrid();
    });
    return;
  }
  payload.creator_id = currentUser.id;
  payload.status = "draft";
  payload.max_supply = 0;
  payload.creator_stock = 0;
  supabase.from(table).insert(payload).select().single().then(function(res) {
    if (res.error) {
      toast(t("shop.err_create"));
      return;
    }
    if (scDraft.flagTexts && scDraft.flagTexts.length) tagEntityWithFlags(scDraft.flagTexts, scDraft.type, res.data.id);
    toast(t("shop.toast_created"));
    $("storeCreateBackdrop").classList.remove("open");
    loadMintableItems();
  });
}

function openWalletPanel() {
  activatePanel("panel-wallet");
  loadWalletScreen();
  if (!state.suppressPush) {
    history.pushState({
      view: "wallet"
    }, "", "/monedero");
  }
  state.suppressPush = false;
}

$("storeWallet").addEventListener("click", openWalletPanel);

$("btnStoreRecharge").addEventListener("click", function() {
  if (!currentUser) {
    toast(t("shop.err_login_first"));
    return;
  }
  openRechargeModal();
});

$("btnWalletBack").addEventListener("click", function() {
  goBack("panel-store");
});

var COLLECTION_SORT = "recent";

var COLLECTION_ENTRIES = [];

function sortCollectionEntries(entries, mode) {
  var arr = entries.slice();
  if (mode === "name") {
    arr.sort(function(a, b) {
      return (a.name || "").localeCompare(b.name || "", "es", {
        sensitivity: "base"
      });
    });
  } else if (mode === "oldest") {
    arr.sort(function(a, b) {
      return new Date(a.acquired_at) - new Date(b.acquired_at);
    });
  } else if (mode === "equipped_time") {
    arr.sort(function(a, b) {
      if (a.equipped !== b.equipped) return a.equipped ? -1 : 1;
      return new Date(a.acquired_at) - new Date(b.acquired_at);
    });
  } else {
    arr.sort(function(a, b) {
      return new Date(b.acquired_at) - new Date(a.acquired_at);
    });
  }
  return arr;
}

function renderMyCollection() {
  var sorted = sortCollectionEntries(COLLECTION_ENTRIES, COLLECTION_SORT);
  $("myCollectionEmpty").hidden = sorted.length > 0;
  $("myCollectionList").innerHTML = sorted.map(function(e, i) {
    var typeLabel = e.type === "frame" ? "Marco" : "Burbuja";
    var when = new Date(e.acquired_at).toLocaleDateString("es", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
    return '<button type="button" class="social-list-row" data-idx="' + i + '">' + '<span class="collection-row-thumb" style="background-image:url(&quot;' + escapeHtml(e.thumb || "") + '&quot;)"></span>' + '<div class="social-list-row-info">' + '<div class="social-list-row-name">' + escapeHtml(e.name || "") + (e.equipped ? ' · <span style="color:#a855f7">Equipado</span>' : "") + "</div>" + '<div class="collection-row-meta">' + typeLabel + " · Obtenido el " + when + "</div>" + "</div>" + "</button>";
  }).join("");
  qsa(".social-list-row", $("myCollectionList")).forEach(function(btn) {
    btn.addEventListener("click", function() {
      var e = sorted[parseInt(btn.getAttribute("data-idx"), 10)];
      if (!e) return;
      if (e.type === "frame") openStoreFrameById(e.id); else openStoreBubbleById(e.id);
    });
  });
}

function loadMyCollection() {
  activatePanel("panel-my-collection");
  $("collectionFilterDropdown").hidden = true;
  $("myCollectionList").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  Promise.all([ supabase.from("user_frames").select("frame_id, equipped, acquired_at, frames(id, name, thumbnail_url)").eq("user_id", currentUser.id), supabase.from("user_chat_bubbles").select("bubble_id, equipped, acquired_at, chat_bubbles(id, name, thumbnail_url)").eq("user_id", currentUser.id), supabase.from("frames").select("id, name, thumbnail_url, created_at").eq("creator_id", currentUser.id).gt("creator_stock", 0), supabase.from("chat_bubbles").select("id, name, thumbnail_url, created_at").eq("creator_id", currentUser.id).gt("creator_stock", 0) ]).then(function(results) {
    var frameRows = results[0].data || [];
    var bubbleRows = results[1].data || [];
    var ownFrames = results[2].data || [];
    var ownBubbles = results[3].data || [];
    COLLECTION_ENTRIES = frameRows.filter(function(r) {
      return r.frames;
    }).map(function(r) {
      return {
        type: "frame",
        id: r.frame_id,
        name: r.frames.name,
        thumb: r.frames.thumbnail_url,
        equipped: !!r.equipped,
        acquired_at: r.acquired_at
      };
    }).concat(bubbleRows.filter(function(r) {
      return r.chat_bubbles;
    }).map(function(r) {
      return {
        type: "bubble",
        id: r.bubble_id,
        name: r.chat_bubbles.name,
        thumb: r.chat_bubbles.thumbnail_url,
        equipped: !!r.equipped,
        acquired_at: r.acquired_at
      };
    }));
    ownFrames.forEach(function(f) {
      if (COLLECTION_ENTRIES.some(function(e) {
        return e.type === "frame" && e.id === f.id;
      })) return;
      COLLECTION_ENTRIES.push({
        type: "frame",
        id: f.id,
        name: f.name,
        thumb: f.thumbnail_url,
        equipped: false,
        acquired_at: f.created_at,
        isCreation: true
      });
    });
    ownBubbles.forEach(function(b) {
      if (COLLECTION_ENTRIES.some(function(e) {
        return e.type === "bubble" && e.id === b.id;
      })) return;
      COLLECTION_ENTRIES.push({
        type: "bubble",
        id: b.id,
        name: b.name,
        thumb: b.thumbnail_url,
        equipped: false,
        acquired_at: b.created_at,
        isCreation: true
      });
    });
    renderMyCollection();
  });
}

$("btnOpenMyCollection").addEventListener("click", loadMyCollection);

$("btnMyCollectionBack").addEventListener("click", function() {
  goBack("panel-wallet");
});

$("btnMyCollectionFilter").addEventListener("click", function(e) {
  e.stopPropagation();
  $("collectionFilterDropdown").hidden = !$("collectionFilterDropdown").hidden;
});

qsa(".collection-filter-opt", $("collectionFilterDropdown")).forEach(function(btn) {
  btn.addEventListener("click", function() {
    COLLECTION_SORT = btn.getAttribute("data-sort");
    qsa(".collection-filter-opt", $("collectionFilterDropdown")).forEach(function(b) {
      b.classList.toggle("active", b === btn);
    });
    $("collectionFilterDropdown").hidden = true;
    renderMyCollection();
  });
});

document.addEventListener("click", function() {
  $("collectionFilterDropdown").hidden = true;
});

function loadWalletScreen() {
  if (!currentUser) return;
  supabase.rpc("rpc_get_my_wallet").then(function(res) {
    var row = res.data && res.data[0];
    if (res.error || !row) return;
    $("walletStars").textContent = row.stars_balance;
    $("walletCoin").textContent = row.coin_balance;
    $("walletSellerStars").textContent = row.seller_stars_earned || 0;
    $("walletSellerCoin").textContent = row.seller_coin_earned || 0;
  });
  Promise.all([ supabase.from("user_frames").select("frame_id, equipped, frames(id, name, thumbnail_url, frame_png_url)").eq("user_id", currentUser.id), supabase.from("user_chat_bubbles").select("bubble_id, equipped, chat_bubbles(id, name, thumbnail_url, bubble_png_url)").eq("user_id", currentUser.id), supabase.from("frames").select("id, name, thumbnail_url, frame_png_url").eq("creator_id", currentUser.id).gt("creator_stock", 0), supabase.from("chat_bubbles").select("id, name, thumbnail_url, bubble_png_url").eq("creator_id", currentUser.id).gt("creator_stock", 0) ]).then(function(results) {
    var frameRows = results[0].data || [];
    var bubbleRows = results[1].data || [];
    var ownFrames = results[2].data || [];
    var ownBubbles = results[3].data || [];
    var entries = frameRows.filter(function(r) {
      return r.frames;
    }).map(function(r) {
      return {
        type: "frame",
        equipped: !!r.equipped,
        name: r.frames.name,
        thumb: r.frames.thumbnail_url,
        item: {
          id: r.frame_id,
          name: r.frames.name,
          frame_png_url: r.frames.frame_png_url
        }
      };
    }).concat(bubbleRows.filter(function(r) {
      return r.chat_bubbles;
    }).map(function(r) {
      return {
        type: "bubble",
        equipped: !!r.equipped,
        name: r.chat_bubbles.name,
        thumb: r.chat_bubbles.thumbnail_url,
        item: {
          id: r.bubble_id,
          name: r.chat_bubbles.name,
          bubble_png_url: r.chat_bubbles.bubble_png_url
        }
      };
    }));
    ownFrames.forEach(function(f) {
      if (entries.some(function(e) {
        return e.type === "frame" && e.item.id === f.id;
      })) return;
      entries.push({
        type: "frame",
        equipped: false,
        name: f.name,
        thumb: f.thumbnail_url,
        item: {
          id: f.id,
          name: f.name,
          frame_png_url: f.frame_png_url
        }
      });
    });
    ownBubbles.forEach(function(b) {
      if (entries.some(function(e) {
        return e.type === "bubble" && e.item.id === b.id;
      })) return;
      entries.push({
        type: "bubble",
        equipped: false,
        name: b.name,
        thumb: b.thumbnail_url,
        item: {
          id: b.id,
          name: b.name,
          bubble_png_url: b.bubble_png_url
        }
      });
    });
    $("walletItemsCount").textContent = entries.length;
    $("walletItemsStrip").innerHTML = entries.map(function(e, i) {
      return '<button type="button" class="wallet-item-thumb' + (e.equipped ? " equipped" : "") + '" data-idx="' + i + '" title="' + escapeHtml(e.name || "") + (e.equipped ? " (equipado)" : " — toca para equipar") + '" style="background-image:url(&quot;' + escapeHtml(e.thumb || "") + '&quot;)"></button>';
    }).join("") || '<p class="profile-empty-hint">Aún no tienes marcos ni burbujas.</p>';
    qsa(".wallet-item-thumb", $("walletItemsStrip")).forEach(function(btn) {
      btn.addEventListener("click", function() {
        var e = entries[parseInt(btn.getAttribute("data-idx"), 10)];
        if (!e) return;
        if (e.type === "frame") openStoreFrameById(e.item.id); else openStoreBubbleById(e.item.id);
      });
    });
  });
}

var RECHARGE_CURRENCY = "stars";

function loadRechargePackages() {
  $("rechargePackages").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("currency_packages").select("*").eq("currency", RECHARGE_CURRENCY).eq("active", true).order("sort_order").then(function(res) {
    var pkgs = res.data || [];
    if (!pkgs.length) {
      $("rechargePackages").innerHTML = '<p class="profile-empty-hint">No hay paquetes disponibles ahora.</p>';
      return;
    }
    $("rechargePackages").innerHTML = pkgs.map(function(p) {
      return '<button type="button" class="admin-portal-row recharge-pkg" data-id="' + escapeHtml(p.id) + '">' + "<span>" + escapeHtml(p.label) + "</span><span>$" + Number(p.price_usd).toFixed(2) + "</span>" + "</button>";
    }).join("");
    qsa(".recharge-pkg", $("rechargePackages")).forEach(function(btn) {
      btn.addEventListener("click", function() {
        buyRechargePackage(btn.getAttribute("data-id"));
      });
    });
  });
}

function buyRechargePackage(packageId) {
  if (!currentUser) {
    toast(t("shop.err_login_first"));
    return;
  }
  toast(t("shop.toast_opening_payment"));
  supabase.auth.getSession().then(function(sessRes) {
    var token = sessRes.data && sessRes.data.session ? sessRes.data.session.access_token : null;
    if (!token) {
      toast(t("shop.err_session_expired"));
      return;
    }
    fetch(SUPABASE_URL + "/functions/v1/create-crypto-payment", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token
      },
      body: JSON.stringify({
        package_id: packageId
      })
    }).then(function(r) {
      return r.json();
    }).then(function(data) {
      if (data.error) {
        toast(t("shop.err_payment_create") + " " + data.error);
        return;
      }
      if (data.invoice_url) {
        window.open(data.invoice_url, "_blank");
        $("rechargeBackdrop").classList.remove("open");
      }
    }).catch(function() {
      showErrorAlert("No se pudo conectar con el servidor de pagos.");
    });
  });
}

function openRechargeModal() {
  RECHARGE_CURRENCY = "stars";
  $("rechargeTabStars").classList.add("active");
  $("rechargeTabCoin").classList.remove("active");
  loadRechargePackages();
  $("rechargeBackdrop").classList.add("open");
}

$("btnWalletRecharge").addEventListener("click", openRechargeModal);

$("btnRechargeClose").addEventListener("click", function() {
  $("rechargeBackdrop").classList.remove("open");
});

$("rechargeBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

$("rechargeTabStars").addEventListener("click", function() {
  RECHARGE_CURRENCY = "stars";
  $("rechargeTabStars").classList.add("active");
  $("rechargeTabCoin").classList.remove("active");
  loadRechargePackages();
});

$("rechargeTabCoin").addEventListener("click", function() {
  RECHARGE_CURRENCY = "coin";
  $("rechargeTabCoin").classList.add("active");
  $("rechargeTabStars").classList.remove("active");
  loadRechargePackages();
});

$("btnWalletGiftHistory").addEventListener("click", function() {
  activatePanel("panel-store-detail");
  $("storeDetail").innerHTML = '<div class="frame-detail-shell">' + '<button class="icon-btn" id="btnGiftHistoryBack" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + "<h3>Historial de Regalos</h3>" + '<div id="giftHistoryList"><p class="profile-empty-hint">Cargando...</p></div>' + "</div>";
  $("btnGiftHistoryBack").addEventListener("click", function() {
    activatePanel("panel-wallet");
  });
  supabase.from("gifts").select("*, sender:profiles!gifts_sender_id_fkey(username), recipient:profiles!gifts_recipient_id_fkey(username)").or("sender_id.eq." + currentUser.id + ",recipient_id.eq." + currentUser.id).order("created_at", {
    ascending: false
  }).limit(50).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    var list = $("giftHistoryList");
    if (!rows.length) {
      list.innerHTML = '<p class="profile-empty-hint">Todavía no hay regalos.</p>';
      return;
    }
    list.innerHTML = '<div class="social-list">' + rows.map(function(g) {
      var mine = g.sender_id === currentUser.id;
      var who = mine ? "a @" + (g.recipient ? g.recipient.username : "usuario") : "de @" + (g.sender ? g.sender.username : "usuario");
      var what = g.gift_type === "stars" ? coinIconHtml("stars") + " " + g.amount : g.gift_type === "coin" ? coinIconHtml("coin") + " " + g.amount : g.gift_type === "frame" ? "un marco" : "una burbuja";
      return '<div class="social-list-row"><div class="social-list-row-info"><div class="social-list-row-name">' + (mine ? "Enviaste " : "Recibiste ") + what + " " + escapeHtml(who) + "</div></div></div>";
    }).join("") + "</div>";
  });
});

$("btnWalletGoodies").addEventListener("click", function() {
  activatePanel("panel-store-detail");
  $("storeDetail").innerHTML = '<div class="frame-detail-shell">' + '<button class="icon-btn" id="btnGoodiesBack" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + "<h3>Mis Marcos y Burbujas</h3>" + '<div class="community-grid" id="goodiesGrid"><p class="profile-empty-hint">Cargando...</p></div>' + "</div>";
  $("btnGoodiesBack").addEventListener("click", function() {
    activatePanel("panel-wallet");
  });
  Promise.all([ supabase.from("user_frames").select("frame_id, equipped, frames(id, name, thumbnail_url)").eq("user_id", currentUser.id), supabase.from("user_chat_bubbles").select("bubble_id, equipped, chat_bubbles(id, name, thumbnail_url)").eq("user_id", currentUser.id) ]).then(function(results) {
    var items = (results[0].data || []).map(function(r) {
      return {
        id: r.frame_id,
        type: "frame",
        name: r.frames && r.frames.name,
        thumb: r.frames && r.frames.thumbnail_url,
        equipped: r.equipped
      };
    }).concat((results[1].data || []).map(function(r) {
      return {
        id: r.bubble_id,
        type: "bubble",
        name: r.chat_bubbles && r.chat_bubbles.name,
        thumb: r.chat_bubbles && r.chat_bubbles.thumbnail_url,
        equipped: r.equipped
      };
    }));
    var grid = $("goodiesGrid");
    if (!items.length) {
      grid.innerHTML = '<p class="profile-empty-hint">Todavía no tienes nada. Ve a la tienda a conseguir tu primer marco o burbuja.</p>';
      return;
    }
    grid.innerHTML = items.map(function(it) {
      return '<div class="community-card store-card" data-id="' + escapeHtml(it.id) + '" data-type="' + it.type + '">' + '<div class="community-card-banner" style="background-image:url(&quot;' + escapeHtml(it.thumb || "") + '&quot;)">' + (it.equipped ? '<span class="store-card-owned-tag">Equipado</span>' : "") + "</div>" + '<div class="community-card-name">' + escapeHtml(it.name || "") + "</div>" + "</div>";
    }).join("");
    qsa(".store-card", grid).forEach(function(card) {
      card.addEventListener("click", function() {
        var id = card.getAttribute("data-id");
        var type = card.getAttribute("data-type");
        if (type === "frame") openStoreFrameById(id); else openStoreBubbleById(id);
      });
    });
  });
});

$("btnWalletSendGift").addEventListener("click", function() {
  openGiftSend("wallet", null, null, null);
});

var myStoreBackTarget = "panel-wallet";

var myStoreViewingUid = null;

$("btnWalletMyStore").addEventListener("click", function() {
  myStoreBackTarget = "panel-wallet";
  activatePanel("panel-my-store");
  loadMyStore(currentUser ? currentUser.id : null);
});

$("btnMyStoreBack").addEventListener("click", function() {
  if (myStoreBackTarget === "profile") {
    activatePanel(null);
    $("profileBackdrop").classList.add("open");
    document.body.classList.add("profile-open");
  } else {
    activatePanel("panel-wallet");
  }
});

function setStoreBg(url) {
  var panel = $("panel-my-store");
  if (!panel) return;
  panel.style.setProperty("--store-bg", url ? 'url("' + String(url).replace(/"/g, "%22") + '")' : "none");
  panel.classList.toggle("has-store-bg", !!url);
}

function loadMyStore(targetUid, cameFromProfile) {
  var uid = targetUid || (currentUser ? currentUser.id : null);
  if (!uid) return;
  myStoreViewingUid = uid;
  var isOwnStore = !!currentUser && uid === currentUser.id;
  myStoreBackTarget = cameFromProfile ? "profile" : "panel-wallet";
  $("storeAdminRow").hidden = !isOwnStore;
  $("btnPickMyStoreBanner").hidden = !isOwnStore;
  $("btnPickMyStoreBg").hidden = !isOwnStore;
  setStoreBg(null);
  supabase.from("profiles").select("username, store_banner_url, store_background_url").eq("id", uid).single().then(function(res) {
    var p = res.data || {};
    $("myStoreBannerPreview").style.backgroundImage = p.store_banner_url ? 'url("' + p.store_banner_url + '")' : "";
    setStoreBg(p.store_background_url);
    var headEl = document.querySelector("#panel-my-store .communities-head h2");
    if (headEl) headEl.textContent = isOwnStore ? "Mi Tienda" : "Tienda de @" + (p.username || "");
  });
  Promise.all([ supabase.from("frames").select("*").eq("creator_id", uid).order("created_at", {
    ascending: false
  }), supabase.from("chat_bubbles").select("*").eq("creator_id", uid).order("created_at", {
    ascending: false
  }) ]).then(function(results) {
    if (myStoreViewingUid !== uid) return;
    var items = (results[0].data || []).map(function(i) {
      i._type = "frame";
      return i;
    }).concat((results[1].data || []).map(function(i) {
      i._type = "bubble";
      return i;
    }));
    if (!isOwnStore) items = items.filter(function(i) {
      return i.status !== "draft";
    });
    $("myStoreEmpty").hidden = !!items.length;
    $("myStoreGrid").innerHTML = items.map(function(item) {
      var statusTag = item.status === "draft" ? '<span class="store-card-soldout-tag">Sin acuñar</span>' : "";
      var actionsHtml = isOwnStore ? '<div class="store-card-btn-row">' + '<button type="button" class="link-btn sc-mint-btn" data-id="' + escapeHtml(item.id) + '" data-type="' + item._type + '">Acuñar</button>' + '<button type="button" class="link-btn sc-sell-btn" data-id="' + escapeHtml(item.id) + '" data-type="' + item._type + '">Vender</button>' + '<button type="button" class="link-btn sc-edit-btn" data-id="' + escapeHtml(item.id) + '" data-type="' + item._type + '">Editar</button>' + "</div>" : "";
      return '<div class="community-card store-card" data-id="' + escapeHtml(item.id) + '" data-type="' + item._type + '">' + '<div class="community-card-banner" style="background-image:url(&quot;' + escapeHtml(item.thumbnail_url || "") + '&quot;)">' + statusTag + "</div>" + '<div class="community-card-name">' + escapeHtml(item.name) + "</div>" + '<div class="store-card-foot"><span>' + item.minted_count + "/" + item.max_supply + (isOwnStore ? " · " + (item.creator_stock || 0) + " en tu monedero · " + (item.store_stock || 0) + " a la venta" : "") + "</span>" + actionsHtml + "</div>" + "</div>";
    }).join("");
    qsa(".store-card", $("myStoreGrid")).forEach(function(card) {
      card.addEventListener("click", function() {
        var id = card.getAttribute("data-id");
        var type = card.getAttribute("data-type");
        if (type === "frame") openStoreFrameById(id); else openStoreBubbleById(id);
      });
    });
    qsa(".sc-mint-btn", $("myStoreGrid")).forEach(function(btn) {
      btn.addEventListener("click", function(e) {
        e.stopPropagation();
        openMintModal(btn.getAttribute("data-type"), btn.getAttribute("data-id"));
      });
    });
    qsa(".sc-sell-btn", $("myStoreGrid")).forEach(function(btn) {
      btn.addEventListener("click", function(e) {
        e.stopPropagation();
        var id = btn.getAttribute("data-id");
        var type = btn.getAttribute("data-type");
        var item = items.find(function(it) {
          return it.id === id;
        });
        if (item) openSellModal(type, item);
      });
    });
    qsa(".sc-edit-btn", $("myStoreGrid")).forEach(function(btn) {
      btn.addEventListener("click", function(e) {
        e.stopPropagation();
        var id = btn.getAttribute("data-id");
        var type = btn.getAttribute("data-type");
        var item = items.find(function(it) {
          return it.id === id;
        });
        if (item) openStoreEdit(type, item);
      });
    });
  });
}

$("btnPickMyStoreBanner").addEventListener("click", function(e) {
  e.stopPropagation();
  openBackgroundPicker("myStoreBannerFile");
});

$("myStoreBannerFile").addEventListener("change", function() {
  var file = this.files[0];
  if (!file) return;
  uploadFiles([ file ], "store-profile-banner").then(function(uploaded) {
    supabase.from("profiles").update({
      store_banner_url: uploaded[0].url
    }).eq("id", currentUser.id).then(function() {
      $("myStoreBannerPreview").style.backgroundImage = 'url("' + uploaded[0].url + '")';
      toast(t("shop.toast_banner_updated"));
    });
  });
});

$("btnPickMyStoreBg").addEventListener("click", function(e) {
  e.stopPropagation();
  openBackgroundPicker("myStoreBgFile");
});

$("myStoreBgFile").addEventListener("change", function() {
  var file = this.files[0];
  if (!file) return;
  uploadFiles([ file ], "store-profile-bg").then(function(uploaded) {
    supabase.from("profiles").update({
      store_background_url: uploaded[0].url
    }).eq("id", currentUser.id).then(function() {
      setStoreBg(uploaded[0].url);
      toast(t("shop.toast_bg_updated"));
    });
  });
});

var mintTarget = null;

function mintCostPreview() {
  var qty = parseInt($("mintQuantity").value, 10) || 0;
  var currency = $("mintCurrency").value;
  var per100 = currency === "coin" ? 100 : 500;
  var cost = Math.ceil(qty / 100) * per100;
  $("mintCostPreview").textContent = qty > 0 ? "Costo: " + cost + " " + (currency === "coin" ? "Z-Coins" : "diamantes") + " por " + qty + " existencias." : "";
}

function openMintModal(type, itemId) {
  var table = type === "frame" ? "frames" : "chat_bubbles";
  supabase.from(table).select("id, name, creator_id").eq("id", itemId).single().then(function(res) {
    if (res.error || !res.data) {
      toast(t("shop.err_creation_not_found"));
      return;
    }
    if (!currentUser || res.data.creator_id !== currentUser.id) {
      toast(t("shop.err_only_creator"));
      return;
    }
    mintTarget = {
      type: type,
      id: itemId
    };
    $("mintItemName").textContent = res.data.name || (type === "frame" ? "marco" : "burbuja");
    $("mintQuantity").value = 100;
    $("mintCurrency").value = "stars";
    mintCostPreview();
    hideMintProgress();
    $("mintItemBackdrop").classList.add("open");
  });
}

function showMintProgress(state) {
  $("mintItemForm").hidden = true;
  $("mintProgress").hidden = false;
  $("mintProgressLoading").hidden = state !== "loading";
  $("mintProgressDone").hidden = state !== "done";
  $("mintProgressText").textContent = state === "done" ? "Generación completa." : "Acuñando...";
}

function hideMintProgress() {
  $("mintItemForm").hidden = false;
  $("mintProgress").hidden = true;
}

$("btnMintItemClose").addEventListener("click", function() {
  $("mintItemBackdrop").classList.remove("open");
  mintTarget = null;
  hideMintProgress();
});

$("mintItemBackdrop").addEventListener("click", function(e) {
  if (e.target === this) {
    this.classList.remove("open");
    mintTarget = null;
    hideMintProgress();
  }
});

$("mintQuantity").addEventListener("input", mintCostPreview);

$("mintCurrency").addEventListener("change", mintCostPreview);

qsa("[data-qty]", $("mintQuantityChips")).forEach(function(btn) {
  btn.addEventListener("click", function() {
    $("mintQuantity").value = btn.getAttribute("data-qty");
    mintCostPreview();
  });
});

$("btnMintConfirm").addEventListener("click", function() {
  if (!mintTarget) return;
  var qty = parseInt($("mintQuantity").value, 10);
  if (!qty || qty < 1) {
    toast(t("shop.err_qty_invalid"));
    return;
  }
  var currency = $("mintCurrency").value;
  showMintProgress("loading");
  supabase.rpc("mint_store_item", {
    p_item_type: mintTarget.type,
    p_item_id: mintTarget.id,
    p_quantity: qty,
    p_currency: currency
  }).then(function(res) {
    if (res.error) {
      hideMintProgress();
      showErrorAlert(res.error.message || "revisa tu saldo");
      return;
    }
    toast(t("shop.toast_minted"));
    refreshWalletDisplay();
    loadMyStore();
    loadStoreGrid();
    var minted = mintTarget;
    showMintProgress("done");
    setTimeout(function() {
      $("mintItemBackdrop").classList.remove("open");
      mintTarget = null;
      hideMintProgress();
      if (!minted) return;
      var tbl = minted.type === "frame" ? "frames" : "chat_bubbles";
      supabase.from(tbl).select("*").eq("id", minted.id).single().then(function(r) {
        if (r.data) openSellModal(minted.type, r.data);
      });
    }, 1000);
  });
});

$("btnWalletMint").addEventListener("click", function() {
  activatePanel("panel-my-store");
  loadMyStore();
});

var sellTarget = null;

function openSellModal(type, item) {
  sellTarget = {
    type: type,
    id: item.id,
    creator_stock: item.creator_stock || 0,
    store_stock: item.store_stock || 0
  };
  $("sellItemName").textContent = item.name || (type === "frame" ? "marco" : "burbuja");
  $("sellItemStockHint").textContent = "Tienes " + sellTarget.creator_stock + " en tu monedero y " + sellTarget.store_stock + " ya puestas a la venta.";
  $("sellQuantity").value = Math.min(10, sellTarget.creator_stock) || 1;
  $("sellItemBackdrop").classList.add("open");
}

window.openSellModal = openSellModal;

$("btnSellItemClose").addEventListener("click", function() {
  $("sellItemBackdrop").classList.remove("open");
  sellTarget = null;
});

$("sellItemBackdrop").addEventListener("click", function(e) {
  if (e.target === this) {
    this.classList.remove("open");
    sellTarget = null;
  }
});

$("btnSellConfirm").addEventListener("click", function() {
  if (!sellTarget) return;
  var qty = parseInt($("sellQuantity").value, 10);
  if (!qty || qty < 1) {
    toast(t("shop.err_qty_invalid"));
    return;
  }
  if (qty > sellTarget.creator_stock) {
    toast(t("shop.err_no_wallet_stock"));
    return;
  }
  supabase.rpc("list_item_for_sale", {
    p_item_type: sellTarget.type,
    p_item_id: sellTarget.id,
    p_quantity: qty
  }).then(function(res) {
    if (res.error) {
      showErrorAlert(res.error.message);
      return;
    }
    toast(t("shop.toast_listed"));
    $("sellItemBackdrop").classList.remove("open");
    sellTarget = null;
    loadMyStore();
    loadStoreGrid();
  });
});

$("btnUnsellConfirm").addEventListener("click", function() {
  if (!sellTarget) return;
  var qty = parseInt($("sellQuantity").value, 10);
  if (!qty || qty < 1) {
    toast(t("shop.err_qty_invalid"));
    return;
  }
  if (qty > sellTarget.store_stock) {
    toast(t("shop.err_no_sale_stock"));
    return;
  }
  supabase.rpc("list_item_for_sale", {
    p_item_type: sellTarget.type,
    p_item_id: sellTarget.id,
    p_quantity: -qty
  }).then(function(res) {
    if (res.error) {
      showErrorAlert(res.error.message);
      return;
    }
    toast(t("shop.toast_unlisted2"));
    $("sellItemBackdrop").classList.remove("open");
    sellTarget = null;
    loadMyStore();
    loadStoreGrid();
  });
});

var resellTarget = null;

function openResellModal(type, item) {
  resellTarget = {
    type: type,
    id: item.id
  };
  $("resellItemName").textContent = item.name || (type === "frame" ? "marco" : "burbuja");
  $("resellCurrency").value = "stars";
  $("resellPrice").value = 50;
  $("resellItemBackdrop").classList.add("open");
}

window.openResellModal = openResellModal;

$("btnResellItemClose").addEventListener("click", function() {
  $("resellItemBackdrop").classList.remove("open");
  resellTarget = null;
});

$("resellItemBackdrop").addEventListener("click", function(e) {
  if (e.target === this) {
    this.classList.remove("open");
    resellTarget = null;
  }
});

$("btnResellConfirm").addEventListener("click", function() {
  if (!resellTarget) return;
  var price = parseInt($("resellPrice").value, 10);
  if (!price || price < 1) {
    toast(t("shop.err_price_invalid"));
    return;
  }
  var currency = $("resellCurrency").value;
  supabase.rpc("list_owned_item_for_resale", {
    p_item_type: resellTarget.type,
    p_item_id: resellTarget.id,
    p_currency: currency,
    p_price: price
  }).then(function(res) {
    if (res.error) {
      showErrorAlert(res.error.message);
      return;
    }
    toast(t("shop.toast_resale_listed"));
    $("resellItemBackdrop").classList.remove("open");
    resellTarget = null;
  });
});