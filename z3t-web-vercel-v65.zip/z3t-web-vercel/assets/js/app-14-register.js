"use strict";

setupRegionCardGrid("regRegionCardGrid", detectRegion(), function(region) {
  I18N.applyLanguage(region);
}, "regRegion");

$("registerForm").addEventListener("submit", function(e) {
  e.preventDefault();
  var email = $("regEmail").value.trim();
  var name = $("regName").value.trim();
  var pass = $("regPass").value;
  var pass2 = $("regPass2").value;
  var regionChoice = $("regRegion").value;
  var errEl = $("regError");
  if (name.length < 2 || name.length > 32) {
    errEl.textContent = "Elige un nombre de usuario de 2 a 32 caracteres.";
    errEl.hidden = false;
    return;
  }
  if (pass !== pass2) {
    errEl.textContent = "Las contraseñas no coinciden.";
    errEl.hidden = false;
    return;
  }
  errEl.hidden = true;
  $("regAlreadyRegistered").hidden = true;
  var btn = $("registerSubmit");
  btn.disabled = true;
  btn.firstChild.textContent = "Preparando tu @... ";
  generateAvailableHandle(name).then(function(user) {
    btn.firstChild.textContent = "Recopilando datos... ";
    suppressAuthListener = true;
    return createAccount(user);
  }).catch(function() {
    btn.disabled = false;
    btn.firstChild.textContent = "Crear cuenta ";
    errEl.textContent = "No se pudo preparar tu cuenta. Intenta de nuevo.";
    errEl.hidden = false;
  });
  function createAccount(user) {
    return fetchIpAndLocation().then(function(net) {
      var device = detectDevice();
      return supabase.auth.signUp({
        email: email,
        password: pass,
        options: {
          data: {
            username: user,
            name: name,
            ip: net.ip,
            location: net.location,
            device: device,
            region: regionChoice || detectRegion()
          },
          emailRedirectTo: isNativeApp() ? "z3t://auth-callback" : window.location.origin + "/"
        }
      }).then(function(res) {
        if (res.error) {
          btn.disabled = false;
          btn.firstChild.textContent = "Crear cuenta ";
          suppressAuthListener = false;
          toast("No se pudo crear la cuenta: " + res.error.message);
          return;
        }
        if (res.data && res.data.user && Array.isArray(res.data.user.identities) && res.data.user.identities.length === 0) {
          btn.disabled = false;
          btn.firstChild.textContent = "Crear cuenta ";
          suppressAuthListener = false;
          $("registerForm").hidden = true;
          if ($("regResendVerify")) $("regResendVerify").setAttribute("data-email", email);
          $("regAlreadyRegistered").hidden = false;
          return;
        }
        var record = {
          username: user,
          name: name,
          email: email,
          ip: net.ip,
          location: net.location,
          device: device,
          joinedAt: (new Date).toISOString()
        };
        btn.disabled = false;
        btn.firstChild.textContent = "Crear cuenta ";
        suppressAuthListener = false;
        $("registerForm").reset();
        markHandleSet(res.data.user.id, name);
        if (!res.data.session) {
          $("registerForm").hidden = true;
          $("regCheckEmail").hidden = false;
          return;
        }
        return fetchProfile(res.data.user.id).then(function(profile) {
          currentUser = profile || Object.assign({
            id: res.data.user.id,
            threadsCount: 0,
            repliesCount: 0
          }, record);
          currentUser.handleSet = true;
          toast("Cuenta creada. Bienvenido, " + record.username + ".");
          startOnboarding(function() {
            enterForum();
            recordLoginStreak(currentUser.id);
          });
        });
      });
    });
  }
});

$("regCheckEmailGoLogin").addEventListener("click", function() {
  $("regCheckEmail").hidden = true;
  $("registerForm").hidden = false;
  showView("login");
});

$("btnGoLogin").addEventListener("click", function() {
  showView("login");
});

$("linkGoRegister").addEventListener("click", function(e) {
  e.preventDefault();
  showView("register");
});

$("goRegisterFromLogin").addEventListener("click", function(e) {
  e.preventDefault();
  showView("register");
});

var regResendEl = $("regResendVerify");

if (regResendEl) regResendEl.addEventListener("click", function() {
  var em = $("regEmail").value.trim() || regResendEl.getAttribute("data-email") || "";
  if (!em) return toast("Escribe tu correo.");
  regResendEl.disabled = true;
  supabase.auth.resend({
    type: "signup",
    email: em,
    options: { emailRedirectTo: isNativeApp() ? "z3t://auth-callback" : window.location.origin + "/" }
  }).then(function(r) {
    regResendEl.disabled = false;
    toast(r.error ? "No se pudo reenviar: " + r.error.message : "Listo. Revisa tu correo (y spam).");
  });
});

var regGoLoginInsteadEl = $("regGoLoginInstead");

if (regGoLoginInsteadEl) regGoLoginInsteadEl.addEventListener("click", function() {
  showView("login");
});

var regGoForgotInsteadEl = $("regGoForgotInstead");

if (regGoForgotInsteadEl) regGoForgotInsteadEl.addEventListener("click", function() {
  $("forgotPasswordForm").hidden = false;
  $("forgotCheckEmail").hidden = true;
  $("forgotEmail").value = $("regEmail").value || "";
  showView("forgot-password");
});

$("goLoginFromRegister").addEventListener("click", function(e) {
  e.preventDefault();
  showView("login");
});

$("loginBack").addEventListener("click", function() {
  showView("landing");
});

var forgotBackEl = $("forgotBack");

if (forgotBackEl) forgotBackEl.addEventListener("click", function() {
  showView("login");
});

var goLoginFromForgotEl = $("goLoginFromForgot");

if (goLoginFromForgotEl) goLoginFromForgotEl.addEventListener("click", function(e) {
  e.preventDefault();
  showView("login");
});

var forgotPasswordLinkEl = $("forgotPasswordLink");

if (forgotPasswordLinkEl) forgotPasswordLinkEl.addEventListener("click", function(e) {
  e.preventDefault();
  $("forgotPasswordForm").hidden = false;
  $("forgotCheckEmail").hidden = true;
  $("forgotEmail").value = $("loginUser").value || "";
  showView("forgot-password");
});

var forgotPasswordFormEl = $("forgotPasswordForm");

if (forgotPasswordFormEl) forgotPasswordFormEl.addEventListener("submit", function(e) {
  e.preventDefault();
  var email = $("forgotEmail").value.trim();
  var errEl = $("forgotError");
  errEl.hidden = true;
  if (!email) {
    errEl.textContent = "Escribe tu correo.";
    errEl.hidden = false;
    return;
  }
  var btn = $("forgotSubmit");
  btn.disabled = true;
  btn.textContent = "Enviando...";
  supabase.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin + "/"
  }).then(function(res) {
    btn.disabled = false;
    btn.textContent = "Enviar enlace";
    $("forgotPasswordForm").hidden = true;
    $("forgotCheckEmail").hidden = false;
  });
});

var forgotCheckEmailGoLoginEl = $("forgotCheckEmailGoLogin");

if (forgotCheckEmailGoLoginEl) forgotCheckEmailGoLoginEl.addEventListener("click", function() {
  showView("login");
});

var resetPasswordFormEl = $("resetPasswordForm");

if (resetPasswordFormEl) resetPasswordFormEl.addEventListener("submit", function(e) {
  e.preventDefault();
  var pass = $("resetPass").value;
  var pass2 = $("resetPass2").value;
  var errEl = $("resetError");
  errEl.hidden = true;
  if (pass.length < 6) {
    errEl.textContent = "La contraseña debe tener al menos 6 caracteres.";
    errEl.hidden = false;
    return;
  }
  if (pass !== pass2) {
    errEl.textContent = "Las contraseñas no coinciden.";
    errEl.hidden = false;
    return;
  }
  var btn = $("resetSubmit");
  btn.disabled = true;
  btn.textContent = "Guardando...";
  supabase.auth.updateUser({
    password: pass
  }).then(function(res) {
    btn.disabled = false;
    btn.textContent = "Guardar nueva contraseña";
    if (res.error) {
      errEl.textContent = "No se pudo cambiar: " + res.error.message;
      errEl.hidden = false;
      return;
    }
    toast("Contraseña actualizada. Ya puedes iniciar sesión con la nueva.");
    z3tSetRecoveryMode(false);
    supabase.auth.signOut().then(function() {
      showView("login");
    });
  });
});

(function checkPasswordRecoveryLink() {
  if (z3tIsRecoveryMode()) showView("reset-password");
})();

$("registerBack").addEventListener("click", function() {
  showView("landing");
});

window.addEventListener("popstate", function() {
  if (currentUser) return;
  if (location.pathname === "/login") showView("login"); else if (location.pathname === "/registro") showView("register"); else showView("landing");
});

qsa(".oauth-btn").forEach(function(btn) {
  btn.addEventListener("click", function() {
    var provider = btn.getAttribute("data-provider");
    qsa(".oauth-btn").forEach(function(b) {
      b.disabled = true;
    });
    var isNative = window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
    if (isNative) {
      supabase.auth.signInWithOAuth({
        provider: provider,
        options: {
          redirectTo: "z3t://auth-callback",
          skipBrowserRedirect: true
        }
      }).then(function(res) {
        if (res.error || !res.data || !res.data.url) {
          qsa(".oauth-btn").forEach(function(b) {
            b.disabled = false;
          });
          toast("No se pudo iniciar sesión con " + provider + (res.error ? ": " + res.error.message : ""));
          return;
        }
        window.Capacitor.Plugins.Browser.open({
          url: res.data.url,
          presentationStyle: "popover"
        });
      });
      return;
    }
    supabase.auth.signInWithOAuth({
      provider: provider,
      options: {
        redirectTo: window.location.origin + "/"
      }
    }).then(function(res) {
      if (res.error) {
        qsa(".oauth-btn").forEach(function(b) {
          b.disabled = false;
        });
        toast("No se pudo iniciar sesión con " + provider + ": " + res.error.message);
      }
    });
  });
});

function isNativeApp() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}

function handleAuthDeepLink(url) {
  if (!url || url.indexOf("z3t://auth-callback") !== 0) return;
  if (window.Capacitor.Plugins.Browser) window.Capacitor.Plugins.Browser.close().catch(function() {});
  var q = url.indexOf("?"), h = url.indexOf("#");
  var query = new URLSearchParams(q > -1 ? url.slice(q + 1, h > q ? h : undefined) : "");
  var hash = new URLSearchParams(h > -1 ? url.slice(h + 1) : "");
  function enableOauth() {
    qsa(".oauth-btn").forEach(function(b) {
      b.disabled = false;
    });
  }
  var err = query.get("error_description") || hash.get("error_description");
  if (err) {
    enableOauth();
    toast("No se pudo completar la verificación: " + err.replace(/\+/g, " "));
    return;
  }
  var job;
  if (hash.get("access_token") && hash.get("refresh_token")) {
    job = supabase.auth.setSession({
      access_token: hash.get("access_token"),
      refresh_token: hash.get("refresh_token")
    });
  } else if (query.get("code")) {
    job = supabase.auth.exchangeCodeForSession(query.get("code"));
  } else {
    return;
  }
  job.then(function(res) {
    if (res.error) {
      enableOauth();
      toast("No se pudo completar el inicio de sesión: " + res.error.message);
    }
  });
}

if (isNativeApp()) {
  window.Capacitor.Plugins.App.addListener("appUrlOpen", function(data) {
    handleAuthDeepLink(data && data.url);
  });
  window.Capacitor.Plugins.App.getLaunchUrl().then(function(r) {
    handleAuthDeepLink(r && r.url);
  }).catch(function() {});
}

supabase.auth.onAuthStateChange(function(event, session) {
  if (event === "PASSWORD_RECOVERY") {
    z3tSetRecoveryMode(true);
    showView("reset-password");
    return;
  }
  if (event === "SIGNED_IN" && z3tIsRecoveryMode()) return;
  if (suppressAuthListener) return;
  if (event === "SIGNED_IN" && session && (!currentUser || currentUser.id !== session.user.id)) {
    fetchProfile(session.user.id).then(function(profile) {
      if (!profile) {
        var reason = fetchProfile.lastSelfHealError && fetchProfile.lastSelfHealError.message;
        toast("No se pudo terminar de crear tu cuenta" + (reason ? ": " + reason : ".") + " Contacta a soporte si sigue pasando.");
        console.error("[onAuthStateChange] SIGNED_IN pero no se pudo crear/leer el perfil de", session.user.id, fetchProfile.lastSelfHealError);
        return;
      }
      currentUser = profile;
      if (typeof z3tCacheProfile === "function") z3tCacheProfile(profile);
      enterForum();
      recordLoginStreak(profile.id);
      toast("Bienvenido, " + profile.username + ".");
    });
  } else if (event === "SIGNED_OUT") {
    if (typeof stopDeviceSessionWatch === "function") stopDeviceSessionWatch();
    if (typeof z3tClearCachedProfile === "function") z3tClearCachedProfile();
    if (typeof z3tRealtimeStopAll === "function") z3tRealtimeStopAll();
    var wasLoggedIn = !!currentUser;
    currentUser = null;
    if (wasLoggedIn && $("view-app") && $("view-app").classList.contains("active")) {
      showView("landing");
      toast("Tu sesión expiró. Inicia sesión de nuevo.");
    }
  }
});