"use strict";

/* ================= Colores de roles + moderación de mensajes en chats ================= */

var Z3T_ROLE_DEFAULTS = {
  admin: "#f5c542",
  co_admin: "#4cc9f0",
  member: ""
};

var Z3T_ROLE_LABELS = {
  admin: "Admin",
  co_admin: "Co-Admin",
  member: "Miembro"
};

function z3tValidHex(c) {
  return typeof c === "string" && /^#[0-9a-f]{6}$/i.test(c);
}

/* Color de un rol: el que configuró la comunidad/grupo (role_colors) o el predeterminado. */
function z3tRoleColor(role, entity) {
  var custom = entity && entity.role_colors && typeof entity.role_colors === "object" ? entity.role_colors : null;
  if (custom && z3tValidHex(custom[role])) return custom[role];
  return Z3T_ROLE_DEFAULTS[role] || "";
}

/* Rol de un usuario dentro del chat actual. kind: "community" | "group" */
function z3tChatRoleOf(kind, userId) {
  if (!userId) return null;
  var list = kind === "group" ? typeof groupMembers !== "undefined" ? groupMembers : [] : typeof communityMembers !== "undefined" ? communityMembers : [];
  var m = (list || []).filter(function(x) {
    return x.user_id === userId;
  })[0];
  if (m) return m.role;
  /* El creador del grupo siempre es admin, aunque su fila de miembro no se haya podido crear */
  if (kind === "group" && typeof currentGroup !== "undefined" && currentGroup && currentGroup.created_by === userId) return "admin";
  return null;
}

function z3tChatEntity(kind) {
  if (kind === "group") return typeof currentGroup !== "undefined" ? currentGroup : null;
  return typeof currentCommunity !== "undefined" ? currentCommunity : null;
}

/* Etiqueta de rol con marco del color del rol (solo Admin y Co-Admin en los mensajes) */
function z3tRoleTagHtml(role, entity, always) {
  if (!role) return "";
  if (!always && role !== "admin" && role !== "co_admin") return "";
  var c = z3tRoleColor(role, entity);
  var style = c ? ' style="color:' + escapeHtml(c) + ";border-color:" + escapeHtml(c) + '"' : "";
  return '<span class="role-tag chat-role-tag ' + escapeHtml(role) + '"' + style + ">" + (Z3T_ROLE_LABELS[role] || role) + "</span>";
}

/* Atributos para el contenedor del mensaje: pinta nombre y texto con el color del rol */
function z3tMsgRoleAttrs(kind, senderId) {
  var role = z3tChatRoleOf(kind, senderId);
  if (role !== "admin" && role !== "co_admin" && role !== "member") return {
    cls: "",
    style: "",
    role: role
  };
  var c = z3tRoleColor(role, z3tChatEntity(kind));
  if (!c) return {
    cls: "",
    style: "",
    role: role
  };
  return {
    cls: " chat-msg--role",
    style: ' style="--role-color:' + escapeHtml(c) + '"',
    role: role
  };
}

/* ¿Puede el usuario actual borrar este mensaje? Autor, admin/co-admin del chat o admin del sitio. */
function z3tCanDeleteChatMsg(kind, m) {
  if (!currentUser || !m || m.type === "system") return false;
  if (m.sender_id && m.sender_id === currentUser.id) return true;
  if (currentUser.role === "admin") return true;
  var role = z3tChatRoleOf(kind, currentUser.id);
  return role === "admin" || role === "co_admin";
}

/* Menú ⋮ del mensaje, con "Borrar" cuando corresponde */
function z3tChatMsgKebab(kind, m) {
  /* Reemplazado por la semipantalla al mantener presionado el mensaje (app-36-chat-actions.js) */
  return "";
  if (typeof kebabMenuHtml !== "function") return "";
  var table = kind === "group" ? "private_group_messages" : "community_messages";
  return kebabMenuHtml("message", m.id, false, z3tCanDeleteChatMsg(kind, m) ? {
    deleteTable: table
  } : null);
}

function z3tDeleteChatMessage(table, id) {
  if (!currentUser || !table || !id) return;
  if (!confirm("¿Borrar este mensaje? Esta acción no se puede deshacer.")) return;
  supabase.from(table).delete().eq("id", id).select("id").then(function(res) {
    if (res.error) {
      toast("No se pudo borrar el mensaje: " + res.error.message);
      return;
    }
    if (!res.data || !res.data.length) {
      toast("No tienes permiso para borrar este mensaje. Falta la política de borrado en Supabase.");
      return;
    }
    if (table === "community_messages" && typeof COMMUNITY_MESSAGES !== "undefined") {
      COMMUNITY_MESSAGES = COMMUNITY_MESSAGES.filter(function(m) {
        return String(m.id) !== String(id);
      });
      if (typeof renderCommunityChat === "function") renderCommunityChat();
    } else if (table === "dm_messages" && typeof DM_MESSAGES !== "undefined") {
      DM_MESSAGES = DM_MESSAGES.filter(function(m) {
        return String(m.id) !== String(id);
      });
      if (typeof renderDmMessages === "function") renderDmMessages();
    } else if (table === "private_group_messages" && typeof GROUP_MESSAGES !== "undefined") {
      GROUP_MESSAGES = GROUP_MESSAGES.filter(function(m) {
        return String(m.id) !== String(id);
      });
      if (typeof renderGroupMessages === "function") renderGroupMessages();
    }
    toast("Mensaje borrado.");
  });
}

/* ================= Selectores de color de roles (ajustes de la comunidad) ================= */

function z3tRoleColorFieldsHtml(entity) {
  var roles = [ "admin", "co_admin", "member" ];
  return '<div class="community-settings-section role-colors-section"><h4>Colores de roles</h4>' + '<p class="field-hint">El color se usa en el marco del rol, el nombre y el texto de quien escribe.</p>' + roles.map(function(r) {
    var c = z3tRoleColor(r, entity) || "#9aa0a6";
    return '<label class="field role-color-field"><span>' + Z3T_ROLE_LABELS[r] + '</span><input type="color" id="settRoleColor_' + r + '" value="' + escapeHtml(c) + '"></label>';
  }).join("") + "</div>";
}

function z3tReadRoleColorFields() {
  var out = {};
  [ "admin", "co_admin", "member" ].forEach(function(r) {
    var el = document.getElementById("settRoleColor_" + r);
    if (el && z3tValidHex(el.value)) out[r] = el.value;
  });
  return out;
}

/* ================= Ventana "Colores de roles" del grupo (solo Admin / Co-Admin) ================= */

function z3tOpenGroupRoleColors() {
  if (typeof currentGroup === "undefined" || !currentGroup || !currentUser) return;
  var role = z3tChatRoleOf("group", currentUser.id);
  if (role !== "admin" && role !== "co_admin") {
    toast("Solo los admins del grupo pueden cambiar los colores.");
    return;
  }
  var old = document.getElementById("groupRoleColorsBackdrop");
  if (old) old.remove();
  var bd = document.createElement("div");
  bd.className = "modal-backdrop";
  bd.id = "groupRoleColorsBackdrop";
  bd.innerHTML = '<div class="modal" role="dialog" aria-modal="true">' +
    '<div class="modal-head"><h3>Colores de roles</h3>' +
    '<button class="icon-btn" type="button" id="groupRoleColorsClose" aria-label="Cerrar">\u2715</button></div>' +
    z3tRoleColorFieldsHtml(currentGroup) +
    '<p class="field-error" id="groupRoleColorsErr" hidden></p>' +
    '<div class="edit-box-actions" style="margin-top:1rem">' +
    '<button class="terminal-btn" type="button" id="groupRoleColorsSave">Guardar</button>' +
    '<button class="link-btn" type="button" id="groupRoleColorsReset">Restablecer</button></div></div>';
  document.body.appendChild(bd);
  requestAnimationFrame(function() { bd.classList.add("open"); });

  function close() { bd.classList.remove("open"); setTimeout(function() { bd.remove(); }, 200); }
  bd.addEventListener("click", function(e) { if (e.target === bd) close(); });
  document.getElementById("groupRoleColorsClose").addEventListener("click", close);

  document.getElementById("groupRoleColorsReset").addEventListener("click", function() {
    ["admin", "co_admin", "member"].forEach(function(r) {
      var el = document.getElementById("settRoleColor_" + r);
      if (el) el.value = Z3T_ROLE_DEFAULTS[r] || "#9aa0a6";
    });
  });

  document.getElementById("groupRoleColorsSave").addEventListener("click", function() {
    var colors = z3tReadRoleColorFields();
    var btn = this;
    var err = document.getElementById("groupRoleColorsErr");
    err.hidden = true;
    btn.disabled = true;
    supabase.from("private_groups").update({ role_colors: colors }).eq("id", currentGroup.id).select("id").then(function(res) {
      btn.disabled = false;
      if (res.error || !res.data || !res.data.length) {
        err.textContent = "No se pudo guardar" + (res.error ? ": " + res.error.message : ". Verifica que eres admin del grupo.");
        err.hidden = false;
        return;
      }
      currentGroup.role_colors = colors;
      var chat = document.getElementById("groupChat");
      if (chat) chat.dataset.msgSig = "";
      if (typeof renderGroupMessages === "function") renderGroupMessages();
      toast("Colores de roles guardados.");
      close();
    });
  });
}
