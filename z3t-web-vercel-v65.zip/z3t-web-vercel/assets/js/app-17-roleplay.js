"use strict";

var rpScope = "group";

var rpEntity = null;

var rpMyRole = null;

var rpCharacters = [];

var rpClaims = [];

var rpPollTimer = null;

var rpOpenInfoId = null;

var rpSettingsTab = "characters";

var RP_SCOPES = {
  group: {
    entityTable: "private_groups",
    characterTable: "group_characters",
    claimTable: "group_character_claims",
    entityIdField: "group_id",
    wrapId: "groupRoleplayWrap",
    closeConfirmMsg: "¿Apagar el Roleplay? Se dejará de ver para todo el grupo.",
    offLabel: "todo el grupo",
    setActivity: function(mode) {
      if (typeof setGroupActivity === "function") setGroupActivity(mode);
    },
    getCurrentEntity: function() {
      return typeof currentGroup !== "undefined" ? currentGroup : null;
    },
    syncCurrentEntity: function(patch) {
      if (typeof currentGroup !== "undefined" && currentGroup) Object.assign(currentGroup, patch);
    }
  },
  dm: {
    entityTable: "dm_conversations",
    characterTable: "dm_characters",
    claimTable: "dm_character_claims",
    entityIdField: "conversation_id",
    wrapId: "dmRoleplayWrap",
    closeConfirmMsg: "¿Apagar el Roleplay? Se dejará de ver para los dos.",
    offLabel: "los dos",
    setActivity: function(mode) {
      if (typeof setDmActivity === "function") setDmActivity(mode);
    },
    getCurrentEntity: function() {
      return typeof currentConversation !== "undefined" && currentConversation ? currentConversation.dmRow || null : null;
    },
    syncCurrentEntity: function(patch) {
      if (typeof currentConversation !== "undefined" && currentConversation && currentConversation.dmRow) Object.assign(currentConversation.dmRow, patch);
    }
  },
  community: {
    entityTable: "communities",
    characterTable: "community_characters",
    claimTable: "community_character_claims",
    entityIdField: "community_id",
    wrapId: "communityRoleplayWrap",
    closeConfirmMsg: "¿Apagar el Roleplay? Se dejará de ver para toda la comunidad.",
    offLabel: "toda la comunidad",
    setActivity: function(mode) {
      if (typeof setCommunityActivity === "function") setCommunityActivity(mode);
    },
    getCurrentEntity: function() {
      return typeof currentCommunity !== "undefined" ? currentCommunity : null;
    },
    syncCurrentEntity: function(patch) {
      if (typeof currentCommunity !== "undefined" && currentCommunity) Object.assign(currentCommunity, patch);
    }
  }
};

function rpConf() {
  return RP_SCOPES[rpScope] || RP_SCOPES.group;
}

function rpIsStaff() {
  return rpMyRole === "admin" || rpMyRole === "co_admin";
}

function rpClaimByCharacter(charId) {
  return rpClaims.filter(function(c) {
    return c.character_id === charId;
  })[0] || null;
}

function rpActiveKey() {
  return "z3t_rp_active_" + rpScope + "_" + (rpEntity ? rpEntity.id : "");
}

function rpMyClaims() {
  if (!currentUser) return [];
  return rpClaims.filter(function(c) {
    return c.user_id === currentUser.id;
  });
}

function rpMyClaim() {
  var mine = rpMyClaims();
  if (!mine.length) return null;
  var saved = null;
  try {
    saved = localStorage.getItem(rpActiveKey());
  } catch (_e) {}
  var hit = mine.filter(function(c) {
    return c.character_id === saved;
  })[0];
  return hit || mine[mine.length - 1];
}

function rpSetActiveChar(charId) {
  try {
    localStorage.setItem(rpActiveKey(), charId);
  } catch (_e) {}
}

function rpCharacterById(id) {
  return rpCharacters.filter(function(c) {
    return c.id === id;
  })[0] || null;
}

function myActiveRoleplayCharacter() {
  var claim = rpMyClaim();
  if (!claim) return null;
  return rpCharacterById(claim.character_id);
}

function roleplayVoiceIdentityFor(userId, scope) {
  if (scope && scope !== rpScope) return null;
  var entity = rpConf().getCurrentEntity();
  if (!rpEntity || !entity || entity.active_activity !== "roleplay") return null;
  var claim = currentUser && userId === currentUser.id ? rpMyClaim() : rpClaims.filter(function(c) {
    return c.user_id === userId;
  })[0];
  if (!claim) return null;
  var ch = rpCharacterById(claim.character_id);
  if (!ch) return null;
  return {
    name: ch.name,
    avatarUrl: ch.avatar_url || null
  };
}

window.roleplayVoiceIdentityFor = roleplayVoiceIdentityFor;

var RP_BODY_RE = /^\[\[rp\|([^|\]]*)\|([^|\]]*)\]\]/;

function rpEncodeBody(ch, body) {
  return "[[rp|" + encodeURIComponent(ch.name || "") + "|" + encodeURIComponent(ch.avatar_url || "") + "]]" + body;
}

function rpDecodeMessage(m) {
  if (!m || typeof m.body !== "string") return null;
  var mt = m.body.match(RP_BODY_RE);
  if (!mt) return null;
  var nm, av;
  try {
    nm = decodeURIComponent(mt[1]);
    av = decodeURIComponent(mt[2]);
  } catch (_e) {
    return null;
  }
  return {
    name: nm,
    avatar: av || null,
    body: m.body.slice(mt[0].length)
  };
}

function rpStripBody(body) {
  if (typeof body === "string") body = body.replace(/^((?:\[\[rp\|[^|\]]*\|[^|\]]*\]\])?)\[\[re\|[^|\]]*\|[^|\]]*\|[^|\]]*\]\]/, "$1");
  return typeof body === "string" ? body.replace(RP_BODY_RE, "") : body;
}

function rpInsertMessage(table, row, myChar) {
  if (!myChar) return supabase.from(table).insert(row);
  var full = Object.assign({}, row, {
    roleplay_character_id: myChar.id,
    roleplay_character_name: myChar.name,
    roleplay_character_avatar: myChar.avatar_url || null
  });
  return supabase.from(table).insert(full).then(function(res) {
    if (!res.error) return res;
    console.error("Roleplay: falló el envío con columnas de personaje:", res.error);
    var fallback = Object.assign({}, row, {
      body: rpEncodeBody(myChar, row.body)
    });
    return supabase.from(table).insert(fallback);
  });
}

var rpVoiceRoom = null;

var rpVoiceKey = null;

var rpVoiceMuted = false;

var rpVoiceJoined = false;

var rpVoiceSeq = 0;

var rpVoiceConnectPromise = null;

var rpVoiceMuteBusy = false;

var rpVoiceLastTry = 0;

function rpNoop() {}

function rpCurrentKey() {
  return rpEntity ? rpScope + ":" + rpEntity.id : null;
}

function rpVoiceAllowed() {
  if (!rpEntity) return false;
  var cur = rpConf().getCurrentEntity();
  var src = cur && cur.id === rpEntity.id ? cur : rpEntity;
  return src.roleplay_voice_enabled !== false;
}

function rpVoiceReleaseLegacy() {
  if (!rpEntity) return;
  if (rpScope === "community") {
    if (typeof voiceRoom !== "undefined" && voiceRoom && typeof voiceRoomCommunityId !== "undefined" && voiceRoomCommunityId === rpEntity.id && typeof leaveVoiceChat === "function") leaveVoiceChat();
  } else if (typeof activityVoiceRoom !== "undefined" && activityVoiceRoom && activityVoiceKind === (rpScope === "dm" ? "dm" : "group") && activityVoiceRoomId === rpEntity.id && typeof leaveActivityVoice === "function") {
    leaveActivityVoice();
  }
}

function rpVoiceTokenFrom(res) {
  return res && !res.error && res.data ? res.data.token || res.data : null;
}

function rpVoiceFetchToken() {
  var id = rpEntity.id;
  return supabase.rpc("create_activity_livekit_token", {
    p_room_kind: "roleplay_" + rpScope,
    p_room_id: id
  }).then(function(res) {
    var tk = rpVoiceTokenFrom(res);
    if (tk) return tk;
    if (rpScope === "community") {
      return supabase.rpc("create_livekit_token", {
        p_community_id: id
      }).then(rpVoiceTokenFrom);
    }
    return supabase.rpc("create_activity_livekit_token", {
      p_room_kind: rpScope === "dm" ? "dm" : "group",
      p_room_id: id
    }).then(rpVoiceTokenFrom);
  });
}

function rpVoiceWireRoom(room) {
  var E = LivekitClient.RoomEvent;
  room.on(E.TrackSubscribed, function(track, _pub, participant) {
    if (track.kind === "audio") {
      var el = track.attach();
      el.setAttribute("data-rp-livekit-audio", participant.identity);
      el.style.display = "none";
      document.body.appendChild(el);
    }
  });
  room.on(E.TrackUnsubscribed, function(track) {
    track.detach().forEach(function(el) {
      el.remove();
    });
  });
  room.on(E.Disconnected, function() {
    if (rpVoiceRoom !== room) return;
    rpVoiceRoom = null;
    rpVoiceKey = null;
    rpVoiceJoined = false;
    rpVoiceMuted = false;
    rpVoiceConnectPromise = null;
    qsa("[data-rp-livekit-audio]", document.body).forEach(function(el) {
      el.remove();
    });
    if (rpEntity) renderRoleplayWrap();
  });
}

function rpVoiceConnect() {
  if (!currentUser || !rpEntity || !rpMyRole) return Promise.resolve(false);
  if (typeof LivekitClient === "undefined") return Promise.resolve(false);
  if (!rpVoiceAllowed()) return Promise.resolve(false);
  var key = rpCurrentKey();
  if (rpVoiceRoom && rpVoiceKey === key && rpVoiceRoom.state !== "disconnected") {
    return rpVoiceConnectPromise || Promise.resolve(true);
  }
  rpVoiceLeave();
  rpVoiceReleaseLegacy();
  var seq = ++rpVoiceSeq;
  rpVoiceKey = key;
  rpVoiceLastTry = Date.now();
  rpVoiceConnectPromise = rpVoiceFetchToken().then(function(token) {
    if (seq !== rpVoiceSeq || !token) return false;
    var room = new LivekitClient.Room({
      adaptiveStream: true,
      dynacast: true
    });
    rpVoiceWireRoom(room);
    rpVoiceRoom = room;
    return room.connect(LIVEKIT_WS_URL, token).then(function() {
      if (seq !== rpVoiceSeq) {
        try {
          room.disconnect();
        } catch (_e) {}
        return false;
      }
      return true;
    });
  }).catch(function() {
    if (seq === rpVoiceSeq) {
      var r = rpVoiceRoom;
      rpVoiceRoom = null;
      rpVoiceKey = null;
      if (r) try {
        r.disconnect();
      } catch (_e) {}
    }
    return false;
  }).then(function(ok) {
    if (seq === rpVoiceSeq) rpVoiceConnectPromise = null;
    return ok;
  });
  return rpVoiceConnectPromise;
}

function rpVoiceLeave() {
  rpVoiceSeq++;
  var room = rpVoiceRoom;
  rpVoiceRoom = null;
  rpVoiceKey = null;
  rpVoiceJoined = false;
  rpVoiceMuted = false;
  rpVoiceConnectPromise = null;
  rpVoiceMuteBusy = false;
  if (room) try {
    room.disconnect();
  } catch (_e) {}
  qsa("[data-rp-livekit-audio]", document.body).forEach(function(el) {
    el.remove();
  });
}

function rpVoiceSync() {
  if (!rpEntity) return;
  if (rpVoiceAllowed()) {
    if (rpMyRole && !rpVoiceRoom && Date.now() - rpVoiceLastTry > 3e4) rpVoiceConnect();
  } else if (rpVoiceRoom) {
    rpVoiceLeave();
  }
}

function rpVoiceStartAudio() {
  try {
    var p = rpVoiceRoom && rpVoiceRoom.startAudio ? rpVoiceRoom.startAudio() : null;
    if (p && p.catch) p.catch(rpNoop);
  } catch (_e) {}
}

function rpVoiceJoin() {
  if (!currentUser || !rpEntity) return;
  if (!rpMyRole) {
    toast("Únete para poder hablar.");
    return;
  }
  if (!rpVoiceAllowed()) {
    toast("El chat de voz está apagado en este Roleplay.");
    return;
  }
  if (!rpMyClaim()) {
    toast("Elige un personaje para hablar como él.");
    return;
  }
  var other = typeof activeVoiceActivityElsewhere === "function" ? activeVoiceActivityElsewhere(rpScope, rpEntity.id) : null;
  if (other) {
    toast("Ya tienes una actividad de voz activa en " + other + ". Sal de ahí antes de unirte aquí.");
    return;
  }
  var key = rpCurrentKey();
  rpVoiceConnect().then(function() {
    if (!rpVoiceRoom || rpVoiceKey !== key) {
      toast("No se pudo conectar al chat de voz del Roleplay.");
      return;
    }
    rpVoiceStartAudio();
    return rpVoiceRoom.localParticipant.setMicrophoneEnabled(true).then(function() {
      rpVoiceMuted = false;
      rpVoiceJoined = true;
      renderRoleplayWrap();
    });
  }).catch(function() {
    toast("No se pudo activar tu micrófono. Revisa los permisos del navegador.");
  });
}

function rpVoiceStepDown() {
  rpVoiceJoined = false;
  rpVoiceMuted = false;
  var lp = rpVoiceRoom && rpVoiceRoom.localParticipant;
  Promise.resolve(lp ? lp.setMicrophoneEnabled(false) : null).catch(rpNoop).then(function() {
    if (rpEntity) renderRoleplayWrap();
  });
}

function rpVoiceToggleMute() {
  if (!rpVoiceRoom || !rpVoiceRoom.localParticipant || rpVoiceMuteBusy) return;
  var micPub = rpVoiceRoom.localParticipant.getTrackPublication ? rpVoiceRoom.localParticipant.getTrackPublication(LivekitClient.Track.Source.Microphone) : null;
  if (!micPub || !micPub.track) return;
  var next = !rpVoiceMuted;
  rpVoiceMuteBusy = true;
  Promise.resolve(next ? micPub.track.mute() : micPub.track.unmute()).then(function() {
    rpVoiceMuteBusy = false;
    rpVoiceMuted = next;
    renderRoleplayWrap();
  }).catch(function() {
    rpVoiceMuteBusy = false;
    toast("No se pudo cambiar el micrófono. Intenta de nuevo.");
  });
}

document.addEventListener("click", function() {
  if (rpVoiceRoom && rpVoiceRoom.state === "connected" && rpVoiceRoom.canPlaybackAudio === false) rpVoiceStartAudio();
});

function initRoleplayPanel(entity, role, scope) {
  rpScope = scope === "community" ? "community" : scope === "dm" ? "dm" : "group";
  rpEntity = entity;
  rpMyRole = role;
  rpOpenInfoId = null;
  if (rpVoiceRoom && rpVoiceKey !== rpCurrentKey()) rpVoiceLeave();
  loadRoleplayData().then(function() {
    rpVoiceSync();
    renderRoleplayWrap();
  });
  if (rpPollTimer) clearInterval(rpPollTimer);
  rpPollTimer = setInterval(function() {
    var current = rpConf().getCurrentEntity();
    if (!rpEntity || !current || current.active_activity !== "roleplay") return;
    loadRoleplayData().then(function() {
      rpVoiceSync();
      renderRoleplayWrap();
    });
  }, 5e3);
}

function stopRoleplayPanel() {
  if (rpPollTimer) {
    clearInterval(rpPollTimer);
    rpPollTimer = null;
  }
  rpVoiceLeave();
  rpEntity = null;
  rpMyRole = null;
  rpCharacters = [];
  rpClaims = [];
  rpOpenInfoId = null;
}

function loadRoleplayData() {
  if (!rpEntity) return Promise.resolve();
  var conf = rpConf();
  var filter = {};
  filter[conf.entityIdField] = rpEntity.id;
  return Promise.all([ supabase.from(conf.characterTable).select("*").eq(conf.entityIdField, rpEntity.id).order("created_at", {
    ascending: true
  }), supabase.from(conf.claimTable).select("*").eq(conf.entityIdField, rpEntity.id) ]).then(function(results) {
    rpCharacters = results[0].error ? [] : results[0].data || [];
    rpClaims = results[1].error ? [] : results[1].data || [];
  });
}

function rpPlusSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>';
}

function rpGearSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
}

function rpXSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></svg>';
}

function rpPencilSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
}

function rpTrashSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg>';
}

var RP_HEX_COLORS = [ "#f0ab54", "#22d3ee", "#b0362e", "#2563eb", "#16a34a", "#ec4899", "#a855f7", "#eab308" ];

function rpCharColor(seed) {
  seed = String(seed == null ? "" : seed);
  var h = 0;
  for (var i = 0; i < (seed || "").length; i++) {
    h = (h * 31 + seed.charCodeAt(i)) % 997;
  }
  return RP_HEX_COLORS[h % RP_HEX_COLORS.length];
}

/* Color del personaje: el elegido por el admin (columna color) o, si no hay, uno automático */
function rpColorOf(ch) {
  if (ch && typeof ch.color === "string" && /^#[0-9a-fA-F]{6}$/.test(ch.color)) return ch.color;
  return rpCharColor(ch ? ch.id || ch.name : "");
}

function rpUserLabel(uid) {
  if (rpScope === "dm") {
    if (typeof currentConversation !== "undefined" && currentConversation) {
      if (currentUser && uid === currentUser.id) return null;
      if (uid === currentConversation.otherId) return currentConversation.otherName || null;
    }
    return null;
  }
  var list = rpScope === "community" ? typeof communityMembers !== "undefined" ? communityMembers : [] : typeof groupMembers !== "undefined" ? groupMembers : [];
  var m = list.filter(function(x) {
    return x.user_id === uid;
  })[0];
  var p = m && m.profiles;
  return p ? p.name || p.username || null : null;
}

/* Color del personaje que escribió un mensaje (marco del avatar y burbuja) */
function rpMsgColor(m, name) {
  if (!m) return null;
  var key = m.roleplay_character_id || null;
  if (!key && name && Array.isArray(rpCharacters)) {
    var ch = rpCharacters.filter(function(c) {
      return c.name === name;
    })[0];
    key = ch ? ch.id : name;
  }
  var byId = Array.isArray(rpCharacters) && key ? rpCharacters.filter(function(c) {
    return c.id === key;
  })[0] : null;
  if (byId) return rpColorOf(byId);
  return rpCharColor(key || name || "");
}

var RP_PAGE_SIZE = 8;

var RP_MAX_CHARACTERS = 2000;

var rpPage = 0;

function rpStatusInfo(ch) {
  var claim = rpClaimByCharacter(ch.id);
  var isMine = !!(claim && currentUser && claim.user_id === currentUser.id);
  var who = claim && !isMine ? rpUserLabel(claim.user_id) : null;
  return {
    claim: claim,
    isMine: isMine,
    cls: isMine ? "rp-cast-status--mine" : claim ? "rp-cast-status--used" : "rp-cast-status--free",
    txt: isMine ? (rpMyClaim() && rpMyClaim().character_id === ch.id ? "Hablando como él" : "Tu personaje") : claim ? who ? "Usado por " + escapeHtml(who) : "Usado" : "Libre"
  };
}

function rpAvatarBg(ch) {
  return ch.avatar_url ? ' style="background-image:url(&quot;' + encodeURI(ch.avatar_url).replace(/"/g, "%22").replace(/\'/g, "%27") + '&quot;)"' : "";
}

function rpHexItemHtml(ch) {
  var st = rpStatusInfo(ch);
  var color = st.isMine && !(ch.color) ? "#a855f7" : rpColorOf(ch);
  return '<div class="rp-hex-item' + (st.claim && !st.isMine ? " rp-hex-used" : "") + '" data-char-id="' + escapeHtml(ch.id) + '">' + '<div class="rp-hex-glow" style="filter:drop-shadow(0 0 5px ' + hexToRgba(color, .55) + ')">' + '<div class="rp-hex-ring" style="background:' + color + '">' + '<button type="button" class="rp-hex' + (st.isMine ? " rp-hex-mine" : "") + '"' + rpAvatarBg(ch) + ' data-act="open-claim" data-char="' + escapeHtml(ch.id) + '" aria-label="' + escapeHtml(ch.name) + '">' + (ch.avatar_url ? "" : '<span class="rp-hex-placeholder">' + escapeHtml(initials(ch.name)) + "</span>") + "</button>" + "</div>" + "</div>" + (st.claim && !st.isMine ? '<span class="rp-hex-badge" title="En uso"></span>' : "") + '<span class="rp-hex-label" style="--rol:' + color + '">' + escapeHtml(ch.name) + "</span>" + "</div>";
}

function rpPagerHtml() {
  if (!rpCharacters.length) return "";
  var pages = Math.ceil(Math.min(rpCharacters.length, RP_MAX_CHARACTERS) / RP_PAGE_SIZE);
  if (rpPage > pages - 1) rpPage = pages - 1;
  var html = '<div class="rp-pager" id="rpPager">';
  for (var p = 0; p < pages; p++) {
    html += '<div class="rp-page"><div class="rp-hex-grid">' + rpCharacters.slice(0, RP_MAX_CHARACTERS).slice(p * RP_PAGE_SIZE, (p + 1) * RP_PAGE_SIZE).map(rpHexItemHtml).join("") + "</div></div>";
  }
  html += "</div>";
  if (pages > 1) {
    html += '<div class="rp-dots" id="rpDots">';
    for (var d = 0; d < pages; d++) {
      html += '<button type="button" class="rp-dot' + (d === rpPage ? " active" : "") + '" data-dot="' + d + '" aria-label="Página ' + (d + 1) + '"></button>';
    }
    html += "</div>";
  }
  return html;
}

function rpWirePager(wrap) {
  var pager = wrap.querySelector("#rpPager");
  if (!pager) return;
  var dots = qsa(".rp-dot", wrap);
  var setDots = function(i) {
    dots.forEach(function(d, idx) {
      d.classList.toggle("active", idx === i);
    });
  };
  pager.scrollLeft = rpPage * pager.clientWidth;
  pager.addEventListener("scroll", function() {
    var w = pager.clientWidth || 1;
    var i = Math.round(pager.scrollLeft / w);
    if (i !== rpPage) {
      rpPage = i;
      setDots(i);
    }
  }, {
    passive: true
  });
  dots.forEach(function(d) {
    d.addEventListener("click", function(e) {
      e.stopPropagation();
      var i = parseInt(d.getAttribute("data-dot"), 10) || 0;
      rpPage = i;
      pager.scrollTo({
        left: i * pager.clientWidth,
        behavior: "smooth"
      });
      setDots(i);
    });
  });
}

function renderRoleplayWrap() {
  var wrap = $(rpConf().wrapId);
  if (!wrap || !rpEntity) return;
  var isStaff = rpIsStaff();
  var myClaim = rpMyClaim();
  if (!myClaim && rpVoiceJoined) rpVoiceStepDown();
  var prevPopup = $("rpSettingsPopup");
  var popupWasOpen = !!(prevPopup && prevPopup.classList.contains("open"));
  var freeCount = rpCharacters.filter(function(ch) {
    return !rpClaimByCharacter(ch.id);
  }).length;
  var emptyHint = !rpCharacters.length ? isStaff ? '<p class="rp-empty-hint">Todavía no hay personajes. Toca el engranaje para crear el primero.</p>' : '<p class="rp-empty-hint">Todavía no hay personajes en este Roleplay. Un admin o co-admin puede crear el primero.</p>' : "";
  var myCharBarHtml = "";
  if (myClaim) {
    var myCh = rpCharacterById(myClaim.character_id);
    if (myCh) {
      var ctlHtml = "";
      if (rpVoiceAllowed()) {
        if (rpVoiceJoined) {
          ctlHtml = '<button type="button" class="voice-control-btn mic" data-act="rp-mic-toggle" aria-label="Silenciar">' + (rpVoiceMuted ? micOffSvg() : micOnSvg()) + "</button>";
        } else {
          ctlHtml = '<button type="button" class="voice-control-btn mic" data-act="rp-mic-up" aria-label="Encender micrófono">' + micOffSvg() + "</button>";
        }
      }
      myCharBarHtml = ctlHtml ? '<div class="rp-call-controls">' + ctlHtml + "</div>" : "";
    }
  }
  if (!isStaff) rpSettingsTab = "characters";
  wrap.innerHTML = '<div class="roleplay-topbar">' + '<div class="roleplay-topbar-title">' + activityIconHtml("roleplay") + " Roleplay" + (rpCharacters.length ? '<span class="rp-cast-count">' + freeCount + (freeCount === 1 ? " libre" : " libres") + " · " + (rpCharacters.length - freeCount) + " en uso</span>" : "") + "</div>" + '<div style="position:relative;">' + '<button class="icon-btn" type="button" id="btnRpSettings" aria-label="Personajes y ajustes del Roleplay">' + rpGearSvg() + "</button>" + '<div class="rp-settings-popup' + (popupWasOpen ? " open" : "") + '" id="rpSettingsPopup">' + (isStaff ? '<div class="chat-actions-tabs">' + '<button type="button" class="chat-actions-tab' + (rpSettingsTab === "characters" ? " active" : "") + '" data-rptab="characters">Personajes</button>' + '<button type="button" class="chat-actions-tab' + (rpSettingsTab === "audio" ? " active" : "") + '" data-rptab="audio">Audio</button>' + "</div>" : '<div class="rp-settings-title">Personajes</div>') + '<div class="rp-settings-body" id="rpSettingsBody"></div>' + "</div>" + "</div>" + (isStaff ? '<button class="icon-btn rp-close-btn" type="button" id="btnRpClose" aria-label="Apagar Roleplay" title="Apagar Roleplay">' + rpXSvg() + "</button>" : "") + "</div>" + rpPagerHtml() + emptyHint + myCharBarHtml;
  renderRpSettingsBody();
  wireRoleplayEvents(wrap);
  rpWirePager(wrap);
  rpMountSwitcher();
  rpFitOverlay(wrap);
}

/* El panel flota sobre el chat: no le quita altura, así los mensajes se ven por detrás */
function rpFitOverlay(wrap) {
  if (!wrap) return;
  function fit() {
    var h = wrap.offsetHeight;
    wrap.style.marginBottom = h > 0 ? "-" + h + "px" : "";
  }
  fit();
  if (!wrap._rpRO && window.ResizeObserver) {
    wrap._rpRO = new ResizeObserver(fit);
    wrap._rpRO.observe(wrap);
  }
}

function renderRpSettingsBody() {
  var body = $("rpSettingsBody");
  if (!body) return;
  var isStaff = rpIsStaff();
  if (rpSettingsTab === "characters") {
    var rows = rpCharacters.map(function(ch) {
      var st = rpStatusInfo(ch);
      var color = rpColorOf(ch);
      return '<div class="rp-char-row">' + avatarSpanHtml(ch.name, ch.avatar_url) + '<button type="button" class="rp-char-row-main" data-act="open-claim" data-char="' + escapeHtml(ch.id) + '">' + '<span class="rp-char-row-name" style="color:' + color + '">' + escapeHtml(ch.name) + "</span>" + '<span class="rp-cast-status rp-cast-status--sm ' + st.cls + '"><i></i>' + st.txt + "</span>" + "</button>" + (isStaff ? '<div class="rp-char-row-actions">' + '<button type="button" data-act="edit" data-char="' + escapeHtml(ch.id) + '" aria-label="Editar">' + rpPencilSvg() + "</button>" + '<button type="button" class="rp-del" data-act="delete" data-char="' + escapeHtml(ch.id) + '" aria-label="Eliminar">' + rpTrashSvg() + "</button>" + "</div>" : "") + "</div>";
    }).join("");
    body.innerHTML = (rows || '<p class="rp-audio-hint">Todavía no hay personajes.</p>') + (isStaff ? '<button type="button" class="rp-add-char-btn" id="btnRpAddCharacter">' + rpPlusSvg() + " Agregar personaje</button>" : "") + (rpMyClaim() ? '<button type="button" class="rp-add-char-btn" data-act="release" data-char="' + escapeHtml(rpMyClaim().character_id) + '">Dejar personaje actual</button>' : "");
  } else {
    var enabled = rpEntity.roleplay_voice_enabled !== false;
    body.innerHTML = '<label class="toggle-row"><span>Permitir chat de voz mientras el Roleplay está activo</span><input type="checkbox" id="rpVoiceToggle"' + (enabled ? " checked" : "") + "></label>" + '<p class="rp-audio-hint">Solo un admin o co-admin puede cambiar esto. Los usuarios siempre pueden entrar y jugar al Roleplay, esto solo prende o apaga el chat de voz mientras tanto.</p>';
  }
  var addBtn = $("btnRpAddCharacter");
  if (addBtn) addBtn.addEventListener("click", function() {
    openCharacterModal(null);
  });
  var voiceToggle = $("rpVoiceToggle");
  if (voiceToggle) voiceToggle.addEventListener("change", function() {
    setRoleplayVoiceEnabled(voiceToggle.checked);
  });
}

function wireRoleplayEvents(wrap) {
  if (!wrap._rpClickBound) {
  wrap._rpClickBound = true;
  wrap.addEventListener("click", function(e) {
    var btn = e.target.closest("[data-act]");
    if (!btn) return;
    e.stopPropagation();
    var act = btn.getAttribute("data-act");
    var charId = btn.getAttribute("data-char");
    if (act === "open-claim") {
      var pop = $("rpSettingsPopup");
      if (pop) pop.classList.remove("open");
      openCharacterClaimModal(charId);
    } else if (act === "add") {
      openCharacterModal(null);
    } else if (act === "edit") {
      openCharacterModal(rpCharacterById(charId));
    } else if (act === "delete") {
      deleteCharacterConfirm(charId);
    } else if (act === "claim") {
      claimRoleplayCharacter(charId);
    } else if (act === "release") {
      releaseRoleplayCharacter(charId || null);
    } else if (act === "rp-mic-up") {
      rpVoiceJoin();
    } else if (act === "rp-mic-toggle") {
      rpVoiceToggleMute();
    } else if (act === "rp-mic-down") {
      rpVoiceStepDown();
    }
  });
  }
  var settingsBtn = $("btnRpSettings"), settingsPopup = $("rpSettingsPopup");
  if (settingsBtn) settingsBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    settingsPopup.classList.toggle("open");
  });
  if (settingsPopup) settingsPopup.addEventListener("click", function(e) {
    if (!e.target.closest("[data-act]")) e.stopPropagation();
  });
  qsa(".chat-actions-tab", wrap).forEach(function(tabBtn) {
    tabBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      rpSettingsTab = tabBtn.getAttribute("data-rptab");
      qsa(".chat-actions-tab", wrap).forEach(function(t) {
        t.classList.remove("active");
      });
      tabBtn.classList.add("active");
      renderRpSettingsBody();
    });
  });
  var closeBtn = $("btnRpClose");
  if (closeBtn) closeBtn.addEventListener("click", function() {
    if (confirm(rpConf().closeConfirmMsg)) rpConf().setActivity(null);
  });
}

document.addEventListener("click", function() {
  var p = $("rpSettingsPopup");
  if (p) p.classList.remove("open");
});

var rpClaimModalCharId = null;

function openCharacterClaimModal(charId) {
  var ch = rpCharacterById(charId);
  if (!ch) return;
  rpClaimModalCharId = charId;
  renderCharacterClaimModal();
  $("rpClaimBackdrop").classList.add("open");
}

function closeCharacterClaimModal() {
  var b = $("rpClaimBackdrop");
  if (b) b.classList.remove("open");
  rpClaimModalCharId = null;
}

function renderCharacterClaimModal() {
  var body = $("rpClaimModalBody");
  var ch = rpCharacterById(rpClaimModalCharId);
  if (!body || !ch) return;
  var claim = rpClaimByCharacter(ch.id);
  var isMine = !!(claim && currentUser && claim.user_id === currentUser.id);
  var isActiveMine = isMine && rpMyClaim() && rpMyClaim().character_id === ch.id;
  var bgStyle = ch.avatar_url ? ' style="background-image:url(&quot;' + encodeURI(ch.avatar_url).replace(/"/g, "%22").replace(/\'/g, "%27") + '&quot;)"' : "";
  var actionHtml = "";
  if (isMine) {
    actionHtml = (isActiveMine ? "" : '<button type="button" class="terminal-btn full-width" id="rpClaimModalUse">Hablar como ' + escapeHtml(ch.name) + "</button>") + '<button type="button" class="terminal-btn full-width" id="rpClaimModalAccept" data-act="release">Dejar personaje</button>';
  } else if (!claim) {
    actionHtml = '<button type="button" class="terminal-btn full-width" id="rpClaimModalAccept" data-act="claim">Aceptar y hablar como ' + escapeHtml(ch.name) + "</button>";
  } else {
    actionHtml = '<p class="rp-audio-hint">Alguien más está usando este personaje ahora mismo.</p>';
  }
  body.innerHTML = '<div class="rp-hex rp-claim-modal-hex"' + bgStyle + ">" + (ch.avatar_url ? "" : '<span class="rp-hex-placeholder">' + escapeHtml(initials(ch.name)) + "</span>") + "</div>" + '<h4 class="rp-claim-modal-name">' + escapeHtml(ch.name) + "</h4>" + (ch.age ? '<div class="rp-info-age">Edad: ' + escapeHtml(ch.age) + "</div>" : "") + (ch.info ? '<p class="rp-info-text">' + escapeHtml(ch.info) + "</p>" : "") + (ch.extra_info ? '<p class="rp-info-extra">' + escapeHtml(ch.extra_info) + "</p>" : "") + '<div class="rp-claim-modal-actions">' + actionHtml + "</div>";
  var acceptBtn = $("rpClaimModalAccept");
  if (acceptBtn) acceptBtn.addEventListener("click", function() {
    var act = acceptBtn.getAttribute("data-act");
    if (act === "claim") claimRoleplayCharacter(ch.id); else if (act === "release") releaseRoleplayCharacter(ch.id);
    closeCharacterClaimModal();
  });
  var useBtn = $("rpClaimModalUse");
  if (useBtn) useBtn.addEventListener("click", function() {
    rpSetActiveChar(ch.id);
    closeCharacterClaimModal();
    renderRoleplayWrap();
  });
}

$("rpClaimClose").addEventListener("click", closeCharacterClaimModal);

$("rpClaimBackdrop").addEventListener("click", function(e) {
  if (e.target === this) closeCharacterClaimModal();
});

/* ---- Selector de color del rol en el formulario del personaje ---- */
var rpColorAuto = true;

function rpSetColorField(color) {
  var input = $("rpCharacterColor");
  var box = $("rpColorSwatches");
  if (!input) return;
  rpColorAuto = !color;
  input.value = color || "#a855f7";
  if (box && !box.children.length) {
    box.innerHTML = RP_HEX_COLORS.map(function(c) {
      return '<button type="button" class="rp-color-swatch" data-color="' + c + '" style="background:' + c + '" aria-label="' + c + '"></button>';
    }).join("");
  }
  rpRefreshColorUi();
}

function rpRefreshColorUi() {
  var input = $("rpCharacterColor");
  var auto = $("rpCharacterColorAuto");
  var box = $("rpColorSwatches");
  if (!input) return;
  if (auto) auto.classList.toggle("active", rpColorAuto);
  input.classList.toggle("is-auto", rpColorAuto);
  if (box) Array.prototype.forEach.call(box.children, function(b) {
    b.classList.toggle("active", !rpColorAuto && b.getAttribute("data-color").toLowerCase() === input.value.toLowerCase());
  });
}

if ($("rpCharacterColor")) {
  $("rpCharacterColor").addEventListener("input", function() {
    rpColorAuto = false;
    rpRefreshColorUi();
  });
  $("rpCharacterColorAuto").addEventListener("click", function() {
    rpColorAuto = true;
    rpRefreshColorUi();
  });
  $("rpColorSwatches").addEventListener("click", function(e) {
    var b = e.target.closest && e.target.closest(".rp-color-swatch");
    if (!b) return;
    $("rpCharacterColor").value = b.getAttribute("data-color");
    rpColorAuto = false;
    rpRefreshColorUi();
  });
}

function openCharacterModal(char) {
  $("rpCharacterForm").reset();
  $("rpCharacterId").value = char ? char.id : "";
  $("rpCharacterModalTitle").textContent = char ? "Editar personaje" : "Nuevo personaje";
  $("rpCharacterSubmitBtn").textContent = char ? "Guardar cambios" : "Crear personaje";
  if (char) {
    $("rpCharacterName").value = char.name || "";
    $("rpCharacterAge").value = char.age || "";
    $("rpCharacterInfo").value = char.info || "";
    $("rpCharacterExtra").value = char.extra_info || "";
  }
  rpSetColorField(char && char.color ? char.color : null);
  $("rpCharacterBackdrop").classList.add("open");
}

function closeCharacterModal() {
  $("rpCharacterBackdrop").classList.remove("open");
  $("rpCharacterForm").reset();
}

$("rpCharacterClose").addEventListener("click", closeCharacterModal);

$("rpCharacterBackdrop").addEventListener("click", function(e) {
  if (e.target === this) closeCharacterModal();
});

$("rpCharacterForm").addEventListener("submit", function(e) {
  e.preventDefault();
  if (!currentUser || !rpEntity) return;
  var conf = rpConf();
  var id = $("rpCharacterId").value || null;
  var name = $("rpCharacterName").value.trim();
  if (!name) return;
  if (!id && rpCharacters.length >= RP_MAX_CHARACTERS) {
    toast("Se alcanzó el límite de " + RP_MAX_CHARACTERS + " personajes.");
    return;
  }
  var age = $("rpCharacterAge").value.trim();
  var info = $("rpCharacterInfo").value.trim();
  var extra = $("rpCharacterExtra").value.trim();
  var avatarFile = $("rpCharacterAvatar").files[0];
  var btn = $("rpCharacterSubmitBtn");
  btn.disabled = true;
  btn.textContent = "Guardando...";
  var patch = {
    name: name,
    age: age || null,
    info: info || null,
    extra_info: extra || null,
    color: rpColorAuto ? null : $("rpCharacterColor").value
  };
  var colorSkipped = false;
  var photoFailed = false;
  /* La politica de storage exige subir a roleplay/<id del personaje>/, asi que el personaje debe existir antes de subir su foto */
  function uploadPhotoFor(charId) {
    return uploadFiles([ avatarFile ], "roleplay/" + charId).then(function(up) {
      return up[0] ? up[0].url : null;
    }).catch(function(err) {
      console.error("Roleplay: no se pudo subir la foto del personaje:", err);
      photoFailed = true;
      return null;
    });
  }
  var uploadedUrl = null;
  function doSave() {
    if (id) {
      return (avatarFile && !uploadedUrl ? uploadPhotoFor(id) : Promise.resolve(uploadedUrl)).then(function(url) {
        if (url) {
          uploadedUrl = url;
          patch.avatar_url = url;
        }
        return supabase.from(conf.characterTable).update(patch).eq("id", id).select().single();
      });
    }
    patch[conf.entityIdField] = rpEntity.id;
    patch.created_by = currentUser.id;
    return supabase.from(conf.characterTable).insert(patch).select().single().then(function(res) {
      if (res.error || !res.data || !avatarFile) return res;
      return uploadPhotoFor(res.data.id).then(function(url) {
        if (!url) return res;
        return supabase.from(conf.characterTable).update({
          avatar_url: url
        }).eq("id", res.data.id).select().single();
      });
    });
  }
  /* Si la columna "color" todavía no existe en la base de datos, guarda el personaje igual y avisa */
  var saveChar = doSave().then(function(res) {
    if (res.error && /color/i.test(res.error.message || "") && "color" in patch) {
      delete patch.color;
      colorSkipped = true;
      return doSave();
    }
    return res;
  });
  saveChar.then(function(res) {
    btn.disabled = false;
    btn.textContent = id ? "Guardar cambios" : "Crear personaje";
    if (res.error) {
      toast(t("roleplay.err_char_save") + " " + res.error.message);
      return;
    }
    closeCharacterModal();
    toast((id ? "Personaje actualizado." : "Personaje creado.") + (colorSkipped ? " El color no se guardó: falta crear la columna color en la base de datos." : "") + (photoFailed ? " " + t("roleplay.err_photo_upload") : ""));
    loadRoleplayData().then(renderRoleplayWrap);
  }).catch(function(err) {
    console.error("Roleplay: error guardando personaje:", err);
    toast(t("roleplay.err_char_save") + " " + (err && err.message ? err.message : ""));
    btn.disabled = false;
    btn.textContent = id ? "Guardar cambios" : "Crear personaje";
  });
});

function deleteCharacterConfirm(charId) {
  var ch = rpCharacterById(charId);
  if (!ch) return;
  if (!confirm('¿Eliminar a "' + ch.name + '"? Esto también libera a quien lo esté usando.')) return;
  supabase.from(rpConf().characterTable).delete().eq("id", charId).then(function(res) {
    if (res.error) {
      toast(t("roleplay.err_char_delete") + " " + res.error.message);
      return;
    }
    toast(t("roleplay.toast_char_deleted"));
    loadRoleplayData().then(renderRoleplayWrap);
  });
}

function claimRoleplayCharacter(charId) {
  if (!currentUser || !rpEntity) return;
  var conf = rpConf();
  var row = {
    character_id: charId,
    user_id: currentUser.id
  };
  row[conf.entityIdField] = rpEntity.id;
  supabase.from(conf.claimTable).insert(row).then(function(res) {
    if (res.error) {
      toast(t("roleplay.err_char_taken"));
      loadRoleplayData().then(renderRoleplayWrap);
      return;
    }
    rpOpenInfoId = null;
    rpSetActiveChar(charId);
    toast(t("roleplay.toast_now_speaking_as") + " " + (rpCharacterById(charId) ? rpCharacterById(charId).name : t("roleplay.that_character")) + ".");
    loadRoleplayData().then(renderRoleplayWrap);
  });
}

function releaseRoleplayCharacter(charId) {
  if (!currentUser || !rpEntity) return;
  var existing = charId ? rpMyClaims().filter(function(c) {
    return c.character_id === charId;
  })[0] : rpMyClaim();
  if (!existing) return;
  supabase.from(rpConf().claimTable).delete().eq("character_id", existing.character_id).then(function(res) {
    if (res.error) {
      toast(t("roleplay.err_char_release") + " " + res.error.message);
      return;
    }
    rpOpenInfoId = null;
    toast(t("roleplay.toast_char_released"));
    loadRoleplayData().then(function() {
      if (!rpMyClaim() && rpVoiceJoined) rpVoiceStepDown();
      renderRoleplayWrap();
    });
  });
}

function setRoleplayVoiceEnabled(enabled) {
  if (!currentUser || !rpEntity || !rpIsStaff()) return;
  var conf = rpConf();
  supabase.from(conf.entityTable).update({
    roleplay_voice_enabled: enabled
  }).eq("id", rpEntity.id).select().single().then(function(res) {
    if (res.error) {
      toast(t("roleplay.err_audio_change") + " " + res.error.message);
      return;
    }
    rpEntity.roleplay_voice_enabled = res.data.roleplay_voice_enabled;
    conf.syncCurrentEntity({
      roleplay_voice_enabled: res.data.roleplay_voice_enabled
    });
    rpVoiceSync();
    renderRoleplayWrap();
    toast(enabled ? "Chat de voz permitido en el Roleplay." : "Chat de voz apagado en el Roleplay.");
  });
}

function rpMountSwitcher() {
  var old = $("rpSwitchBtn");
  if (old) old.remove();
  var entity = rpEntity && rpConf().getCurrentEntity();
  var mine = rpMyClaims();
  if (!entity || entity.active_activity !== "roleplay" || !mine.length) {
    var pp = $("rpSwitchPopup");
    if (pp) pp.classList.remove("open");
    return;
  }
  var input = $(rpScope === "community" ? "communityChatInput" : rpScope === "dm" ? "dmInput" : "groupChatInput");
  if (!input || !input.parentNode) return;
  var cur = rpMyClaim();
  var ch = cur ? rpCharacterById(cur.character_id) : null;
  if (!ch) return;
  var btn = document.createElement("button");
  btn.type = "button";
  btn.id = "rpSwitchBtn";
  btn.className = "rp-switch-btn";
  btn.setAttribute("aria-label", "Cambiar de personaje");
  btn.innerHTML = avatarSpanHtml(ch.name, ch.avatar_url, "rp-switch-av", null) + (mine.length > 1 ? '<span class="rp-switch-count">' + mine.length + "</span>" : "");
  btn.addEventListener("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    rpToggleSwitchPopup(btn);
  });
  input.parentNode.insertBefore(btn, input);
}

function rpToggleSwitchPopup(anchor) {
  var pop = $("rpSwitchPopup");
  if (!pop) {
    pop = document.createElement("div");
    pop.id = "rpSwitchPopup";
    pop.className = "rp-switch-popup";
    document.body.appendChild(pop);
    pop.addEventListener("click", function(e) {
      e.stopPropagation();
      var item = e.target.closest("[data-rp-use]");
      if (!item) return;
      rpSetActiveChar(item.getAttribute("data-rp-use"));
      pop.classList.remove("open");
      renderRoleplayWrap();
    });
    document.addEventListener("click", function() {
      pop.classList.remove("open");
    });
  }
  if (pop.classList.contains("open")) {
    pop.classList.remove("open");
    return;
  }
  var cur = rpMyClaim();
  pop.innerHTML = '<div class="rp-switch-title">Hablar como</div>' + rpMyClaims().map(function(c) {
    var ch = rpCharacterById(c.character_id);
    if (!ch) return "";
    var on = cur && cur.character_id === c.character_id;
    return '<button type="button" class="rp-switch-item' + (on ? " on" : "") + '" data-rp-use="' + escapeHtml(ch.id) + '">' + avatarSpanHtml(ch.name, ch.avatar_url, "rp-switch-av", null) + "<span>" + escapeHtml(ch.name) + "</span>" + (on ? '<em>activo</em>' : "") + "</button>";
  }).join("") + '<div class="rp-switch-hint">Para tomar otro personaje, ábrelo en el panel de Roleplay: ya no tienes que dejar el que usas.</div>';
  var r = anchor.getBoundingClientRect();
  pop.style.left = Math.max(8, Math.min(r.left, window.innerWidth - 260)) + "px";
  pop.style.bottom = Math.max(8, window.innerHeight - r.top + 8) + "px";
  pop.classList.add("open");
}
