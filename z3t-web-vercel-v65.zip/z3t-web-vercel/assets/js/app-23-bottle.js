"use strict";

var BOTTLE_ICON_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="M10 2h4v3.2c1.6.9 2.6 2.6 2.6 4.5V19a2.5 2.5 0 0 1-2.5 2.5h-4.2A2.5 2.5 0 0 1 7.4 19V9.7c0-1.9 1-3.6 2.6-4.5V2Z"/>' + '<path d="M9.5 5h5"/><path d="M8.5 12h7"/>' + "</svg>";

var bottleGrabBusy = false;

function openBottleScreen() {
  if (!currentUser) return;
  enterImmersive("bottle");
  activatePanel("panel-bottle");
  renderBottleScreen();
}

function closeBottleScreen() {
  exitImmersive("bottle");
  activatePanel("panel-list");
  if (location.pathname !== "/") history.pushState({
    view: "list"
  }, "", "/");
}

function renderBottleScreen() {
  var wrap = $("bottleDetail");
  if (!wrap) return;
  var floatSpots = [ {
    top: "12%",
    left: "10%"
  }, {
    top: "18%",
    left: "78%"
  }, {
    top: "38%",
    left: "4%"
  }, {
    top: "34%",
    left: "88%"
  }, {
    top: "66%",
    left: "12%"
  }, {
    top: "62%",
    left: "82%"
  }, {
    top: "82%",
    left: "50%",
    transform: "translateX(-50%)"
  } ];
  var floatsHtml = floatSpots.map(function(spot, i) {
    var dur = (5 + Math.random() * 3).toFixed(2);
    var delay = (Math.random() * 3).toFixed(2);
    var style = "top:" + spot.top + "; left:" + spot.left + ";" + (spot.transform ? " transform:" + spot.transform + ";" : "") + " --bdur:" + dur + "s; --bdelay:" + delay + "s;";
    return '<span class="bottle-float" style="' + style + '">' + BOTTLE_ICON_SVG + "</span>";
  }).join("");
  var starsHtml = "";
  for (var i = 0; i < 34; i++) {
    var top = (Math.random() * 100).toFixed(2);
    var left = (Math.random() * 100).toFixed(2);
    var size = (Math.random() * 2 + 1).toFixed(2);
    var dur = (Math.random() * 4 + 3).toFixed(2);
    var delay = (Math.random() * 5).toFixed(2);
    var drift = (Math.random() * 30 - 15).toFixed(1);
    starsHtml += '<span class="home-star" style="top:' + top + "%; left:" + left + "%; width:" + size + "px; height:" + size + "px; --dur:" + dur + "s; --delay:" + delay + "s; --drift:" + drift + 'px;"></span>';
  }
  wrap.innerHTML = '<div class="bottle-shell">' + '<div class="bottle-star-field">' + starsHtml + "</div>" + '<div class="bottle-topbar">' + '<button class="icon-btn" id="btnBottleBack" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + "<h2>Botella a la Deriva</h2>" + '<button class="icon-btn" id="btnBottleInfo" type="button" aria-label="Cómo funciona">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16.5"/><circle cx="12" cy="7.7" r="1"/></svg>' + "</button>" + "</div>" + '<div class="bottle-stage">' + floatsHtml + '<button class="bottle-grab-btn" id="btnBottleGrab" type="button">Grab</button>' + "</div>" + '<p class="bottle-empty-hint" id="bottleEmptyHint" hidden>El mar está tranquilo... nadie ha soltado botellas todavía. ¡Sé el primero!</p>' + '<div class="bottle-send-row">' + '<button class="bottle-send-btn" id="btnBottleSend" type="button" aria-label="Enviar una botella">' + BOTTLE_ICON_SVG + "</button>" + "<span>Send a Bottle</span>" + "</div>" + "</div>";
  $("btnBottleBack").addEventListener("click", closeBottleScreen);
  $("btnBottleInfo").addEventListener("click", function() {
    toast('🍾 Escribe un mensaje y suéltalo al mar. Toca "Grab" para recibir el de otra persona al azar -- nunca te puede tocar el tuyo.');
  });
  $("btnBottleGrab").addEventListener("click", grabBottle);
  $("btnBottleSend").addEventListener("click", openBottleCompose);
}

function openBottleCompose() {
  $("bottleComposeBody").value = "";
  updateBottleCharCount();
  $("bottleComposeBackdrop").classList.add("open");
}

function updateBottleCharCount() {
  var len = $("bottleComposeBody").value.length;
  $("bottleCharCount").textContent = len + " / 500";
}

function sendBottle() {
  var body = $("bottleComposeBody").value.trim();
  if (!body) {
    toast("Escribe algo antes de soltar la botella.");
    return;
  }
  var btn = $("btnBottleComposeSend");
  btn.disabled = true;
  supabase.rpc("send_bottle", {
    p_message: body
  }).then(function(res) {
    btn.disabled = false;
    if (res.error) {
      toast("No se pudo soltar la botella: " + res.error.message);
      return;
    }
    $("bottleComposeBackdrop").classList.remove("open");
    toast("🍾 Tu botella ya está a la deriva...");
  });
}

function grabBottle() {
  if (bottleGrabBusy || !currentUser) return;
  bottleGrabBusy = true;
  var grabBtn = $("btnBottleGrab");
  grabBtn.classList.add("grabbing");
  supabase.rpc("grab_bottle").then(function(res) {
    setTimeout(function() {
      grabBtn.classList.remove("grabbing");
      bottleGrabBusy = false;
      if (res.error) {
        toast("No se pudo agarrar una botella: " + res.error.message);
        return;
      }
      var rows = res.data;
      var bottle = Array.isArray(rows) ? rows[0] : rows;
      if (!bottle) {
        var hint = $("bottleEmptyHint");
        if (hint) {
          hint.hidden = false;
          setTimeout(function() {
            hint.hidden = true;
          }, 3500);
        }
        toast("🌊 No hay botellas a la deriva ahora mismo. ¡Suelta tú la primera!");
        return;
      }
      showBottleReveal(bottle);
    }, 650);
  });
}

function showBottleReveal(bottle) {
  $("bottleRevealText").textContent = bottle.message;
  $("bottleRevealTime").textContent = "Recibida " + timeAgo(bottle.created_at);
  var stage = $("bottleRevealStage");
  stage.innerHTML = '<img loading=lazy decoding=async class="bottle-reveal-bottle" src="assets/icons/tile-botella-deriva.webp" alt="Botella">';
  var scroll = $("bottleRevealScroll");
  scroll.classList.remove("bottle-scroll");
  void scroll.offsetWidth;
  scroll.classList.add("bottle-scroll");
  $("bottleRevealBackdrop").classList.add("open");
}

if ($("bottleComposeClose")) $("bottleComposeClose").addEventListener("click", function() {
  $("bottleComposeBackdrop").classList.remove("open");
});

if ($("bottleComposeBackdrop")) $("bottleComposeBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

if ($("bottleComposeBody")) $("bottleComposeBody").addEventListener("input", updateBottleCharCount);

if ($("btnBottleComposeSend")) $("btnBottleComposeSend").addEventListener("click", sendBottle);

if ($("bottleRevealClose")) $("bottleRevealClose").addEventListener("click", function() {
  $("bottleRevealBackdrop").classList.remove("open");
});

if ($("bottleRevealBackdrop")) $("bottleRevealBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

if ($("btnBottleRevealAnother")) $("btnBottleRevealAnother").addEventListener("click", function() {
  $("bottleRevealBackdrop").classList.remove("open");
  setTimeout(grabBottle, 200);
});