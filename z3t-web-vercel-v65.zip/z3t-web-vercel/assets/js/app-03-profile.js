"use strict";

var currentProfileUid = null;

var currentProfileData = null;

(function watchProfileOpenState() {
  var el = document.getElementById("profileBackdrop");
  if (!el || !window.MutationObserver) return;
  var sync = function() {
    document.body.classList.toggle("profile-open", el.classList.contains("open"));
  };
  new MutationObserver(sync).observe(el, {
    attributes: true,
    attributeFilter: [ "class" ]
  });
  sync();
})();

function fetchPublicProfile(userId) {
  var PUBLIC_PROFILE_COLUMNS = [ "id", "username", "name", "bio", "location_public", "avatar_url", "banner_url", "name_color", "role", "verified", "is_volunteer", "banned", "followers_count", "following_count", "joined_at", "social_links" ].join(",");
  return supabase.from("profiles").select(PUBLIC_PROFILE_COLUMNS).eq("id", userId).single().then(function(res) {
    if (res.error) {
      console.error("[fetchPublicProfile] error de Supabase:", res.error);
      var e = new Error(res.error.message || "Error desconocido de Supabase");
      e.code = res.error.code;
      e.details = res.error.details;
      e.hint = res.error.hint;
      throw e;
    }
    return res.data;
  });
}

function openFileView(slug) {
  supabase.from("attachments").select("*, profiles(username), threads(title, slug)").eq("slug", slug).single().then(function(res) {
    if (res.error || !res.data) {
      toast(t("profile.err_file_not_found"));
      resetToFeedOnMissingRoute("/archivos/");
      return;
    }
    var a = res.data;
    var isImage = a.type && a.type.indexOf("image/") === 0;
    $("fileModalTitle").textContent = a.name;
    var uploaderName = a.profiles ? a.profiles.username : "usuario";
    var threadTitle = a.threads ? a.threads.title : null;
    var threadSlug = a.threads ? a.threads.slug : null;
    $("fileBody").innerHTML = (isImage ? '<img loading=lazy decoding=async src="' + a.url + '" alt="' + escapeHtml(a.name) + '">' : "") + '<div class="file-meta">' + "<div><b>Nombre:</b> " + escapeHtml(a.name) + "</div>" + "<div><b>Tamaño:</b> " + formatSize(a.size) + "</div>" + '<div><b>Subido por:</b> <span class="user-link" id="fileUploaderLink" data-uid="' + escapeHtml(a.uploader_id || "") + '">@' + escapeHtml(uploaderName) + "</span></div>" + (threadTitle ? '<div><b>Publicación:</b> <span class="user-link" id="fileThreadLink">' + escapeHtml(threadTitle) + "</span></div>" : "") + "</div>" + '<a class="terminal-btn full-width" href="' + a.url + '" target="_blank" rel="noopener noreferrer" download>Descargar archivo</a>';
    if (!state.suppressPush) history.pushState({
      view: "file",
      slug: slug
    }, "", "/archivos/" + encodeURIComponent(slug));
    state.suppressPush = false;
    $("fileBackdrop").classList.add("open");
    var upLink = $("fileUploaderLink");
    if (upLink) upLink.addEventListener("click", function() {
      $("fileBackdrop").classList.remove("open");
      openProfile(a.uploader_id);
    });
    var thLink = $("fileThreadLink");
    if (thLink && threadSlug) thLink.addEventListener("click", function() {
      $("fileBackdrop").classList.remove("open");
      resolveThreadBySlug(threadSlug);
    });
  }).catch(function(err) {
    console.error("[openFileView] fallo consultando el archivo:", err);
    toast(t("profile.err_file_not_found"));
    resetToFeedOnMissingRoute("/archivos/");
  });
}

$("fileClose").addEventListener("click", function() {
  $("fileBackdrop").classList.remove("open");
  history.pushState({
    view: "list"
  }, "", "/");
});

$("fileBackdrop").addEventListener("click", function(e) {
  if (e.target === this) {
    this.classList.remove("open");
    history.pushState({
      view: "list"
    }, "", "/");
  }
});

function openProfile(userId) {
  if (!currentUser) return;
  var uid = userId || currentUser.id;
  var isSelf = uid === currentUser.id;
  var profilePromise = isSelf ? Promise.resolve({
    id: currentUser.id,
    username: currentUser.username,
    avatar_url: currentUser.avatarUrl,
    zcard_avatar_url: currentUser.zcardAvatarUrl,
    banner_url: currentUser.bannerUrl,
    bio: currentUser.bio,
    location_public: currentUser.profileLocation,
    joined_at: currentUser.joinedAt,
    circle_id: currentUser.circleId,
    role: currentUser.role,
    verified: currentUser.verified,
    is_volunteer: currentUser.isVolunteer,
    name_color: currentUser.nameColor,
    name: currentUser.name,
    followers_count: currentUser.followersCount,
    following_count: currentUser.followingCount
  }) : fetchPublicProfile(uid);
  profilePromise.then(function(p) {
    if (!p) {
      toast(t("profile.err_load"));
      return;
    }
    var requiredIds = [ "profileModalTitle", "profileAvatar", "profileBanner", "profileName", "profileHandle", "profileMeta", "profileOnline", "profileStatusDot", "statFollowers", "statFollowing", "statVisits", "profileBioText", "profileLocationText", "profileLocationRow", "btnFollow", "btnMessageUser", "btnOpenSettings", "btnAdminBan", "btnAdminVerify", "btnOpenAdminPanel", "profileFlags", "profileVolunteerBadgeWrap", "profileBackdrop" ];
    var missing = requiredIds.filter(function(id) {
      return !$(id);
    });
    if (missing.length) {
      console.error("[openProfile] Falta(n) en el HTML: " + missing.join(", ") + ". El index.html desplegado probablemente no es la misma versión que este JS.");
      toast(t("profile.err_version_mismatch"));
      return;
    }
    var isSuspended = !isSelf && p.banned === true;
    currentProfileUid = uid;
    currentProfileData = {
      username: p.username,
      name: p.name,
      avatar_url: p.avatar_url
    };
    $("profileModalTitle").textContent = isSelf ? "Tu perfil" : "@" + p.username;
    if (isSuspended) {
      setAvatarEl($("profileAvatar"), p.username, "assets/status/banned-avatar.webp");
      $("profileBanner").style.backgroundImage = 'url("assets/status/banned-banner.webp")';
    } else {
      setAvatarEl($("profileAvatar"), p.username, p.avatar_url);
      loadProfileAvatarFrame(uid);
      $("profileBanner").style.backgroundImage = p.banner_url ? 'url("' + encodeURI(p.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '")' : "";
    }
    $("profileName").innerHTML = escapeHtml(p.name || p.username) + roleBadgeHtml(p.role, p.verified);
    $("profileName").style.color = p.name_color || "";
    $("profileVolunteerBadgeWrap").innerHTML = volunteerBadgeHtml(p.is_volunteer);
    $("profileHandle").textContent = "@" + p.username;
    $("profileMeta").textContent = "Miembro desde " + timeAgo(p.joined_at);
    $("profileOnline").hidden = !isSelf;
    $("profileStatusDot").hidden = !isSelf;
    $("statFollowers").textContent = p.followers_count || 0;
    $("statFollowing").textContent = p.following_count || 0;
    $("statVisits").textContent = "···";
    renderProfileBio(p);
    if (typeof renderProfileSocials === "function") renderProfileSocials(p);
    $("profileLocationText").textContent = p.location_public || "";
    $("profileLocationRow").hidden = !p.location_public;
    $("profileLocationText").hidden = !p.location_public;
    var shouldPushUrl = !!(p.username && !state.suppressPush);
    state.suppressPush = false;
    var btnFollow = $("btnFollow");
    var btnMessageUser = $("btnMessageUser");
    var btnOpenSettings = $("btnOpenSettings");
    if (isSelf) {
      btnFollow.hidden = true;
      btnMessageUser.hidden = true;
      $("btnAdminBan").hidden = true;
      $("btnAdminVerify").hidden = true;
      btnOpenSettings.hidden = false;
      btnOpenSettings.onclick = function() {
        openSettings(p);
      };
      $("btnOpenAdminPanel").hidden = true;
      $("profileBackdrop").classList.add("open");
      document.body.classList.add("profile-open");
      if (shouldPushUrl) history.pushState({
        view: "profile",
        username: p.username
      }, "", "/perfiles/" + encodeURIComponent(p.username));
    } else if (isSuspended) {
      btnOpenSettings.hidden = true;
      $("btnOpenAdminPanel").hidden = true;
      btnFollow.hidden = true;
      btnMessageUser.hidden = true;
      var btnAdminBanS = $("btnAdminBan");
      btnAdminBanS.hidden = true;
      var btnAdminVerifyS = $("btnAdminVerify");
      btnAdminVerifyS.hidden = true;
      $("profileBackdrop").classList.add("open");
      document.body.classList.add("profile-open");
      if (shouldPushUrl) history.pushState({
        view: "profile",
        username: p.username
      }, "", "/perfiles/" + encodeURIComponent(p.username));
    } else {
      btnOpenSettings.hidden = true;
      $("btnOpenAdminPanel").hidden = true;
      btnFollow.hidden = false;
      btnFollow.disabled = true;
      btnFollow.textContent = "Cargando...";
      btnMessageUser.hidden = false;
      btnMessageUser.onclick = function() {
        btnMessageUser.disabled = true;
        getOrCreateConversation(uid).then(function(conv) {
          btnMessageUser.disabled = false;
          if (!conv) return;
          $("profileBackdrop").classList.remove("open");
          document.body.classList.remove("profile-open");
          if (location.pathname.indexOf("/perfiles/") === 0) history.pushState({
            view: "list"
          }, "", "/");
          openConversation(conv.id, uid, p.username, p.name || p.username, p.avatar_url, p.name_color, p.role, p.verified);
        });
      };
      $("profileBackdrop").classList.add("open");
      document.body.classList.add("profile-open");
      if (shouldPushUrl) history.pushState({
        view: "profile",
        username: p.username
      }, "", "/perfiles/" + encodeURIComponent(p.username));
      var btnAdminBan = $("btnAdminBan");
      btnAdminBan.hidden = true;
      var btnAdminVerify = $("btnAdminVerify");
      btnAdminVerify.hidden = true;
      supabase.from("follows").select("follower_id").eq("follower_id", currentUser.id).eq("following_id", uid).maybeSingle().then(function(res) {
        var following = !!res.data;
        btnFollow.disabled = false;
        btnFollow.textContent = following ? "Dejar de seguir" : "Seguir";
        btnFollow.onclick = function() {
          btnFollow.disabled = true;
          var action = following ? supabase.from("follows").delete().eq("follower_id", currentUser.id).eq("following_id", uid) : supabase.from("follows").insert({
            follower_id: currentUser.id,
            following_id: uid
          });
          action.then(function(res2) {
            if (res2.error) {
              toast(t("profile.err_update"));
              btnFollow.disabled = false;
              return;
            }
            toast(following ? "Dejaste de seguir a @" + p.username : "Ahora sigues a @" + p.username);
            if (!following) awardAchievement(currentUser.id, "first_friend");
            openProfile(uid);
          });
        };
      });
      supabase.from("profile_visits").insert({
        profile_user_id: uid,
        visitor_id: currentUser.id
      }).then(function() {});
    }
    renderProfileBadges(uid);
    renderProfileFlags(uid);
    renderProfileCommunitiesStrip(uid);
    renderFactionFlag(uid);
    renderWall(uid, isSelf);
    renderProfilePosts(uid);
    supabase.rpc("get_profile_visit_count", {
      target_user_id: uid
    }).then(function(res) {
      $("statVisits").textContent = res.error ? 0 : res.data || 0;
    });
  }).catch(function(err) {
    console.error("[openProfile] fallo al abrir el perfil:", err, err && err.stack);
    var detail = err && err.code ? " (" + err.code + ": " + err.message + ")" : err && err.message ? " (" + err.message + ")" : "";
    toast(t("profile.err_load") + detail);
  });
}

var MAX_PROFILE_FLAGS = 35;

function renderProfileFlags(uid) {
  var wrap = $("profileFlags");
  if (!wrap) return;
  supabase.from("profile_flags").select("*").eq("user_id", uid).order("position").then(function(res) {
    var rows = res.error ? [] : res.data || [];
    if (!rows.length) {
      wrap.innerHTML = "";
      wrap.hidden = true;
      return;
    }
    wrap.hidden = false;
    wrap.innerHTML = rows.map(function(f) {
      return typeof flagPennantHtml === "function" ? flagPennantHtml(f.text, f.color) : '<span class="profile-flag-pennant" style="background:' + hexToRgba(f.color || "#a855f7", .4) + ';">' + escapeHtml(f.text || "") + "</span>";
    }).join("");
  });
}

function renderFlagsManageList(uid) {
  var wrap = $("flagsManageList");
  if (!wrap) return;
  flagFieldMax.profileFlagsField = MAX_PROFILE_FLAGS;
  flagFieldHandlers.profileFlagsField = function(list) {
    syncProfileFlags(uid, list).then(function() {
      renderProfileFlags(uid);
    }).catch(function() {
      toast(t("profile.err_flag_save"));
      renderFlagsManageList(uid);
    });
  };
  wrap.innerHTML = flagFieldHtml("profileFlagsField", "Tus banderas");
  supabase.from("profile_flags").select("*").eq("user_id", uid).order("position").then(function(res) {
    var rows = res.error ? [] : res.data || [];
    rows.forEach(function(f) {
      if (f.color && typeof flagKnownColors !== "undefined") flagKnownColors[flagTextKey(f.text)] = f.color;
    });
    flagFieldSet("profileFlagsField", rows.map(function(f) {
      return f.text;
    }));
  });
}

function renderProfileCommunitiesStrip(uid) {
  var wrap = $("profileCommunitiesStrip");
  if (!wrap) return;
  wrap.hidden = true;
  wrap.innerHTML = "";
  supabase.from("community_members").select("role, communities(id, name, slug, banner_url, created_by)").eq("user_id", uid).then(function(res) {
    var rows = (res.error ? [] : res.data || []).filter(function(r) {
      if (!r.communities) return false;
      var c = r.communities;
      var isCreator = c.created_by === uid;
      var isStaff = r.role === "admin" || r.role === "co_admin";
      return isCreator || isStaff;
    });
    if (!rows.length) return;
    wrap.hidden = false;
    wrap.innerHTML = rows.map(function(r) {
      var c = r.communities;
      var isCreator = c.created_by === uid;
      var isStaff = r.role === "admin" || r.role === "co_admin";
      var badge = isCreator ? "👑" : isStaff ? "⚙" : "";
      var badgeTitle = isCreator ? "Creador" : r.role === "admin" ? "Admin" : r.role === "co_admin" ? "Co-Admin" : "Miembro";
      return '<button type="button" class="profile-community-chip" data-slug="' + escapeHtml(c.slug) + '" title="' + escapeHtml(c.name) + " · " + escapeHtml(badgeTitle) + '">' + avatarSpanHtml(c.name, c.banner_url, null) + (badge ? '<span class="profile-community-chip-badge">' + badge + "</span>" : "") + '<span class="profile-community-chip-name">' + escapeHtml(c.name) + "</span>" + "</button>";
    }).join("");
    qsa(".profile-community-chip", wrap).forEach(function(chip) {
      chip.addEventListener("click", function() {
        $("profileBackdrop").classList.remove("open");
        document.body.classList.remove("profile-open");
        if (location.pathname.indexOf("/perfiles/") === 0) history.pushState({
          view: "list"
        }, "", "/");
        if (typeof openCommunity === "function") openCommunity(chip.getAttribute("data-slug"));
      });
    });
  });
}

function loadProfileAvatarFrame(uid) {
  var ring = $("profileAvatarFrameRing");
  if (!ring) return;
  ring.hidden = true;
  ring.style.backgroundImage = "";
  if (!uid) return;
  supabase.from("user_frames").select("frame_id, frames(id, frame_png_url)").eq("user_id", uid).eq("equipped", true).maybeSingle().then(function(res) {
    var row = res.data;
    var frame = row && row.frames;
    if (!frame || !frame.frame_png_url) return;
    ring.style.backgroundImage = 'url("' + encodeURI(frame.frame_png_url).replace(/"/g, "%22").replace(/'/g, "%27") + '")';
    ring.hidden = false;
  });
}

function openAvatarView(uid, username, avatarUrl, displayName) {
  setAvatarEl($("avatarViewPhoto"), username, avatarUrl);
  $("avatarViewName").textContent = displayName || username || "";
  var ring = $("avatarViewFrameRing");
  var findBtn = $("avatarViewFindFrame");
  ring.hidden = true;
  ring.style.backgroundImage = "";
  findBtn.hidden = true;
  findBtn.onclick = null;
  $("avatarViewBackdrop").classList.add("open");
  if (!uid) return;
  supabase.from("user_frames").select("frame_id, frames(id, frame_png_url)").eq("user_id", uid).eq("equipped", true).maybeSingle().then(function(res) {
    var row = res.data;
    var frame = row && row.frames;
    if (!frame || !frame.frame_png_url) return;
    ring.style.backgroundImage = 'url("' + encodeURI(frame.frame_png_url).replace(/"/g, "%22").replace(/'/g, "%27") + '")';
    ring.hidden = false;
    findBtn.hidden = false;
    findBtn.onclick = function() {
      $("avatarViewBackdrop").classList.remove("open");
      $("profileBackdrop").classList.remove("open");
      document.body.classList.remove("profile-open");
      if (location.pathname.indexOf("/perfiles/") === 0) history.pushState({
        view: "list"
      }, "", "/");
      if (typeof openStoreFrameById === "function") openStoreFrameById(frame.id);
    };
  });
}

var profileAvatarEl = $("profileAvatar");

if (profileAvatarEl) profileAvatarEl.addEventListener("click", function() {
  if (!currentProfileData) return;
  openAvatarView(currentProfileUid, currentProfileData.username, currentProfileData.avatar_url, currentProfileData.name);
});

var avatarViewCloseEl = $("avatarViewClose");

if (avatarViewCloseEl) avatarViewCloseEl.addEventListener("click", function() {
  $("avatarViewBackdrop").classList.remove("open");
});

var avatarViewBackdropEl = $("avatarViewBackdrop");

if (avatarViewBackdropEl) avatarViewBackdropEl.addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

function openSettings(p) {
  if (!currentUser) return;
  $("nameInput").value = p.name || p.username || "";
  $("usernameInput").value = p.username;
  bioEditorSet(p.bio);
  if (typeof socialsSettingsFill === "function") socialsSettingsFill(p);
  $("locationInput").value = p.location_public || "";
  setupRegionCardGrid("regionCardGrid", p.region || "LATAM");
  $("nameColorInput").value = p.name_color || "#efe9e1";
  setAvatarEl($("settingsAvatarPreview"), p.username, p.avatar_url);
  $("settingsAvatarPreview").setAttribute("data-uid", currentUser.id);
  queueFrameLookup(currentUser.id);
  renderAchievementManageList(currentUser.id);
  renderFlagsManageList(currentUser.id);
  renderZcardPreview(p);
  $("settingsBackdrop").classList.add("open");
}

$("btnResetNameColor").addEventListener("click", function() {
  $("nameColorInput").value = "#efe9e1";
});

$("settingsClose").addEventListener("click", function() {
  $("settingsBackdrop").classList.remove("open");
});

$("settingsBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

function openProfileMenu() {
  if (!currentUser) {
    toast(t("profile.err_no_session"));
    return;
  }
  setAvatarEl($("profileMenuAvatar"), currentUser.username, currentUser.avatarUrl);
  $("profileMenuAvatar").setAttribute("data-uid", currentUser.id);
  queueFrameLookup(currentUser.id);
  $("btnProfileMenuAdmin").hidden = currentUser.role !== "admin";
  var volunteerMenuBtn = $("btnProfileMenuVolunteer");
  if (volunteerMenuBtn) volunteerMenuBtn.hidden = !(currentUser.isVolunteer || currentUser.role === "admin");
  $("profileMenuName").textContent = currentUser.name || currentUser.username;
  $("profileMenuHandle").textContent = currentUser.username;
  $("profileMenu").classList.add("open");
  $("profileMenuBackdrop").classList.add("open");
  document.body.classList.add("profile-open");
  if (window.updateAchvMenuBadge) window.updateAchvMenuBadge();
}

function closeProfileMenu() {
  $("profileMenu").classList.remove("open");
  $("profileMenuBackdrop").classList.remove("open");
  document.body.classList.remove("profile-open");
}

$("btnProfile").addEventListener("click", openProfileMenu);

$("profileMenuBackdrop").addEventListener("click", closeProfileMenu);

$("profileMenuCard").addEventListener("click", function() {
  closeProfileMenu();
  openProfile();
});

$("btnProfileMenuSettings").addEventListener("click", function() {
  closeProfileMenu();
  openSettings({
    id: currentUser.id,
    username: currentUser.username,
    avatar_url: currentUser.avatarUrl,
    zcard_avatar_url: currentUser.zcardAvatarUrl,
    bio: currentUser.bio,
    location_public: currentUser.profileLocation,
    name_color: currentUser.nameColor,
    name: currentUser.name
  });
});

$("btnProfileMenuWallet").addEventListener("click", function() {
  closeProfileMenu();
  openWalletPanel();
});

$("btnProfileMenuThemes").addEventListener("click", function() {
  closeProfileMenu();
  activatePanel("panel-themes");
  if (location.pathname !== "/temas") history.pushState({
    view: "themes"
  }, "", "/temas");
});

$("btnProfileMenuAppIcons").addEventListener("click", function() {
  closeProfileMenu();
  activatePanel("panel-app-icons");
  if (location.pathname !== "/iconos") history.pushState({
    view: "app-icons"
  }, "", "/iconos");
});

$("btnProfileMenuAdmin").addEventListener("click", function() {
  closeProfileMenu();
  openAdminPanel();
});

var volunteerMenuBtnEl = $("btnProfileMenuVolunteer");

if (volunteerMenuBtnEl) volunteerMenuBtnEl.addEventListener("click", function() {
  closeProfileMenu();
  if (typeof openVolunteerPanel === "function") openVolunteerPanel();
});

$("btnProfileMenuCredits").addEventListener("click", function() {
  closeProfileMenu();
  activatePanel("panel-credits");
  if (location.pathname !== "/creditos") history.pushState({
    view: "credits"
  }, "", "/creditos");
});

var btnCreditsBackEl = $("btnCreditsBack");

if (btnCreditsBackEl) btnCreditsBackEl.addEventListener("click", function() {
  goBack("panel-list");
});

$("btnProfileMenuLogout").addEventListener("click", function() {
  closeProfileMenu();
  $("btnLogout").click();
});

$("profileClose").addEventListener("click", function() {
  $("profileBackdrop").classList.remove("open");
  document.body.classList.remove("profile-open");
  history.pushState({
    view: "list"
  }, "", "/");
});

$("btnOpenUserStore").addEventListener("click", function() {
  if (!currentProfileUid) return;
  activatePanel("panel-my-store");
  loadMyStore(currentProfileUid, true);
});

$("profileBackdrop").addEventListener("click", function(e) {
  if (e.target === this) {
    this.classList.remove("open");
    document.body.classList.remove("profile-open");
    history.pushState({
      view: "list"
    }, "", "/");
  }
});

function enrichSocialRows(rows) {
  var ids = rows.map(function(r) {
    return r.id;
  }).filter(function(id) {
    return id;
  });
  if (!ids.length) return Promise.resolve(rows);
  return supabase.from("profiles").select("id, name_color, role, verified").in("id", ids).then(function(res) {
    var map = {};
    (res.data || []).forEach(function(p) {
      map[p.id] = p;
    });
    rows.forEach(function(r) {
      var p = map[r.id];
      if (p) {
        r.name_color = p.name_color;
        r.role = p.role;
        r.verified = p.verified;
      }
    });
    return rows;
  }).catch(function() {
    return rows;
  });
}

function renderSocialListRows(rows) {
  var body = $("socialListBody");
  if (!rows.length) {
    body.innerHTML = '<p class="profile-empty-hint">Aquí no hay nadie todavía.</p>';
    return;
  }
  body.innerHTML = rows.map(function(r) {
    return '<div class="social-list-row" data-uid="' + escapeHtml(r.id) + '">' + avatarSpanHtml(r.username, r.avatar_url, "avatar-md", r.id) + '<div class="social-list-row-info">' + '<div class="social-list-row-name"' + (r.name_color ? ' style="color:' + escapeHtml(r.name_color) + '"' : "") + ">" + escapeHtml(r.username) + roleBadgeHtml(r.role, r.verified) + "</div>" + (r.meta ? '<div class="social-list-row-meta">' + escapeHtml(r.meta) + "</div>" : "") + "</div>" + '<svg class="social-list-row-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>' + "</div>";
  }).join("");
}

function openSocialList(type) {
  if (!currentProfileUid) return;
  var uid = currentProfileUid;
  var titles = {
    followers: "Seguidores",
    following: "Siguiendo",
    visits: "Quién vio tu perfil"
  };
  $("socialListTitle").textContent = titles[type] || "Lista";
  $("socialListBody").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  $("socialListBackdrop").classList.add("open");
  if (type === "followers") {
    supabase.rpc("get_followers_list", {
      target_user_id: uid
    }).then(function(res) {
      var rows = (res.error ? [] : res.data || []).map(function(r) {
        return {
          id: r.user_id,
          username: r.username,
          avatar_url: r.avatar_url
        };
      });
      renderSocialListRows(rows);
      enrichSocialRows(rows).then(renderSocialListRows);
    });
  } else if (type === "following") {
    supabase.rpc("get_following_list", {
      target_user_id: uid
    }).then(function(res) {
      var rows = (res.error ? [] : res.data || []).map(function(r) {
        return {
          id: r.user_id,
          username: r.username,
          avatar_url: r.avatar_url
        };
      });
      renderSocialListRows(rows);
      enrichSocialRows(rows).then(renderSocialListRows);
    });
  } else if (type === "visits") {
    supabase.rpc("get_profile_visitors", {
      target_user_id: uid
    }).then(function(res) {
      if (res.error) {
        $("socialListBody").innerHTML = '<p class="profile-empty-hint">No se pudo cargar la lista de visitas.</p>';
        return;
      }
      var rows = (res.data || []).map(function(r) {
        return {
          id: r.visitor_id,
          username: r.username,
          avatar_url: r.avatar_url,
          meta: r.visited_at ? timeAgo(r.visited_at) : ""
        };
      });
      renderSocialListRows(rows);
      enrichSocialRows(rows).then(renderSocialListRows);
    });
  }
}

$("statFollowersBtn").addEventListener("click", function() {
  openSocialList("followers");
});

$("statFollowingBtn").addEventListener("click", function() {
  openSocialList("following");
});

$("statVisitsBtn").addEventListener("click", function() {
  openSocialList("visits");
});

$("socialListClose").addEventListener("click", function() {
  $("socialListBackdrop").classList.remove("open");
});

$("socialListBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

function renderZcardBadges(uid) {
  var wrap = $("zcardBadges");
  if (!wrap) return;
  loadEquippedAchievements(uid).then(function(rows) {
    var filled = rows.filter(function(r) {
      return r && r.achievement;
    });
    if (!filled.length) {
      wrap.hidden = true;
      wrap.innerHTML = "";
      return;
    }
    wrap.hidden = false;
    wrap.innerHTML = filled.map(function(r) {
      return '<span class="zcard-badge" title="' + escapeHtml(r.achievement.name) + '">' + achievementIconHtml(r.achievement) + "</span>";
    }).join("");
  });
}

function openProfileCard(userId) {
  if (!currentUser || !userId) return;
  var uid = userId;
  var isSelf = uid === currentUser.id;
  var zcardRequiredIds = [
    "zcardBackdrop", "zcardModal", "zcardAvatar", "zcardBanner", "zcardName",
    "zcardHandle", "zcardMeta", "zcardFollowers", "zcardFollowing",
    "zcardVolunteerBadgeWrap", "zcardKebabWrap", "zcardBadges"
  ];
  var zcardMissing = zcardRequiredIds.filter(function(id) {
    return !$(id);
  });
  if (zcardMissing.length) {
    console.error("[openProfileCard] Falta(n) en el HTML: " + zcardMissing.join(", ") + ". El index.html desplegado probablemente no es la misma versión que este JS.");
    toast(t("profile.err_version_mismatch"));
    return;
  }
  var goToFullProfile = function() {
    qsa(".modal-backdrop.open").forEach(function(mb) {
      if (mb.id !== "zcardBackdrop") mb.classList.remove("open");
    });
    $("zcardBackdrop").classList.remove("open");
    openProfile(uid);
  };
  $("zcardModal").onclick = function(e) {
    if (e.target.closest("#zcardClose")) return;
    if (e.target.closest(".zcard-kebab")) return;
    goToFullProfile();
  };
  var viewBtn = $("zcardModal").querySelector(".zcard-view-btn");
  if (viewBtn) {
    viewBtn.onclick = function(e) {
      e.stopPropagation();
      goToFullProfile();
    };
  }
  var kebabWrap = $("zcardKebabWrap");
  if (kebabWrap) kebabWrap.innerHTML = typeof kebabMenuHtml === "function" && !isSelf ? kebabMenuHtml("profile", uid) : "";
  var profilePromise = isSelf ? Promise.resolve({
    id: currentUser.id,
    username: currentUser.username,
    avatar_url: currentUser.avatarUrl,
    zcard_avatar_url: currentUser.zcardAvatarUrl,
    banner_url: currentUser.bannerUrl,
    joined_at: currentUser.joinedAt,
    role: currentUser.role,
    verified: currentUser.verified,
    is_volunteer: currentUser.isVolunteer,
    name_color: currentUser.nameColor,
    name: currentUser.name,
    followers_count: currentUser.followersCount,
    following_count: currentUser.followingCount
  }) : fetchPublicProfile(uid);
  profilePromise.then(function(p) {
    if (!p) {
      toast(t("profile.err_load"));
      return;
    }
    setAvatarEl($("zcardAvatar"), p.username, p.zcard_avatar_url || p.avatar_url);
    $("zcardAvatar").setAttribute("data-uid", uid);
    queueFrameLookup(uid);
    $("zcardBanner").style.backgroundImage = p.banner_url ? 'url("' + encodeURI(p.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '")' : "";
    $("zcardName").innerHTML = escapeHtml(p.name || p.username) + roleBadgeHtml(p.role, p.verified);
    $("zcardName").style.color = p.name_color || "";
    $("zcardVolunteerBadgeWrap").innerHTML = volunteerBadgeHtml(p.is_volunteer);
    $("zcardHandle").textContent = "@" + p.username;
    $("zcardMeta").textContent = "Usuario desde " + timeAgo(p.joined_at);
    $("zcardFollowers").textContent = p.followers_count || 0;
    $("zcardFollowing").textContent = p.following_count || 0;
    renderZcardBadges(uid);
    $("zcardBackdrop").classList.add("open");
  }).catch(function(err) {
    console.error("[openProfileCard] fallo al abrir la zcard:", err, err && err.stack);
    var detail = err && err.code ? " (" + err.code + ": " + err.message + ")" : err && err.message ? " (" + err.message + ")" : "";
    toast(t("profile.err_load") + detail);
  });
}

$("zcardClose").addEventListener("click", function(e) {
  e.stopPropagation();
  $("zcardBackdrop").classList.remove("open");
});

$("zcardBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

document.addEventListener("click", function(e) {
  if (!currentUser || !e.target || !e.target.closest) return;
  var el = e.target.closest("[data-uid]");
  if (!el) return;
  if (el.closest("#btnProfile")) return;
  if (el.closest("#profileMenuCard")) return;
  if (el.closest("#zcardModal")) return;
  var uid = el.getAttribute("data-uid");
  if (!uid) return;
  var actionable = e.target.closest("button, a, input, textarea, select, [data-action], [data-note-id], #profileBadges");
  if (actionable && (el.contains(actionable) || actionable.contains(el))) return;
  e.stopPropagation();
  e.preventDefault();
  openProfileCard(uid);
}, true);

function loadEquippedAchievements(uid) {
  return supabase.from("user_achievements").select("*").eq("user_id", uid).eq("equipped", true).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    if (!rows.length) return [];
    var ids = rows.map(function(r) {
      return r.achievement_id;
    });
    return supabase.from("achievements").select("id,name,icon,icon_url,description").in("id", ids).then(function(res2) {
      var map = {};
      (res2.data || []).forEach(function(a) {
        map[a.id] = a;
      });
      rows.forEach(function(r) {
        r.achievement = map[r.achievement_id] || null;
      });
      return rows;
    });
  });
}

function renderProfileBadges(uid) {
  var wrap = $("profileBadges");
  wrap.setAttribute("data-uid", uid);
  if (!wrap.hasAttribute("data-wired")) {
    wrap.setAttribute("data-wired", "1");
    wrap.addEventListener("click", function() {
      var currentUid = wrap.getAttribute("data-uid");
      if (!currentUid) return;
      if (currentUser && currentUid === currentUser.id && typeof activatePanel === "function") {
        $("profileBackdrop").classList.remove("open");
        document.body.classList.remove("profile-open");
        if (location.pathname.indexOf("/perfiles/") === 0) history.pushState({
          view: "list"
        }, "", "/");
        activatePanel("panel-achievements");
        achvCurrentCat = "all";
        qsa(".achv-tab", $("achvTabs")).forEach(function(tb) {
          tb.classList.toggle("active", tb.getAttribute("data-cat") === "all");
        });
        renderAchievementsPanel();
        if (window.syncAchievements) window.syncAchievements();
        return;
      }
      openAchievementsGallery(currentUid);
    });
  }
  loadEquippedAchievements(uid).then(function(rows) {
    var slots = [ null, null, null ];
    rows.forEach(function(r) {
      if (r.equip_slot >= 1 && r.equip_slot <= 3) slots[r.equip_slot - 1] = r;
    });
    wrap.innerHTML = slots.map(function(r) {
      if (!r || !r.achievement) return '<span class="profile-badge-slot"></span>';
      return '<span class="profile-badge-slot filled" title="' + escapeHtml(r.achievement.name) + (r.achievement.description ? " — " + escapeHtml(r.achievement.description) : "") + '">' + achievementIconHtml(r.achievement) + "</span>";
    }).join("");
  });
}

function openAchievementsGallery(uid) {
  $("achvGalleryBackdrop").classList.add("open");
  $("achvGalleryGrid").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  var isOwn = currentUser && uid === currentUser.id;
  supabase.from("profiles").select("username").eq("id", uid).single().then(function(pRes) {
    var uname = pRes.data ? pRes.data.username : "usuario";
    $("achvGalleryTitle").textContent = isOwn ? "Tus logros" : "Logros de @" + uname;
    $("achvGalleryHint").textContent = isOwn ? "Vista rápida. Para reclamar o equipar medallas, abre Logros desde tu menú de perfil." : "Logros conseguidos por @" + uname + ".";
  });
  Promise.all([ supabase.from("achievements").select("id,name,icon,icon_url,description,reward_coins").order("name", {
    ascending: true
  }), supabase.from("user_achievements").select("achievement_id,earned_at,claimed").eq("user_id", uid) ]).then(function(results) {
    var allRes = results[0], mineRes = results[1];
    var all = allRes.error ? [] : allRes.data || [];
    var mineRows = mineRes.error ? [] : mineRes.data || [];
    var earnedMap = {};
    mineRows.forEach(function(r) {
      earnedMap[r.achievement_id] = r;
    });
    if (!all.length) {
      $("achvGalleryGrid").innerHTML = '<p class="profile-empty-hint">Todavía no hay logros configurados en el sitio.</p>';
      return;
    }
    $("achvGalleryGrid").innerHTML = all.map(function(a) {
      var mine = earnedMap[a.id];
      var earnedAt = mine && mine.earned_at;
      var unclaimed = isOwn && mine && !mine.claimed;
      var cls = "achv-card " + (earnedAt ? unclaimed ? "earned unclaimed" : "earned" : "locked");
      var dateHtml = earnedAt && !unclaimed ? '<div class="achv-card-date">' + new Date(earnedAt).toLocaleDateString() + "</div>" : "";
      var claimHtml = unclaimed ? '<button type="button" class="terminal-btn small achv-claim-btn" data-achv-id="' + escapeHtml(a.id) + '">Reclamar' + (a.reward_coins > 0 ? " +" + a.reward_coins + ' <img class="coin-icon" src="assets/icons/coin-z.png" alt="Coin" loading="lazy" decoding="async">' : "") + "</button>" : "";
      return '<div class="' + cls + '">' + '<span class="achv-card-icon">' + achievementIconHtml(a) + "</span>" + '<div class="achv-card-name">' + escapeHtml(a.name) + "</div>" + (a.description ? '<div class="achv-card-desc">' + escapeHtml(a.description) + "</div>" : "") + dateHtml + claimHtml + "</div>";
    }).join("");
    qsa(".achv-claim-btn", $("achvGalleryGrid")).forEach(function(btn) {
      btn.addEventListener("click", function(e) {
        e.stopPropagation();
        var achvId = btn.getAttribute("data-achv-id");
        btn.disabled = true;
        btn.textContent = "Reclamando...";
        supabase.rpc("claim_achievement", {
          p_achievement_id: achvId
        }).then(function(res) {
          if (res.error) {
            toast(t("profile.err_claim") + " " + res.error.message);
            btn.disabled = false;
            btn.textContent = t("profile.btn_claim");
            return;
          }
          var reward = res.data || 0;
          toast(reward > 0 ? "¡Logro reclamado! +" + reward + " Coin 🪙" : "¡Logro reclamado!");
          if (typeof refreshWalletDisplay === "function") refreshWalletDisplay();
          openAchievementsGallery(uid);
        });
      });
    });
  });
}

(function wireAchvGalleryModal() {
  var close = $("achvGalleryClose"), backdrop = $("achvGalleryBackdrop");
  if (close) close.addEventListener("click", function() {
    backdrop.classList.remove("open");
  });
  if (backdrop) backdrop.addEventListener("click", function(e) {
    if (e.target === backdrop) backdrop.classList.remove("open");
  });
})();

function renderAchievementManageList(uid) {
  var wrap = $("achievementManageList");
  wrap.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("user_achievements").select("*").eq("user_id", uid).order("earned_at", {
    ascending: true
  }).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    if (!rows.length) {
      wrap.innerHTML = '<p class="profile-empty-hint">Aún no tienes logros.</p>';
      return;
    }
    var ids = rows.map(function(r) {
      return r.achievement_id;
    });
    supabase.from("achievements").select("id,name,icon,icon_url,description").in("id", ids).then(function(res2) {
      var map = {};
      (res2.data || []).forEach(function(a) {
        map[a.id] = a;
      });
      wrap.innerHTML = rows.map(function(r) {
        var a = map[r.achievement_id];
        if (!a) return "";
        return '<div class="achievement-manage-row">' + '<div class="achievement-manage-info"><span class="achievement-manage-icon">' + achievementIconHtml(a) + "</span><span>" + escapeHtml(a.name) + "</span></div>" + '<button type="button" class="link-btn" data-row-id="' + r.id + '">' + (r.equipped ? "Quitar" : "Equipar") + "</button>" + "</div>";
      }).join("");
      qsa("button[data-row-id]", wrap).forEach(function(btn) {
        btn.addEventListener("click", function() {
          toggleEquipAchievement(uid, btn.getAttribute("data-row-id"));
        });
      });
    });
  });
}

function toggleEquipAchievement(uid, rowId) {
  supabase.from("user_achievements").select("*").eq("user_id", uid).eq("equipped", true).then(function(res) {
    var equippedRows = res.error ? [] : res.data || [];
    var current = equippedRows.filter(function(r) {
      return r.id === rowId;
    })[0];
    if (current) {
      supabase.from("user_achievements").update({
        equipped: false,
        equip_slot: null
      }).eq("id", rowId).then(function(r) {
        if (r.error) {
          toast(t("profile.err_update"));
          return;
        }
        renderAchievementManageList(uid);
        renderProfileBadges(uid);
      });
      return;
    }
    if (equippedRows.length >= 3) {
      toast(t("profile.err_achievements_max"));
      return;
    }
    var usedSlots = equippedRows.map(function(r) {
      return r.equip_slot;
    });
    var slot = [ 1, 2, 3 ].filter(function(s) {
      return usedSlots.indexOf(s) === -1;
    })[0];
    supabase.from("user_achievements").update({
      equipped: true,
      equip_slot: slot
    }).eq("id", rowId).then(function(r) {
      if (r.error) {
        toast(t("profile.err_equip") + " " + r.error.message);
        return;
      }
      renderAchievementManageList(uid);
      renderProfileBadges(uid);
    });
  });
}

function renderFactionFlag(uid) {
  var wrap = $("factionFlagWrap");
  if (!wrap) return;
  if (!uid) {
    wrap.innerHTML = '<span class="profile-empty-hint">No pertenece a ningún círculo.</span>';
    return;
  }
  supabase.from("circle_members").select("circles(id,name,slug,icon_url)").eq("user_id", uid).then(function(res) {
    var rows = (res.error ? [] : res.data || []).filter(function(r) {
      return r.circles;
    });
    if (!rows.length) {
      wrap.innerHTML = '<span class="profile-empty-hint">No pertenece a ningún círculo.</span>';
      return;
    }
    wrap.innerHTML = rows.map(function(r) {
      return '<button type="button" class="profile-flag" data-slug="' + escapeHtml(r.circles.slug) + '">🚩 ' + escapeHtml(r.circles.name) + "</button>";
    }).join("");
    qsa(".profile-flag", wrap).forEach(function(btn) {
      btn.addEventListener("click", function() {
        openCircle(btn.getAttribute("data-slug"));
      });
    });
  });
}

function loadWallNotes(profileUid) {
  return supabase.from("profile_wall_notes").select("*").eq("profile_user_id", profileUid).order("created_at", {
    ascending: false
  }).then(function(res) {
    if (res.error) return [];
    var notes = res.data.map(function(n) {
      return {
        id: n.id,
        authorId: n.author_id,
        body: n.body,
        createdAt: n.created_at,
        authorName: "usuario"
      };
    });
    var authorIds = notes.map(function(n) {
      return n.authorId;
    }).filter(function(id, i, arr) {
      return arr.indexOf(id) === i;
    });
    if (!authorIds.length) return notes;
    return supabase.from("profiles").select("id, username").in("id", authorIds).then(function(res2) {
      var map = {};
      (res2.data || []).forEach(function(p) {
        map[p.id] = p.username;
      });
      notes.forEach(function(n) {
        if (map[n.authorId]) n.authorName = map[n.authorId];
      });
      return notes;
    });
  });
}

function renderWall(profileUid, isSelf) {
  var listEl = $("wallNotesList");
  var writeRow = $("wallWriteRow");
  writeRow.hidden = isSelf;
  listEl.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  loadWallNotes(profileUid).then(function(notes) {
    if (!notes.length) {
      listEl.innerHTML = '<p class="profile-empty-hint">Todavía no hay notas.</p>';
      return;
    }
    listEl.innerHTML = notes.map(function(n) {
      var canDelete = currentUser && (currentUser.id === n.authorId || currentUser.id === profileUid);
      return '<div class="wall-note">' + '<div class="wall-note-head"><span class="user-link" data-uid="' + escapeHtml(n.authorId || "") + '">@' + escapeHtml(n.authorName) + "</span><span> · " + timeAgo(n.createdAt) + "</span>" + (canDelete ? '<button type="button" class="wall-note-del" data-note-id="' + n.id + '">Borrar</button>' : "") + "</div>" + '<div class="wall-note-body">' + z3tRichText(n.body, true) + "</div>" + "</div>";
    }).join("");
    qsa(".wall-note-del", listEl).forEach(function(btn) {
      btn.addEventListener("click", function() {
        if (!confirm("¿Borrar esta nota?")) return;
        supabase.from("profile_wall_notes").delete().eq("id", btn.getAttribute("data-note-id")).then(function(res) {
          if (res.error) {
            toast(t("profile.err_note_delete"));
            return;
          }
          renderWall(profileUid, isSelf);
        });
      });
    });
  });
  var btnPost = $("btnPostWallNote");
  btnPost.onclick = function() {
    var body = $("wallNoteInput").value.trim();
    if (!body || !currentUser) return;
    btnPost.disabled = true;
    supabase.from("profile_wall_notes").insert({
      profile_user_id: profileUid,
      author_id: currentUser.id,
      body: body
    }).then(function(res) {
      btnPost.disabled = false;
      if (res.error) {
        toast(t("profile.err_note_publish"));
        return;
      }
      $("wallNoteInput").value = "";
      renderWall(profileUid, isSelf);
    });
  };
}

function renderProfilePosts(uid) {
  var wrap = $("profilePostsList");
  wrap.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("threads").select("*").eq("author_id", uid).order("created_at", {
    ascending: false
  }).limit(20).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    if (!rows.length) {
      wrap.innerHTML = '<p class="profile-empty-hint">Todavía no hay publicaciones.</p>';
      return;
    }
    wrap.innerHTML = rows.map(function(t) {
      return '<div class="profile-post-item" data-thread-id="' + escapeHtml(t.id) + '" data-slug="' + escapeHtml(t.slug) + '">' + '<div class="profile-post-title">' + escapeHtml(t.title) + "</div>" + '<div class="profile-post-excerpt">' + escapeHtml(t.excerpt || "") + " · " + timeAgo(t.created_at) + "</div>" + "</div>";
    }).join("");
    qsa(".profile-post-item", wrap).forEach(function(el) {
      el.addEventListener("click", function() {
        $("profileBackdrop").classList.remove("open");
        document.body.classList.remove("profile-open");
        var id = el.getAttribute("data-thread-id");
        var existing = THREADS.filter(function(x) {
          return x.id === id;
        })[0];
        if (existing) {
          openThread(id);
          return;
        }
        resolveThreadBySlug(el.getAttribute("data-slug"));
      });
    });
  });
}

function renderZcardPreview(p) {
  var wrap = $("zcardPreview");
  if (!wrap) return;
  setAvatarEl($("zcardPreviewAvatar"), p.username, p.zcard_avatar_url || p.avatar_url);
  $("zcardPreviewAvatar").setAttribute("data-uid", currentUser.id);
  queueFrameLookup(currentUser.id);
  $("zcardPreviewBanner").style.backgroundImage = p.banner_url ? 'url("' + encodeURI(p.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '")' : "";
  $("zcardPreviewName").innerHTML = escapeHtml(p.name || p.username) + roleBadgeHtml(p.role, p.verified);
  $("zcardPreviewName").style.color = p.name_color || "";
  $("zcardPreviewHandle").textContent = "@" + p.username;
}

function uploadAvatarNow(payload, opts) {
  opts = opts || {};
  return stripImageMetadata(payload.file).then(function(cleanFile) {
    var ext = cleanFile.type === "image/png" ? "png" : cleanFile.type === "image/webp" ? "webp" : "jpg";
    var path = payload.userId + "/avatar_" + payload.ts + "." + ext;
    return supabase.storage.from(AVATAR_BUCKET).upload(path, cleanFile, {
      upsert: true,
      contentType: cleanFile.type
    }).then(function(res) {
      if (res.error) throw res.error;
      var pub = supabase.storage.from(AVATAR_BUCKET).getPublicUrl(path);
      var url = pub.data.publicUrl;
      return supabase.from("profiles").update({
        avatar_url: url
      }).eq("id", payload.userId).then(function(res2) {
        if (res2.error) throw res2.error;
        if (currentUser && currentUser.id === payload.userId) {
          currentUser.avatarUrl = url;
          photoCache[currentUser.id] = url;
          applyPhotoToDom(currentUser.id, url);
          setAvatarEl($("profileAvatar"), currentUser.username, url);
          setAvatarEl($("topAvatar"), currentUser.username, url);
          $("topAvatar").setAttribute("data-uid", currentUser.id);
          queueFrameLookup(currentUser.id);
          setAvatarEl($("zcardPreviewAvatar"), currentUser.username, currentUser.zcardAvatarUrl || url);
          $("zcardPreviewAvatar").setAttribute("data-uid", currentUser.id);
          queueFrameLookup(currentUser.id);
          setAvatarEl($("settingsAvatarPreview"), currentUser.username, url);
          $("settingsAvatarPreview").setAttribute("data-uid", currentUser.id);
          queueFrameLookup(currentUser.id);
        }
        toast(opts.fromQueue ? "Tu foto de perfil pendiente ya se subió." : "Foto de perfil actualizada.");
      });
    });
  });
}

if (typeof OfflineQueue !== "undefined") {
  OfflineQueue.registerHandler("upload_avatar", function(payload) {
    return uploadAvatarNow(payload, {
      fromQueue: true
    });
  });
}

var AVATAR_BUCKET = "avatars";

var MAX_AVATAR_SIZE = 5 * 1024 * 1024;

$("btnChangeAvatar").addEventListener("click", function() {
  $("avatarInput").click();
});

$("avatarInput").addEventListener("change", function() {
  var file = this.files && this.files[0];
  this.value = "";
  if (!file || !currentUser) return;
  if (file.type.indexOf("image/") !== 0) {
    toast(t("profile.err_pick_image"));
    return;
  }
  if (file.size > MAX_AVATAR_SIZE) {
    toast(t("profile.err_image_too_big"));
    return;
  }
  var btn = $("btnChangeAvatar");
  var payload = {
    userId: currentUser.id,
    file: file,
    ts: Date.now()
  };
  var localPreviewUrl = URL.createObjectURL(file);
  setAvatarEl($("profileAvatar"), currentUser.username, localPreviewUrl);
  setAvatarEl($("topAvatar"), currentUser.username, localPreviewUrl);
  setAvatarEl($("settingsAvatarPreview"), currentUser.username, localPreviewUrl);
  if (OfflineQueue.isOffline()) {
    OfflineQueue.enqueue("upload_avatar", payload);
    toast(t("profile.toast_offline_avatar"));
    return;
  }
  btn.disabled = true;
  uploadAvatarNow(payload)["catch"](function(err) {
    btn.disabled = false;
    if (OfflineQueue.isNetworkError(err)) {
      OfflineQueue.enqueue("upload_avatar", payload);
      toast(t("profile.toast_offline_avatar"));
    } else {
      toast(t("profile.err_avatar_upload"));
    }
  }).then(function() {
    btn.disabled = false;
  });
});

$("btnChangeZcardAvatar").addEventListener("click", function() {
  $("zcardAvatarInput").click();
});

$("zcardAvatarInput").addEventListener("change", function() {
  var file = this.files && this.files[0];
  this.value = "";
  if (!file || !currentUser) return;
  if (file.type.indexOf("image/") !== 0) {
    toast(t("profile.err_pick_image"));
    return;
  }
  if (file.size > MAX_AVATAR_SIZE) {
    toast(t("profile.err_image_too_big"));
    return;
  }
  var btn = $("btnChangeZcardAvatar");
  btn.disabled = true;
  btn.textContent = "Subiendo...";
  stripImageMetadata(file).then(function(cleanFile) {
    var ext = cleanFile.type === "image/png" ? "png" : cleanFile.type === "image/webp" ? "webp" : "jpg";
    var path = currentUser.id + "/zcard_" + Date.now() + "." + ext;
    return supabase.storage.from(AVATAR_BUCKET).upload(path, cleanFile, {
      upsert: true,
      contentType: cleanFile.type
    }).then(function(res) {
      if (res.error) {
        toast(t("profile.err_zcard_upload"));
        btn.disabled = false;
        btn.textContent = t("profile.btn_change_zcard");
        return;
      }
      var pub = supabase.storage.from(AVATAR_BUCKET).getPublicUrl(path);
      var url = pub.data.publicUrl;
      return supabase.from("profiles").update({
        zcard_avatar_url: url
      }).eq("id", currentUser.id).then(function(res2) {
        btn.disabled = false;
        btn.textContent = "Cambiar foto de la Z-Card";
        if (res2.error) {
          toast(t("profile.err_zcard_save"));
          return;
        }
        currentUser.zcardAvatarUrl = url;
        setAvatarEl($("zcardPreviewAvatar"), currentUser.username, url);
        $("zcardPreviewAvatar").setAttribute("data-uid", currentUser.id);
        queueFrameLookup(currentUser.id);
        toast(t("profile.toast_zcard_updated"));
      });
    });
  });
});

$("btnChangeBanner").addEventListener("click", function() {
  openBackgroundPicker("bannerInput");
});

$("bannerInput").addEventListener("change", function() {
  var file = this.files && this.files[0];
  this.value = "";
  if (!file || !currentUser) return;
  if (file.type.indexOf("image/") !== 0) {
    toast(t("profile.err_pick_image"));
    return;
  }
  if (file.size > MAX_AVATAR_SIZE) {
    toast(t("profile.err_image_too_big"));
    return;
  }
  var btn = $("btnChangeBanner");
  btn.disabled = true;
  btn.textContent = "Subiendo...";
  stripImageMetadata(file).then(function(cleanFile) {
    var ext = cleanFile.type === "image/png" ? "png" : cleanFile.type === "image/webp" ? "webp" : "jpg";
    var path = currentUser.id + "/banner_" + Date.now() + "." + ext;
    return supabase.storage.from(AVATAR_BUCKET).upload(path, cleanFile, {
      upsert: true,
      contentType: cleanFile.type
    }).then(function(res) {
      if (res.error) {
        toast(t("profile.err_banner_upload"));
        btn.disabled = false;
        btn.textContent = t("settings.change_banner");
        return;
      }
      var pub = supabase.storage.from(AVATAR_BUCKET).getPublicUrl(path);
      var url = pub.data.publicUrl;
      return supabase.from("profiles").update({
        banner_url: url
      }).eq("id", currentUser.id).then(function(res2) {
        btn.disabled = false;
        btn.textContent = "Cambiar foto de fondo";
        if (res2.error) {
          toast(t("profile.err_banner_save"));
          return;
        }
        currentUser.bannerUrl = url;
        var cssUrl = 'url("' + encodeURI(url).replace(/"/g, "%22").replace(/'/g, "%27") + '")';
        $("profileBanner").style.backgroundImage = cssUrl;
        $("zcardPreviewBanner").style.backgroundImage = cssUrl;
        toast(t("profile.toast_banner_updated"));
      });
    });
  });
});

$("btnSaveProfile").addEventListener("click", function() {
  if (!currentUser) return;
  var nameVal = $("nameInput").value.trim();
  var val = $("usernameInput").value.trim();
  var bioVal = bioEditorGet();
  var locVal = $("locationInput").value.trim();
  var regionVal = $("regionCardGrid") && $("regionCardGrid").dataset.selected || "LATAM";
  var colorVal = $("nameColorInput").value;
  if (!isValidHandle(val)) {
    toast(t("profile.err_handle_invalid"));
    return;
  }
  var socialRes = typeof socialsSettingsGet === "function" ? socialsSettingsGet() : null;
  if (socialRes && socialRes.error) {
    toast(socialRes.error);
    return;
  }
  var finalName = nameVal || val;
  var usernameChanged = val !== currentUser.username;
  var patch = {
    name: finalName,
    bio: bioVal || null,
    location_public: locVal || null,
    name_color: colorVal || null,
    region: regionVal
  };
  if (socialRes) patch.social_links = socialRes.links;
  if (usernameChanged) patch.username = val;
  var btn = $("btnSaveProfile");
  btn.disabled = true;
  btn.textContent = usernameChanged ? "Revisando @..." : "Guardando...";
  (usernameChanged ? isHandleAvailable(val, currentUser.id) : Promise.resolve(true)).then(function(available) {
    if (!available) {
      btn.disabled = false;
      btn.textContent = "Guardar cambios";
      toast(t("profile.err_handle_taken"));
      return;
    }
    btn.textContent = "Guardando...";
    return saveProfilePatch(patch, usernameChanged, val, finalName, bioVal, locVal, colorVal);
  }).catch(function() {
    btn.disabled = false;
    btn.textContent = "Guardar cambios";
    toast(t("profile.err_handle_check"));
  });
});

function saveProfilePatch(patch, usernameChanged, val, finalName, bioVal, locVal, colorVal) {
  var btn = $("btnSaveProfile");
  supabase.from("profiles").update(patch).eq("id", currentUser.id).then(function(res) {
    btn.disabled = false;
    btn.textContent = "Guardar cambios";
    if (res.error) {
      var msg = /duplicate|unique/i.test(res.error.message || "") ? "Ese nombre de usuario ya está en uso." : "No se pudo actualizar el perfil.";
      toast(msg);
      return;
    }
    if (usernameChanged) {
      currentUser.username = val;
      $("profileHandle").textContent = "@" + val;
      $("topUsername").textContent = val;
      $("profileModalTitle").textContent = "Tu perfil";
      $("zcardPreviewHandle").textContent = "@" + val;
      if (!state.suppressPush) history.replaceState({
        view: "profile",
        username: val
      }, "", "/perfiles/" + encodeURIComponent(val));
    }
    currentUser.name = finalName;
    currentUser.bio = bioVal;
    if (patch.social_links) currentUser.socialLinks = patch.social_links;
    currentUser.profileLocation = locVal;
    currentUser.nameColor = colorVal || null;
    var regionChanged = patch.region && patch.region !== currentUser.region;
    currentUser.region = patch.region || currentUser.region;
    $("profileName").innerHTML = escapeHtml(finalName) + roleBadgeHtml(currentUser.role, currentUser.verified);
    $("profileName").style.color = colorVal || "";
    $("zcardPreviewName").innerHTML = escapeHtml(finalName) + roleBadgeHtml(currentUser.role, currentUser.verified);
    $("zcardPreviewName").style.color = colorVal || "";
    $("profileBioText").textContent = bioVal || "Aún no hay Biografía";
    $("profileLocationText").textContent = locVal ? "📍 " + locVal : "";
    $("profileLocationText").hidden = !locVal;
    toast(regionChanged ? "Perfil actualizado. Recargando tu feed de " + currentUser.region + "..." : "Perfil actualizado.");
    if (regionChanged) {
      I18N.applyLanguage(currentUser.region);
      loadThreads().then(function() {
        renderThreadList();
      });
      if (typeof loadCommunities === "function") loadCommunities();
    }
  });
}

$("btnLogout").addEventListener("click", function() {
  if (typeof stopDeviceSessionWatch === "function") stopDeviceSessionWatch();
  supabase.auth.signOut().then(function() {
    currentUser = null;
    if (typeof z3tRealtimeStopAll === "function") z3tRealtimeStopAll();
    if (notifPollTimer) {
      clearInterval(notifPollTimer);
      notifPollTimer = null;
    }
    if (typeof stopCommunityActivityBadgePolling === "function") stopCommunityActivityBadgePolling();
    NOTIFICATIONS = [];
    $("notifBadge").hidden = true;
    $("profileBackdrop").classList.remove("open");
    document.body.classList.remove("profile-open");
    $("settingsBackdrop").classList.remove("open");
    history.pushState({
      view: "landing"
    }, "", "/");
    showView("landing");
    toast(t("profile.toast_logged_out"));
  });
});