"use strict";

var NOTIFICATIONS = [];

var notifActiveTab = "general";

var notifPollTimer = null;

var notifSeenIds = null;

var NOTIF_TABS = [ {
  id: "general",
  label: "General"
}, {
  id: "reacciones",
  label: "Reacciones"
}, {
  id: "comentarios",
  label: "Comentarios"
}, {
  id: "seguidores",
  label: "Seguidores"
} ];

var NOTIF_TYPE_GROUPS = {
  reacciones: [ "like", "reaction", "thread_like", "post_like", "message_like" ],
  comentarios: [ "reply", "comment", "wall_note" ],
  seguidores: [ "follow", "unfollow" ]
};

function notifMatchesTab(n, tabId) {
  if (tabId === "general") return true;
  var types = NOTIF_TYPE_GROUPS[tabId] || [];
  return types.indexOf(n.type) !== -1;
}

function loadNotifications() {
  if (!currentUser) return Promise.resolve();
  return supabase.from("notifications").select("id, type, read, created_at, thread_id, community_id, conversation_id, meta, actor:profiles!notifications_actor_id_fkey(id, username, name, avatar_url, name_color, role, verified), threads(title, slug), communities(name, slug)").eq("recipient_id", currentUser.id).order("created_at", {
    ascending: false
  }).limit(60).then(function(res) {
    if (res.error) return;
    NOTIFICATIONS = res.data || [];
    announceNewNotifications(NOTIFICATIONS);
    renderNotifBadge();
    renderNotifTabs();
    renderNotifPanel();
  });
}

function notifPlainText(n) {
  var tmp = document.createElement("div");
  tmp.innerHTML = notifText(n);
  return (tmp.textContent || "").replace(/\s+/g, " ").trim();
}

function showDeviceNotification(title, body, tag) {
  if (!("Notification" in window) || Notification.permission !== "granted") return false;
  var opts = {
    body: body,
    icon: "/assets/logo-256.png",
    badge: "/assets/icons/ic-notification.png",
    tag: tag,
    renotify: true,
    data: {
      url: "/notificaciones"
    }
  };
  try {
    if (navigator.serviceWorker && navigator.serviceWorker.ready) {
      navigator.serviceWorker.ready.then(function(reg) {
        reg.showNotification(title, opts);
      }).catch(function() {
        new Notification(title, opts);
      });
    } else {
      new Notification(title, opts);
    }
    return true;
  } catch (e) {
    return false;
  }
}

function announceNewNotifications(list) {
  var firstLoad = notifSeenIds === null;
  var fresh = [];
  if (!firstLoad) {
    fresh = list.filter(function(n) {
      return !n.read && !notifSeenIds[n.id];
    });
  }
  notifSeenIds = {};
  list.forEach(function(n) {
    notifSeenIds[n.id] = true;
  });
  if (!fresh.length) return;
  var panel = $("panel-notifications");
  if (!document.hidden && panel && panel.classList.contains("active")) return;
  var text = fresh.length > 3 ? "Tienes " + fresh.length + " notificaciones nuevas" : fresh.map(notifPlainText).join(" · ");
  if (document.hidden && showDeviceNotification("Z3T", text, "z3t-notif-" + fresh[0].id)) return;
  toast(text);
}

function updateDeviceNotifBanner() {
  var el = $("notifDeviceBanner");
  if (!el) return;
  el.hidden = !("Notification" in window) || Notification.permission !== "default";
}

if ($("btnEnableDeviceNotifs")) {
  $("btnEnableDeviceNotifs").addEventListener("click", function() {
    if (!("Notification" in window)) return;
    Notification.requestPermission().then(function(perm) {
      updateDeviceNotifBanner();
      if (perm === "granted") {
        toast("Listo, te avisaremos de tus notificaciones");
      }
    });
  });
}

function renderNotifBadge() {
  var unread = NOTIFICATIONS.filter(function(n) {
    return !n.read;
  }).length;
  $("notifBadge").hidden = unread === 0;
}

function renderNotifTabs() {
  var wrap = $("notifTabs");
  if (!wrap) return;
  wrap.innerHTML = NOTIF_TABS.map(function(t) {
    var count = NOTIFICATIONS.filter(function(n) {
      return !n.read && notifMatchesTab(n, t.id);
    }).length;
    return '<button type="button" class="tab' + (notifActiveTab === t.id ? " active" : "") + '" data-notiftab="' + t.id + '">' + t.label + (count ? ' <span class="notif-tab-count">' + count + "</span>" : "") + "</button>";
  }).join("");
  qsa(".tab", wrap).forEach(function(btn) {
    btn.addEventListener("click", function() {
      notifActiveTab = btn.getAttribute("data-notiftab");
      renderNotifTabs();
      renderNotifPanel();
    });
  });
}

function notifText(n) {
  var actorName = n.actor ? escapeHtml(n.actor.name || n.actor.username) : "alguien";
  var actorBadge = n.actor ? roleBadgeHtml(n.actor.role, n.actor.verified) : "";
  var threadTitle = escapeHtml(n.threads ? n.threads.title : "una publicación");
  if (n.type === "follow") {
    return "<b>" + actorName + "</b>" + actorBadge + " empezó a seguirte";
  }
  var nm = n.meta || {}, nItem = escapeHtml(nm.item_name || "tu artículo"), who = "<b>" + actorName + "</b>" + actorBadge;
  if (n.type === "announcement") return "📢 Nuevo anuncio: <b>" + escapeHtml(nm.title || "ver anuncio") + "</b>";
  if (n.type === "dm") return who + " te envió un mensaje" + (nm.count > 1 ? " (" + nm.count + " nuevos)" : "");
  if (n.type === "unfollow") return who + " dejó de seguirte";
  if (n.type === "wall_note") return who + " comentó en tu muro";
  if (n.type === "frame_purchase") return who + " compró tu marco <b>" + nItem + "</b>";
  if (n.type === "bubble_purchase") return who + " compró tu burbuja <b>" + nItem + "</b>";
  if (n.type === "resale_sold") return who + " te compró <b>" + nItem + "</b> en reventa";
  if (n.type === "gift") return who + (nm.admin ? " (equipo de Z3T)" : "") + " te envió un regalo 🎁";
  if (n.type === "community_call") {
    var communityName = escapeHtml(n.communities ? n.communities.name : "una comunidad");
    return "<b>" + actorName + "</b>" + actorBadge + " te está esperando en <b>" + communityName + "</b>";
  }
  if (n.type === "community_call_all") {
    var communityName2 = escapeHtml(n.communities ? n.communities.name : "una comunidad");
    return "<b>" + actorName + "</b>" + actorBadge + " llamó a todos en <b>" + communityName2 + "</b>";
  }
  if (NOTIF_TYPE_GROUPS.reacciones.indexOf(n.type) !== -1) {
    return "<b>" + actorName + "</b>" + actorBadge + ' reaccionó a <b>"' + threadTitle + '"</b>';
  }
  return "<b>" + actorName + "</b>" + actorBadge + ' comentó tu publicación <b>"' + threadTitle + '"</b>';
}

function renderNotifPanel() {
  var list = $("notifList");
  if (!list) return;
  var filtered = NOTIFICATIONS.filter(function(n) {
    return notifMatchesTab(n, notifActiveTab);
  });
  if (!filtered.length) {
    list.innerHTML = "";
    $("notifEmpty").hidden = false;
    return;
  }
  $("notifEmpty").hidden = true;
  list.innerHTML = filtered.map(function(n) {
    var idx = NOTIFICATIONS.indexOf(n);
    return '<div class="notif-item' + (n.read ? "" : " unread") + '" data-idx="' + idx + '"><span class="notif-av">' + avatarSpanHtml(n.actor ? n.actor.username : "?", n.actor ? n.actor.avatar_url : null, null, n.actor ? n.actor.id : null) + '<span class="notif-av-badge" aria-hidden="true"><span class="mask-ico mask-ico--logo"></span></span></span><div class="notif-item-body">' + '<div class="notif-item-text">' + notifText(n) + "</div>" + '<div class="notif-item-time">' + timeAgo(n.created_at) + "</div>" + "</div>" + "</div>";
  }).join("");
  qsa(".notif-item", list).forEach(function(el) {
    el.addEventListener("click", function() {
      var n = NOTIFICATIONS[parseInt(el.getAttribute("data-idx"), 10)];
      openNotifItem(n);
    });
  });
}

function openNotifItem(n) {
  if (!n) return;
  if (!n.read) {
    n.read = true;
    renderNotifBadge();
    renderNotifTabs();
    supabase.from("notifications").update({
      read: true
    }).eq("id", n.id).then(function() {});
  }
  if (n.type === "dm" && n.conversation_id && n.actor) {
    openConversation(n.conversation_id, n.actor.id, n.actor.username, n.actor.name || n.actor.username, n.actor.avatar_url, n.actor.name_color, n.actor.role, n.actor.verified);
  } else if (n.type === "wall_note" && currentUser) {
    openProfile(currentUser.id);
  } else if ((n.type === "frame_purchase" || n.type === "bubble_purchase" || n.type === "resale_sold") && typeof openStore === "function") {
    openStore();
  } else if (n.type === "announcement") {
    var annId = n.meta && n.meta.announcement_id;
    if (annId && typeof openAnnouncement === "function") {
      goBack("panel-list");
      var tryOpen = function() {
        openAnnouncement(annId);
      };
      if (typeof ANNOUNCEMENTS !== "undefined" && ANNOUNCEMENTS.some(function(x) {
        return x.id === annId;
      })) tryOpen(); else if (typeof loadAnnouncements === "function") loadAnnouncements().then(tryOpen);
    }
  } else if (n.type === "gift") {
    if (typeof checkPendingGifts === "function") checkPendingGifts();
  } else if ((n.type === "follow" || n.type === "unfollow") && n.actor) {
    openProfile(n.actor.id);
  } else if ((n.type === "community_call" || n.type === "community_call_all") && n.communities) {
    openCommunity(n.communities.slug);
  } else if (n.threads && n.threads.slug) {
    resolveThreadBySlug(n.threads.slug);
  } else if (n.thread_id) {
    openThread(n.thread_id);
  }
}

function openNotificationsPanel() {
  minimizeActiveContexts();
  activatePanel("panel-notifications");
  loadNotifications();
  updateDeviceNotifBanner();
  if (!state.suppressPush) {
    history.pushState({
      view: "notifications"
    }, "", "/notificaciones");
  }
  state.suppressPush = false;
}

$("btnNotif").addEventListener("click", function(e) {
  e.stopPropagation();
  openNotificationsPanel();
});

$("btnNotifBack").addEventListener("click", function() {
  goBack("panel-list");
});

$("btnMarkAllRead").addEventListener("click", function() {
  if (!currentUser) return;
  var unread = NOTIFICATIONS.filter(function(n) {
    return !n.read;
  });
  if (!unread.length) return;
  NOTIFICATIONS.forEach(function(n) {
    n.read = true;
  });
  renderNotifBadge();
  renderNotifTabs();
  renderNotifPanel();
  supabase.from("notifications").update({
    read: true
  }).eq("recipient_id", currentUser.id).eq("read", false).then(function() {});
});

document.addEventListener("visibilitychange", function() {
  if (!document.hidden && currentUser) loadNotifications();
});

/* Avisos del dispositivo activados por defecto: se pide el permiso una sola vez, en el primer toque tras entrar */
function z3tAutoEnableDeviceNotifs() {
  if (!("Notification" in window) || Notification.permission !== "default") return;
  try {
    if (localStorage.getItem("z3t_notif_asked") === "1") return;
  } catch (e) {}
  var ask = function() {
    document.removeEventListener("pointerdown", ask, true);
    try {
      localStorage.setItem("z3t_notif_asked", "1");
    } catch (e) {}
    Notification.requestPermission().then(function() {
      updateDeviceNotifBanner();
    }).catch(function() {});
  };
  document.addEventListener("pointerdown", ask, true);
}
