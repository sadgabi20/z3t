"use strict";

var meetProfilePool = [];

var meetOrbitTimer = null;

var meetOrbitBuilt = false;

var meetChosenMode = null;

var meetPollTimer = null;

var currentMeetSession = null;

var meetMessagesPollTimer = null;

var MEET_MESSAGES = [];

var MEET_REVEAL_MINUTES = 20;

var meetRevealTimer = null;

var meetRevealAvailable = false;

var meetConnected = false;

var meetPickedPhoto = null;

var MEET_ORBIT_RINGS = [ {
  radius: 5.6,
  dur: 15,
  dir: 1
}, {
  radius: 7.4,
  dur: 21,
  dir: -1
}, {
  radius: 9.3,
  dur: 27,
  dir: 1
} ];

var MEET_ORBIT_SLOTS = 6;

var MEET_ORBIT_RING_IMAGES = [ {
  src: "assets/effects/orbit-ring-1.png",
  fill: .646
}, {
  src: "assets/effects/orbit-ring-2.png",
  fill: .683
}, {
  src: "assets/effects/orbit-ring-3.png",
  fill: .738
}, {
  src: "assets/effects/orbit-ring-4.png",
  fill: .8
}, {
  src: "assets/effects/orbit-ring-5.png",
  fill: .8
}, {
  src: "assets/effects/orbit-ring-6.png",
  fill: .7
}, {
  src: "assets/effects/orbit-ring-7.png",
  fill: .738
} ];

var MEET_AVATAR_BASE_REM = 2;

var MEET_RING_SCALE = 1.9;

function loadMeetOrbit() {
  if (!currentUser) return;
  refreshMeetPool().then(function() {
    buildMeetOrbit();
    if (meetOrbitTimer) clearInterval(meetOrbitTimer);
    meetOrbitTimer = setInterval(function() {
      if (!document.hidden) refreshMeetPool();
    }, 9e4);
  });
}

function refreshMeetPool() {
  if (!currentUser) return Promise.resolve();
  return supabase.from("profiles").select("id, username, avatar_url").neq("id", currentUser.id).limit(30).then(function(res) {
    meetProfilePool = res.error ? [] : res.data || [];
  });
}

function pickRandomMeetProfile(excludeId) {
  if (!meetProfilePool.length) return null;
  var pool = excludeId ? meetProfilePool.filter(function(p) {
    return p.id !== excludeId;
  }) : meetProfilePool;
  if (!pool.length) pool = meetProfilePool;
  return pool[Math.floor(Math.random() * pool.length)];
}

function swapMeetOrbitSlot(avatarEl) {
  var currentUid = avatarEl.getAttribute("data-uid");
  var next = pickRandomMeetProfile(currentUid);
  var photoEl = avatarEl.querySelector(".meet-orbit-avatar-photo");
  if (!photoEl) return;
  photoEl.style.backgroundImage = "none";
  photoEl.textContent = "";
  avatarEl.removeAttribute("data-frame-url");
  avatarEl.style.removeProperty("--avatar-frame-img");
  if (!next) {
    avatarEl.removeAttribute("data-uid");
    return;
  }
  avatarEl.setAttribute("data-uid", next.id);
  if (next.avatar_url) {
    photoEl.style.backgroundImage = 'url("' + encodeURI(next.avatar_url).replace(/"/g, "%22").replace(/'/g, "%27") + '")';
  } else {
    photoEl.appendChild(document.createTextNode((next.username || "?").charAt(0).toUpperCase()));
  }
  queueFrameLookup(next.id);
}

function buildMeetOrbit() {
  var orbit = $("meetOrbit");
  if (!orbit) return;
  if (meetOrbitBuilt) {
    qsa(".meet-orbit-avatar", orbit).forEach(function(el) {
      if (!el.getAttribute("data-uid")) swapMeetOrbitSlot(el);
    });
    return;
  }
  if (!meetProfilePool.length) return;
  var html = "";
  for (var i = 0; i < MEET_ORBIT_SLOTS; i++) {
    var ring = MEET_ORBIT_RINGS[i % MEET_ORBIT_RINGS.length];
    var oppositeSide = Math.floor(i / MEET_ORBIT_RINGS.length) === 1;
    var delay = -(ring.dur * (oppositeSide ? .5 : 0)) - i * .9;
    var ringDef = MEET_ORBIT_RING_IMAGES[i % MEET_ORBIT_RING_IMAGES.length];
    var photoRem = (ringDef.fill * MEET_AVATAR_BASE_REM * MEET_RING_SCALE).toFixed(2);
    var ringDur = (9 + i * 2.3).toFixed(1);
    var ringDirClass = i % 2 === 0 ? "" : " reverse";
    html += '<div class="meet-orbit-slot' + (ring.dir < 0 ? " reverse" : "") + '" style="--radius:' + ring.radius + "rem;--dur:" + ring.dur + "s;--delay:" + delay.toFixed(2) + 's;">' + '<div class="avatar meet-orbit-avatar">' + '<div class="meet-orbit-avatar-ring' + ringDirClass + '" style="background-image:url(\'' + ringDef.src + '\');--ring-dur:' + ringDur + 's;"></div>' + '<div class="meet-orbit-avatar-photo" style="--photo-size:' + photoRem + 'rem;"></div>' + "</div>" + "</div>";
  }
  orbit.innerHTML = html;
  qsa(".meet-orbit-avatar", orbit).forEach(function(el) {
    swapMeetOrbitSlot(el);
    el.addEventListener("click", function() {
      var uid = this.getAttribute("data-uid");
      if (uid) openProfile(uid);
    });
    el.addEventListener("animationiteration", function(e) {
      if (e.animationName !== "meetOrbitAvatarCycle") return;
      swapMeetOrbitSlot(e.target);
    });
  });
  meetOrbitBuilt = true;
}

if ($("btnMeetCenter")) $("btnMeetCenter").addEventListener("click", function() {
  $("meetChooseBackdrop").classList.add("open");
});

$("meetChooseClose").addEventListener("click", function() {
  $("meetChooseBackdrop").classList.remove("open");
});

$("meetChooseBackdrop").addEventListener("click", function(e) {
  if (e.target === this) $("meetChooseBackdrop").classList.remove("open");
});

$("btnMeetVoice").addEventListener("click", function() {
  startMeetSearch("voice");
});

$("btnMeetText").addEventListener("click", function() {
  startMeetSearch("text");
});

if ($("btnMeetVoicePill")) $("btnMeetVoicePill").addEventListener("click", function() {
  if (!currentUser) return;
  startMeetSearch("voice");
});

if ($("btnMeetTextPill")) $("btnMeetTextPill").addEventListener("click", function() {
  if (!currentUser) return;
  startMeetSearch("text");
});

if ($("btnBottleAdrift")) $("btnBottleAdrift").addEventListener("click", function() {
  if (!currentUser) {
    toast("Espera un momento a que cargue tu sesión e intenta de nuevo.");
    return;
  }
  openBottleScreen();
});

function startMeetSearch(mode) {
  if (!currentUser) return;
  meetChosenMode = mode;
  $("meetChooseBackdrop").classList.remove("open");
  enterImmersive("meet");
  activatePanel("panel-meet-session");
  if (mode === "voice") {
    $("meetSessionDetail").innerHTML = voiceMeetSearchingHtml();
    wireVoiceMeetSearchingScreen();
  } else {
    $("meetSessionDetail").innerHTML = '<div class="community-shell" style="align-items:center; justify-content:center; text-align:center; padding:2rem;">' + '<div><div class="voice-bar-empty" style="justify-content:center; font-size:1rem; margin-bottom:1rem;">Buscando a alguien más para Meet (escrito)...</div>' + '<button class="terminal-btn" id="btnMeetCancel" type="button">Cancelar</button></div>' + "</div>";
    $("btnMeetCancel").addEventListener("click", cancelMeetSearch);
  }
  pollMeetMatch();
  if (meetPollTimer) clearInterval(meetPollTimer);
  meetPollTimer = setInterval(pollMeetMatch, 2500);
}

function voiceMeetRingsHtml() {
  return '<div class="voice-meet-ring r1"></div>' + '<div class="voice-meet-ring r2"></div>' + '<div class="voice-meet-ring r3"></div>' + '<div class="voice-meet-ring r4"></div>';
}

var VOICE_MEET_SILHOUETTE_SVG = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10Zm0 2c-4.4 0-9 2.2-9 5.5V22h18v-2.5c0-3.3-4.6-5.5-9-5.5Z"/></svg>';

function voiceMeetSearchingHtml() {
  return '<div class="voice-meet-shell">' + '<div class="voice-meet-topbar">' + '<button class="icon-btn" id="btnMeetCancel" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + "<h2>Voice Meet</h2>" + '<span class="voice-meet-topbar-spacer" aria-hidden="true"></span>' + "</div>" + '<div class="voice-meet-pref-row">' + '<div class="voice-meet-pref-label">Preferencias</div>' + '<button type="button" class="voice-meet-pref-change" id="btnVoiceMeetPrefs">Sin preferencias · Cambiar →</button>' + "</div>" + '<div class="voice-meet-radar searching" id="voiceMeetRadar">' + voiceMeetRingsHtml() + '<span class="voice-meet-blip"></span>' + '<div class="voice-meet-avatar-wrap"><span class="voice-meet-avatar-placeholder">' + VOICE_MEET_SILHOUETTE_SVG + "</span></div>" + "</div>" + '<button type="button" class="terminal-btn voice-meet-stop-btn" id="btnVoiceMeetStop">Stop</button>' + '<p class="voice-meet-status-label">Buscando<span class="voice-meet-dots"><span>.</span><span>.</span><span>.</span></span></p>' + "</div>";
}

function wireVoiceMeetSearchingScreen() {
  $("btnMeetCancel").addEventListener("click", cancelMeetSearch);
  $("btnVoiceMeetStop").addEventListener("click", cancelMeetSearch);
  $("btnVoiceMeetPrefs").addEventListener("click", function() {
    toast(t("meet.filters_soon"));
  });
}

function pollMeetMatch() {
  if (!meetChosenMode) return;
  var modeAtRequest = meetChosenMode;
  supabase.rpc("try_match_meet", {
    p_mode: modeAtRequest
  }).then(function(res) {
    if (res.error) return;
    if (meetChosenMode !== modeAtRequest) {
      if (res.data) supabase.from("meet_sessions").update({
        ended_at: (new Date).toISOString()
      }).eq("id", res.data);
      return;
    }
    if (res.data) {
      if (meetPollTimer) {
        clearInterval(meetPollTimer);
        meetPollTimer = null;
      }
      openMeetSession(res.data, modeAtRequest);
    }
  });
}

function cancelMeetSearch() {
  if (meetPollTimer) {
    clearInterval(meetPollTimer);
    meetPollTimer = null;
  }
  if (currentUser) supabase.rpc("leave_meet_queue");
  meetChosenMode = null;
  exitImmersive("meet");
  activatePanel("panel-list");
  if (location.pathname !== "/") history.pushState({
    view: "list"
  }, "", "/");
}

window.addEventListener("pagehide", function() {
  if (meetChosenMode && currentUser) supabase.rpc("leave_meet_queue");
});

function openMeetSession(sessionId, mode) {
  currentMeetSession = {
    id: sessionId,
    mode: mode,
    createdAt: null,
    partnerId: null,
    dmConversationId: null
  };
  meetRevealAvailable = false;
  meetConnected = false;
  meetPickedPhoto = null;
  var isVoice = mode === "voice";
  if (isVoice) {
    $("meetSessionDetail").innerHTML = voiceMeetConnectedHtml();
    $("btnMeetEnd").addEventListener("click", endMeetSession);
    ensureActivityVoiceConnected("meet", sessionId, function() {
      return null;
    }).then(function() {
      activityVoiceActive = true;
      if (activityVoiceRoom && activityVoiceRoom.localParticipant) {
        activityVoiceRoom.localParticipant.setMicrophoneEnabled(true).then(renderVoiceMeetMuteBtn);
      }
      renderVoiceMeetMuteBtn();
    });
    $("btnVoiceMeetMute").addEventListener("click", function() {
      activityToggleMute();
      renderVoiceMeetMuteBtn();
    });
    loadMeetSessionRow(sessionId);
    startMeetRevealWatcher();
    return;
  }
  $("meetSessionDetail").innerHTML = '<div class="community-shell">' + '<div class="community-fixed-top">' + '<div class="community-header-bar" style="padding:.9rem;">' + '<div class="community-header-name"><h3>Meet con un desconocido</h3><div class="community-header-sub" id="meetHeaderSub">Chat escrito anónimo</div></div>' + '<button class="link-btn" id="btnMeetSkip" type="button" style="flex:none; margin-right:.5rem;">Continuar con otra persona</button>' + '<button class="terminal-btn" id="btnMeetEnd" type="button" style="flex:none;">Terminar</button>' + "</div>" + "</div>" + '<div id="meetRevealBanner"></div>' + '<div class="community-chat meet-chat-bg" id="meetChat"></div>' + '<form class="community-chat-input-row" id="meetChatForm">' + '<input type="file" id="meetChatFile" accept="image/*" hidden>' + '<button class="icon-btn" type="button" id="btnMeetChatAttach" aria-label="Adjuntar foto"><img loading=lazy decoding=async src="assets/icons/ic-upload.png" alt="" class="upload-icon-img"></button>' + '<input type="text" id="meetChatInput" placeholder="Escribe algo... (anónimo)" autocomplete="off">' + '<button class="icon-btn" type="submit" aria-label="Enviar">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>' + "</button>" + "</form>" + "</div>";
  $("btnMeetEnd").addEventListener("click", endMeetSession);
  $("btnMeetSkip").addEventListener("click", skipMeetPartner);
  $("btnMeetChatAttach").addEventListener("click", function() {
    $("meetChatFile").click();
  });
  $("meetChatFile").addEventListener("change", function() {
    meetPickedPhoto = this.files && this.files[0] || null;
    if (meetPickedPhoto) sendMeetMessage(null, true);
  });
  loadMeetSessionRow(sessionId);
  loadMeetMessages();
  if (meetMessagesPollTimer) clearInterval(meetMessagesPollTimer);
  meetMessagesPollTimer = setInterval(loadMeetMessages, 3e3);
  $("meetChatForm").addEventListener("submit", sendMeetMessage);
  startMeetRevealWatcher();
}

function loadMeetSessionRow(sessionId) {
  supabase.from("meet_sessions").select("*").eq("id", sessionId).single().then(function(res) {
    if (res.error || !res.data || !currentMeetSession) return;
    if (currentMeetSession.id !== sessionId) return;
    var row = res.data;
    var otherId = row.user_a === currentUser.id ? row.user_b : row.user_b === currentUser.id ? row.user_a : null;
    currentMeetSession.createdAt = row.created_at;
    currentMeetSession.partnerId = otherId;
    currentMeetSession.dmConversationId = row.dm_conversation_id || null;
    if (row.dm_conversation_id) {
      meetConnected = true;
    }
    if (currentMeetSession.mode === "voice") loadMeetPartner(otherId);
    checkMeetRevealElapsed();
  });
}

function voiceMeetConnectedHtml() {
  return '<div class="voice-meet-shell voice-meet-connected">' + '<div class="voice-meet-topbar">' + '<button class="icon-btn" id="btnMeetEnd" type="button" aria-label="Terminar">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + "<h2>Voice Meet</h2>" + '<span class="voice-meet-topbar-spacer" aria-hidden="true"></span>' + "</div>" + '<div class="voice-meet-radar matched" id="voiceMeetRadar">' + voiceMeetRingsHtml() + '<div class="voice-meet-avatar-wrap" id="voiceMeetPartnerWrap">' + '<span class="voice-meet-avatar-placeholder">' + VOICE_MEET_SILHOUETTE_SVG + "</span>" + "</div>" + "</div>" + '<div class="voice-meet-controls-row">' + '<button type="button" class="voice-meet-mute-btn" id="btnVoiceMeetMute" aria-label="Silenciar">' + voiceIconSvg() + "</button>" + '<button type="button" class="terminal-btn voice-meet-end-btn" id="btnMeetEndPill">Terminar</button>' + "</div>" + '<button type="button" class="link-btn" id="btnVoiceMeetSkip">Continuar con otra persona</button>' + '<p class="voice-meet-status-label">Conectado · anónimo</p>' + "</div>";
}

function renderVoiceMeetMuteBtn() {
  var btn = $("btnVoiceMeetMute");
  if (!btn) return;
  btn.classList.toggle("muted", !!activityVoiceMuted);
  btn.innerHTML = activityVoiceMuted ? micOffSvg() : micOnSvg();
}

document.addEventListener("click", function(e) {
  if (e.target.closest && e.target.closest("#btnMeetEndPill")) endMeetSession();
  if (e.target.closest && e.target.closest("#btnVoiceMeetSkip")) skipMeetPartner();
});

function loadMeetPartner(otherId) {
  if (!otherId) return;
  supabase.from("profiles").select("id, username, avatar_url").eq("id", otherId).single().then(function(pRes) {
    if (pRes.error || !pRes.data) return;
    var wrap = $("voiceMeetPartnerWrap");
    if (!wrap) return;
    wrap.className = "voice-meet-avatar-wrap voice-participant reveal";
    wrap.setAttribute("data-identity", otherId);
    wrap.innerHTML = avatarSpanHtml(meetConnected ? pRes.data.username : "Desconocido", pRes.data.avatar_url, "voice-meet-avatar", meetConnected ? otherId : null);
  });
}

function startMeetRevealWatcher() {
  if (meetRevealTimer) clearInterval(meetRevealTimer);
  meetRevealTimer = setInterval(checkMeetRevealElapsed, 2e4);
}

function checkMeetRevealElapsed() {
  if (!currentMeetSession || !currentMeetSession.createdAt || meetRevealAvailable) return;
  var elapsedMs = Date.now() - new Date(currentMeetSession.createdAt).getTime();
  if (elapsedMs >= MEET_REVEAL_MINUTES * 60 * 1e3) {
    meetRevealAvailable = true;
    renderMeetRevealBanner();
  }
}

function renderMeetRevealBanner() {
  if (meetConnected) return;
  var host = currentMeetSession.mode === "voice" ? $("voiceMeetRadar") : $("meetRevealBanner");
  if (!host) return;
  var bannerHtml = '<div class="dm-request-banner" id="meetConnectBanner">' + '<div class="dm-request-ask">Ya pasaron ' + MEET_REVEAL_MINUTES + " minutos. ¿Quieren pasar esta conversación a sus Chats?</div>" + '<div class="dm-request-actions">' + '<button class="terminal-btn" id="btnMeetConnectYes" type="button">Conectarnos en Chats</button>' + '<button class="link-btn" id="btnMeetConnectNo" type="button">Seguir anónimo</button>' + "</div>" + "</div>";
  if (currentMeetSession.mode === "voice") {
    host.insertAdjacentHTML("afterend", bannerHtml);
  } else {
    host.innerHTML = bannerHtml;
  }
  $("btnMeetConnectYes").addEventListener("click", requestMeetConnect);
  $("btnMeetConnectNo").addEventListener("click", function() {
    var el = $("meetConnectBanner");
    if (el) el.remove();
  });
}

function requestMeetConnect() {
  if (!currentMeetSession) return;
  var btn = $("btnMeetConnectYes");
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Enviando...";
  }
  supabase.rpc("request_meet_connect", {
    p_session_id: currentMeetSession.id
  }).then(function(res) {
    if (res.error) {
      toast(t("meet.err_connect") + " " + res.error.message);
      if (btn) {
        btn.disabled = false;
        btn.textContent = t("meet.btn_connect_chats");
      }
      return;
    }
    var data = res.data || {};
    if (data.connected) {
      meetConnected = true;
      currentMeetSession.dmConversationId = data.conversation_id;
      var bannerEl = $("meetConnectBanner");
      if (bannerEl) bannerEl.outerHTML = '<div class="dm-request-waiting">🎉 Se conectaron. Ya está en tus Chats.</div>';
      var sub = $("meetHeaderSub");
      if (sub) sub.textContent = "Conectados a Chats";
      if (currentMeetSession.mode === "voice" && currentMeetSession.partnerId) loadMeetPartner(currentMeetSession.partnerId);
      toast(t("meet.toast_connected"));
    } else {
      toast(t("meet.toast_vote_saved"));
      if (btn) {
        btn.textContent = "Esperando a la otra persona...";
      }
    }
  });
}

function loadMeetMessages() {
  if (!currentMeetSession) return;
  var sessionId = currentMeetSession.id;
  supabase.from("meet_messages").select("*").eq("session_id", sessionId).order("created_at", {
    ascending: true
  }).then(function(res) {
    if (!currentMeetSession || currentMeetSession.id !== sessionId) return;
    MEET_MESSAGES = res.error ? [] : res.data || [];
    renderMeetMessages();
  });
}

function renderMeetMessages() {
  var chat = $("meetChat");
  if (!chat) return;
  if (!MEET_MESSAGES.length) {
    chat.innerHTML = '<p class="empty-state">Di hola 👋</p>';
    return;
  }
  chat.innerHTML = MEET_MESSAGES.map(function(m) {
    var mine = currentUser && m.sender_id === currentUser.id;
    return '<div class="chat-msg' + (mine ? " mine" : "") + '">' + avatarSpanHtml(mine ? "Tú" : "?", null) + chatMsgBodyOpenTag(mine ? currentUser.id : null) + '<div class="chat-msg-name">' + (mine ? "Tú" : "Desconocido") + "</div>" + (m.image_url ? '<div class="chat-msg-image"><img loading=lazy decoding=async src="' + escapeHtml(m.image_url) + '" alt=""></div>' : "") + (m.body ? '<div class="chat-msg-text">' + escapeHtml(m.body) + "</div>" : "") + "</div>" + "</div>";
  }).join("");
  chat.scrollTop = chat.scrollHeight;
}

function sendMeetMessage(e, isPhoto) {
  if (e) e.preventDefault();
  if (!currentUser || !currentMeetSession) return;
  var input = $("meetChatInput");
  var body = input ? input.value.trim() : "";
  if (!isPhoto && !body) return;
  if (input) input.value = "";
  var uploadPromise = isPhoto && meetPickedPhoto ? uploadFiles([ meetPickedPhoto ], "meet/" + currentMeetSession.id).then(function(up) {
    return up[0] ? up[0].url : null;
  }) : Promise.resolve(null);
  uploadPromise.then(function(imageUrl) {
    meetPickedPhoto = null;
    if (isPhoto && !imageUrl) {
      toast(t("meet.err_photo_upload"));
      return;
    }
    var payload = {
      session_id: currentMeetSession.id,
      sender_id: currentUser.id,
      body: body || null
    };
    if (imageUrl) payload.image_url = imageUrl;
    return supabase.from("meet_messages").insert(payload).then(function(res) {
      if (res.error) {
        toast(t("meet.err_send") + " " + res.error.message);
        return;
      }
      loadMeetMessages();
    });
  });
}

function endMeetSessionQuiet() {
  if (meetMessagesPollTimer) {
    clearInterval(meetMessagesPollTimer);
    meetMessagesPollTimer = null;
  }
  if (meetRevealTimer) {
    clearInterval(meetRevealTimer);
    meetRevealTimer = null;
  }
  var p = Promise.resolve();
  if (currentMeetSession) {
    var sessionId = currentMeetSession.id;
    var wasConnected = meetConnected;
    p = supabase.from("meet_sessions").update({
      ended_at: (new Date).toISOString()
    }).eq("id", sessionId).then(function() {
      if (!wasConnected) {
        return supabase.from("meet_messages").delete().eq("session_id", sessionId);
      }
    });
  }
  leaveActivityVoice();
  currentMeetSession = null;
  meetRevealAvailable = false;
  meetConnected = false;
  if (typeof exitImmersive === "function") exitImmersive("meet");
  return p;
}

window.autoEndMeetIfActive = function() {
  if (!currentMeetSession) return;
  endMeetSessionQuiet();
};

function skipMeetPartner() {
  var mode = meetChosenMode;
  endMeetSessionQuiet().then(function() {
    startMeetSearch(mode);
  });
}

function endMeetSession() {
  endMeetSessionQuiet().then(function() {
    meetChosenMode = null;
    exitImmersive("meet");
    activatePanel("panel-list");
    if (location.pathname !== "/") history.pushState({
      view: "list"
    }, "", "/");
    toast(t("meet.toast_ended"));
  });
}

function openCommunitySettings() {
  var settTitleEl = $("communitySettingsTitle");
  if (settTitleEl) settTitleEl.textContent = "Configurar comunidad";
  var c = currentCommunity;
  var isAdmin = myCommunityRole() === "admin" || currentUser && currentUser.role === "admin";
  var html = '<div class="community-settings-section"><h4>Apariencia y actividades</h4>' + '<label class="field"><span>Nombre</span><input type="text" id="settName" value="' + escapeHtml(c.name) + '" maxlength="60"></label>' + '<label class="field"><span>Descripción</span><textarea id="settDesc" maxlength="300" rows="2">' + escapeHtml(c.description || "") + "</textarea></label>" + '<label class="field"><span>Categoría</span><select id="settTag"></select></label>' + '<label class="field"><span>Círculo afiliado</span><select id="settCircle"></select></label>' + '<div class="image-setting-row">' + "<span>Foto de banner (se ve en la tarjeta antes de entrar)</span>" + '<div class="image-setting-preview" id="settBannerPreview">' + (c.banner_url ? '<img loading=lazy decoding=async src="' + escapeHtml(c.banner_url) + '" alt="">' : '<span class="image-setting-empty">Sin foto</span>') + "</div>" + '<input type="file" id="settBannerFile" accept="image/*" hidden>' + '<button class="link-btn" id="btnPickSettBanner" type="button">Cambiar foto de banner</button>' + "</div>" + '<div class="image-setting-row">' + "<span>Foto de fondo (se ve dentro de la comunidad)</span>" + '<div class="image-setting-preview" id="settBackgroundPreview">' + (c.background_url ? '<img loading=lazy decoding=async src="' + escapeHtml(c.background_url) + '" alt="">' : '<span class="image-setting-empty">Sin foto</span>') + "</div>" + '<input type="file" id="settBackgroundFile" accept="image/*" hidden>' + '<button class="link-btn" id="btnPickSettBackground" type="button">Cambiar foto de fondo</button>' + "</div>" + '<div class="toggle-row"><span>Actividades activadas</span><input type="checkbox" id="settActivities" ' + (c.activities_enabled ? "checked" : "") + "></div>" + '' + (isAdmin ? z3tRoleColorFieldsHtml(c) : "") + '<button class="terminal-btn full-width" id="btnSaveCommunitySettings" type="button">Guardar cambios</button>' + "</div>";
  if (isAdmin) {
    html += '<div class="community-settings-section"><h4>Co-administradores</h4>' + '<p class="settings-hint">Elige hasta 20 personas que puedan moderar y editar esta comunidad.</p>' + '<div id="settCoAdminList"></div>' + "</div>";
    html += '<div class="community-settings-section"><h4>Zona peligrosa</h4>' + '<button class="link-btn danger" id="btnDeleteCommunity" type="button">Eliminar comunidad permanentemente</button>' + "</div>";
  }
  $("communitySettingsBody").innerHTML = html;
  var sel = $("settTag");
  sel.innerHTML = COMMUNITY_TAGS.filter(function(t) {
    return t.kind === "tag";
  }).map(function(t) {
    return '<option value="' + t.id + '"' + (t.id === c.tag ? " selected" : "") + ">" + escapeHtml(t.label) + "</option>";
  }).join("");
  var circleSel = $("settCircle");
  circleSel.innerHTML = '<option value="">Ninguno</option>';
  supabase.from("circles").select("id,name").order("name").then(function(res) {
    (res.data || []).forEach(function(circ) {
      var opt = document.createElement("option");
      opt.value = circ.id;
      opt.textContent = circ.name;
      if (circ.id === c.circle_id) opt.selected = true;
      circleSel.appendChild(opt);
    });
  });
  $("btnSaveCommunitySettings").addEventListener("click", saveCommunitySettings);
  $("btnPickSettBanner").addEventListener("click", function() {
    $("settBannerFile").click();
  });
  $("settBannerFile").addEventListener("change", function() {
    handleSettingsImageChange(this, "banner", "settBannerPreview");
  });
  $("btnPickSettBackground").addEventListener("click", function() {
    $("settBackgroundFile").click();
  });
  $("settBackgroundFile").addEventListener("change", function() {
    handleSettingsImageChange(this, "background", "settBackgroundPreview");
  });
  if (isAdmin) renderSettCoAdminList();
  var delBtn = $("btnDeleteCommunity");
  if (delBtn) delBtn.addEventListener("click", function() {
    $("communitySettingsBackdrop").classList.remove("open");
    handleCommunityLeaveClick();
  });
  $("communitySettingsBackdrop").classList.add("open");
}

function handleSettingsImageChange(inputEl, kind, previewId) {
  var file = inputEl.files && inputEl.files[0];
  inputEl.value = "";
  if (!file || !currentCommunity) return;
  var previewEl = $(previewId);
  if (previewEl) previewEl.innerHTML = '<span class="image-setting-empty">Subiendo...</span>';
  uploadCommunityImage(currentCommunity.id, file, kind).then(function(url) {
    var patch = {};
    patch[kind === "banner" ? "banner_url" : "background_url"] = url;
    return supabase.from("communities").update(patch).eq("id", currentCommunity.id);
  }).then(function(res) {
    if (res && res.error) {
      toast(t("meet.err_save") + " " + res.error.message);
      openCommunitySettings();
      return;
    }
    toast(kind === "banner" ? "Banner actualizado." : "Fondo actualizado.");
    return supabase.from("communities").select("*").eq("id", currentCommunity.id).single();
  }).then(function(res) {
    if (res && res.data) currentCommunity = res.data;
    openCommunitySettings();
    renderCommunityDetail();
    loadCommunities();
  }).catch(function() {
    toast(t("meet.err_image_upload"));
    openCommunitySettings();
  });
}

function renderSettCoAdminList() {
  var wrap = $("settCoAdminList");
  if (!wrap) return;
  var others = communityMembers.filter(function(m) {
    return m.role !== "admin";
  });
  if (!others.length) {
    wrap.innerHTML = '<p class="settings-hint">Todavía no hay más miembros en esta comunidad.</p>';
    return;
  }
  wrap.innerHTML = others.map(function(m) {
    var name = m.profiles ? m.profiles.username : "usuario";
    var checked = m.role === "co_admin";
    return '<label class="toggle-row"><span>' + escapeHtml(name) + '</span><input type="checkbox" data-member="' + m.id + '" class="coadmin-toggle" ' + (checked ? "checked" : "") + "></label>";
  }).join("");
  qsa(".coadmin-toggle", wrap).forEach(function(cb) {
    cb.addEventListener("change", function() {
      var memberId = cb.getAttribute("data-member");
      var makeCoAdmin = cb.checked;
      supabase.from("community_members").update({
        role: makeCoAdmin ? "co_admin" : "member"
      }).eq("id", memberId).then(function(res) {
        if (res.error) {
          toast(t("meet.err_update") + " " + res.error.message);
          cb.checked = !makeCoAdmin;
          return;
        }
        toast(makeCoAdmin ? "Ahora es Co-Admin." : "Ya no es Co-Admin.");
        loadCommunityMembers().then(function() {
          renderCommunityDetail();
        });
      });
    });
  });
}

function saveCommunitySettings() {
  var name = $("settName").value.trim();
  if (name.length < 3) {
    toast(t("meet.err_name_length"));
    return;
  }
  var payload = {
    name: name,
    description: $("settDesc").value.trim() || null,
    tag: $("settTag").value,
    circle_id: $("settCircle").value || null,
    activities_enabled: $("settActivities").checked
  };
  supabase.from("communities").update(payload).eq("id", currentCommunity.id).then(function(res) {
    if (res.error) {
      toast(t("meet.err_save") + " " + res.error.message);
      return;
    }
    var roleColors = z3tReadRoleColorFields();
    if (Object.keys(roleColors).length && $("settRoleColor_admin")) {
      supabase.from("communities").update({
        role_colors: roleColors
      }).eq("id", currentCommunity.id).then(function(rc) {
        if (rc.error) {
          toast("No se pudieron guardar los colores de roles: falta la columna role_colors en Supabase (ver docs/SQL-2026-10-29.sql).");
          return;
        }
        currentCommunity.role_colors = roleColors;
        if (typeof renderCommunityChat === "function") {
          var chatEl = $("communityChat");
          if (chatEl) chatEl.dataset.msgSig = "";
          renderCommunityChat();
        }
      });
    }
    toast(t("meet.toast_community_updated"));
    $("communitySettingsBackdrop").classList.remove("open");
    refreshCommunityView(false);
    loadCommunities();
  });
}

$("communitySettingsClose").addEventListener("click", function() {
  $("communitySettingsBackdrop").classList.remove("open");
});

$("communitySettingsBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

var COMMUNITY_IMG_BUCKET = "attachments";

var MAX_COMMUNITY_IMG_SIZE = 10 * 1024 * 1024;

function uploadCommunityImage(communityId, file, kind) {
  return new Promise(function(resolve, reject) {
    if (!file) {
      resolve(null);
      return;
    }
    if (file.type.indexOf("image/") !== 0) {
      toast(t("meet.err_pick_image"));
      reject(new Error("not-image"));
      return;
    }
    if (file.size > MAX_COMMUNITY_IMG_SIZE) {
      toast(t("meet.err_image_too_big"));
      reject(new Error("too-big"));
      return;
    }
    stripImageMetadata(file).then(function(cleanFile) {
      var ext = cleanFile.type === "image/png" ? "png" : cleanFile.type === "image/webp" ? "webp" : "jpg";
      var path = "communities/" + communityId + "/" + kind + "_" + Date.now() + "." + ext;
      return supabase.storage.from(COMMUNITY_IMG_BUCKET).upload(path, cleanFile, {
        upsert: true,
        contentType: cleanFile.type
      }).then(function(res) {
        if (res.error) {
          reject(res.error);
          return;
        }
        var pub = supabase.storage.from(COMMUNITY_IMG_BUCKET).getPublicUrl(path);
        resolve(pub.data.publicUrl);
      });
    }).catch(reject);
  });
}

function renderImagePickPreview(containerId, file) {
  var el = $(containerId);
  if (!el) return;
  if (!file) {
    el.innerHTML = "";
    return;
  }
  el.innerHTML = '<img loading=lazy decoding=async src="' + URL.createObjectURL(file) + '" alt="">';
}

var pickedCommunityBanner = null;

var pickedCommunityBackground = null;

function openCreateCommunityModal() {
  $("communityTag").value = "";
  if (typeof flagFieldSet === "function") flagFieldSet("communityCreateFlag", []);
  if (typeof refreshFlagOptionsList === "function") refreshFlagOptionsList();
  var picker = $("communityTagPicker");
  picker.innerHTML = COMMUNITY_TAGS.filter(function(t) {
    return t.kind === "tag";
  }).map(function(t) {
    return '<button type="button" class="community-tag-pill" data-tag="' + t.id + '">' + t.icon + " " + escapeHtml(t.label) + "</button>";
  }).join("");
  qsa(".community-tag-pill", picker).forEach(function(btn) {
    btn.addEventListener("click", function() {
      qsa(".community-tag-pill", picker).forEach(function(b) {
        b.classList.remove("active");
      });
      btn.classList.add("active");
      $("communityTag").value = btn.getAttribute("data-tag");
    });
  });
  pickedCommunityBanner = null;
  pickedCommunityBackground = null;
  $("communityBannerPreview").innerHTML = "";
  $("communityBackgroundPreview").innerHTML = "";
  var circleSel = $("communityCircle");
  circleSel.innerHTML = '<option value="">Ninguno</option>';
  supabase.from("circles").select("id,name").order("name").then(function(res) {
    (res.data || []).forEach(function(c) {
      var opt = document.createElement("option");
      opt.value = c.id;
      opt.textContent = c.name;
      circleSel.appendChild(opt);
    });
  });
  $("createCommunityBackdrop").classList.add("open");
  $("communityName").focus();
}

$("createCommunityClose").addEventListener("click", function() {
  $("createCommunityBackdrop").classList.remove("open");
  $("createCommunityForm").reset();
});

$("createCommunityBackdrop").addEventListener("click", function(e) {
  if (e.target === this) {
    this.classList.remove("open");
    $("createCommunityForm").reset();
  }
});

$("btnPickCommunityBanner").addEventListener("click", function() {
  openBackgroundPicker("communityBannerFile");
});

$("communityBannerFile").addEventListener("change", function() {
  pickedCommunityBanner = this.files && this.files[0] || null;
  renderImagePickPreview("communityBannerPreview", pickedCommunityBanner);
});

$("btnPickCommunityBackground").addEventListener("click", function() {
  openBackgroundPicker("communityBackgroundFile");
});

$("communityBackgroundFile").addEventListener("change", function() {
  pickedCommunityBackground = this.files && this.files[0] || null;
  renderImagePickPreview("communityBackgroundPreview", pickedCommunityBackground);
});

$("createCommunityForm").addEventListener("submit", function(e) {
  e.preventDefault();
  if (!currentUser) return;
  var name = $("communityName").value.trim();
  var tag = $("communityTag").value;
  if (!tag) {
    toast(t("meet.err_pick_category"));
    return;
  }
  var desc = $("communityDesc").value.trim();
  var btn = $("createCommunitySubmit");
  btn.disabled = true;
  var slug = slugify(name);
  supabase.from("communities").insert({
    name: name,
    slug: slug,
    tag: tag,
    description: desc || null,
    circle_id: $("communityCircle").value || null,
    creator_id: currentUser.id
  }).select().single().then(function(res) {
    if (res.error) {
      toast(t("meet.err_community_create") + " " + res.error.message);
      return null;
    }
    var community = res.data;
    var flagTexts = typeof flagFieldGet === "function" ? flagFieldGet("communityCreateFlag") : [];
    if (flagTexts.length && typeof tagEntityWithFlags === "function") tagEntityWithFlags(flagTexts, "community", community.id);
    if (typeof flagFieldSet === "function") flagFieldSet("communityCreateFlag", []);
    return supabase.from("community_members").insert({
      community_id: community.id,
      user_id: currentUser.id,
      role: "admin"
    }).then(function(memberRes) {
      if (memberRes.error) toast(t("meet.err_community_admin") + " " + memberRes.error.message);
      return community;
    });
  }).then(function(community) {
    if (!community) return null;
    return Promise.all([ uploadCommunityImage(community.id, pickedCommunityBanner, "banner").catch(function() {
      return null;
    }), uploadCommunityImage(community.id, pickedCommunityBackground, "background").catch(function() {
      return null;
    }) ]).then(function(urls) {
      var patch = {};
      if (urls[0]) patch.banner_url = urls[0];
      if (urls[1]) patch.background_url = urls[1];
      if (!Object.keys(patch).length) return community;
      return supabase.from("communities").update(patch).eq("id", community.id).then(function() {
        return community;
      });
    });
  }).then(function(community) {
    btn.disabled = false;
    if (!community) return;
    $("createCommunityBackdrop").classList.remove("open");
    $("createCommunityForm").reset();
    pickedCommunityBanner = null;
    pickedCommunityBackground = null;
    $("communityBannerPreview").innerHTML = "";
    $("communityBackgroundPreview").innerHTML = "";
    toast(t("meet.toast_community_created"));
    awardAchievement(currentUser.id, "own_community");
    state.suppressPush = false;
    openCommunity(community.slug);
  }).catch(function() {
    btn.disabled = false;
    toast(t("meet.err_community_unknown"));
  });
});

$("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();
  var email = $("loginUser").value.trim();
  var pass = $("loginPass").value;
  var btn = $("loginSubmit");
  btn.disabled = true;
  btn.firstChild.textContent = "Autenticando... ";
  suppressAuthListener = true;
  function resetLoginBtn() {
    btn.disabled = false;
    btn.firstChild.textContent = "Acceder ";
    suppressAuthListener = false;
  }
  supabase.auth.signInWithPassword({
    email: email,
    password: pass
  }).then(function(res) {
    if (res.error) {
      resetLoginBtn();
      toast(t("meet.err_login") + " " + res.error.message);
      return;
    }
    return fetchProfile(res.data.user.id).then(function(profile) {
      resetLoginBtn();
      if (!profile) {
        var reason = fetchProfile.lastSelfHealError && fetchProfile.lastSelfHealError.message;
        toast("No se pudo cargar tu perfil" + (reason ? ": " + reason : ".") + " Intenta de nuevo o contacta a soporte si sigue pasando.");
        return;
      }
      currentUser = profile;
      $("loginForm").reset();
      enterForum();
      recordLoginStreak(profile.id);
      toast(t("meet.toast_welcome_back") + " " + profile.username + ".");
    });
  }).catch(function(err) {
    resetLoginBtn();
    console.error("[login] fallo inesperado al iniciar sesión:", err);
    toast("No se pudo iniciar sesión. Revisa tu conexión e intenta de nuevo.");
  });
});