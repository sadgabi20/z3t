"use strict";

/* =====================================================================
   Redes sociales del perfil (TikTok, X, Discord, Roblox, Facebook)
   - Cada usuario las pone en Configuración. Las que deja vacías no se ven.
   - Si no tiene ninguna, el apartado completo se oculta.
   - Es una tira deslizable con el dedo, SIN rotación automática.
   ===================================================================== */

var SOCIAL_NETWORKS = [ {
  id: "tiktok",
  label: "TikTok",
  hosts: [ "tiktok.com" ],
  ph: "https://www.tiktok.com/@tuusuario",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16.6 3c.3 2.3 1.7 3.9 3.9 4.1v3.1c-1.4.1-2.7-.3-3.9-1.1v6.1c0 3.1-2.2 5.6-5.4 5.6-3 0-5.4-2.4-5.4-5.4s2.4-5.4 5.4-5.4c.3 0 .6 0 .9.1v3.2a2.3 2.3 0 0 0-.9-.2 2.3 2.3 0 1 0 2.3 2.3V3h3.1Z"/></svg>'
}, {
  id: "x",
  label: "X",
  hosts: [ "x.com", "twitter.com" ],
  ph: "https://x.com/tuusuario",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.8 3h3.1l-6.8 7.7L22 21h-6.2l-4.9-6.3L5.3 21H2.2l7.2-8.3L1.9 3h6.4l4.4 5.8L17.8 3Zm-1.1 16.2h1.7L7.3 4.7H5.5l11.2 14.5Z"/></svg>'
}, {
  id: "youtube",
  label: "YouTube",
  hosts: [ "youtube.com", "youtu.be" ],
  ph: "https://www.youtube.com/@tucanal",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd"><path d="M23 7.2a3 3 0 0 0-2.1-2.1C19 4.6 12 4.6 12 4.6s-7 0-8.9.5A3 3 0 0 0 1 7.2C.5 9.1.5 12 .5 12s0 2.9.5 4.8a3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1c.5-1.9.5-4.8.5-4.8s0-2.9-.5-4.8ZM9.7 15.5v-7l6 3.5-6 3.5Z"/></svg>'
}, {
  id: "instagram",
  label: "Instagram",
  hosts: [ "instagram.com" ],
  ph: "https://www.instagram.com/tuusuario",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd"><path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7Zm5 3a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm5.5-3.5a1.1 1.1 0 1 1 0 2.2 1.1 1.1 0 0 1 0-2.2Z"/></svg>'
}, {
  id: "discord",
  label: "Discord",
  hosts: [ "discord.com", "discord.gg", "discordapp.com" ],
  ph: "https://discord.gg/tuinvitacion",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.6 5.3A16.5 16.5 0 0 0 15.5 4l-.5 1a15 15 0 0 0-4 0l-.5-1a16.5 16.5 0 0 0-4.1 1.3C3.8 9.1 3.1 12.8 3.4 16.4a16.6 16.6 0 0 0 5 2.5l1.1-1.7c-.6-.2-1.2-.5-1.7-.9l.4-.3a11.8 11.8 0 0 0 10.2 0l.4.3c-.5.4-1.100.7-1.700.9l1.100 1.700a16.600 16.600 0 0 0 5-2.500c.4-4.200-.7-7.900-3.200-11.100ZM9.400 14.200c-.9 0-1.600-.8-1.600-1.800s.7-1.800 1.600-1.800 1.600.8 1.600 1.800-.7 1.800-1.600 1.800Zm5.200 0c-.9 0-1.600-.8-1.600-1.800s.7-1.800 1.600-1.800 1.600.8 1.600 1.800-.7 1.800-1.600 1.800Z"/></svg>'
}, {
  id: "twitch",
  label: "Twitch",
  hosts: [ "twitch.tv" ],
  ph: "https://www.twitch.tv/tuusuario",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd"><path d="M4 2 2.5 6v14.5h5V23h3l2.5-2.5h4L21.5 16V2H4Zm15.5 12-3 3h-5l-2.5 2.5V17h-2.5V4h13v10ZM16 7.5h-2v5h2v-5Zm-5.5 0h-2v5h2v-5Z"/></svg>'
}, {
  id: "roblox",
  label: "Roblox",
  hosts: [ "roblox.com", "ro.blox.com" ],
  ph: "https://www.roblox.com/users/123456/profile",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m5.2 2.4 16.400 4.400-4.400 16.400L.8 18.800 5.200 2.400Zm6.100 6.800-1.100 4.200 4.200 1.100 1.100-4.200-4.200-1.100Z"/></svg>'
}, {
  id: "facebook",
  label: "Facebook",
  hosts: [ "facebook.com", "fb.com", "fb.me", "fb.watch" ],
  ph: "https://www.facebook.com/tuusuario",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 21v-7.700h2.600l.4-3h-3V8.400c0-.9.3-1.500 1.500-1.500h1.600V4.200c-.3 0-1.200-.1-2.300-.1-2.300 0-3.900 1.400-3.900 4v2.200H7.800v3h2.600V21h3.100Z"/></svg>'
}, {
  id: "telegram",
  label: "Telegram",
  hosts: [ "t.me", "telegram.me", "telegram.org" ],
  ph: "https://t.me/tuusuario",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd"><path d="M21.4 3.3 2.6 10.6c-1 .4-1 1.1-.2 1.3l4.8 1.5 1.8 5.7c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.8 3.5c.9.5 1.5.2 1.7-.8L22.9 4.8c.3-1.3-.5-1.9-1.5-1.5ZM8.7 13.2l10.2-6.4c.5-.3.9-.1.5.2l-8.3 7.5-.3 3.4-2.1-4.7Z"/></svg>'
}, {
  id: "spotify",
  label: "Spotify",
  hosts: [ "spotify.com", "spoti.fi" ],
  ph: "https://open.spotify.com/user/tuusuario",
  icon: '<svg viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd"><path d="M12 1a11 11 0 1 0 0 22 11 11 0 0 0 0-22ZM5.2 8.6C9.3 7.3 14.6 7.7 18.9 10.2l-.8 1.6C14.3 9.6 9.6 9.3 5.8 10.4L5.2 8.6Zm.9 3.7c3.4-1 7.5-.7 10.7 1.1l-.7 1.4c-2.900-1.600-6.500-1.800-9.500-1l-.5-1.500Zm1 3.500c2.600-.7 5.400-.5 7.700.8l-.6 1.300c-1.900-1.100-4.200-1.200-6.300-.6l-.8-1.500Z"/></svg>'
} ];

/* Devuelve la URL limpia si es válida para esa red; null si no */
function socialCleanUrl(net, raw) {
  var url = typeof bioNormalizeUrl === "function" ? bioNormalizeUrl(raw) : null;
  if (!url || url.indexOf("http") !== 0) return null;
  var host;
  try {
    host = new URL(url).hostname.toLowerCase().replace(/^www\./, "");
  } catch (e) {
    return null;
  }
  var ok = net.hosts.some(function(h) {
    return host === h || host.slice(-(h.length + 1)) === "." + h;
  });
  return ok ? url : null;
}

/* Saca un nombre corto para mostrar (@usuario) a partir del link */
function socialHandle(net, url) {
  try {
    var u = new URL(url);
    var parts = u.pathname.split("/").filter(Boolean);
    if (net.id === "tiktok") {
      var at = parts.filter(function(x) {
        return x.charAt(0) === "@";
      })[0];
      return at || "";
    }
    if (net.id === "youtube") {
      var yat = parts.filter(function(x) {
        return x.charAt(0) === "@";
      })[0];
      if (yat) return yat;
      if ((parts[0] === "c" || parts[0] === "user") && parts[1]) return parts[1];
      return "";
    }
    if (net.id === "instagram" || net.id === "twitch" || net.id === "telegram") {
      var f = parts[0] || "";
      if (!f || /^(p|reel|reels|tv|stories|explore|accounts|directory|videos|joinchat|s|addstickers|share)$/i.test(f) || f.charAt(0) === "+") return "";
      return "@" + f.replace(/^@/, "");
    }
    if (net.id === "x" || net.id === "facebook") {
      var first = parts[0] || "";
      if (!first || /^(profile\.php|people|pages|share|home|i|intent)$/i.test(first)) return "";
      return "@" + first.replace(/^@/, "");
    }
    return "";
  } catch (e) {
    return "";
  }
}

/* ---- Perfil: tira de redes arriba del Muro ---- */
function renderProfileSocials(p) {
  var sec = $("socialSection");
  var strip = $("socialStrip");
  if (!sec || !strip) return;
  var links = p && p.social_links && typeof p.social_links === "object" ? p.social_links : {};
  var cards = SOCIAL_NETWORKS.map(function(net) {
    var url = links[net.id] ? socialCleanUrl(net, links[net.id]) : null;
    if (!url) return "";
    var handle = socialHandle(net, url);
    return '<a class="social-card social-' + net.id + '" href="' + escapeHtml(url) + '" target="_blank" rel="noopener noreferrer nofollow ugc" aria-label="' + net.label + '">' + '<span class="social-tile">' + net.icon + "</span>" + '<span class="social-card-text"><span class="social-card-title">' + escapeHtml(handle || net.label) + "</span>" + '<span class="social-card-sub">' + (handle ? net.label : "Ver perfil") + "</span></span></a>";
  }).join("");
  strip.innerHTML = cards;
  sec.hidden = !cards;
}

/* ---- Configuración: campos para pegar los links ---- */
function socialsSettingsBuild() {
  var wrap = $("socialSettingsFields");
  if (!wrap || wrap.firstChild) return;
  wrap.innerHTML = SOCIAL_NETWORKS.map(function(net) {
    return '<label class="field social-field"><span class="social-field-label"><span class="social-chip-ico">' + net.icon + "</span>" + net.label + '</span><input type="url" id="social_' + net.id + '" maxlength="250" inputmode="url" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="' + net.ph + '"></label>';
  }).join("");
}

function socialsSettingsFill(p) {
  socialsSettingsBuild();
  var apply = function(links) {
    links = links && typeof links === "object" ? links : {};
    SOCIAL_NETWORKS.forEach(function(net) {
      var el = $("social_" + net.id);
      if (el) el.value = links[net.id] || "";
    });
  };
  if (p && p.social_links !== undefined) {
    apply(p.social_links);
    return;
  }
  apply(currentUser && currentUser.socialLinks);
  if (!currentUser) return;
  supabase.from("profiles").select("social_links").eq("id", currentUser.id).single().then(function(res) {
    if (res.error || !res.data) return;
    currentUser.socialLinks = res.data.social_links || {};
    apply(currentUser.socialLinks);
  });
}

/* Lee y valida los campos. Devuelve { links } o { error } */
function socialsSettingsGet() {
  var out = {};
  for (var i = 0; i < SOCIAL_NETWORKS.length; i++) {
    var net = SOCIAL_NETWORKS[i];
    var el = $("social_" + net.id);
    var v = el ? el.value.trim() : "";
    if (!v) continue;
    var url = socialCleanUrl(net, v);
    if (!url) return {
      error: "El link de " + net.label + " no es válido. Pega la dirección de tu perfil en " + net.label + "."
    };
    out[net.id] = url;
  }
  return {
    links: out
  };
}
