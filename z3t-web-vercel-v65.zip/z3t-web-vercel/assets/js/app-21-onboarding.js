"use strict";

var OB_MIN_FLAGS = 5;

var OB_FLAG_COLORS = [ "#a855f7", "#ff5a7c", "#ff8a4c", "#22c55e", "#38bdf8", "#facc15", "#f472b6", "#94a3b8" ];

var obDoneCallback = null;

function cssUrl(u) {
  return 'url("' + encodeURI(u).replace(/"/g, "%22").replace(/'/g, "%27") + '")';
}

function obGoStep(n) {
  for (var i = 1; i <= 5; i++) {
    var el = $("obStep" + i);
    if (el) el.hidden = i !== n;
  }
  qsa(".onboarding-dot", $("onboardingProgress")).forEach(function(dot) {
    var step = Number(dot.getAttribute("data-step"));
    dot.classList.toggle("active", step === n);
    dot.classList.toggle("done", step < n);
  });
}

function startOnboarding(doneCallback) {
  obDoneCallback = doneCallback;
  if (currentUser) {
    setAvatarEl($("obAvatarPreview"), currentUser.username, currentUser.avatarUrl);
    setAvatarEl($("obZcardPreview"), currentUser.username, currentUser.zcardAvatarUrl);
    $("obBannerPreview").style.backgroundImage = currentUser.bannerUrl ? cssUrl(currentUser.bannerUrl) : "";
  }
  renderObFlagsList();
  loadObSuggested();
  $("obFlagsError").hidden = true;
  obGoStep(1);
  showView("onboarding");
}

window.startOnboarding = startOnboarding;

function obUploadTo(field, inputId, btnId, previewFn) {
  var file = $(inputId).files && $(inputId).files[0];
  $(inputId).value = "";
  if (!file || !currentUser) return;
  if (file.type.indexOf("image/") !== 0) {
    toast("Elige un archivo de imagen.");
    return;
  }
  if (file.size > MAX_AVATAR_SIZE) {
    toast("La imagen supera 5MB.");
    return;
  }
  var btn = $(btnId);
  var originalLabel = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Subiendo...";
  stripImageMetadata(file).then(function(cleanFile) {
    var ext = cleanFile.type === "image/png" ? "png" : cleanFile.type === "image/webp" ? "webp" : "jpg";
    var path = currentUser.id + "/" + field.replace("_url", "") + "_" + Date.now() + "." + ext;
    return supabase.storage.from(AVATAR_BUCKET).upload(path, cleanFile, {
      upsert: true,
      contentType: cleanFile.type
    }).then(function(res) {
      btn.disabled = false;
      btn.textContent = originalLabel;
      if (res.error) {
        toast("No se pudo subir la foto.");
        return;
      }
      var url = supabase.storage.from(AVATAR_BUCKET).getPublicUrl(path).data.publicUrl;
      var patch = {};
      patch[field] = url;
      return supabase.from("profiles").update(patch).eq("id", currentUser.id).then(function(res2) {
        if (res2.error) {
          toast("No se pudo guardar la foto.");
          return;
        }
        previewFn(url);
        toast("Foto guardada.");
      });
    });
  });
}

$("obBtnAvatar").addEventListener("click", function() {
  $("obAvatarInput").click();
});

$("obAvatarInput").addEventListener("change", function() {
  obUploadTo("avatar_url", "obAvatarInput", "obBtnAvatar", function(url) {
    currentUser.avatarUrl = url;
    photoCache[currentUser.id] = url;
    applyPhotoToDom(currentUser.id, url);
    setAvatarEl($("obAvatarPreview"), currentUser.username, url);
  });
});

$("obStep1Next").addEventListener("click", function() {
  obGoStep(2);
});

$("obStep1Skip").addEventListener("click", function() {
  obGoStep(2);
});

$("obBtnBanner").addEventListener("click", function() {
  openBackgroundPicker("obBannerInput");
});

$("obBannerInput").addEventListener("change", function() {
  obUploadTo("banner_url", "obBannerInput", "obBtnBanner", function(url) {
    currentUser.bannerUrl = url;
    $("obBannerPreview").style.backgroundImage = cssUrl(url);
  });
});

$("obStep2Next").addEventListener("click", function() {
  obGoStep(3);
});

$("obStep2Skip").addEventListener("click", function() {
  obGoStep(3);
});

$("obBtnZcard").addEventListener("click", function() {
  $("obZcardInput").click();
});

$("obZcardInput").addEventListener("change", function() {
  obUploadTo("zcard_avatar_url", "obZcardInput", "obBtnZcard", function(url) {
    currentUser.zcardAvatarUrl = url;
    setAvatarEl($("obZcardPreview"), currentUser.username, url);
  });
});

$("obStep3Next").addEventListener("click", function() {
  obGoStep(4);
});

$("obStep3Skip").addEventListener("click", function() {
  obGoStep(4);
});

function renderObFlagsList() {
  if (!currentUser) return;
  supabase.from("profile_flags").select("*").eq("user_id", currentUser.id).order("position").then(function(res) {
    paintObFlags(res.error ? [] : res.data || []);
  });
}

function paintObFlags(rows) {
  var wrap = $("obFlagsList");
  wrap.innerHTML = rows.length ? rows.map(function(f) {
    return '<div class="flag-edit-row" data-id="' + escapeHtml(f.id) + '">' + '<input type="text" class="flag-text-input" maxlength="18" placeholder="Texto" value="' + escapeHtml(f.text || "") + '">' + '<button class="icon-btn flag-remove-btn" type="button" aria-label="Quitar bandera">✕</button>' + "</div>";
  }).join("") : '<p class="profile-empty-hint">Aún no tienes banderas. Agrega al menos ' + OB_MIN_FLAGS + ".</p>";
  var count = rows.length;
  $("obFlagsCount").textContent = count + " de " + OB_MIN_FLAGS + " como mínimo";
  $("obBtnAddFlag").disabled = count >= MAX_PROFILE_FLAGS;
  if (count >= OB_MIN_FLAGS) $("obFlagsError").hidden = true;
  qsa(".flag-edit-row", wrap).forEach(function(row) {
    var id = row.getAttribute("data-id");
    var textInput = row.querySelector(".flag-text-input");
    var saveIt = function() {
      var val = textInput.value.trim();
      if (!val) return;
      getOrCreateFlag(val, null).then(function(flag) {
        return supabase.from("profile_flags").update({
          text: val,
          color: flag && flag.color ? flag.color : flagColorFor(val)
        }).eq("id", id);
      }).then(function(res2) {
        if (res2 && res2.error) toast("No se pudo guardar la bandera.");
      });
    };
    textInput.addEventListener("change", saveIt);
    row.querySelector(".flag-remove-btn").addEventListener("click", function() {
      supabase.from("profile_flags").delete().eq("id", id).then(function(res2) {
        if (res2.error) {
          toast("No se pudo quitar la bandera.");
          return;
        }
        renderObFlagsList();
      });
    });
  });
}

$("obBtnAddFlag").addEventListener("click", function() {
  if (!currentUser) return;
  supabase.from("profile_flags").select("position").eq("user_id", currentUser.id).then(function(res) {
    var used = (res.data || []).map(function(r) {
      return r.position;
    });
    var next = -1;
    for (var i = 0; i < MAX_PROFILE_FLAGS; i++) {
      if (used.indexOf(i) === -1) {
        next = i;
        break;
      }
    }
    if (next === -1) {
      toast("Ya tienes el máximo de " + MAX_PROFILE_FLAGS + " banderas.");
      return;
    }
    var color = "#a855f7"; // provisional: al escribir el texto se le asigna el color oficial de la etiqueta
    supabase.from("profile_flags").insert({
      user_id: currentUser.id,
      text: "Nueva",
      color: color,
      position: next
    }).then(function(res2) {
      if (res2.error) {
        toast("No se pudo agregar la bandera.");
        return;
      }
      renderObFlagsList();
    });
  });
});

$("obStep4Next").addEventListener("click", function() {
  if (!currentUser) return;
  var btn = $("obStep4Next");
  btn.disabled = true;
  var timedOut = false;
  var failSafe = setTimeout(function() {
    timedOut = true;
    btn.disabled = false;
    console.error("[onboarding] obStep4Next: la consulta a profile_flags no respondió a tiempo, se deja continuar.");
    $("obFlagsError").hidden = true;
    obGoStep(5);
  }, 6e3);
  supabase.from("profile_flags").select("id").eq("user_id", currentUser.id).then(function(res) {
    if (timedOut) return;
    clearTimeout(failSafe);
    btn.disabled = false;
    if (res.error) {
      console.error("[onboarding] obStep4Next: error consultando profile_flags, se deja continuar.", res.error);
      $("obFlagsError").hidden = true;
      obGoStep(5);
      return;
    }
    var count = (res.data || []).length;
    if (count < OB_MIN_FLAGS) {
      $("obFlagsError").hidden = false;
      return;
    }
    $("obFlagsError").hidden = true;
    obGoStep(5);
  });
});

var obStep4SkipEl = $("obStep4Skip");

if (obStep4SkipEl) obStep4SkipEl.addEventListener("click", function() {
  $("obFlagsError").hidden = true;
  obGoStep(5);
});

function loadObSuggested() {
  var wrap = $("obSuggestedList");
  if (!wrap || !currentUser) return;
  wrap.innerHTML = '<p class="profile-empty-hint">Buscando gente para ti...</p>';
  supabase.from("profiles").select("id, username, name, avatar_url").neq("id", currentUser.id).limit(40).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    for (var i = rows.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = rows[i];
      rows[i] = rows[j];
      rows[j] = t;
    }
    rows = rows.slice(0, 8);
    if (!rows.length) {
      wrap.innerHTML = '<p class="profile-empty-hint">Todavía no hay más gente en la comunidad.</p>';
      return;
    }
    wrap.innerHTML = rows.map(function(u) {
      return '<div class="onboarding-suggested-row">' + avatarSpanHtml(u.name || u.username, u.avatar_url, null, u.id) + '<div class="onboarding-suggested-info">' + '<div class="onboarding-suggested-name">' + escapeHtml(u.name || u.username) + "</div>" + '<div class="onboarding-suggested-handle">@' + escapeHtml(u.username) + "</div>" + "</div>" + '<button class="terminal-btn onboarding-follow-btn" type="button" data-uid="' + escapeHtml(u.id) + '">Seguir</button>' + "</div>";
    }).join("");
    rows.forEach(function(u) {
      queueFrameLookup(u.id);
    });
    qsa(".onboarding-follow-btn", wrap).forEach(function(btn) {
      btn.addEventListener("click", function() {
        var uid = this.getAttribute("data-uid");
        var isFollowing = this.classList.contains("following");
        var thisBtn = this;
        thisBtn.disabled = true;
        var action = isFollowing ? supabase.from("follows").delete().eq("follower_id", currentUser.id).eq("following_id", uid) : supabase.from("follows").insert({
          follower_id: currentUser.id,
          following_id: uid
        });
        action.then(function(res2) {
          thisBtn.disabled = false;
          if (res2.error) {
            toast("No se pudo actualizar.");
            return;
          }
          thisBtn.classList.toggle("following", !isFollowing);
          thisBtn.textContent = !isFollowing ? "Siguiendo" : "Seguir";
        });
      });
    });
  });
}

$("obStep5Next").addEventListener("click", function() {
  var cb = obDoneCallback;
  obDoneCallback = null;
  if (typeof cb === "function") cb();
});