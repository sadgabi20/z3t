/* Z3T · interfaz del tema Personalizado */
(function () {
  "use strict";
  var C = window.Z3TCustom;
  if (!C) return;
  var $ = function (id) { return document.getElementById(id); };
  var st = C.load();

  var PRESETS = [
    { id: "violeta", n: "Violeta", a: "#a855f7", t: "#f1ecfa", s: "#0a0713" },
    { id: "dorado", n: "Dorado", a: "#d4a537", t: "#f5e9c8", s: "#0d0904" },
    { id: "oscuro", n: "Oscuro", a: "#9ca3af", t: "#e5e7eb", s: "#050505" },
    { id: "neon", n: "Neón cian", a: "#22f0ff", t: "#e6fdff", s: "#03090f" },
    { id: "lima", n: "Neón verde", a: "#39ff88", t: "#e8fff2", s: "#030a06" },
    { id: "sangre", n: "Sangre", a: "#e11d48", t: "#fde8ec", s: "#0f0306" },
    { id: "rosa", n: "Rosa", a: "#ff5c96", t: "#f5e9ef", s: "#170610" },
    { id: "esmeralda", n: "Esmeralda", a: "#10b981", t: "#e6fbf3", s: "#03100b" },
    { id: "hielo", n: "Hielo", a: "#7dd3fc", t: "#eef9ff", s: "#06101a" },
    { id: "ambar", n: "Ámbar", a: "#f97316", t: "#fff1e6", s: "#120801" }
  ];
  var role = "accent";
  var hsv = { h: 270, s: .66, v: .97 };

  function persist() {
    if (!C.save(st)) toast("No hay espacio para guardar la imagen. Prueba con una más ligera.");
  }
  function toast(m) { if (typeof window.toast === "function") window.toast(m); }
  function commit() { st.enabled = true; persist(); C.apply(st); refreshUI(); }

  /* ---- conversión HSV <-> hex ---- */
  function hsvToHex(h, s, v) {
    var l = v * (1 - s / 2), sl = (l === 0 || l === 1) ? 0 : (v - l) / Math.min(l, 1 - l);
    return C.toHex(C.hslToRgb(h, sl * 100, l * 100));
  }
  function hexToHsv(hex) {
    var rgb = C.hexToRgb(hex), hl = C.rgbToHsl(rgb[0], rgb[1], rgb[2]);
    var s = hl[1] / 100, l = hl[2] / 100, v = l + s * Math.min(l, 1 - l);
    return { h: hl[0], s: v === 0 ? 0 : 2 * (1 - l / v), v: v };
  }
  function roleKey() { return role === "accent" ? "accent" : role; }

  /* ---- selector de color ---- */
  function syncPicker() {
    var hex = st[roleKey()];
    hsv = hexToHsv(hex);
    paintPicker(hex);
  }
  function paintPicker(hex) {
    var sv = $("tcSV");
    sv.style.background = "linear-gradient(to top,#000,transparent),linear-gradient(to right,#fff,hsl(" + Math.round(hsv.h) + ",100%,50%))";
    $("tcSVThumb").style.left = (hsv.s * 100) + "%";
    $("tcSVThumb").style.top = ((1 - hsv.v) * 100) + "%";
    $("tcSVThumb").style.background = hex;
    $("tcHueThumb").style.left = (hsv.h / 360 * 100) + "%";
    $("tcHueThumb").style.background = "hsl(" + Math.round(hsv.h) + ",100%,50%)";
    $("tcHexSwatch").style.background = hex;
    if (document.activeElement !== $("tcHex")) $("tcHex").value = hex;
  }
  function setFromHsv() {
    var hex = hsvToHex(hsv.h, hsv.s, hsv.v);
    st[roleKey()] = hex; st.preset = "custom";
    paintPicker(hex); commit();
  }
  function drag(el, cb) {
    function mv(e) {
      var r = el.getBoundingClientRect();
      cb(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)), Math.max(0, Math.min(1, (e.clientY - r.top) / r.height)));
    }
    el.addEventListener("pointerdown", function (e) {
      e.preventDefault(); el.setPointerCapture(e.pointerId); mv(e);
      var move = function (ev) { mv(ev); };
      var up = function () { el.removeEventListener("pointermove", move); el.removeEventListener("pointerup", up); };
      el.addEventListener("pointermove", move); el.addEventListener("pointerup", up);
    });
  }

  /* ---- imágenes ---- */
  function resize(file, max, type, q) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        var k = Math.min(1, max / Math.max(img.width, img.height));
        var cv = document.createElement("canvas");
        cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
        cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
        URL.revokeObjectURL(url);
        res(cv.toDataURL(type, q));
      };
      img.onerror = function () { URL.revokeObjectURL(url); rej(); };
      img.src = url;
    });
  }

  /* ---- construcción de UI ---- */
  function buildPresets() {
    $("tcPresets").innerHTML = PRESETS.map(function (p) {
      return '<button type="button" class="tc-preset" data-id="' + p.id + '" style="--pa:' + p.a + ';--ps:' + p.s + '"><span class="tc-preset-dot"></span><small>' + p.n + "</small></button>";
    }).join("");
    Array.prototype.forEach.call($("tcPresets").querySelectorAll(".tc-preset"), function (b) {
      b.addEventListener("click", function () {
        var p = PRESETS.filter(function (x) { return x.id === b.dataset.id; })[0];
        st.accent = p.a; st.text = p.t; st.surface = p.s; st.preset = p.id;
        commit(); syncPicker();
      });
    });
  }
  function buildFonts() {
    ["Head", "Body"].forEach(function (k) {
      var key = "font" + k, box = $("tcFonts" + k);
      box.innerHTML = Object.keys(C.FONTS).map(function (id) {
        var f = C.FONTS[id];
        return '<button type="button" class="tc-font" data-id="' + id + '" style="font-family:' + (f.stack || "inherit") + '">' + f.label + "</button>";
      }).join("");
      Array.prototype.forEach.call(box.querySelectorAll(".tc-font"), function (b) {
        b.addEventListener("click", function () { st[key] = b.dataset.id; commit(); });
      });
    });
  }
  function previewFonts() { Object.keys(C.FONTS).forEach(function (id) { if (C.FONTS[id].css) { var l = document.getElementById("z3t-font-" + id); if (!l) { l = document.createElement("link"); l.id = "z3t-font-" + id; l.rel = "stylesheet"; l.href = "https://fonts.googleapis.com/css2?family=" + C.FONTS[id].css + "&display=swap"; document.head.appendChild(l); } } }); }

  function refreshUI() {
    var card = $("themeCustomCard"); if (card) card.classList.toggle("active", !!st.enabled);
    Array.prototype.forEach.call(document.querySelectorAll(".tc-preset"), function (b) { b.classList.toggle("active", b.dataset.id === st.preset); });
    Array.prototype.forEach.call(document.querySelectorAll("#tcFontsHead .tc-font"), function (b) { b.classList.toggle("active", b.dataset.id === st.fontHead); });
    Array.prototype.forEach.call(document.querySelectorAll("#tcFontsBody .tc-font"), function (b) { b.classList.toggle("active", b.dataset.id === st.fontBody); });
    Array.prototype.forEach.call(document.querySelectorAll(".tc-role"), function (b) {
      b.classList.toggle("active", b.dataset.role === role);
      b.firstChild.style.background = st[b.dataset.role];
    });
    $("tcDim").value = st.dim; $("tcDimVal").textContent = st.dim + "%";
    $("tcLogoThumb").src = st.logo || "assets/planet/planet-z-logo.png";
    $("tcPvLogo").src = st.logo || "assets/logo-64.png";
    $("tcClearBg").hidden = !st.bg; $("tcClearLogo").hidden = !st.logo;
    $("tcPreview").style.backgroundImage = st.bg ? 'url("' + st.bg + '")' : "";
    $("tcPreview").style.setProperty("--pv-dim", st.dim / 100);
  }

  function open() {
    st = C.load();
    if (!st.enabled) { st.enabled = true; persist(); try { localStorage.setItem("app_theme", "default"); } catch (e) {} document.body.classList.remove("theme-pinky", "theme-golden"); C.apply(st); }
    previewFonts(); syncPicker(); refreshUI();
    if (typeof activatePanel === "function") activatePanel("panel-theme-custom");
  }
  function disable() {
    st = C.load(); if (!st.enabled) return;
    st.enabled = false; C.save(st); C.apply(st); C.applyLogo(st); refreshUI();
  }
  window.Z3TTheme = { disable: disable, open: open, reload: function () { st = C.load(); if ($("tcDim")) refreshUI(); } };

  function init() {
    if (!$("panel-theme-custom")) return;
    buildPresets(); buildFonts();
    $("themeCustomCard").addEventListener("click", open);
    $("btnThemeCustomBack").addEventListener("click", function () { if (typeof goBack === "function") goBack("panel-themes"); });
    $("tcReset").addEventListener("click", function () {
      var keep = C.load(); keep = Object.assign({}, C.DEF); C.save(keep); st = keep; C.apply(st); C.applyLogo(st);
      try { localStorage.setItem("app_theme", "default"); } catch (e) {}
      if (typeof applyTheme === "function") applyTheme("default");
      refreshUI(); toast("Tema original restaurado.");
      if (typeof goBack === "function") goBack("panel-themes");
    });
    Array.prototype.forEach.call(document.querySelectorAll(".tc-role"), function (b) {
      b.addEventListener("click", function () { role = b.dataset.role; syncPicker(); refreshUI(); });
    });
    drag($("tcSV"), function (x, y) { hsv.s = x; hsv.v = 1 - y; setFromHsv(); });
    drag($("tcHue"), function (x) { hsv.h = x * 359.9; setFromHsv(); });
    $("tcHex").addEventListener("input", function () {
      var v = this.value.trim(); if (v[0] !== "#") v = "#" + v;
      if (/^#[0-9a-fA-F]{6}$/.test(v)) { st[roleKey()] = v.toLowerCase(); st.preset = "custom"; hsv = hexToHsv(v); paintPicker(v.toLowerCase()); commit(); }
    });
    $("tcDim").addEventListener("input", function () { st.dim = parseInt(this.value, 10) || 0; commit(); });
    $("tcPickBg").addEventListener("click", function () { $("tcBgFile").click(); });
    $("tcPickLogo").addEventListener("click", function () { $("tcLogoFile").click(); });
    $("tcClearBg").addEventListener("click", function () { st.bg = null; commit(); });
    $("tcClearLogo").addEventListener("click", function () { st.logo = null; commit(); C.applyLogo(st); });
    $("tcBgFile").addEventListener("change", function () {
      var f = this.files[0]; this.value = ""; if (!f) return;
      resize(f, 1600, "image/jpeg", .82).then(function (d) { st.bg = d; commit(); }, function () { toast("No se pudo leer esa imagen."); });
    });
    $("tcLogoFile").addEventListener("change", function () {
      var f = this.files[0]; this.value = ""; if (!f) return;
      resize(f, 384, "image/png").then(function (d) { st.logo = d; commit(); C.applyLogo(st); }, function () { toast("No se pudo leer esa imagen."); });
    });
    st = C.load(); refreshUI(); C.applyLogo(st);
    // el logo del planeta se reasigna semanalmente en core: lo reaplicamos
    setTimeout(function () { C.applyLogo(C.load()); }, 800);
    if (!document.body.getAttribute("data-panel")) document.body.setAttribute("data-panel", "panel-list");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
