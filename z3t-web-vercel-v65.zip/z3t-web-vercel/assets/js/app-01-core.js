"use strict";

if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {
  document.documentElement.classList.add("native-app");
}

var SUPABASE_URL = "https://pqbpeccvzycdspmfsgab.supabase.co";

var SUPABASE_PUBLISHABLE_KEY = "sb_publishable_kFQRBOv-qOxy5x_B9z3Jpw_dr7YsSpt";

/* ---- Recuperación de contraseña ----
   supabase-js BORRA el #hash del enlace en cuanto lo lee, así que hay que detectar
   "type=recovery" aquí, ANTES de crear el cliente, y recordarlo en sessionStorage.
   Mientras esté activo, la app NO entra al foro: solo muestra "Elige tu nueva contraseña". */
var Z3T_RECOVERY_KEY = "z3t_pw_recovery";

function z3tIsRecoveryMode() {
  try { return sessionStorage.getItem(Z3T_RECOVERY_KEY) === "1"; } catch (e) { return false; }
}

function z3tSetRecoveryMode(on) {
  try {
    if (on) sessionStorage.setItem(Z3T_RECOVERY_KEY, "1");
    else sessionStorage.removeItem(Z3T_RECOVERY_KEY);
  } catch (e) {}
}

var z3tRecoveryLinkExpired = false;

(function detectRecoveryLink() {
  var raw = (window.location.hash || "") + "&" + (window.location.search || "");
  if (/(^|[#?&])type=recovery(&|$)/.test(raw)) {
    z3tSetRecoveryMode(true);
  } else if (/error_code=otp_expired/.test(raw)) {
    z3tRecoveryLinkExpired = true;
    try { history.replaceState(null, "", window.location.pathname); } catch (e) {}
  }
})();

var supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: window.localStorage
  },
  realtime: {
    params: {
      eventsPerSecond: 5
    }
  }
});

var SITE_URL = "https://z3t.fun";

function siteOrigin() {
  var isNative = window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
  var isLocalhostOrigin = /^(https?:\/\/)?localhost(:\d+)?$/i.test(window.location.origin);
  return isNative || isLocalhostOrigin ? SITE_URL : window.location.origin;
}

(function reportOAuthRedirectError() {
  var qs = new URLSearchParams(window.location.search);
  var hs = new URLSearchParams(window.location.hash.replace(/^#/, ""));
  var err = qs.get("error") || hs.get("error");
  if (!err) return;
  var desc = qs.get("error_description") || hs.get("error_description") || err;
  try {
    desc = decodeURIComponent(desc.replace(/\+/g, " "));
  } catch (e) {}
  console.error("[OAuth redirect] el proveedor devolvió un error al volver:", err, desc);
  history.replaceState(null, "", window.location.pathname);
  setTimeout(function() {
    toast("No se pudo iniciar sesión con Google/GitHub: " + desc);
  }, 0);
})();

var currentUser = null;

var suppressAuthListener = false;

window.addEventListener("unhandledrejection", function(e) {
  console.error("[unhandledrejection]", e.reason);
});

(function setupRealViewportHeight() {
  var root = document.documentElement;
  function apply() {
    var h = window.visualViewport && window.visualViewport.height || window.innerHeight;
    root.style.setProperty("--vh", h * .01 + "px");
    root.style.setProperty("--app-height", h + "px");
  }
  apply();
  if (window.visualViewport) {
    window.visualViewport.addEventListener("resize", apply);
    window.visualViewport.addEventListener("scroll", apply);
  } else {
    window.addEventListener("resize", apply);
  }
  window.addEventListener("orientationchange", function() {
    setTimeout(apply, 120);
  });
})();

function $(id) {
  return document.getElementById(id);
}

function qs(sel, ctx) {
  return (ctx || document).querySelector(sel);
}

function qsa(sel, ctx) {
  return Array.prototype.slice.call((ctx || document).querySelectorAll(sel));
}

var WEEKLY_PLANET_LOGOS = [ "assets/planet/planet-z-logo.png" ];

function isoWeekNumber(d) {
  var date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay() || 7));
  var yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil(((date - yearStart) / 864e5 + 1) / 7);
}

function applyWeeklyPlanetLogo() {
  var img = $("planetLogoImg");
  if (!img || !WEEKLY_PLANET_LOGOS.length) return;
  var week = isoWeekNumber(new Date);
  img.src = WEEKLY_PLANET_LOGOS[week % WEEKLY_PLANET_LOGOS.length];
}

applyWeeklyPlanetLogo();

(function initHomeStarField() {
  var field = $("homeStarField");
  if (!field) return;
  var STAR_COUNT = 46;
  var html = "";
  for (var i = 0; i < STAR_COUNT; i++) {
    var top = (Math.random() * 100).toFixed(2);
    var left = (Math.random() * 100).toFixed(2);
    var size = (Math.random() * 2 + 1).toFixed(2);
    var dur = (Math.random() * 4 + 3).toFixed(2);
    var delay = (Math.random() * 5).toFixed(2);
    var drift = (Math.random() * 30 - 15).toFixed(1);
    html += '<span class="home-star" style="top:' + top + "%; left:" + left + "%; width:" + size + "px; height:" + size + "px; --dur:" + dur + "s; --delay:" + delay + "s; --drift:" + drift + 'px;"></span>';
  }
  field.innerHTML = html;
})();

function timeAgo(iso) {
  var diff = (Date.now() - new Date(iso).getTime()) / 1e3;
  if (diff < 60) return "hace instantes";
  if (diff < 3600) return "hace " + Math.floor(diff / 60) + " min";
  if (diff < 86400) return "hace " + Math.floor(diff / 3600) + " h";
  return "hace " + Math.floor(diff / 86400) + " d";
}

function initials(name) {
  return (name || "?").trim().slice(0, 2).toUpperCase();
}

var HANDLE_MIN_LEN = 3;

var HANDLE_MAX_LEN = 16;

var HANDLE_PATTERN = /^[a-zA-Z0-9_]{3,16}$/;

function isValidHandle(v) {
  return typeof v === "string" && HANDLE_PATTERN.test(v);
}

function slugifyToHandle(name) {
  var base = (name || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9_]/g, "");
  if (base.length < HANDLE_MIN_LEN) base = (base + "usuario").slice(0, HANDLE_MIN_LEN + 3);
  base = base.slice(0, HANDLE_MAX_LEN);
  return base;
}

function generateAvailableHandle(name, excludeUserId) {
  var base = slugifyToHandle(name);
  function tryHandle(candidate, attempt) {
    return isHandleAvailable(candidate, excludeUserId).then(function(available) {
      if (available) return candidate;
      if (attempt > 6) {
        return "op_" + Math.random().toString(36).slice(2, 12);
      }
      var suffix = String(Math.floor(Math.random() * 1e4));
      var trimmed = base.slice(0, HANDLE_MAX_LEN - suffix.length);
      return tryHandle(trimmed + suffix, attempt + 1);
    });
  }
  return tryHandle(base, 0);
}

window.slugifyToHandle = slugifyToHandle;

window.generateAvailableHandle = generateAvailableHandle;

function isHandleAvailable(val, excludeUserId) {
  return supabase.rpc("is_handle_available", {
    p_handle: val,
    p_exclude: excludeUserId || null
  }).then(function(res) {
    if (!res.error && typeof res.data === "boolean") return res.data;
    return supabase.from("profiles").select("id").ilike("username", val).limit(5).then(function(res2) {
      if (res2.error) throw res2.error;
      var rows = res2.data || [];
      if (excludeUserId) rows = rows.filter(function(r) {
        return r.id !== excludeUserId;
      });
      return rows.length === 0;
    });
  });
}

var AVATAR_COLORS = [ "#7e22ce", "#5b21b6", "#9333ea", "#4c1d95", "#6d28d9" ];

function avatarColor(name) {
  var h = 0;
  for (var i = 0; i < (name || "").length; i++) {
    h = (h * 31 + name.charCodeAt(i)) % 997;
  }
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

function hexToRgba(hex, alpha) {
  hex = (hex || "").replace("#", "");
  if (hex.length === 3) hex = hex.split("").map(function(c) {
    return c + c;
  }).join("");
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) hex = "a855f7";
  var r = parseInt(hex.substr(0, 2), 16);
  var g = parseInt(hex.substr(2, 2), 16);
  var b = parseInt(hex.substr(4, 2), 16);
  return "rgba(" + r + "," + g + "," + b + "," + (alpha == null ? 1 : alpha) + ")";
}

var AVATAR_LOAD_RETRY_DELAYS = [ 800, 2000, 4000 ];

function setAvatarEl(el, name, avatarUrl) {
  if (!el) return;
  el.style.backgroundImage = "none";
  el.style.backgroundColor = avatarColor(name);
  el.textContent = initials(name);
  if (!avatarUrl) return;
  var attempt = 0;
  function tryLoad() {
    var probe = new Image;
    probe.onload = function() {
      if (!el.isConnected) return;
      el.style.backgroundImage = "url('" + avatarUrl + "')";
      el.style.backgroundSize = "cover";
      el.style.backgroundPosition = "center";
      el.style.backgroundColor = "transparent";
      el.textContent = "";
    };
    probe.onerror = function() {
      if (!el.isConnected) return;
      if (attempt >= AVATAR_LOAD_RETRY_DELAYS.length) return;
      var delay = AVATAR_LOAD_RETRY_DELAYS[attempt];
      attempt++;
      setTimeout(tryLoad, delay);
    };
    probe.src = attempt === 0 ? avatarUrl : avatarUrl + (avatarUrl.indexOf("?") === -1 ? "?retry=" : "&retry=") + attempt;
  }
  tryLoad();
}

var frameCache = {};

var framePendingUids = {};

var frameBatchTimer = null;

var photoCache = {};

var photoOkCache = {};

var bannedCache = {};

var BANNED_AVATAR_URL = "assets/status/banned-avatar.webp";

function markBannedUser(uid, flag) {
  if (!uid) return;
  bannedCache[uid] = flag === true;
  if (flag !== true && photoCache[uid] === BANNED_AVATAR_URL) delete photoCache[uid];
  if (flag === true) {
    photoOkCache[uid] = true;
    frameCache[uid] = null;
    applyFrameToDom(uid, null);
    applyPhotoToDom(uid, BANNED_AVATAR_URL);
  }
}

function queueFrameLookup(uid) {
  if (!uid) return;
  if (frameCache.hasOwnProperty(uid)) applyFrameToDom(uid, frameCache[uid]);
  if (photoCache.hasOwnProperty(uid)) applyPhotoToDom(uid, photoCache[uid]);
  if (frameCache.hasOwnProperty(uid) && photoCache.hasOwnProperty(uid) || framePendingUids[uid]) return;
  framePendingUids[uid] = true;
  if (frameBatchTimer) clearTimeout(frameBatchTimer);
  frameBatchTimer = setTimeout(flushFrameLookups, 120);
}

function flushFrameLookups() {
  frameBatchTimer = null;
  var uids = Object.keys(framePendingUids);
  framePendingUids = {};
  if (!uids.length || typeof supabase === "undefined") return;
  Promise.all([ supabase.from("user_frames").select("user_id, frames(frame_png_url)").eq("equipped", true).in("user_id", uids), supabase.from("profiles").select("id, avatar_url, banned").in("id", uids) ]).then(function(results) {
    var frameRes = results[0], photoRes = results[1];
    var foundFrames = {};
    (frameRes.data || []).forEach(function(row) {
      foundFrames[row.user_id] = row.frames && row.frames.frame_png_url ? row.frames.frame_png_url : null;
    });
    var foundPhotos = {};
    (photoRes.data || []).forEach(function(row) {
      if (row.banned === true) bannedCache[row.id] = true;
      else if (bannedCache[row.id]) bannedCache[row.id] = false;
      foundPhotos[row.id] = row.banned === true ? BANNED_AVATAR_URL : row.avatar_url || null;
      if (row.banned === true) foundFrames[row.id] = null;
    });
    uids.forEach(function(uid) {
      frameCache[uid] = foundFrames.hasOwnProperty(uid) ? foundFrames[uid] : null;
      photoCache[uid] = foundPhotos.hasOwnProperty(uid) ? foundPhotos[uid] : null;
      applyFrameToDom(uid, frameCache[uid]);
      applyPhotoToDom(uid, photoCache[uid]);
    });
  }).catch(function() {
    uids.forEach(function(uid) {
      frameCache[uid] = null;
      photoCache[uid] = null;
    });
  });
}

function frameUrlAttrString(url) {
  return ' data-frame-url="1" style="--avatar-frame-img:url(&quot;' + encodeURI(url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"';
}

function applyFrameToDom(uid, frameUrl) {
  var sel = '.avatar[data-uid="' + (window.CSS && CSS.escape ? CSS.escape(uid) : uid) + '"]';
  qsa(sel, document).forEach(function(el) {
    if (frameUrl) {
      el.setAttribute("data-frame-url", "1");
      el.style.setProperty("--avatar-frame-img", 'url("' + encodeURI(frameUrl).replace(/"/g, "%22").replace(/'/g, "%27") + '")');
    } else {
      el.removeAttribute("data-frame-url");
      el.style.removeProperty("--avatar-frame-img");
    }
  });
}

function looksLikeImageUrl(u) {
  return !!u && (/^(https?:)?\/\//i.test(u) || u.indexOf("assets/status/") === 0);
}

function applyPhotoToDom(uid, avatarUrl) {
  if (!looksLikeImageUrl(avatarUrl)) {
    photoOkCache[uid] = false;
    return;
  }
  var sel = '.avatar[data-uid="' + (window.CSS && CSS.escape ? CSS.escape(uid) : uid) + '"]:not([data-zcard-photo])';
  var safeUrl = 'url("' + encodeURI(avatarUrl).replace(/"/g, "%22").replace(/'/g, "%27") + '")';
  var probe = new Image;
  probe.onload = function() {
    photoOkCache[uid] = true;
    qsa(sel, document).forEach(function(el) {
      if (el.style.backgroundImage === safeUrl && el.style.backgroundColor === "transparent") return;
      el.style.backgroundImage = safeUrl;
      el.style.backgroundSize = "cover";
      el.style.backgroundPosition = "center";
      el.style.backgroundColor = "transparent";
      el.textContent = "";
    });
  };
  probe.onerror = function() {
    photoOkCache[uid] = false;
  };
  probe.src = avatarUrl;
}

function avatarSpanHtml(name, avatarUrl, extraClass, uid) {
  var cls = "avatar" + (extraClass ? " " + extraClass : "") + (uid ? " avatar-link" : "");
  var uidAttr = uid ? ' data-uid="' + escapeHtml(uid) + '"' : "";
  var frameAttr = "";
  if (uid) {
    if (frameCache.hasOwnProperty(uid)) {
      if (frameCache[uid]) frameAttr = frameUrlAttrString(frameCache[uid]);
    }
    queueFrameLookup(uid);
    if (!looksLikeImageUrl(avatarUrl) && photoCache.hasOwnProperty(uid) && photoCache[uid]) {
      avatarUrl = photoCache[uid];
    }
    if (photoOkCache[uid] === false) avatarUrl = null;
    if (bannedCache[uid] === true) {
      avatarUrl = BANNED_AVATAR_URL;
      frameAttr = "";
      photoOkCache[uid] = true;
    }
  }
  var paintPhoto = looksLikeImageUrl(avatarUrl) && (!uid || photoOkCache[uid] === true);
  if (paintPhoto) {
    return '<span class="' + cls + '"' + uidAttr + frameAttr + ' style="background-image:url(&quot;' + encodeURI(avatarUrl).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;);background-size:cover;background-position:center;"></span>';
  }
  return '<span class="' + cls + '"' + uidAttr + frameAttr + ' style="background:' + avatarColor(name) + '">' + escapeHtml(initials(name)) + "</span>";
}

var bubbleCache = {};

var bubblePendingUids = {};

var bubbleBatchTimer = null;

function queueBubbleLookup(uid) {
  if (!uid) return;
  if (bubbleCache.hasOwnProperty(uid)) {
    applyBubbleToDom(uid, bubbleCache[uid]);
    return;
  }
  if (bubblePendingUids[uid]) return;
  bubblePendingUids[uid] = true;
  if (bubbleBatchTimer) clearTimeout(bubbleBatchTimer);
  bubbleBatchTimer = setTimeout(flushBubbleLookups, 120);
}

function flushBubbleLookups() {
  bubbleBatchTimer = null;
  var uids = Object.keys(bubblePendingUids);
  bubblePendingUids = {};
  if (!uids.length || typeof supabase === "undefined") return;
  supabase.from("user_chat_bubbles").select("user_id, chat_bubbles(bubble_png_url)").eq("equipped", true).in("user_id", uids).then(function(res) {
    var found = {};
    (res.data || []).forEach(function(row) {
      found[row.user_id] = row.chat_bubbles && row.chat_bubbles.bubble_png_url ? row.chat_bubbles.bubble_png_url : null;
    });
    uids.forEach(function(uid) {
      bubbleCache[uid] = found.hasOwnProperty(uid) ? found[uid] : null;
      applyBubbleToDom(uid, bubbleCache[uid]);
    });
  }).catch(function() {
    uids.forEach(function(uid) {
      bubbleCache[uid] = null;
    });
  });
}

function bubbleUrlAttrString(url) {
  return ' data-bubble-url="1" style="--chat-bubble-img:url(&quot;' + encodeURI(url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"';
}

function applyBubbleToDom(uid, bubbleUrl) {
  var sel = '.chat-msg-body[data-uid="' + (window.CSS && CSS.escape ? CSS.escape(uid) : uid) + '"]';
  qsa(sel, document).forEach(function(el) {
    if (bubbleUrl) {
      el.setAttribute("data-bubble-url", "1");
      el.style.setProperty("--chat-bubble-img", 'url("' + encodeURI(bubbleUrl).replace(/"/g, "%22").replace(/'/g, "%27") + '")');
    } else {
      el.removeAttribute("data-bubble-url");
      el.style.removeProperty("--chat-bubble-img");
    }
  });
}

function chatMsgBodyOpenTag(uid, rpColor) {
  var uidAttr = uid ? ' data-uid="' + escapeHtml(uid) + '"' : "";
  var bubbleAttr = "";
  if (uid) {
    if (bubbleCache.hasOwnProperty(uid)) {
      if (bubbleCache[uid]) bubbleAttr = bubbleUrlAttrString(bubbleCache[uid]);
    } else {
      queueBubbleLookup(uid);
    }
  }
  /* Mensajes de personaje (roleplay): burbuja del color del personaje.
     Si el usuario tiene una burbuja equipada (data-bubble-url) esa manda sobre el color. */
  var rpAttr = "";
  if (rpColor && /^#[0-9a-f]{6}$/i.test(rpColor)) {
    var vars = "--rp-color:" + rpColor + ";--rp-color-soft:" + hexToRgba(rpColor, .22) + ";";
    if (bubbleAttr.indexOf(' style="') !== -1) {
      bubbleAttr = bubbleAttr.replace(' style="', ' style="' + vars);
    } else {
      rpAttr = ' style="' + vars + '"';
    }
    rpAttr += ' data-rp-color="1"';
  }
  return '<div class="chat-msg-body"' + uidAttr + bubbleAttr + rpAttr + ">";
}

/* Marco de color alrededor del avatar de un personaje (roleplay) */
function rpTintAvatar(html, color) {
  if (!color || !/^#[0-9a-f]{6}$/i.test(color) || typeof html !== "string") return html;
  return html.replace('class="avatar', 'class="avatar rp-ring').replace(' style="', ' style="--rp-color:' + color + ";");
}

function roleBadgeHtml(role, verified) {
  var html = "";
  if (role === "admin") html += '<span class="role-badge role-badge-admin" title="Cuenta admin">⚙</span>';
  if (verified) html += '<img loading=lazy decoding=async class="role-badge role-badge-verified" src="assets/badge-verified.png" alt="Verificado" title="Cuenta verificada">';
  return html;
}

function volunteerBadgeHtml(isVolunteer) {
  if (!isVolunteer) return "";
  return '<img loading=lazy decoding=async class="profile-volunteer-badge" src="assets/badges/badge-volunteer.webp" alt="Volunteer" title="Volunteer">';
}

function coinIconHtml(type) {
  return type === "coin" ? '<img loading=lazy decoding=async class="coin-icon" src="assets/currency/coin-zcoin.png" alt="Z-Coins">' : '<img loading=lazy decoding=async class="coin-icon" src="assets/currency/coin-diamante.png" alt="Diamantes">';
}

var TOAST_PIPS = {
  success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
  error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round"><path d="M12 6v8M12 18.2v.1"/></svg>'
};

function toast(msg) {
  var text = String(msg == null ? "" : msg);
  var kind = "info", title = "", body = text;
  var m = text.match(/^🏆\s*Logro desbloqueado:\s*([\s\S]*)$/);
  if (m) {
    kind = "achievement";
    title = "Logro desbloqueado";
    body = m[1];
  } else if (/^(No se pudo|No se pudieron|Error|Falló|Fallo|Inválid|Credenciales|Contraseña incorrecta|Tu sesión expiró|No puedes|No tienes)/i.test(text)) {
    kind = "error";
  } else if (/^(Bienvenid|Listo|¡Listo|Guardad|Enviad|Copiad|Cuenta verificada|Publicad|Actualizad|Cread|Eliminad|Reclamad)/i.test(text)) {
    kind = "success";
  }
  var el = document.createElement("div");
  el.className = "toast toast--" + kind;
  el.setAttribute("role", kind === "error" ? "alert" : "status");
  var dur = kind === "achievement" ? 4600 : 3600;
  el.style.setProperty("--dur", dur + "ms");
  var ico = document.createElement("span");
  ico.className = "toast-ico";
  ico.innerHTML = '<span class="toast-mask ' + (kind === "achievement" ? "toast-mask--hex" : "toast-mask--logo") + '"></span>' + (TOAST_PIPS[kind] ? '<span class="toast-pip">' + TOAST_PIPS[kind] + "</span>" : "");
  var box = document.createElement("div");
  box.className = "toast-txt";
  if (title) {
    var t = document.createElement("b");
    t.className = "toast-title";
    t.textContent = title;
    box.appendChild(t);
  }
  var b = document.createElement("span");
  b.className = "toast-body";
  body.split("🪙").forEach(function(part, i) {
    if (i > 0) {
      var coin = document.createElement("img");
      coin.className = "coin-icon";
      coin.src = "assets/icons/coin-z.png";
      coin.alt = "Coin";
      b.appendChild(coin);
    }
    b.appendChild(document.createTextNode(part));
  });
  box.appendChild(b);
  var bar = document.createElement("i");
  bar.className = "toast-bar";
  el.appendChild(ico);
  el.appendChild(box);
  el.appendChild(bar);
  $("toastContainer").appendChild(el);
  var closed = false;
  function close() {
    if (closed) return;
    closed = true;
    el.classList.add("toast-out");
    setTimeout(function() {
      el.remove();
    }, 300);
  }
  el.addEventListener("click", close);
  setTimeout(close, dur);
}

function showAppAlert(opts) {
  opts = opts || {};
  $("appAlertTitle").textContent = opts.title || "";
  $("appAlertTitle").hidden = !opts.title;
  $("appAlertMessage").textContent = opts.message || "";
  $("appAlertMessage").hidden = !opts.message;
  var buttons = opts.buttons && opts.buttons.length ? opts.buttons : [ {
    label: "Entendido",
    style: "primary"
  } ];
  var wrap = $("appAlertButtons");
  wrap.innerHTML = "";
  buttons.forEach(function(b) {
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "app-alert-btn" + (b.style ? " app-alert-" + b.style : "");
    btn.textContent = b.label;
    btn.addEventListener("click", function() {
      $("appAlertBackdrop").classList.remove("open");
      if (typeof b.onClick === "function") b.onClick();
    });
    wrap.appendChild(btn);
  });
  $("appAlertBackdrop").classList.add("open");
}

window.showAppAlert = showAppAlert;

function showErrorAlert(detail) {
  showAppAlert({
    title: "Ocurrió un error",
    message: "Comunícate con soporte para que se corrija en la próxima actualización." + (detail ? " Detalle: " + detail : ""),
    buttons: [ {
      label: "Entendido",
      style: "primary"
    } ]
  });
}

window.showErrorAlert = showErrorAlert;

$("appAlertBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

var THEME_FAVICON = {
  default: null,
  pinky: "assets/themes/pinky/favicon-32.png",
  golden: "assets/themes/golden/favicon-32.png"
};

var THEME_COLOR = {
  default: "#0a0713",
  pinky: "#ffc2d6",
  golden: "#0d0904"
};

var THEME_LOADING_LOGO = {
  default: "assets/logo-256.png",
  pinky: "assets/themes/pinky/icon.png",
  golden: "assets/themes/golden/icon.png"
};

var THEME_CREST_LOGO = {
  default: "assets/logo-128.png",
  pinky: "assets/themes/pinky/icon.png",
  golden: "assets/themes/golden/icon.png"
};

var DEFAULT_FAVICON_HREF = (document.querySelector('link[rel="icon"]') || {}).href || "assets/logo-64.png";

var APP_ICON_ASSETS = {
  default: null,
  navi: "assets/app-icons/navi.webp",
  glory: "assets/app-icons/glory.webp",
  winter: "assets/app-icons/winter.webp",
  christmas: "assets/app-icons/christmas.webp",
  summer: "assets/app-icons/summer.webp",
  autumn: "assets/app-icons/autumn.webp",
  cristal: "assets/app-icons/cristal.webp",
  spring: "assets/app-icons/spring.webp",
  zeif_christmas: "assets/app-icons/zeif_christmas.webp"
};

function applyAppIcon(name) {
  try {
    localStorage.setItem("app_icon", name);
  } catch (e) {}
  if (window.Z3TAccountPrefs) window.Z3TAccountPrefs.queuePush();
  var asset = APP_ICON_ASSETS[name];
  if (asset) {
    var linkEl = document.querySelector('link[rel="icon"]');
    if (!linkEl) {
      linkEl = document.createElement("link");
      linkEl.rel = "icon";
      document.head.appendChild(linkEl);
    }
    linkEl.href = asset;
    var loadingLogoEl = $("appLoadingLogo");
    if (loadingLogoEl) loadingLogoEl.src = asset;
    var crestLogoEl = $("sidebarCrestLogo");
    if (crestLogoEl) crestLogoEl.src = asset;
  } else {
    var savedTheme = "default";
    try {
      savedTheme = localStorage.getItem("app_theme") || "default";
    } catch (e) {}
    applyTheme(savedTheme);
  }
  var gridEl = $("appIconGrid");
  if (gridEl) qsa(".appicon-card", gridEl).forEach(function(card) {
    card.classList.toggle("active", card.getAttribute("data-appicon") === name);
  });
}

window.applyAppIcon = applyAppIcon;

(function initAppIcon() {
  var saved = "default";
  try {
    saved = localStorage.getItem("app_icon") || "default";
  } catch (e) {}
  applyAppIcon(saved);
})();

var btnAppIconsBackEl = $("btnAppIconsBack");

if (btnAppIconsBackEl) btnAppIconsBackEl.addEventListener("click", function() {
  goBack("panel-list");
});

var appIconGridEl = $("appIconGrid");

if (appIconGridEl) qsa(".appicon-card", appIconGridEl).forEach(function(card) {
  card.addEventListener("click", function() {
    applyAppIcon(card.getAttribute("data-appicon"));
    toast("Ícono aplicado.");
  });
});

function applyTheme(name) {
  document.body.classList.remove("theme-pinky", "theme-golden");
  if (name === "pinky" || name === "golden") document.body.classList.add("theme-" + name);
  try {
    localStorage.setItem("app_theme", name);
  } catch (e) {}
  if (window.Z3TAccountPrefs) window.Z3TAccountPrefs.queuePush();
  var iconHref = THEME_FAVICON[name] || DEFAULT_FAVICON_HREF;
  var linkEl = document.querySelector('link[rel="icon"]');
  if (!linkEl) {
    linkEl = document.createElement("link");
    linkEl.rel = "icon";
    document.head.appendChild(linkEl);
  }
  linkEl.href = iconHref;
  var themeColorEl = document.querySelector('meta[name="theme-color"]');
  if (themeColorEl) themeColorEl.setAttribute("content", THEME_COLOR[name] || THEME_COLOR.default);
  var loadingLogoEl = $("appLoadingLogo");
  if (loadingLogoEl) loadingLogoEl.src = THEME_LOADING_LOGO[name] || THEME_LOADING_LOGO.default;
  var crestLogoEl = $("sidebarCrestLogo");
  if (crestLogoEl) crestLogoEl.src = THEME_CREST_LOGO[name] || THEME_CREST_LOGO.default;
  qsa(".theme-card", $("themeGrid")).forEach(function(card) {
    card.classList.toggle("active", card.getAttribute("data-theme") === name);
  });
  var _savedAppIcon = "default";
  try {
    _savedAppIcon = localStorage.getItem("app_icon") || "default";
  } catch (e) {}
  if (_savedAppIcon !== "default" && APP_ICON_ASSETS[_savedAppIcon]) {
    if (linkEl) linkEl.href = APP_ICON_ASSETS[_savedAppIcon];
    if (loadingLogoEl) loadingLogoEl.src = APP_ICON_ASSETS[_savedAppIcon];
    if (crestLogoEl) crestLogoEl.src = APP_ICON_ASSETS[_savedAppIcon];
  }
}

window.applyTheme = applyTheme;

(function initTheme() {
  var saved = "default";
  try {
    saved = localStorage.getItem("app_theme") || "default";
  } catch (e) {}
  applyTheme(saved);
})();

var btnThemesBackEl = $("btnThemesBack");

if (btnThemesBackEl) btnThemesBackEl.addEventListener("click", function() {
  goBack("panel-list");
});

var themeGridEl = $("themeGrid");

if (themeGridEl) qsa(".theme-card", themeGridEl).forEach(function(card) {
  card.addEventListener("click", function() {
    if (window.Z3TTheme) window.Z3TTheme.disable();
    applyTheme(card.getAttribute("data-theme"));
    toast("Tema aplicado.");
  });
});

function recordLoginStreak(uid) {
  if (!uid) return Promise.resolve();
  return supabase.rpc("record_login_streak").then(function() {
    awardAchievement(uid);
  }).catch(function() {});
}

function awardAchievement(uid, code) {
  if (!uid) return Promise.resolve();
  if (currentUser && uid !== currentUser.id) return Promise.resolve();
  if (window.syncAchievements) return window.syncAchievements();
  return Promise.resolve();
}

function markHandleSet(userId, name, attempt) {
  var patch = {
    handle_set: true
  };
  if (name) patch.name = name;
  return supabase.from("profiles").update(patch).eq("id", userId).select("id").then(function(res) {
    var updated = !res.error && res.data && res.data.length > 0;
    if (updated) awardAchievement(userId, "welcome");
    if (!updated && (attempt || 0) < 5) {
      return new Promise(function(resolve) {
        setTimeout(resolve, 500);
      }).then(function() {
        return markHandleSet(userId, name, (attempt || 0) + 1);
      });
    }
  }).catch(function() {});
}

var ATTACH_BUCKET = "attachments";

var MAX_ATTACH_FILES = 5;

var MAX_ATTACH_SIZE = 50 * 1024 * 1024;

function messagesSignature(list) {
  return list.map(function(m) {
    return m.id + ":" + (m.body ? m.body.length : 0);
  }).join(",");
}

function isNearBottom(el, threshold) {
  if (!el) return true;
  return el.scrollHeight - el.scrollTop - el.clientHeight < (threshold || 140);
}

function detectRegion() {
  var lang = (navigator.language || navigator.languages && navigator.languages[0] || "").toLowerCase();
  return lang.indexOf("pt") === 0 ? "BR" : "LATAM";
}

function setupRegionCardGrid(gridId, initialRegion, onChange, hiddenInputId) {
  var grid = $(gridId);
  if (!grid) return;
  function paint(region) {
    grid.dataset.selected = region;
    qsa(".region-card", grid).forEach(function(card) {
      card.classList.toggle("active", card.getAttribute("data-region") === region);
    });
    if (hiddenInputId && $(hiddenInputId)) $(hiddenInputId).value = region;
  }
  paint(initialRegion || "LATAM");
  qsa(".region-card", grid).forEach(function(card) {
    card.addEventListener("click", function() {
      var region = card.getAttribute("data-region");
      paint(region);
      if (onChange) onChange(region);
    });
  });
  return {
    get: function() {
      return grid.dataset.selected;
    },
    set: paint
  };
}

function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, function(c) {
    return {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[c];
  });
}

/* URL segura para meter en src/href: solo http(s), // o ruta absoluta. Cualquier otra cosa (javascript:, data:, etc.) queda vacia. */
function safeUrlAttr(u) {
  u = String(u == null ? "" : u).trim();
  return /^(https?:)?\/\//i.test(u) || /^\/(?!\/)/.test(u) ? escapeHtml(u) : "";
}

function achievementIconHtml(a, extraClass) {
  if (!a) return "";
  var cls = "achv-icon-img" + (extraClass ? " " + extraClass : "");
  if (a.icon_url) return '<img loading=lazy decoding=async class="' + cls + '" src="' + escapeHtml(a.icon_url) + '" alt="' + escapeHtml(a.name || "") + '">';
  return escapeHtml(a.icon || "");
}

function slugify(text) {
  var base = String(text || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-+|-+$)/g, "").slice(0, 60);
  var suffix = Math.random().toString(36).slice(2, 8);
  return (base || "item") + "-" + suffix;
}

function formatSize(bytes) {
  if (bytes == null) return "";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}

var lightboxSlug = "";

var lightboxUrl = "";

var lightboxName = "";

document.addEventListener("click", function(e) {
  var trigger = e.target.closest("[data-lightbox-image]");
  if (trigger) {
    e.preventDefault();
    lightboxSlug = trigger.getAttribute("data-file-slug") || "";
    lightboxUrl = trigger.getAttribute("data-img-url") || "";
    lightboxName = trigger.getAttribute("data-img-name") || "imagen";
    $("imageLightboxImg").src = lightboxUrl;
    $("imageLightboxImg").alt = lightboxName;
    $("imageLightboxDropdown").hidden = true;
    $("imageLightboxBackdrop").classList.add("open");
    return;
  }
  if (!e.target.closest(".image-lightbox-menu-wrap")) {
    var dd = $("imageLightboxDropdown");
    if (dd) dd.hidden = true;
  }
});

$("imageLightboxClose").addEventListener("click", function() {
  $("imageLightboxBackdrop").classList.remove("open");
});

$("imageLightboxBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

$("imageLightboxMenuBtn").addEventListener("click", function(e) {
  e.stopPropagation();
  $("imageLightboxDropdown").hidden = !$("imageLightboxDropdown").hidden;
});

$("imageLightboxDownload").addEventListener("click", function() {
  $("imageLightboxDropdown").hidden = true;
  if (!lightboxUrl) return;
  fetch(lightboxUrl).then(function(res) {
    return res.blob();
  }).then(function(blob) {
    var objUrl = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = objUrl;
    a.download = lightboxName || "imagen";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function() {
      URL.revokeObjectURL(objUrl);
    }, 4e3);
  }).catch(function() {
    window.open(lightboxUrl, "_blank", "noopener");
  });
});

$("imageLightboxReport").addEventListener("click", function() {
  $("imageLightboxDropdown").hidden = true;
  $("imageLightboxBackdrop").classList.remove("open");
  if (typeof openReportModal === "function") openReportModal("attachment", lightboxSlug || lightboxUrl);
});

function encodeAttachments(list) {
  return list && list.length ? "\n\x3c!--ATTACH:" + JSON.stringify(list) + "--\x3e" : "";
}

function parseAttachments(body) {
  var text = body || "";
  var attachments = [];
  var m = text.match(/<!--ATTACH:([\s\S]*?)-->/);
  if (m) {
    try {
      attachments = JSON.parse(m[1]) || [];
    } catch (e) {
      attachments = [];
    }
    text = text.slice(0, m.index) + text.slice(m.index + m[0].length);
  }
  return {
    text: text.replace(/\s+$/, ""),
    attachments: attachments
  };
}

var UPLOAD_ICON_HTML = '<img loading=lazy decoding=async src="assets/icons/ic-upload.png" alt="" class="upload-icon-img">';

var ICON_CLIP_SM = UPLOAD_ICON_HTML;

var ICON_IMG_SM = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>';

var ICON_FILE_SM = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>';

var Z3T_AUDIO_PLAY_SVG = '<svg class="z3t-ico-play" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>';
var Z3T_AUDIO_PAUSE_SVG = '<svg class="z3t-ico-pause" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4.2" height="14" rx="1.2"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.2"/></svg>';

function z3tAudioPlayerHtml(url) {
  return '<div class="z3t-audio">' + '<button type="button" class="z3t-audio-btn" aria-label="Reproducir audio">' + Z3T_AUDIO_PLAY_SVG + Z3T_AUDIO_PAUSE_SVG + "</button>" + '<div class="z3t-audio-wave" aria-hidden="true"></div>' + '<audio preload="none" src="' + safeUrlAttr(url) + '"></audio>' + "</div>";
}

function renderAttachments(list) {
  if (!list || !list.length) return "";
  return '<div class="attach-gallery">' + list.map(function(a) {
    if (a.type && a.type.indexOf("audio/") === 0) {
      return z3tAudioPlayerHtml(a.url);
    }
    if (a.type && a.type.indexOf("image/") === 0) {
      return '<button type="button" class="attach-image" data-lightbox-image data-file-slug="' + escapeHtml(a.slug || "") + '" data-img-url="' + escapeHtml(a.url || "") + '" data-img-name="' + escapeHtml(a.name || "") + '"><img src="' + safeUrlAttr(a.url) + '" alt="' + escapeHtml(a.name) + '" loading="lazy"></button>';
    }
    return '<a class="attach-file" href="/archivos/' + encodeURIComponent(a.slug || "") + '" data-file-slug="' + escapeHtml(a.slug || "") + '">' + ICON_FILE_SM + '<span class="attach-chip-name">' + escapeHtml(a.name) + "</span>" + '<span class="attach-file-size">' + formatSize(a.size) + "</span></a>";
  }).join("") + "</div>";
}

function readFileHead(file, n) {
  var blob = file.slice(0, n);
  if (blob.arrayBuffer) return blob.arrayBuffer();
  return new Promise(function(resolve, reject) {
    var fr = new FileReader;
    fr.onload = function() {
      resolve(fr.result);
    };
    fr.onerror = reject;
    fr.readAsArrayBuffer(blob);
  });
}

function sniffImageInfo(file) {
  return readFileHead(file, 8192).then(function(buf) {
    var b = new Uint8Array(buf);
    function str(o, l) {
      var s = "";
      for (var i = o; i < o + l && i < b.length; i++) s += String.fromCharCode(b[i]);
      return s;
    }
    if (str(0, 3) === "GIF") return {
      mime: "image/gif",
      ext: "gif",
      animated: true,
      keep: true
    };
    if (b[0] === 137 && str(1, 3) === "PNG") {
      var off = 8, anim = false;
      while (off + 8 <= b.length) {
        var len = (b[off] * 16777216 + (b[off + 1] << 16) + (b[off + 2] << 8) + b[off + 3]);
        var type = str(off + 4, 4);
        if (type === "acTL") {
          anim = true;
          break;
        }
        if (type === "IDAT" || type === "IEND") break;
        off += 12 + len;
      }
      return {
        mime: "image/png",
        ext: "png",
        animated: anim,
        keep: anim
      };
    }
    if (str(0, 4) === "RIFF" && str(8, 4) === "WEBP") {
      var animWebp = str(12, 4) === "VP8X" && (b[20] & 2) === 2 || str(0, 8192).indexOf("ANIM") > -1;
      return {
        mime: "image/webp",
        ext: "webp",
        animated: animWebp,
        keep: animWebp
      };
    }
    if (str(4, 4) === "ftyp" && (str(8, 4) === "avif" || str(8, 4) === "avis")) return {
      mime: "image/avif",
      ext: "avif",
      animated: str(8, 4) === "avis",
      keep: true
    };
    if (b[0] === 255 && b[1] === 216) return {
      mime: "image/jpeg",
      ext: "jpg",
      animated: false,
      keep: false
    };
    return {
      mime: file.type || "",
      ext: null,
      animated: false,
      keep: false,
      unknown: true
    };
  }).catch(function() {
    return {
      mime: file.type || "",
      ext: null,
      animated: false,
      keep: false,
      unknown: true
    };
  });
}

function withRealImageType(file, info) {
  if (!info || !info.mime || info.unknown) return file;
  var name = file.name || "imagen";
  if (info.ext) {
    var re = /\.[A-Za-z0-9]+$/;
    var curExt = (name.match(re) || [ "" ])[0].toLowerCase().replace(".", "");
    var same = curExt === info.ext || info.ext === "jpg" && curExt === "jpeg";
    if (!same) name = name.replace(re, "") + "." + info.ext;
  }
  if (file.type === info.mime && name === file.name) return file;
  return new File([ file ], name, {
    type: info.mime,
    lastModified: Date.now()
  });
}

function stripImageMetadata(file) {
  if (!file || !file.type && !/\.(gif|png|apng|webp|avif|jpe?g)$/i.test(file.name || "")) {
    return Promise.resolve(file);
  }
  if (file.type && file.type.indexOf("image/") !== 0) {
    return Promise.resolve(file);
  }
  return sniffImageInfo(file).then(function(info) {
    if (info.keep) {
      return withRealImageType(file, info);
    }
    var real = withRealImageType(file, info);
    if (typeof createImageBitmap !== "function" || info.unknown && file.type === "image/gif") {
      return real;
    }
    return createImageBitmap(real, {
      imageOrientation: "from-image"
    }).then(function(bitmap) {
      var canvas = document.createElement("canvas");
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      var ctx = canvas.getContext("2d");
      ctx.drawImage(bitmap, 0, 0);
      if (bitmap.close) bitmap.close();
      var outType = real.type === "image/png" || real.type === "image/webp" ? real.type : "image/jpeg";
      return new Promise(function(resolve) {
        canvas.toBlob(function(blob) {
          if (!blob) {
            resolve(real);
            return;
          }
          resolve(new File([ blob ], real.name, {
            type: outType,
            lastModified: Date.now()
          }));
        }, outType, .92);
      });
    }).catch(function(err) {
      console.error("[stripImageMetadata] no se pudo limpiar metadatos, se sube el archivo original:", err);
      return real;
    });
  });
}

function uploadFiles(files, prefix) {
  var arr = Array.prototype.slice.call(files);
  return arr.reduce(function(promise, file) {
    return promise.then(function(acc) {
      return stripImageMetadata(file).then(function(cleanFile) {
        var safeName = cleanFile.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        var path = prefix + "/" + Date.now() + "_" + Math.random().toString(36).slice(2, 7) + "_" + safeName;
        return supabase.storage.from(ATTACH_BUCKET).upload(path, cleanFile, {
          upsert: false,
          contentType: cleanFile.type || "application/octet-stream"
        }).then(function(res) {
          if (res.error) throw res.error;
          var pub = supabase.storage.from(ATTACH_BUCKET).getPublicUrl(path);
          acc.push({
            url: pub.data.publicUrl,
            name: cleanFile.name,
            type: cleanFile.type,
            size: cleanFile.size,
            slug: slugify(cleanFile.name.replace(/\.[^.]+$/, ""))
          });
          return acc;
        });
      });
    });
  }, Promise.resolve([]));
}

function initAttachPicker(container) {
  var input = container.querySelector(".attach-input");
  var btn = container.querySelector(".attach-trigger");
  var chips = container.querySelector(".attach-chips");
  var files = [];
  function render() {
    chips.innerHTML = files.map(function(f, i) {
      var icon = f.type && f.type.indexOf("image/") === 0 ? ICON_IMG_SM : ICON_FILE_SM;
      return '<span class="attach-chip">' + icon + '<span class="attach-chip-name">' + escapeHtml(f.name) + "</span>" + '<span class="attach-chip-size">' + formatSize(f.size) + "</span>" + '<button type="button" class="attach-chip-remove" data-i="' + i + '" aria-label="Quitar">&times;</button></span>';
    }).join("");
    qsa(".attach-chip-remove", chips).forEach(function(b) {
      b.addEventListener("click", function() {
        files.splice(+b.getAttribute("data-i"), 1);
        render();
      });
    });
  }
  function addFiles(list) {
    Array.prototype.slice.call(list).forEach(function(f) {
      if (files.length >= MAX_ATTACH_FILES) {
        toast("Máximo " + MAX_ATTACH_FILES + " archivos por publicación.");
        return;
      }
      if (!f.type || f.type.indexOf("image/") !== 0 && f.type.indexOf("video/") !== 0) {
        toast('"' + f.name + '" no es una foto, video o GIF. Solo se aceptan esos formatos.');
        return;
      }
      if (f.size > MAX_ATTACH_SIZE) {
        toast('"' + f.name + '" supera 50MB y no se adjuntó.');
        return;
      }
      files.push(f);
    });
    render();
  }
  btn.addEventListener("click", function() {
    input.click();
  });
  input.addEventListener("change", function() {
    addFiles(input.files);
    input.value = "";
  });
  container.addEventListener("dragover", function(e) {
    e.preventDefault();
    container.classList.add("drag");
  });
  container.addEventListener("dragleave", function() {
    container.classList.remove("drag");
  });
  container.addEventListener("drop", function(e) {
    e.preventDefault();
    container.classList.remove("drag");
    if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
  });
  return {
    getFiles: function() {
      return files;
    },
    reset: function() {
      files = [];
      render();
    }
  };
}

var ALL_PANELS = [ "panel-list", "panel-thread", "panel-communities", "panel-community-detail", "panel-messages", "panel-conversation", "panel-group-detail", "panel-circles", "panel-circle-detail", "panel-meet-session", "panel-bottle", "panel-store", "panel-store-detail", "panel-wallet", "panel-my-store", "panel-my-collection", "panel-credits", "panel-community-admin-portal", "panel-community-blocked", "panel-community-audit-log", "panel-search", "panel-notifications", "panel-themes", "panel-app-icons", "panel-achievements", "panel-theme-custom" ];

var immersiveContexts = {};

function enterImmersive(name) {
  immersiveContexts[name] = true;
  document.body.classList.add("community-immersive");
}

function exitImmersive(name) {
  delete immersiveContexts[name];
  if (!Object.keys(immersiveContexts).length) {
    document.body.classList.remove("community-immersive");
  }
}

function resetScrollToTop() {
  function go() {
    window.scrollTo(0, 0);
    if (document.scrollingElement) document.scrollingElement.scrollTop = 0;
    ALL_PANELS.forEach(function(id) {
      var el = $(id);
      if (el) el.scrollTop = 0;
    });
    var content = document.querySelector(".app-content");
    if (content) content.scrollTop = 0;
  }
  go();
  requestAnimationFrame(go);
}

function exitAllImmersive() {
  immersiveContexts = {};
  document.body.classList.remove("community-immersive");
}

var panelHistory = [];

var currentPanelId = null;

function activatePanel(activeId, opts) {
  opts = opts || {};
  if (currentPanelId && currentPanelId !== activeId && !opts.isBack) {
    panelHistory.push(currentPanelId);
  }
  var isRealChange = currentPanelId !== activeId;
  currentPanelId = activeId;
  document.body.setAttribute("data-panel", activeId);
  ALL_PANELS.forEach(function(id) {
    var el = $(id);
    if (el) el.classList.toggle("active", id === activeId);
  });
  var profileBackdropEl = $("profileBackdrop");
  if (isRealChange && profileBackdropEl && profileBackdropEl.classList.contains("open")) {
    profileBackdropEl.classList.remove("open");
    document.body.classList.remove("profile-open");
    if (location.pathname.indexOf("/perfiles/") === 0) history.pushState({
      view: "list"
    }, "", "/");
  }
  if (isRealChange) qsa(".modal-backdrop.open").forEach(function(el) {
    el.classList.remove("open");
  });
  if (activeId !== "panel-meet-session" && typeof window.autoEndMeetIfActive === "function") {
    window.autoEndMeetIfActive();
  }
  if (activeId !== "panel-bottle" && typeof exitImmersive === "function") {
    exitImmersive("bottle");
  }
  if (activeId !== "panel-store-detail") document.body.classList.remove("frame-immersive");
}

function goBack(fallbackId) {
  var prev = panelHistory.pop();
  activatePanel(prev || fallbackId || "panel-list", {
    isBack: true
  });
}

function resetToFeedOnMissingRoute(pathPrefix) {
  activatePanel("panel-list");
  if (pathPrefix && location.pathname.indexOf(pathPrefix) === 0) {
    history.replaceState({
      view: "list"
    }, "", "/");
  }
}

var VIEWS = [ "landing", "login", "register", "onboarding", "app", "banned", "forgot-password", "reset-password" ];

var appLoadingScreenHidden = false;

function hideAppLoadingScreen() {
  if (appLoadingScreenHidden) return;
  appLoadingScreenHidden = true;
  var el = $("appLoadingScreen");
  if (!el) return;
  el.classList.add("app-loading-hide");
  setTimeout(function() {
    if (el.parentNode) el.parentNode.removeChild(el);
  }, 450);
}

function showView(name) {
  hideAppLoadingScreen();
  VIEWS.forEach(function(v) {
    var el = $("view-" + v);
    if (el) el.classList.toggle("active", v === name);
  });
  VIEWS.forEach(function(v) {
    document.body.classList.remove("state-" + v);
    document.documentElement.classList.remove("state-" + v);
  });
  document.body.classList.add("state-" + name);
  document.documentElement.classList.add("state-" + name);
  window.scrollTo(0, 0);
  if (name === "login") {
    if (location.pathname !== "/login") history.pushState({
      view: "login"
    }, "", "/login");
  } else if (name === "register") {
    if (location.pathname !== "/registro") history.pushState({
      view: "register"
    }, "", "/registro");
  } else if (location.pathname === "/login" || location.pathname === "/registro") {
    history.pushState({
      view: name === "app" ? "list" : "landing"
    }, "", "/");
  }
}

var DEVICE_ID_KEY = "hs_device_id";

function getDeviceId() {
  try {
    var id = localStorage.getItem(DEVICE_ID_KEY);
    if (!id) {
      id = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : "dev-" + Date.now() + "-" + Math.random().toString(36).slice(2);
      localStorage.setItem(DEVICE_ID_KEY, id);
    }
    return id;
  } catch (_e) {
    return "dev-session-" + Math.random().toString(36).slice(2);
  }
}

function detectDevice() {
  var ua = navigator.userAgent || "";
  var os = "Sistema desconocido";
  if (/Windows/i.test(ua)) os = "Windows"; else if (/Mac OS X/i.test(ua)) os = "macOS"; else if (/Android/i.test(ua)) os = "Android"; else if (/iPhone|iPad|iPod/i.test(ua)) os = "iOS"; else if (/Linux/i.test(ua)) os = "Linux";
  var browser = "Navegador desconocido";
  if (/Edg\//i.test(ua)) browser = "Edge"; else if (/Chrome\//i.test(ua) && !/OPR\//i.test(ua)) browser = "Chrome"; else if (/Firefox\//i.test(ua)) browser = "Firefox"; else if (/Safari\//i.test(ua) && !/Chrome/i.test(ua)) browser = "Safari";
  var type = /Mobi/i.test(ua) ? "móvil" : "escritorio";
  var screenRes = window.screen && window.screen.width ? window.screen.width + "×" + window.screen.height : "n/d";
  return os + " · " + browser + " (" + type + ") · " + screenRes;
}

function activeVoiceActivityElsewhere(kind, id) {
  if (typeof voiceRoom !== "undefined" && voiceRoom && (kind !== "community" || voiceRoomCommunityId !== id)) {
    return "una comunidad";
  }
  if (typeof activityVoiceRoom !== "undefined" && activityVoiceRoom && (kind !== activityVoiceKind || activityVoiceRoomId !== id)) {
    if (activityVoiceKind === "group") return "un grupo";
    if (activityVoiceKind === "dm") return "un chat privado";
    if (activityVoiceKind === "meet") return "una reunión";
    return "otra actividad";
  }
  return null;
}

function fetchIpAndLocation() {
  return fetch("https://ipapi.co/json/", {
    cache: "no-store"
  }).then(function(r) {
    if (!r.ok) throw new Error("bad response");
    return r.json();
  }).then(function(data) {
    return {
      ip: data.ip || "No disponible",
      location: [ data.city, data.region, data.country_name ].filter(Boolean).join(", ") || "No disponible"
    };
  }).catch(function() {
    return fetch("https://api.ipify.org?format=json").then(function(r) {
      return r.json();
    }).then(function(d) {
      return {
        ip: d.ip || "No disponible",
        location: "No disponible"
      };
    }).catch(function() {
      return {
        ip: "No disponible",
        location: "No disponible"
      };
    });
  });
}

var DEFAULT_BACKGROUNDS = [ {
  name: "Fondo 1",
  url: "assets/backgrounds/default-1.webp",
  thumb: "assets/backgrounds/default-1-thumb.webp"
}, {
  name: "Fondo 2",
  url: "assets/backgrounds/default-2.webp",
  thumb: "assets/backgrounds/default-2-thumb.webp"
}, {
  name: "Fondo 3",
  url: "assets/backgrounds/default-3.webp",
  thumb: "assets/backgrounds/default-3-thumb.webp"
}, {
  name: "Fondo 4",
  url: "assets/backgrounds/default-4.webp",
  thumb: "assets/backgrounds/default-4-thumb.webp"
}, {
  name: "Fondo 5",
  url: "assets/backgrounds/default-5.webp",
  thumb: "assets/backgrounds/default-5-thumb.webp"
} ];

var bgPickerTargetInputId = null;

function renderBgPickerGrid() {
  var grid = $("bgPickerGrid");
  grid.innerHTML = DEFAULT_BACKGROUNDS.map(function(bg, i) {
    return '<button type="button" class="bg-picker-tile" data-bg-index="' + i + '" ' + 'style="background-image:url(&quot;' + bg.thumb + '&quot;)" aria-label="' + escapeHtml(bg.name) + '"></button>';
  }).join("") + '<button type="button" class="bg-picker-tile bg-picker-tile-upload" id="bgPickerUploadTile">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>' + "<span>Subir tu foto</span>" + "</button>";
  qsa(".bg-picker-tile:not(.bg-picker-tile-upload)", grid).forEach(function(tile) {
    tile.addEventListener("click", function() {
      chooseDefaultBackground(DEFAULT_BACKGROUNDS[parseInt(tile.getAttribute("data-bg-index"), 10)], tile);
    });
  });
  $("bgPickerUploadTile").addEventListener("click", function() {
    var input = $(bgPickerTargetInputId);
    closeBgPicker();
    if (input) input.click();
  });
}

function chooseDefaultBackground(bg, tileEl) {
  if (tileEl) tileEl.classList.add("bg-picker-tile-loading");
  fetch(bg.url).then(function(r) {
    if (!r.ok) throw new Error("no se pudo cargar el fondo");
    return r.blob();
  }).then(function(blob) {
    var fileName = bg.url.split("/").pop();
    var file = new File([ blob ], fileName, {
      type: blob.type || "image/webp"
    });
    var input = $(bgPickerTargetInputId);
    if (!input) return;
    var dt = new DataTransfer;
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event("change", {
      bubbles: true
    }));
    closeBgPicker();
  }).catch(function() {
    toast("No se pudo aplicar ese fondo. Intenta de nuevo.");
    if (tileEl) tileEl.classList.remove("bg-picker-tile-loading");
  });
}

function openBackgroundPicker(inputId) {
  bgPickerTargetInputId = inputId;
  renderBgPickerGrid();
  $("bgPickerBackdrop").classList.add("open");
}

function closeBgPicker() {
  $("bgPickerBackdrop").classList.remove("open");
  bgPickerTargetInputId = null;
}

$("bgPickerClose").addEventListener("click", closeBgPicker);

$("bgPickerBackdrop").addEventListener("click", function(e) {
  if (e.target === this) closeBgPicker();
});