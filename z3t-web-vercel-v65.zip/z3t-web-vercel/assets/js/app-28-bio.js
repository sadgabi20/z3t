var BIO_IMG_PREFIX = SUPABASE_URL + "/storage/v1/object/public/";
var BIO_AUDIO_PREFIX = SUPABASE_URL + "/storage/v1/object/public/attachments/bio-audio/";
var BIO_AUDIO_MAX = 5;
var BIO_ALLOWED_TAGS = {
  P: 1, DIV: 1, BR: 1, B: 1, STRONG: 1, I: 1, EM: 1, U: 1, S: 1,
  A: 1, IMG: 1, UL: 1, OL: 1, LI: 1, H3: 1, BLOCKQUOTE: 1, AUDIO: 1
};
var BIO_DROP_TAGS = {
  SCRIPT: 1, STYLE: 1, IFRAME: 1, OBJECT: 1, EMBED: 1, SVG: 1, MATH: 1, FORM: 1,
  INPUT: 1, BUTTON: 1, TEXTAREA: 1, SELECT: 1, LINK: 1, META: 1, TEMPLATE: 1,
  NOSCRIPT: 1, VIDEO: 1, CANVAS: 1, TITLE: 1, HEAD: 1
};

function bioNormalizeUrl(raw) {
  var v = String(raw || "").trim();
  if (!v) return null;
  var compact = v.replace(/[\u0000-\u001f\u007f\s]/g, "");
  if (!/^[a-z][a-z0-9+.-]*:/i.test(compact)) {
    if (/^[^\s@\/]+@[^\s@\/]+\.[^\s@\/]+$/.test(v)) compact = "mailto:" + v;
    else compact = "https://" + compact;
  }
  try {
    var u = new URL(compact);
    if (u.protocol !== "http:" && u.protocol !== "https:" && u.protocol !== "mailto:") return null;
    return u.href;
  } catch (e) {
    return null;
  }
}

function bioCleanInto(src, out, depth) {
  if (depth > 60) return;
  for (var i = 0; i < src.childNodes.length; i++) {
    var ch = src.childNodes[i];
    if (ch.nodeType === 3) {
      out.appendChild(document.createTextNode(ch.nodeValue));
      continue;
    }
    if (ch.nodeType !== 1) continue;
    var tag = ch.tagName.toUpperCase();
    if (BIO_DROP_TAGS[tag]) continue;
    if (!BIO_ALLOWED_TAGS[tag]) {
      bioCleanInto(ch, out, depth + 1); // etiqueta no permitida: se conserva solo el texto
      continue;
    }
    if (tag === "IMG") {
      var s = (ch.getAttribute("src") || "").trim();
      if (s.indexOf(BIO_IMG_PREFIX) !== 0) continue; // solo imágenes de nuestro almacenamiento
      var img = document.createElement("img");
      img.setAttribute("src", s);
      img.setAttribute("alt", (ch.getAttribute("alt") || "").slice(0, 120));
      img.setAttribute("loading", "lazy");
      img.setAttribute("decoding", "async");
      out.appendChild(img);
      continue;
    }
    if (tag === "AUDIO") {
      var asrc = (ch.getAttribute("src") || "").trim();
      if (asrc.indexOf(BIO_AUDIO_PREFIX) !== 0) continue; // solo audios subidos a bio-audio/
      var au = document.createElement("audio");
      au.setAttribute("src", asrc);
      au.setAttribute("controls", "");
      au.setAttribute("preload", "none");
      out.appendChild(au);
      continue;
    }
    if (tag === "A") {
      var href = bioNormalizeUrl(ch.getAttribute("href"));
      if (!href) {
        bioCleanInto(ch, out, depth + 1);
        continue;
      }
      var a = document.createElement("a");
      a.setAttribute("href", href);
      a.setAttribute("target", "_blank");
      a.setAttribute("rel", "noopener noreferrer nofollow ugc");
      bioCleanInto(ch, a, depth + 1);
      out.appendChild(a);
      continue;
    }
    var el = document.createElement(tag.toLowerCase());
    if (tag !== "BR") bioCleanInto(ch, el, depth + 1);
    out.appendChild(el);
  }
}

function bioSanitize(html) {
  var doc = new DOMParser().parseFromString(String(html || ""), "text/html");
  var holder = document.createElement("div");
  bioCleanInto(doc.body, holder, 0);
  return holder.innerHTML;
}

function bioIsHtml(str) {
  return /<\/?(p|div|br|b|strong|i|em|u|s|a|img|audio|ul|ol|li|h3|blockquote)\b/i.test(String(str || ""));
}

function bioToHtml(bio) {
  var s = String(bio || "");
  if (!s.trim()) return "";
  if (bioIsHtml(s)) return bioSanitize(s);
  return escapeHtml(s).replace(/\r?\n/g, "<br>");
}

function bioPlainText(bio) {
  var holder = document.createElement("div");
  holder.innerHTML = bioToHtml(bio);
  holder.querySelectorAll("br,p,div,li,h3,blockquote").forEach(function(n) {
    n.insertAdjacentText("beforebegin", " ");
    n.insertAdjacentText("afterend", " ");
  });
  return (holder.textContent || "").replace(/\s+/g, " ").trim();
}

function bioImageCount(bio) {
  var holder = document.createElement("div");
  holder.innerHTML = bioToHtml(bio);
  return holder.querySelectorAll("img").length;
}

function bioAudioCount(bio) {
  var holder = document.createElement("div");
  holder.innerHTML = bioToHtml(bio);
  return holder.querySelectorAll("audio").length;
}

function bioHasContent(html) {
  var holder = document.createElement("div");
  holder.innerHTML = html;
  return !!((holder.textContent || "").trim() || holder.querySelector("img,audio"));
}

var bioViewed = { html: "", name: "" };

function renderProfileBio(p) {
  var html = bioToHtml(p && p.bio);
  var has = bioHasContent(html);
  bioViewed = { html: html, name: (p && (p.name || p.username)) || "" };
  var box = $("profileBioText");
  var row = $("profileBioBtn");
  if (!has) {
    box.textContent = "Aún no hay Biografía";
    if (row) row.classList.remove("has-bio");
    return;
  }
  var txt = bioPlainText(p.bio);
  var imgs = bioImageCount(p.bio);
  var auds = bioAudioCount(p.bio);
  if (!txt) txt = "Biografía con " + (auds ? auds + (auds === 1 ? " audio" : " audios") : "") + (auds && imgs ? " y " : "") + (imgs ? imgs + (imgs === 1 ? " imagen" : " imágenes") : "") + " · toca para verla";
  else if (auds) txt += " 🎵";
  box.textContent = txt;
  if (row) row.classList.add("has-bio");
}

function openBioSheet() {
  if (!bioViewed.html) return;
  var sheet = $("bioSheet");
  $("bioSheetTitle").textContent = bioViewed.name ? "Biografía · " + bioViewed.name : "Biografía";
  $("bioSheetBody").innerHTML = bioViewed.html;
  $("bioSheetBody").scrollTop = 0;
  var panel = sheet.querySelector(".bio-sheet-panel");
  panel.style.transform = "";
  sheet.hidden = false;
  requestAnimationFrame(function() {
    sheet.classList.add("open");
  });
  document.body.classList.add("bio-sheet-lock");
}

function closeBioSheet() {
  var sheet = $("bioSheet");
  if (!sheet || sheet.hidden) return;
  sheet.classList.remove("open");
  document.body.classList.remove("bio-sheet-lock");
  setTimeout(function() {
    sheet.hidden = true;
    sheet.querySelector(".bio-sheet-panel").style.transform = "";
  }, 260);
}

var bioSavedRange = null;

function bioEditor() {
  return $("bioEditor");
}

function bioEditorSet(bio) {
  var ed = bioEditor();
  if (!ed) return;
  ed.innerHTML = bioToHtml(bio);
  bioSavedRange = null;
  var bar = $("bioLinkBar");
  if (bar) bar.hidden = true;
}

function bioEditorGet() {
  var ed = bioEditor();
  if (!ed) return "";
  var html = bioSanitize(ed.innerHTML);
  return bioHasContent(html) ? html : "";
}

function bioSaveRange() {
  var ed = bioEditor();
  var sel = window.getSelection();
  if (!ed || !sel || !sel.rangeCount) return;
  var r = sel.getRangeAt(0);
  if (ed.contains(r.commonAncestorContainer)) bioSavedRange = r.cloneRange();
}

function bioRestoreRange() {
  var ed = bioEditor();
  ed.focus();
  var sel = window.getSelection();
  sel.removeAllRanges();
  if (bioSavedRange) {
    sel.addRange(bioSavedRange);
  } else {
    var r = document.createRange();
    r.selectNodeContents(ed);
    r.collapse(false);
    sel.addRange(r);
  }
}

function bioCollapseToEnd() {
  var sel = window.getSelection();
  if (sel && sel.rangeCount && !sel.isCollapsed) sel.collapseToEnd();
}

function bioInsertHtml(html) {
  bioRestoreRange();
  bioCollapseToEnd(); // nunca reemplaza el texto seleccionado: se inserta al final de la selección
  document.execCommand("insertHTML", false, html);
  bioSaveRange();
}

function bioApplyLink() {
  var url = bioNormalizeUrl($("bioLinkInput").value);
  if (!url) {
    toast("No se pudo agregar el enlace: escribe una dirección válida (https://…)");
    return;
  }
  bioRestoreRange();
  var sel = window.getSelection();
  if (!sel.rangeCount || sel.isCollapsed) {
    document.execCommand("insertHTML", false, '<a href="' + escapeHtml(url) + '">' + escapeHtml($("bioLinkInput").value.trim()) + "</a>&nbsp;");
  } else {
    document.execCommand("createLink", false, url);
    bioCollapseToEnd();
  }
  bioSaveRange();
  $("bioLinkInput").value = "";
  $("bioLinkBar").hidden = true;
}

function bioRemoveLink() {
  bioRestoreRange();
  document.execCommand("unlink", false, null);
  bioSaveRange();
  $("bioLinkInput").value = "";
  $("bioLinkBar").hidden = true;
}

function bioUploadImage(file) {
  if (!currentUser) return;
  if (!/^image\/(jpeg|png|webp|gif)$/.test(file.type)) {
    toast("No se pudo subir: usa una imagen JPG, PNG, WEBP o GIF");
    return;
  }
  if (file.size > 8 * 1024 * 1024) {
    toast("No se pudo subir: la imagen pesa más de 8 MB");
    return;
  }
  toast("Subiendo imagen…");
  stripImageMetadata(file).then(function(cleanFile) {
    var ext = cleanFile.type === "image/png" ? "png" : cleanFile.type === "image/webp" ? "webp" : cleanFile.type === "image/gif" ? "gif" : "jpg";
    var path = currentUser.id + "/bio_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8) + "." + ext;
    return supabase.storage.from(AVATAR_BUCKET).upload(path, cleanFile, {
      upsert: false,
      contentType: cleanFile.type
    }).then(function(res) {
      if (res.error) throw res.error;
      var url = supabase.storage.from(AVATAR_BUCKET).getPublicUrl(path).data.publicUrl;
      bioInsertHtml('<img src="' + escapeHtml(url) + '" alt=""><br>');
      toast("Listo, imagen agregada a tu biografía");
    });
  }).catch(function() {
    toast("No se pudo subir la imagen. Inténtalo de nuevo");
  });
}

function bioUploadAudio(file) {
  if (!currentUser) return;
  if (!/^audio\/(mpeg|mp3|mp4|x-m4a|m4a|aac|wav|x-wav|webm|ogg)/.test(file.type)) {
    toast("No se pudo subir: usa un audio MP3, M4A, WAV, OGG o WEBM");
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    toast("No se pudo subir: el audio pesa más de 10 MB");
    return;
  }
  var ed = bioEditor();
  if (ed && ed.querySelectorAll("audio").length >= BIO_AUDIO_MAX) {
    toast("Máximo " + BIO_AUDIO_MAX + " audios en tu biografía");
    return;
  }
  var ext = /mpeg|mp3/.test(file.type) ? "mp3" : /mp4|m4a|aac/.test(file.type) ? "m4a" : /wav/.test(file.type) ? "wav" : /ogg/.test(file.type) ? "ogg" : "webm";
  var ctype = file.type.replace("audio/x-m4a", "audio/mp4").replace("audio/m4a", "audio/mp4").replace("audio/aac", "audio/mp4").replace("audio/mp3", "audio/mpeg").replace("audio/x-wav", "audio/wav");
  var path = "bio-audio/" + currentUser.id + "/" + Date.now() + "_" + Math.random().toString(36).slice(2, 8) + "." + ext;
  toast("Subiendo audio…");
  supabase.storage.from(ATTACH_BUCKET).upload(path, file, {
    upsert: false,
    contentType: ctype
  }).then(function(res) {
    if (res.error) throw res.error;
    var url = supabase.storage.from(ATTACH_BUCKET).getPublicUrl(path).data.publicUrl;
    bioInsertHtml('<audio controls preload="none" src="' + escapeHtml(url) + '"></audio><br>');
    toast("Listo, audio agregado a tu biografía");
  }).catch(function() {
    toast("No se pudo subir el audio. Inténtalo de nuevo");
  });
}

(function bioInit() {
  var ed = bioEditor();
  if (ed) {
    document.addEventListener("selectionchange", bioSaveRange);
    ed.addEventListener("paste", function(e) {
      e.preventDefault();
      var text = (e.clipboardData || window.clipboardData).getData("text/plain");
      document.execCommand("insertText", false, text);
    });
    ed.addEventListener("drop", function(e) {
      e.preventDefault();
      var text = e.dataTransfer && e.dataTransfer.getData("text/plain");
      if (text) document.execCommand("insertText", false, text);
    });
    document.querySelectorAll("#bioToolbar button").forEach(function(b) {
      b.addEventListener("mousedown", function(e) {
        e.preventDefault();
      });
    });
    $("bioBtnBold").addEventListener("click", function() {
      bioRestoreRange();
      document.execCommand("bold");
      bioSaveRange();
    });
    $("bioBtnItalic").addEventListener("click", function() {
      bioRestoreRange();
      document.execCommand("italic");
      bioSaveRange();
    });
    $("bioBtnLink").addEventListener("click", function() {
      bioSaveRange();
      var bar = $("bioLinkBar");
      bar.hidden = !bar.hidden;
      if (!bar.hidden) setTimeout(function() {
        $("bioLinkInput").focus();
      }, 0);
    });
    $("bioLinkApply").addEventListener("click", bioApplyLink);
    $("bioLinkRemove").addEventListener("click", bioRemoveLink);
    $("bioLinkInput").addEventListener("keydown", function(e) {
      if (e.key === "Enter") {
        e.preventDefault();
        bioApplyLink();
      }
    });
    $("bioBtnImage").addEventListener("click", function() {
      bioSaveRange();
      $("bioImageInput").click();
    });
    $("bioBtnAudio").addEventListener("click", function() {
      bioSaveRange();
      $("bioAudioInput").click();
    });
    $("bioAudioInput").addEventListener("change", function() {
      var files = Array.prototype.slice.call(this.files || []);
      this.value = "";
      files.forEach(bioUploadAudio);
    });
    $("bioImageInput").addEventListener("change", function() {
      var files = Array.prototype.slice.call(this.files || []);
      this.value = "";
      files.forEach(bioUploadImage);
    });
  }

  var btn = $("profileBioBtn");
  if (btn) {
    btn.addEventListener("click", openBioSheet);
    btn.addEventListener("keydown", function(e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        openBioSheet();
      }
    });
  }
  var sheet = $("bioSheet");
  if (sheet) {
    sheet.querySelector(".bio-sheet-backdrop").addEventListener("click", closeBioSheet);
    $("bioSheetClose").addEventListener("click", closeBioSheet);
    document.addEventListener("keydown", function(e) {
      if (e.key === "Escape") closeBioSheet();
    });
    var panel = sheet.querySelector(".bio-sheet-panel");
    var head = sheet.querySelector(".bio-sheet-head");
    var startY = null, dy = 0;
    head.addEventListener("touchstart", function(e) {
      startY = e.touches[0].clientY;
      dy = 0;
      panel.style.transition = "none";
    }, { passive: true });
    head.addEventListener("touchmove", function(e) {
      if (startY === null) return;
      dy = Math.max(0, e.touches[0].clientY - startY);
      panel.style.transform = "translateY(" + dy + "px)";
    }, { passive: true });
    head.addEventListener("touchend", function() {
      panel.style.transition = "";
      if (dy > 90) closeBioSheet();
      else panel.style.transform = "";
      startY = null;
    });
  }
})();
