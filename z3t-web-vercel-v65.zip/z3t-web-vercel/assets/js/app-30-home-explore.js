"use strict";

var EXPLORE_CIRCLES_COUNT = 4;

function exploreBgStyle(url) {
  return url ? ' style="background-image:url(&quot;' + encodeURI(url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
}

function renderExploreCircles() {
  var el = $("exploreCirclesStrip");
  if (!el) return;
  if (typeof CIRCLES === "undefined" || !CIRCLES.length) {
    el.hidden = true;
    el.innerHTML = "";
    return;
  }
  var top = CIRCLES.slice().sort(function(a, b) {
    return (b.member_count || 0) - (a.member_count || 0);
  }).slice(0, EXPLORE_CIRCLES_COUNT);
  el.hidden = false;
  var cards = top.map(function(c) {
    var fallback = c.icon_url ? "" : '<span class="live-party-fallback">' + escapeHtml((c.name || "?").charAt(0).toUpperCase()) + "</span>";
    return '<div class="live-party-card explore-circle-card" data-slug="' + escapeHtml(c.slug) + '">' + '<div class="live-party-thumb explore-circle-thumb"' + exploreBgStyle(c.icon_url) + ">" + fallback + '<span class="explore-circle-members">👥 ' + (c.member_count || 0) + "</span>" + "</div>" + '<div class="live-party-name">' + escapeHtml(c.name || "") + "</div>" + "</div>";
  }).join("");
  el.innerHTML = '<div class="live-parties-card">' + '<div class="live-parties-head" id="exploreCirclesOpenAll" role="button" tabindex="0"><span class="live-parties-icon">🌐</span><span class="live-parties-title">Explorar círculos</span><span class="live-parties-chevron">›</span></div>' + '<div class="live-parties-row">' + cards + "</div></div>";
  var openAll = $("exploreCirclesOpenAll");
  var goAll = function() {
    if (typeof showCirclesList === "function") showCirclesList();
  };
  openAll.addEventListener("click", goAll);
  openAll.addEventListener("keydown", function(e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      goAll();
    }
  });
  qsa(".explore-circle-card", el).forEach(function(card) {
    card.addEventListener("click", function() {
      if (typeof openCircle === "function") openCircle(card.getAttribute("data-slug"));
    });
  });
}

function announcementBodyHtml(text) {
  var html = escapeHtml(text || "");
  html = html.replace(/!\[([^\]]*)\]\((https?:\/\/[^\s)]+)\)|\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)|(https?:\/\/[^\s<]+)/g, function(m, alt, imgUrl, label, linkUrl, bare) {
    if (imgUrl) return '<img class="ann-img" loading="lazy" decoding="async" src="' + imgUrl + '" alt="' + (alt || "") + '">';
    if (linkUrl) return '<a class="ann-link" href="' + linkUrl + '" target="_blank" rel="noopener noreferrer nofollow">' + label + "</a>";
    if (/\.(png|jpe?g|gif|webp)(\?[^\s]*)?$/i.test(bare)) return '<img class="ann-img" loading="lazy" decoding="async" src="' + bare + '" alt="">';
    return '<a class="ann-link" href="' + bare + '" target="_blank" rel="noopener noreferrer nofollow">' + bare + "</a>";
  });
  return html.replace(/\n/g, "<br>");
}

var ANNOUNCEMENTS = [];

function loadAnnouncements() {
  subscribeAnnouncementsLive();
  return supabase.from("announcements").select("*").order("created_at", {
    ascending: false
  }).limit(20).then(function(res) {
    ANNOUNCEMENTS = res.error ? [] : res.data || [];
    renderAnnouncements();
  }, function() {
    ANNOUNCEMENTS = [];
    renderAnnouncements();
  });
}

var annCarouselTimer = null;
var annCarouselResume = null;
var annRenderSig = "";
var ANN_AUTOPLAY_MS = 5000;

function annStopCarousel() {
  if (annCarouselTimer) clearInterval(annCarouselTimer);
  if (annCarouselResume) clearTimeout(annCarouselResume);
  annCarouselTimer = null;
  annCarouselResume = null;
}

function annStartCarousel(track) {
  annStopCarousel();
  if (!track || track.children.length < 2) return;
  if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  annCarouselTimer = setInterval(function() {
    if (document.hidden || !track.offsetParent) return;
    var w = track.clientWidth;
    if (!w) return;
    var idx = Math.round(track.scrollLeft / w);
    var next = idx + 1 >= track.children.length ? 0 : idx + 1;
    track.scrollTo({
      left: next * w,
      behavior: "smooth"
    });
  }, ANN_AUTOPLAY_MS);
}

function annPauseCarousel(track) {
  if (annCarouselTimer) clearInterval(annCarouselTimer);
  annCarouselTimer = null;
  if (annCarouselResume) clearTimeout(annCarouselResume);
  annCarouselResume = setTimeout(function() {
    annStartCarousel(track);
  }, 6000);
}

function renderAnnouncements(force) {
  var el = $("announcementsStrip");
  if (!el) return;
  if (!ANNOUNCEMENTS.length) {
    annStopCarousel();
    annRenderSig = "";
    el.hidden = true;
    el.innerHTML = "";
    return;
  }
  var sig = ANNOUNCEMENTS.map(function(a) {
    return a.id + "|" + (a.updated_at || a.created_at || "") + "|" + (a.title || "") + "|" + (a.banner_url || "");
  }).join(";");
  if (!force && sig === annRenderSig && el.firstChild) return;
  annRenderSig = sig;
  el.hidden = false;
  var slides = ANNOUNCEMENTS.map(function(a) {
    return '<button type="button" class="ann-banner" data-id="' + escapeHtml(a.id) + '"' + exploreBgStyle(a.banner_url) + ">" + '<span class="ann-banner-shade"></span>' + '<span class="ann-banner-title">' + escapeHtml(a.title || "") + "</span>" + "</button>";
  }).join("");
  var dots = ANNOUNCEMENTS.length > 1 ? '<div class="ann-dots" aria-hidden="true">' + ANNOUNCEMENTS.map(function(a, i) {
    return '<span class="ann-dot' + (i === 0 ? " active" : "") + '"></span>';
  }).join("") + "</div>" : "";
  el.innerHTML = '<div class="ann-carousel"><div class="ann-track">' + slides + "</div>" + dots + "</div>";
  var track = el.querySelector(".ann-track");
  var dragged = false;
  var drag = null;
  qsa(".ann-banner", el).forEach(function(btn) {
    btn.addEventListener("click", function(e) {
      if (dragged) {
        e.preventDefault();
        dragged = false;
        return;
      }
      openAnnouncement(btn.getAttribute("data-id"));
    });
  });
  var dotEls = qsa(".ann-dot", el);
  var raf = 0;
  track.addEventListener("scroll", function() {
    if (raf) return;
    raf = requestAnimationFrame(function() {
      raf = 0;
      var w = track.clientWidth || 1;
      var idx = Math.round(track.scrollLeft / w);
      dotEls.forEach(function(d, i) {
        d.classList.toggle("active", i === idx);
      });
    });
  }, {
    passive: true
  });
  /* Arrastre con mouse (en el celular el deslizado táctil ya funciona solo) */
  track.addEventListener("pointerdown", function(e) {
    annPauseCarousel(track);
    if (e.pointerType !== "mouse") return;
    drag = {
      x: e.clientX,
      left: track.scrollLeft
    };
    dragged = false;
    track.classList.add("dragging");
  });
  window.addEventListener("pointermove", function(e) {
    if (!drag || !track.isConnected) return;
    var dx = e.clientX - drag.x;
    if (Math.abs(dx) > 6) dragged = true;
    track.scrollLeft = drag.left - dx;
  });
  window.addEventListener("pointerup", function() {
    if (!drag) return;
    drag = null;
    track.classList.remove("dragging");
    var w = track.clientWidth || 1;
    track.scrollTo({
      left: Math.round(track.scrollLeft / w) * w,
      behavior: "smooth"
    });
    setTimeout(function() {
      dragged = false;
    }, 50);
  });
  el.addEventListener("mouseenter", function() {
    if (annCarouselTimer) clearInterval(annCarouselTimer);
    annCarouselTimer = null;
  });
  el.addEventListener("mouseleave", function() {
    annStartCarousel(track);
  });
  annStartCarousel(track);
}

function openAnnouncement(id) {
  var a = ANNOUNCEMENTS.filter(function(x) {
    return x.id === id;
  })[0];
  if (!a || typeof zSheetOpen !== "function") return;
  var when = a.created_at ? new Date(a.created_at).toLocaleDateString() : "";
  var html = '<article class="ann-post">' + (a.banner_url ? '<img class="ann-img ann-post-banner" src="' + escapeHtml(a.banner_url) + '" alt="">' : "") + '<h3 class="ann-post-title">' + escapeHtml(a.title || "") + "</h3>" + (when ? '<div class="ann-post-time">' + escapeHtml(when) + "</div>" : "") + '<div class="ann-post-body">' + announcementBodyHtml(a.body) + "</div></article>";
  zSheetOpen("Anuncio", html);
}

var annDraft = {
  bannerUrl: null,
  editingId: null
};

function annResetForm() {
  annDraft = {
    bannerUrl: null,
    editingId: null
  };
  $("annTitle").value = "";
  $("annBody").value = "";
  $("annBannerPreview").style.backgroundImage = "";
  $("annBannerPreview").classList.remove("has-image");
  $("annPublishBtn").textContent = "Publicar anuncio";
  $("annCancelEditBtn").hidden = true;
  var h = $("annFormHead");
  if (h) h.textContent = "Nuevo anuncio";
}

function annStartEdit(id) {
  var a = ANNOUNCEMENTS.filter(function(x) {
    return x.id === id;
  })[0];
  if (!a) return;
  annDraft = {
    bannerUrl: a.banner_url,
    editingId: a.id
  };
  $("annTitle").value = a.title || "";
  $("annBody").value = a.body || "";
  var pv = $("annBannerPreview");
  pv.style.backgroundImage = 'url("' + String(a.banner_url || "").replace(/"/g, "%22") + '")';
  pv.classList.toggle("has-image", !!a.banner_url);
  $("annPublishBtn").textContent = "Guardar cambios";
  $("annCancelEditBtn").hidden = false;
  var h = $("annFormHead");
  if (h) h.textContent = "Editando anuncio";
  $("annTitle").scrollIntoView({
    behavior: "smooth",
    block: "center"
  });
}

function annOpenModal() {
  if (typeof canActAsVolunteer !== "function" || !canActAsVolunteer()) return;
  annResetForm();
  $("volunteerBackdrop").classList.remove("open");
  $("announcementBackdrop").classList.add("open");
  annRenderMine();
}

function annCloseModal() {
  $("announcementBackdrop").classList.remove("open");
}

function annPickImage(file, btn) {
  if (!file) return Promise.resolve(null);
  if (file.type.indexOf("image/") !== 0) {
    toast("Elige un archivo de imagen.");
    return Promise.resolve(null);
  }
  if (file.size > 8 * 1024 * 1024) {
    toast("La imagen supera 8MB.");
    return Promise.resolve(null);
  }
  var label = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Subiendo...";
  return uploadFiles([ file ], "announcements/" + currentUser.id).then(function(up) {
    btn.disabled = false;
    btn.textContent = label;
    return up[0] ? up[0].url : null;
  }).catch(function() {
    btn.disabled = false;
    btn.textContent = label;
    toast("No se pudo subir la imagen.");
    return null;
  });
}

function annInsertAtCursor(textarea, text) {
  var start = textarea.selectionStart == null ? textarea.value.length : textarea.selectionStart;
  var end = textarea.selectionEnd == null ? start : textarea.selectionEnd;
  textarea.value = textarea.value.slice(0, start) + text + textarea.value.slice(end);
  var pos = start + text.length;
  textarea.focus();
  textarea.setSelectionRange(pos, pos);
}

function annRenderMine() {
  var wrap = $("annMineList");
  if (!wrap) return;
  loadAnnouncements().then(function() {
    var count = $("annMineCount");
    if (count) count.textContent = ANNOUNCEMENTS.length ? "(" + ANNOUNCEMENTS.length + ")" : "";
    wrap.innerHTML = ANNOUNCEMENTS.length ? ANNOUNCEMENTS.map(function(a) {
      var when = a.created_at ? new Date(a.created_at).toLocaleDateString() : "";
      return '<div class="flag-edit-row ann-mine-row" data-id="' + escapeHtml(a.id) + '">' + '<span class="ann-mine-thumb"' + exploreBgStyle(a.banner_url) + "></span>" + '<span class="ann-mine-info"><span class="ann-mine-title">' + escapeHtml(a.title || "") + '</span><span class="ann-mine-date">' + escapeHtml(when) + "</span></span>" + '<button class="icon-btn ann-edit-btn" type="button" aria-label="Editar anuncio">✎</button>' + '<button class="icon-btn ann-del-btn" type="button" aria-label="Borrar anuncio">✕</button></div>';
    }).join("") : '<p class="profile-empty-hint">Todavía no hay anuncios.</p>';
    qsa(".ann-edit-btn", wrap).forEach(function(btn) {
      btn.addEventListener("click", function() {
        annStartEdit(btn.closest("[data-id]").getAttribute("data-id"));
      });
    });
    qsa(".ann-del-btn", wrap).forEach(function(btn) {
      btn.addEventListener("click", function() {
        var id = btn.closest("[data-id]").getAttribute("data-id");
        if (!confirm("¿Borrar este anuncio?")) return;
        supabase.from("announcements").delete().eq("id", id).then(function(res) {
          if (res.error) {
            toast("No se pudo borrar el anuncio.");
            return;
          }
          toast("Anuncio borrado.");
          if (annDraft.editingId === id) annResetForm();
          annRenderMine();
        });
      });
    });
  });
}

(function wireAnnouncementUi() {
  var openBtn = $("btnOpenAnnouncements");
  if (openBtn) openBtn.addEventListener("click", annOpenModal);
  var closeBtn = $("announcementClose");
  if (closeBtn) closeBtn.addEventListener("click", annCloseModal);
  var backdrop = $("announcementBackdrop");
  if (backdrop) backdrop.addEventListener("click", function(e) {
    if (e.target === this) annCloseModal();
  });
  var bannerBtn = $("annBannerBtn");
  var bannerFile = $("annBannerFile");
  if (bannerBtn && bannerFile) {
    bannerBtn.addEventListener("click", function() {
      bannerFile.click();
    });
    bannerFile.addEventListener("change", function() {
      var f = bannerFile.files && bannerFile.files[0];
      bannerFile.value = "";
      annPickImage(f, bannerBtn).then(function(url) {
        if (!url) return;
        annDraft.bannerUrl = url;
        var pv = $("annBannerPreview");
        pv.style.backgroundImage = 'url("' + url.replace(/"/g, "%22") + '")';
        pv.classList.add("has-image");
      });
    });
  }
  var imgBtn = $("annBodyImageBtn");
  var imgFile = $("annBodyImageFile");
  if (imgBtn && imgFile) {
    imgBtn.addEventListener("click", function() {
      imgFile.click();
    });
    imgFile.addEventListener("change", function() {
      var f = imgFile.files && imgFile.files[0];
      imgFile.value = "";
      annPickImage(f, imgBtn).then(function(url) {
        if (url) annInsertAtCursor($("annBody"), "\n![](" + url + ")\n");
      });
    });
  }
  var publishBtn = $("annPublishBtn");
  if (publishBtn) publishBtn.addEventListener("click", function() {
    if (!canActAsVolunteer()) return;
    var title = $("annTitle").value.trim();
    var body = $("annBody").value.trim();
    if (!title) {
      toast("Escribe un título para el anuncio.");
      return;
    }
    if (!annDraft.bannerUrl) {
      toast("Sube un banner para el anuncio.");
      return;
    }
    publishBtn.disabled = true;
    var editingId = annDraft.editingId;
    var query = editingId ? supabase.from("announcements").update({
      title: title,
      banner_url: annDraft.bannerUrl,
      body: body,
      updated_at: new Date().toISOString()
    }).eq("id", editingId) : supabase.from("announcements").insert({
      title: title,
      banner_url: annDraft.bannerUrl,
      body: body,
      created_by: currentUser.id
    });
    query.then(function(res) {
      publishBtn.disabled = false;
      if (res.error) {
        toast(editingId ? "No se pudieron guardar los cambios." : "No se pudo publicar el anuncio.");
        return;
      }
      toast(editingId ? "Anuncio actualizado." : "Anuncio publicado. Se notificó a los usuarios.");
      annResetForm();
      annRenderMine();
    });
  });
  var cancelBtn = $("annCancelEditBtn");
  if (cancelBtn) cancelBtn.addEventListener("click", annResetForm);
})();

var announcementsChannel = null;

function subscribeAnnouncementsLive() {
  if (announcementsChannel || typeof supabase.channel !== "function") return;
  try {
    announcementsChannel = supabase.channel("announcements-live").on("postgres_changes", {
      event: "*",
      schema: "public",
      table: "announcements"
    }, function(payload) {
      loadAnnouncements();
      if (payload && payload.eventType === "INSERT" && typeof loadNotifications === "function" && typeof currentUser !== "undefined" && currentUser) {
        setTimeout(loadNotifications, 800);
      }
    }).subscribe();
  } catch (e) {
    announcementsChannel = null;
  }
}

document.addEventListener("visibilitychange", function() {
  if (!document.hidden && typeof currentUser !== "undefined" && currentUser) loadAnnouncements();
});

