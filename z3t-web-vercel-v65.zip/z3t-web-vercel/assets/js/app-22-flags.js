"use strict";

function flagTextKey(t) {
  return (t || "").toString().trim().replace(/\s+/g, " ").toLowerCase();
}

function getOrCreateFlag(text, proposedColor) {
  var key = flagTextKey(text);
  if (!key) return Promise.resolve(null);
  return supabase.from("flags").select("*").eq("text_key", key).maybeSingle().then(function(res) {
    if (res.data) {
      if (res.data.color) flagKnownColors[key] = res.data.color;
      return res.data;
    }
    return supabase.from("flags").insert({
      text_key: key,
      display_text: text.trim(),
      color: flagKnownColors[key] || proposedColor || flagRandomColor()
    }).select().single().then(function(res2) {
      if (res2.error) {
        return supabase.from("flags").select("*").eq("text_key", key).maybeSingle().then(function(res3) {
          if (res3.data && res3.data.color) flagKnownColors[key] = res3.data.color;
          return res3.data || null;
        });
      }
      if (res2.data && res2.data.color) flagKnownColors[key] = res2.data.color;
      return res2.data;
    });
  });
}

function linkFlagToEntity(flagId, entityType, entityId) {
  if (!flagId || !entityId) return Promise.resolve();
  return supabase.from("flag_links").upsert({
    flag_id: flagId,
    entity_type: entityType,
    entity_id: entityId
  }, {
    onConflict: "flag_id,entity_type,entity_id"
  }).then(function() {});
}

function tagEntityWithFlag(text, color, entityType, entityId) {
  if (!text || !text.trim() || !entityId) return Promise.resolve();
  return getOrCreateFlag(text, color).then(function(flag) {
    if (!flag) return;
    return linkFlagToEntity(flag.id, entityType, entityId);
  });
}

var flagOptionsLoaded = false;

function refreshFlagOptionsList() {
  if (flagOptionsLoaded) return;
  flagOptionsLoaded = true;
  supabase.from("flags").select("display_text").order("created_at", {
    ascending: false
  }).limit(200).then(function(res) {
    var dl = $("flagOptionsList");
    if (!dl || res.error) return;
    var seen = {};
    dl.innerHTML = (res.data || []).filter(function(f) {
      var k = flagTextKey(f.display_text);
      if (seen[k]) return false;
      seen[k] = true;
      return true;
    }).map(function(f) {
      return '<option value="' + escapeHtml(f.display_text) + '"></option>';
    }).join("");
  });
}

function flagPennantHtml(text, color) {
  var k = flagTextKey(text);
  var c = flagKnownColors[k] || color || flagColorFor(text);
  return '<span class="profile-flag-pennant flag-clickable" data-flag-text="' + escapeHtml(text || "") + '" style="' + flagChipStyle(c) + '">#' + escapeHtml(text || "") + "</span>";
}

function flagLoadColors(texts) {
  var keys = [];
  (texts || []).forEach(function(t) {
    var k = flagTextKey(t);
    if (k && keys.indexOf(k) < 0) keys.push(k);
  });
  if (!keys.length) return Promise.resolve();
  return supabase.from("flags").select("text_key, color").in("text_key", keys).then(function(res) {
    (res.error ? [] : res.data || []).forEach(function(f) {
      if (f.color) flagKnownColors[f.text_key] = f.color;
    });
  }, function() {});
}

document.addEventListener("click", function(e) {
  var el = e.target.closest ? e.target.closest(".flag-clickable") : null;
  if (!el) return;
  var text = el.getAttribute("data-flag-text");
  if (text) openFlagDetail(text);
});

var FLAG_TABS = [ {
  id: "todo",
  label: "Descubrir"
}, {
  id: "communities",
  label: "Comunidades"
}, {
  id: "publications",
  label: "Publicaciones"
}, {
  id: "frames",
  label: "Marcos"
}, {
  id: "bubbles",
  label: "Burbujas"
}, {
  id: "users",
  label: "Usuarios"
} ];

var flagDetailState = {
  text: null,
  flag: null,
  tab: "todo"
};

function openFlagDetail(text) {
  if (!text) return;
  var key = flagTextKey(text);
  flagDetailState = {
    text: text,
    flag: null,
    tab: "todo"
  };
  var titleEl = $("flagDetailTitle");
  if (titleEl) titleEl.textContent = "🚩 " + text;
  var backdrop = $("flagDetailBackdrop");
  if (!backdrop) return;
  backdrop.classList.add("open");
  document.body.classList.add("profile-open");
  renderFlagTabs();
  $("flagDetailBody").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("flags").select("*").eq("text_key", key).maybeSingle().then(function(res) {
    flagDetailState.flag = res.data || null;
    renderFlagDetailBody();
  });
}

window.openFlagDetail = openFlagDetail;

function closeFlagDetail() {
  var backdrop = $("flagDetailBackdrop");
  if (backdrop) backdrop.classList.remove("open");
  var profileBackdrop = $("profileBackdrop");
  var profileStillOpen = profileBackdrop && profileBackdrop.classList.contains("open");
  if (!profileStillOpen) document.body.classList.remove("profile-open");
}

function renderFlagTabs() {
  var wrap = $("flagDetailTabs");
  if (!wrap) return;
  wrap.innerHTML = FLAG_TABS.map(function(t) {
    return '<button type="button" class="flag-detail-tab' + (flagDetailState.tab === t.id ? " active" : "") + '" data-tab="' + t.id + '">' + t.label + "</button>";
  }).join("");
  qsa(".flag-detail-tab", wrap).forEach(function(btn) {
    btn.addEventListener("click", function() {
      flagDetailState.tab = btn.getAttribute("data-tab");
      renderFlagTabs();
      renderFlagDetailBody();
    });
  });
}

function flagLinkedRows(entityType, table, select) {
  if (!flagDetailState.flag) return Promise.resolve([]);
  return supabase.from("flag_links").select("entity_id").eq("flag_id", flagDetailState.flag.id).eq("entity_type", entityType).then(function(res) {
    var ids = (res.data || []).map(function(r) {
      return r.entity_id;
    });
    if (!ids.length) return [];
    return supabase.from(table).select(select).in("id", ids).then(function(res2) {
      return res2.error ? [] : res2.data || [];
    });
  });
}

function flagUsers() {
  if (!flagDetailState.flag) return Promise.resolve([]);
  return supabase.from("profile_flags").select("profiles(id, username, name, avatar_url)").eq("flag_id", flagDetailState.flag.id).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    var seen = {};
    return rows.map(function(r) {
      return r.profiles;
    }).filter(function(p) {
      if (!p || seen[p.id]) return false;
      seen[p.id] = true;
      return true;
    });
  });
}

function flagCircles() {
  return flagLinkedRows("circle", "circles", "id, slug, name, icon_url");
}

function flagCommunities() {
  return flagLinkedRows("community", "communities", "id, slug, name, banner_url");
}

function flagPublications() {
  return flagLinkedRows("publication", "threads", "id, slug, title, excerpt, cover_image_url");
}

function flagFrames() {
  return flagLinkedRows("frame", "frames", "id, name, thumbnail_url");
}

function flagBubbles() {
  return flagLinkedRows("bubble", "chat_bubbles", "id, name, thumbnail_url");
}

function flagCarouselHtml(kind, items) {
  if (!items.length) return "";
  var cards = items.map(function(it) {
    return flagCardHtml(kind, it);
  }).join("");
  return '<div class="flag-carousel-row">' + cards + "</div>";
}

function flagCardHtml(kind, it) {
  if (kind === "users") {
    return '<button type="button" class="flag-card" data-open="user" data-uid="' + escapeHtml(it.id) + '">' + avatarSpanHtml(it.username, it.avatar_url, null) + '<span class="flag-card-name">@' + escapeHtml(it.username || "") + "</span>" + "</button>";
  }
  if (kind === "circles") {
    return '<button type="button" class="flag-card" data-open="circle" data-slug="' + escapeHtml(it.slug) + '">' + avatarSpanHtml(it.name, it.icon_url, null) + '<span class="flag-card-name">' + escapeHtml(it.name || "") + "</span>" + "</button>";
  }
  if (kind === "communities") {
    return '<button type="button" class="flag-card" data-open="community" data-slug="' + escapeHtml(it.slug) + '">' + avatarSpanHtml(it.name, it.banner_url, null) + '<span class="flag-card-name">' + escapeHtml(it.name || "") + "</span>" + "</button>";
  }
  if (kind === "frames" || kind === "bubbles") {
    return '<button type="button" class="flag-card" data-open="' + (kind === "frames" ? "frame" : "bubble") + '" data-id="' + escapeHtml(it.id) + '">' + '<span class="flag-card-thumb" style="background-image:url(&quot;' + escapeHtml(it.thumbnail_url || "") + '&quot;)"></span>' + '<span class="flag-card-name">' + escapeHtml(it.name || "") + "</span>" + "</button>";
  }
  return "";
}

function flagPublicationsListHtml(items) {
  if (!items.length) return "";
  return '<div class="flag-pub-list">' + items.map(function(t) {
    return '<button type="button" class="flag-pub-row" data-open="publication" data-id="' + escapeHtml(t.id) + '">' + (t.cover_image_url ? '<span class="flag-pub-thumb" style="background-image:url(&quot;' + escapeHtml(t.cover_image_url) + '&quot;)"></span>' : "") + '<span class="flag-pub-text"><span class="flag-pub-title">' + escapeHtml(t.title || "") + "</span>" + '<span class="flag-pub-excerpt">' + escapeHtml(t.excerpt || "") + "</span></span>" + "</button>";
  }).join("") + "</div>";
}

function flagSectionHtml(title, innerHtml) {
  if (!innerHtml) return "";
  return '<div class="flag-section"><h4 class="flag-section-title">' + title + "</h4>" + innerHtml + "</div>";
}

function flagEmptyHtml() {
  return '<p class="profile-empty-hint">Todavía no hay nada con esta bandera.</p>';
}

function wireFlagCardOpens(container) {
  qsa(".flag-card, .flag-pub-row", container).forEach(function(el) {
    el.addEventListener("click", function() {
      closeFlagDetail();
      var kind = el.getAttribute("data-open");
      if (kind === "user" && typeof openProfile === "function") openProfile(el.getAttribute("data-uid")); else if (kind === "circle" && typeof openCircle === "function") openCircle(el.getAttribute("data-slug")); else if (kind === "community" && typeof openCommunity === "function") openCommunity(el.getAttribute("data-slug")); else if (kind === "publication" && typeof openThread === "function") openThread(el.getAttribute("data-id")); else if (kind === "frame" && typeof openStoreFrameById === "function") openStoreFrameById(el.getAttribute("data-id")); else if (kind === "bubble" && typeof openStoreBubbleById === "function") openStoreBubbleById(el.getAttribute("data-id"));
    });
  });
}

function renderFlagDetailBody() {
  var body = $("flagDetailBody");
  if (!body) return;
  if (!flagDetailState.flag) {
    body.innerHTML = flagEmptyHtml();
    return;
  }
  var tab = flagDetailState.tab;
  body.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  if (tab === "todo") {
    Promise.all([ flagUsers(), flagCircles(), flagCommunities(), flagPublications() ]).then(function(results) {
      var html = flagSectionHtml("Usuarios", flagCarouselHtml("users", results[0])) + flagSectionHtml("Círculos", flagCarouselHtml("circles", results[1])) + flagSectionHtml("Comunidades", flagCarouselHtml("communities", results[2])) + flagSectionHtml("Publicaciones", flagPublicationsListHtml(results[3]));
      body.innerHTML = html || flagEmptyHtml();
      wireFlagCardOpens(body);
    });
  } else if (tab === "communities") {
    flagCommunities().then(function(rows) {
      body.innerHTML = rows.length ? '<div class="flag-grid">' + rows.map(function(c) {
        return flagCardHtml("communities", c);
      }).join("") + "</div>" : flagEmptyHtml();
      wireFlagCardOpens(body);
    });
  } else if (tab === "publications") {
    flagPublications().then(function(rows) {
      body.innerHTML = rows.length ? flagPublicationsListHtml(rows) : flagEmptyHtml();
      wireFlagCardOpens(body);
    });
  } else if (tab === "frames") {
    flagFrames().then(function(rows) {
      body.innerHTML = rows.length ? '<div class="flag-grid">' + rows.map(function(f) {
        return flagCardHtml("frames", f);
      }).join("") + "</div>" : flagEmptyHtml();
      wireFlagCardOpens(body);
    });
  } else if (tab === "bubbles") {
    flagBubbles().then(function(rows) {
      body.innerHTML = rows.length ? '<div class="flag-grid">' + rows.map(function(b) {
        return flagCardHtml("bubbles", b);
      }).join("") + "</div>" : flagEmptyHtml();
      wireFlagCardOpens(body);
    });
  } else if (tab === "users") {
    flagUsers().then(function(rows) {
      body.innerHTML = rows.length ? '<div class="flag-grid">' + rows.map(function(p) {
        return flagCardHtml("users", p);
      }).join("") + "</div>" : flagEmptyHtml();
      wireFlagCardOpens(body);
    });
  }
}

var flagDetailCloseEl = $("flagDetailClose");

if (flagDetailCloseEl) flagDetailCloseEl.addEventListener("click", closeFlagDetail);

var flagDetailBackdropEl = $("flagDetailBackdrop");

if (flagDetailBackdropEl) flagDetailBackdropEl.addEventListener("click", function(e) {
  if (e.target === this) closeFlagDetail();
});

var FLAG_PALETTE = [ "#3b82f6", "#ef4444", "#f5b301", "#fb923c", "#a855f7", "#ec4899", "#22c55e", "#06b6d4", "#14b8a6", "#84cc16", "#6366f1", "#f43f5e", "#d946ef", "#0ea5e9", "#eab308" ];

function flagRandomColor() {
  return FLAG_PALETTE[Math.floor(Math.random() * FLAG_PALETTE.length)];
}

function flagChipStyle(c) {
  return "color:" + c + ";border-color:" + hexToRgba(c, .75) + ";background:" + hexToRgba(c, .14) + ";box-shadow:0 0 10px " + hexToRgba(c, .28) + ", inset 0 0 8px " + hexToRgba(c, .12) + ";";
}

var FLAG_DEFAULT_MAX = 10;

var flagKnownColors = {};

function flagColorFor(text) {
  var key = flagTextKey(text);
  if (flagKnownColors[key]) return flagKnownColors[key];
  flagKnownColors[key] = flagRandomColor();
  return flagKnownColors[key];
}

function flagClean(text) {
  return (text || "").toString().replace(/^#+/, "").replace(/\s+/g, " ").trim().slice(0, 24);
}

var flagFieldState = {};

var flagFieldHandlers = {};

var flagFieldMax = {};

function flagChipsHtml(list) {
  return list.map(function(txt) {
    var c = flagColorFor(txt);
    return '<span class="flag-field-chip" style="' + flagChipStyle(c) + '">#' + escapeHtml(txt) + "</span>";
  }).join("");
}

function flagFieldPreviewHtml(list) {
  return list && list.length ? flagChipsHtml(list) : '<span class="flag-field-empty">Banderas</span>';
}

function flagFieldHtml(id, label) {
  return '<div class="field flag-field"><span>' + escapeHtml(label || "Banderas") + "</span>" + '<button type="button" class="flag-field-btn" data-flag-field="' + escapeHtml(id) + '">' + '<span class="flag-field-preview">' + flagFieldPreviewHtml(flagFieldState[id] || []) + "</span>" + '<span class="flag-field-plus">+</span></button></div>';
}

function flagFieldSet(id, list) {
  flagFieldState[id] = (list || []).slice();
  qsa('[data-flag-field="' + id + '"] .flag-field-preview').forEach(function(el) {
    el.innerHTML = flagFieldPreviewHtml(flagFieldState[id]);
  });
}

function flagFieldGet(id) {
  return (flagFieldState[id] || []).slice();
}

document.addEventListener("click", function(e) {
  var btn = e.target.closest ? e.target.closest("[data-flag-field]") : null;
  if (!btn) return;
  var id = btn.getAttribute("data-flag-field");
  openFlagPicker({
    initial: flagFieldGet(id),
    max: flagFieldMax[id] || FLAG_DEFAULT_MAX,
    onDone: function(list) {
      flagFieldSet(id, list);
      if (flagFieldHandlers[id]) flagFieldHandlers[id](list);
    }
  });
});

function tagEntityWithFlags(list, entityType, entityId) {
  return Promise.all((list || []).map(function(txt) {
    return tagEntityWithFlag(txt, flagColorFor(txt), entityType, entityId);
  }));
}

function loadEntityFlagTexts(entityType, entityId) {
  return supabase.from("flag_links").select("id, flags(id, display_text, color)").eq("entity_type", entityType).eq("entity_id", entityId).then(function(res) {
    return (res.error ? [] : res.data || []).filter(function(r) {
      return r.flags;
    });
  });
}

function syncEntityFlags(entityType, entityId, list) {
  var wanted = {};
  (list || []).forEach(function(txt) {
    wanted[flagTextKey(txt)] = txt;
  });
  return loadEntityFlagTexts(entityType, entityId).then(function(rows) {
    var have = {};
    var removals = [];
    rows.forEach(function(r) {
      var k = flagTextKey(r.flags.display_text);
      have[k] = true;
      if (!wanted[k]) removals.push(r.id);
    });
    var adds = Object.keys(wanted).filter(function(k) {
      return !have[k];
    }).map(function(k) {
      return wanted[k];
    });
    var jobs = [];
    if (removals.length) jobs.push(supabase.from("flag_links").delete().in("id", removals));
    jobs.push(tagEntityWithFlags(adds, entityType, entityId));
    return Promise.all(jobs);
  });
}

function syncProfileFlags(uid, list) {
  return supabase.from("profile_flags").select("*").eq("user_id", uid).order("position").then(function(res) {
    var rows = res.error ? [] : res.data || [];
    var wanted = {};
    list.forEach(function(txt) {
      wanted[flagTextKey(txt)] = txt;
    });
    var have = {};
    var usedPos = {};
    var removeIds = [];
    rows.forEach(function(r) {
      var k = flagTextKey(r.text);
      if (wanted[k] && !have[k]) {
        have[k] = true;
        usedPos[r.position] = true;
      } else removeIds.push(r.id);
    });
    var jobs = [];
    if (removeIds.length) jobs.push(supabase.from("profile_flags").delete().in("id", removeIds));
    var pos = 0;
    var toAdd = [];
    list.forEach(function(txt) {
      if (have[flagTextKey(txt)]) return;
      while (usedPos[pos]) pos++;
      usedPos[pos] = true;
      toAdd.push({
        text: txt,
        position: pos
      });
    });
    return Promise.all(toAdd.map(function(a) {
      return getOrCreateFlag(a.text, flagKnownColors[flagTextKey(a.text)]).then(function(f) {
        return {
          user_id: uid,
          text: a.text,
          color: f && f.color ? f.color : flagColorFor(a.text),
          position: a.position
        };
      });
    })).then(function(inserts) {
      if (inserts.length) jobs.push(supabase.from("profile_flags").insert(inserts));
      return Promise.all(jobs);
    }).then(function(results) {
      results.forEach(function(r) {
        if (r && r.error) throw r.error;
      });
    });
  });
}

var flagTopCache = {
  at: 0,
  data: null
};

function loadTopFlags() {
  if (flagTopCache.data && Date.now() - flagTopCache.at < 6e4) return Promise.resolve(flagTopCache.data);
  return Promise.all([ supabase.from("flags").select("id, display_text, color").limit(1000), supabase.from("flag_links").select("flag_id").limit(5000), supabase.from("profile_flags").select("text").limit(5000) ]).then(function(r) {
    var flags = r[0].error ? [] : r[0].data || [];
    var links = r[1].error ? [] : r[1].data || [];
    var profs = r[2].error ? [] : r[2].data || [];
    var byId = {};
    var byKey = {};
    flags.forEach(function(f) {
      var k = flagTextKey(f.display_text);
      if (!k) return;
      if (f.color) flagKnownColors[k] = f.color;
      byId[f.id] = k;
      if (!byKey[k]) byKey[k] = {
        text: flagClean(f.display_text),
        count: 0
      };
    });
    links.forEach(function(l) {
      var k = byId[l.flag_id];
      if (k) byKey[k].count++;
    });
    profs.forEach(function(p) {
      var k = flagTextKey(p.text);
      if (!k) return;
      if (!byKey[k]) byKey[k] = {
        text: flagClean(p.text),
        count: 0
      };
      byKey[k].count++;
    });
    var list = Object.keys(byKey).map(function(k) {
      return byKey[k];
    }).filter(function(x) {
      return x.text;
    }).sort(function(a, b) {
      return b.count - a.count || a.text.localeCompare(b.text);
    }).slice(0, 80);
    flagTopCache = {
      at: Date.now(),
      data: list
    };
    return list;
  }).catch(function() {
    return [];
  });
}

var flagPicker = null;

function flagPickerEnsure() {
  if (flagPicker && document.body.contains(flagPicker.root)) return flagPicker;
  var root = document.createElement("div");
  root.className = "flag-picker";
  root.id = "flagPicker";
  root.innerHTML = '<div class="flag-picker-head">' + '<button type="button" class="flag-picker-x" aria-label="Cerrar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></svg></button>' + "<h3>Editar Etiquetas</h3>" + '<button type="button" class="flag-picker-ok" aria-label="Listo"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 12 10 18 20 6"/></svg></button>' + "</div>" + '<div class="flag-picker-scroll">' + '<div class="flag-picker-chips" id="fpChips"></div>' + '<div class="flag-picker-sub">Más usadas</div>' + '<div class="flag-picker-list" id="fpList"></div>' + "</div>";
  document.body.appendChild(root);
  flagPicker = {
    root: root,
    chips: root.querySelector("#fpChips"),
    list: root.querySelector("#fpList"),
    selected: [],
    max: FLAG_DEFAULT_MAX,
    adding: false,
    top: [],
    onDone: null
  };
  var P = flagPicker;
  root.querySelector(".flag-picker-x").addEventListener("click", flagPickerClose);
  root.querySelector(".flag-picker-ok").addEventListener("click", function() {
    flagPickerCommitInput();
    var cb = P.onDone;
    var out = P.selected.slice();
    flagPickerClose();
    if (cb) cb(out);
  });
  P.chips.addEventListener("click", function(e) {
    var rm = e.target.closest("[data-rm]");
    if (rm) {
      P.selected.splice(parseInt(rm.getAttribute("data-rm"), 10), 1);
      flagPickerRender();
      return;
    }
    if (e.target.closest(".fp-add") && !P.adding) {
      P.adding = true;
      flagPickerRenderChips();
      var inp = $("fpInput");
      if (inp) inp.focus();
    }
  });
  P.chips.addEventListener("keydown", function(e) {
    if (e.target.id !== "fpInput") return;
    if (e.key === "Enter") {
      e.preventDefault();
      flagPickerCommitInput();
      flagPickerRender();
      var inp = $("fpInput");
      if (inp) inp.focus();
    }
  });
  P.chips.addEventListener("input", function(e) {
    if (e.target.id === "fpInput") flagPickerRenderList();
  });
  P.list.addEventListener("click", function(e) {
    var row = e.target.closest("[data-fp]");
    if (!row) return;
    var txt = row.getAttribute("data-fp");
    var k = flagTextKey(txt);
    var idx = P.selected.map(flagTextKey).indexOf(k);
    if (idx >= 0) P.selected.splice(idx, 1); else flagPickerAdd(txt);
    flagPickerRender();
  });
  return flagPicker;
}

function flagPickerAdd(raw) {
  var P = flagPicker;
  var txt = flagClean(raw);
  if (!txt) return false;
  var k = flagTextKey(txt);
  if (P.selected.map(flagTextKey).indexOf(k) >= 0) return false;
  if (P.selected.length >= P.max) {
    toast("Máximo " + P.max + " banderas.");
    return false;
  }
  P.selected.push(txt);
  return true;
}

function flagPickerCommitInput() {
  var inp = $("fpInput");
  if (inp && inp.value.trim()) {
    flagPickerAdd(inp.value);
    inp.value = "";
  }
}

function flagPickerRenderChips() {
  var P = flagPicker;
  var keep = $("fpInput") ? $("fpInput").value : "";
  P.chips.innerHTML = P.selected.map(function(txt, i) {
    var c = flagColorFor(txt);
    return '<button type="button" class="fp-chip" data-rm="' + i + '" style="' + flagChipStyle(c) + '" aria-label="Quitar ' + escapeHtml(txt) + '">#' + escapeHtml(txt) + "</button>";
  }).join("") + (P.adding ? '<span class="fp-chip fp-add fp-add-open"><input type="text" id="fpInput" maxlength="24" placeholder="Escribe tu bandera" autocomplete="off" value="' + escapeHtml(keep) + '"></span>' : '<button type="button" class="fp-chip fp-add" aria-label="Agregar bandera">+</button>');
}

function flagPickerRenderList() {
  var P = flagPicker;
  var q = flagTextKey(($("fpInput") || {}).value || "").replace(/^#+/, "");
  var chosen = P.selected.map(flagTextKey);
  var rows = P.top.filter(function(f) {
    return !q || flagTextKey(f.text).indexOf(q) >= 0;
  });
  if (P.loading) {
    P.list.innerHTML = '<p class="fp-empty">Cargando...</p>';
    return;
  }
  if (!rows.length) {
    P.list.innerHTML = '<p class="fp-empty">' + (q ? "No hay coincidencias. Presiona Enter para crear \"" + escapeHtml(q) + '".' : "Todavía no hay banderas. Crea la primera con el +.") + "</p>";
    return;
  }
  P.list.innerHTML = rows.map(function(f) {
    var on = chosen.indexOf(flagTextKey(f.text)) >= 0;
    return '<button type="button" class="fp-row' + (on ? " selected" : "") + '" data-fp="' + escapeHtml(f.text) + '">' + '<span class="fp-row-name">' + escapeHtml(f.text) + "</span>" + (f.count ? '<span class="fp-row-count">' + f.count + " usos</span>" : "") + '<span class="fp-row-plus">' + (on ? "✓" : "+") + "</span></button>";
  }).join("");
}

function flagPickerRender() {
  flagPickerRenderChips();
  flagPickerRenderList();
}

function flagPickerClose() {
  if (!flagPicker) return;
  flagPicker.root.classList.remove("open");
  document.body.classList.remove("flag-picker-open");
}

function openFlagPicker(opts) {
  var P = flagPickerEnsure();
  P.selected = (opts.initial || []).map(flagClean).filter(Boolean);
  P.max = opts.max || FLAG_DEFAULT_MAX;
  P.onDone = opts.onDone || null;
  P.adding = false;
  P.loading = true;
  P.top = flagTopCache.data || [];
  P.loading = !P.top.length;
  flagPickerRender();
  P.root.classList.add("open");
  document.body.classList.add("flag-picker-open");
  loadTopFlags().then(function(list) {
    P.top = list;
    P.loading = false;
    flagPickerRenderList();
  });
}

window.openFlagPicker = openFlagPicker;
