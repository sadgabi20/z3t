"use strict";

var COMMUNITY_TAGS = [ {
  id: "popular",
  label: "Popular",
  icon: "🔥",
  kind: "sort"
}, {
  id: "recientes",
  label: "Recientes",
  icon: "🆕",
  kind: "sort"
}, {
  id: "roleplay",
  label: "Roleplay",
  icon: "🎭",
  kind: "tag"
}, {
  id: "anime",
  label: "Anime & Manga",
  icon: "🌸",
  kind: "tag"
}, {
  id: "charla",
  label: "Charla libre",
  icon: "☕",
  kind: "tag"
}, {
  id: "arte",
  label: "Arte y estética",
  icon: "🎨",
  kind: "tag"
}, {
  id: "relaciones",
  label: "Relaciones",
  icon: "❤️",
  kind: "tag"
}, {
  id: "canto",
  label: "Canto",
  icon: "🎤",
  kind: "tag"
}, {
  id: "escuela",
  label: "Escuela",
  icon: "🏫",
  kind: "tag"
}, {
  id: "hobbies",
  label: "Hobbies",
  icon: "🧩",
  kind: "tag"
}, {
  id: "lgbtq",
  label: "LGBTQ+",
  icon: "🏳️‍🌈",
  kind: "tag"
}, {
  id: "amigos",
  label: "Hacer amigos",
  icon: "🧑‍🤝‍🧑",
  kind: "tag"
}, {
  id: "general",
  label: "General",
  icon: "✺",
  kind: "tag"
} ];

var COMMUNITY_TAG_MAP = COMMUNITY_TAGS.reduce(function(m, t) {
  m[t.id] = t;
  return m;
}, {});

var COMMUNITY_ACTIVITY_BADGES = {
  voice: {
    icon: "assets/icons/activities/voice-chat.webp",
    label: "En vivo: chat de voz"
  },
  cinema: {
    icon: "assets/icons/activities/cinema.png",
    label: "En vivo: Sala de Cine"
  },
  roleplay: {
    icon: "assets/icons/activities/roleplay.webp",
    label: "En vivo: Roleplay"
  }
};

window.activityIconHtml = function activityIconHtml(kind, extraClass) {
  var info = COMMUNITY_ACTIVITY_BADGES[kind];
  if (!info) return "";
  return '<img loading=lazy decoding=async class="icon-inline' + (extraClass ? " " + extraClass : "") + '" src="' + info.icon + '" alt="">';
};

function communityActivityBadgeHtml(c) {
  var info = c.active_activity ? COMMUNITY_ACTIVITY_BADGES[c.active_activity] : null;
  if (!info) return "";
  return '<div class="community-activity-badge community-activity-badge--' + c.active_activity + '" title="' + escapeHtml(info.label) + '">' + '<img loading=lazy decoding=async class="community-activity-badge-icon" src="' + info.icon + '" alt="">' + '<span class="community-activity-badge-pulse"></span>' + "</div>";
}

var communityFilter = "popular";

var COMMUNITIES = [];

var currentCommunity = null;

var communityMembers = [];

var COMMUNITY_MESSAGES = [];

var communityMessagesPollTimer = null;

var communityAdminPresenceTimer = null;

var communityActivityStatePollTimer = null;

function pollCommunityActivityState() {
  if (!currentCommunity) return;
  var id = currentCommunity.id;
  supabase.from("communities").select("active_activity, cinema_video_url, cinema_video_type, cinema_is_playing, cinema_position_seconds, cinema_updated_at").eq("id", id).single().then(function(res) {
    if (res.error || !res.data || !currentCommunity || currentCommunity.id !== id) return;
    var changed = res.data.active_activity !== currentCommunity.active_activity;
    var cinemaChanged = res.data.cinema_updated_at !== currentCommunity.cinema_updated_at;
    Object.keys(res.data).forEach(function(k) {
      currentCommunity[k] = res.data[k];
    });
    if (changed) {
      renderCommunityDetail();
      voiceChatActive = !!(currentCommunity && currentCommunity.voice_active);
      renderVoiceBar();
      if (typeof ciAutoListen === "function") ciAutoListen();
    } else if (cinemaChanged && typeof pollCommunityCinemaState === "function") {
      pollCommunityCinemaState();
    }
  });
}

function touchCommunityAdminPresence() {
  if (!currentCommunity || !currentUser) return;
  var mine = communityMembers.filter(function(m) {
    return m.user_id === currentUser.id;
  })[0];
  if (!mine || mine.role !== "admin" && mine.role !== "co_admin") return;
  supabase.rpc("touch_community_admin_presence", {
    p_community_id: currentCommunity.id
  }).then(function() {});
}

var CUY_DAILY_LIMIT = 10;

var CUY_COOLDOWNS = [ 5, 4, 3, 2, 1 ];

var communityCuyTapsToday = 0;

var communityCuyCooldownTimer = null;

var CUY_STATE_IMG = {
  active: "assets/cuy/state-active.webp",
  waiting: "assets/cuy/state-waiting.webp",
  disabled: "assets/cuy/state-disabled.webp"
};

var CUY_PARTICLE_GLYPHS = [ "assets/cuy/particle-snow.webp", "assets/cuy/particle-rabbit.webp", "assets/cuy/particle-moon.webp", "assets/cuy/particle-chicken.webp", "assets/cuy/particle-apple.webp", "assets/cuy/particle-heart.webp", "assets/cuy/particle-miss.webp" ];

var CUY_QI_GLYPHS = [ "assets/cuy/qi-1.webp", "assets/cuy/qi-3.webp", "assets/cuy/qi-4.webp", "assets/cuy/qi-5.webp" ];

function loadCommunities() {
  return supabase.from("communities").select("*").eq("region", currentUser && currentUser.region || "LATAM").then(function(res) {
    if (res.error) {
      toast(t("community.err_load_list"));
      return;
    }
    COMMUNITIES = res.data || [];
    renderCommunityTagPills();
    renderTopCommunitiesStrip();
    var cids = COMMUNITIES.map(function(c) {
      return c.id;
    });
    return Promise.all([ loadCommunityPreviewMembers(cids), loadCommunityFirstFlags(cids) ]);
  }).then(function() {
    renderCommunityGrid();
  });
}

var communityActivityBadgePollTimer = null;

function refreshCommunityActivityBadges() {
  if (!COMMUNITIES.length) return;
  var ids = COMMUNITIES.map(function(c) {
    return c.id;
  });
  supabase.from("communities").select("id, active_activity").in("id", ids).then(function(res) {
    if (res.error || !res.data) return;
    var byId = {};
    res.data.forEach(function(row) {
      byId[row.id] = row.active_activity;
    });
    var changed = false;
    COMMUNITIES.forEach(function(c) {
      if (byId.hasOwnProperty(c.id) && byId[c.id] !== c.active_activity) {
        c.active_activity = byId[c.id];
        changed = true;
      }
    });
    if (changed) {
      renderTopCommunitiesStrip();
      renderCommunityGrid();
    }
  });
}

function startCommunityActivityBadgePolling() {
  stopCommunityActivityBadgePolling();
  communityActivityBadgePollTimer = setInterval(function() {
    if (!document.hidden) refreshCommunityActivityBadges();
  }, 6e4);
}

function stopCommunityActivityBadgePolling() {
  if (communityActivityBadgePollTimer) {
    clearInterval(communityActivityBadgePollTimer);
    communityActivityBadgePollTimer = null;
  }
}

var COMMUNITY_PREVIEW_MEMBERS = {};

function loadCommunityPreviewMembers(ids) {
  COMMUNITY_PREVIEW_MEMBERS = {};
  if (!ids || !ids.length) return Promise.resolve();
  return supabase.from("community_members").select("community_id, user_id, joined_at, profiles(username, avatar_url)").in("community_id", ids).order("joined_at", {
    ascending: false
  }).then(function(res) {
    if (res.error || !res.data) return;
    res.data.forEach(function(row) {
      var list = COMMUNITY_PREVIEW_MEMBERS[row.community_id] || (COMMUNITY_PREVIEW_MEMBERS[row.community_id] = []);
      if (list.length < 4) {
        list.push({
          uid: row.user_id,
          username: row.profiles ? row.profiles.username : "usuario",
          avatar_url: row.profiles ? row.profiles.avatar_url : null
        });
      }
    });
  });
}

var COMMUNITY_FIRST_FLAG = {};

function loadCommunityFirstFlags(ids) {
  COMMUNITY_FIRST_FLAG = {};
  if (!ids || !ids.length) return Promise.resolve();
  return supabase.from("flag_links").select("*, flags(display_text, text_key, color)").eq("entity_type", "community").in("entity_id", ids).then(function(res) {
    if (res.error || !res.data) return;
    var byCommunity = {};
    res.data.forEach(function(row) {
      if (!row.flags || !row.flags.display_text) return;
      (byCommunity[row.entity_id] = byCommunity[row.entity_id] || []).push(row);
    });
    Object.keys(byCommunity).forEach(function(cid) {
      var rows = byCommunity[cid];
      /* "la primera bandera" = la vinculada antes (created_at si existe, si no el id) */
      rows.sort(function(a, b) {
        if (a.created_at && b.created_at) return new Date(a.created_at) - new Date(b.created_at);
        if (typeof a.id === "number" && typeof b.id === "number") return a.id - b.id;
        return 0;
      });
      var f = rows[0].flags;
      COMMUNITY_FIRST_FLAG[cid] = {
        text: f.display_text,
        color: f.color || null
      };
    });
  }, function() {});
}

function z3tCompactCount(n) {
  n = Number(n) || 0;
  if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(/\.0$/, "") + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(n >= 1e4 ? 0 : 1).replace(/\.0$/, "") + "K";
  return String(n);
}

var LIVE_PARTIES_TAGS = [ {
  id: "all",
  label: "Todas"
}, {
  id: "roleplay",
  label: "Role play"
}, {
  id: "charla",
  label: "Conversaciones"
}, {
  id: "anime",
  label: "Anime y manga"
}, {
  id: "hobbies",
  label: "Juegos"
} ];

var livePartiesFilter = "all";

function renderTopCommunitiesStrip() {
  var el = $("topCommunitiesStrip");
  if (!el) return;
  if (!COMMUNITIES.length) {
    el.hidden = true;
    el.innerHTML = "";
    return;
  }
  el.hidden = false;
  var pool = livePartiesFilter === "all" ? COMMUNITIES.slice() : COMMUNITIES.filter(function(c) {
    return c.tag === livePartiesFilter;
  });
  var top = pool.sort(function(a, b) {
    return (b.cuy_count || 0) - (a.cuy_count || 0);
  }).slice(0, 4);
  var tagsHtml = LIVE_PARTIES_TAGS.map(function(t, i) {
    var sep = i > 0 ? '<span class="live-parties-tag-sep">•</span>' : "";
    return sep + '<button type="button" class="live-parties-tag' + (livePartiesFilter === t.id ? " active" : "") + '" data-tag="' + t.id + '">' + escapeHtml(t.label) + "</button>";
  }).join("");
  var cardsHtml = top.length ? top.map(function(c) {
    var bannerStyle = c.banner_url ? ' style="background-image:url(&quot;' + encodeURI(c.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
    var fallback = c.banner_url ? "" : '<span class="live-party-fallback">' + escapeHtml((c.name || "?").charAt(0).toUpperCase()) + "</span>";
    return '<div class="live-party-card" data-slug="' + escapeHtml(c.slug) + '">' + '<div class="live-party-thumb"' + bannerStyle + ">" + fallback + communityActivityBadgeHtml(c) + "</div>" + '<div class="live-party-name">' + escapeHtml(c.name) + "</div>" + "</div>";
  }).join("") : '<div class="live-parties-empty">Todavía no hay comunidades en esta categoría.</div>';
  el.innerHTML = '<div class="live-parties-card">' + '<div class="live-parties-head" id="livePartiesOpenAll" role="button" tabindex="0"><span class="live-parties-icon">🎉</span><span class="live-parties-title">Fiestas en vivo</span><span class="live-parties-chevron">›</span></div>' + '<div class="live-parties-tags">' + tagsHtml + "</div>" + '<div class="live-parties-row">' + cardsHtml + "</div>" + "</div>";
  var openAllEl = $("livePartiesOpenAll");
  if (openAllEl) {
    openAllEl.addEventListener("click", function() {
      showCommunitiesList();
    });
    openAllEl.addEventListener("keydown", function(e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        showCommunitiesList();
      }
    });
  }
  qsa(".live-parties-tag", el).forEach(function(btn) {
    btn.addEventListener("click", function() {
      livePartiesFilter = btn.getAttribute("data-tag");
      renderTopCommunitiesStrip();
    });
  });
  qsa(".live-party-card", el).forEach(function(cardEl) {
    cardEl.addEventListener("click", function() {
      openCommunity(cardEl.getAttribute("data-slug"));
    });
  });
}

function renderCommunityTagPills() {
  var wrap = $("communityTagPills");
  wrap.innerHTML = COMMUNITY_TAGS.map(function(t) {
    return '<button class="community-tag-pill' + (communityFilter === t.id ? " active" : "") + '" data-tag="' + t.id + '" type="button">' + t.icon + " " + escapeHtml(t.label) + "</button>";
  }).join("");
  qsa(".community-tag-pill", wrap).forEach(function(btn) {
    btn.addEventListener("click", function() {
      communityFilter = btn.getAttribute("data-tag");
      renderCommunityTagPills();
      renderCommunityGrid();
    });
  });
}

function renderCommunityGrid() {
  var grid = $("communityGrid");
  var list = COMMUNITIES.slice();
  if (communityFilter === "popular") {
    list.sort(function(a, b) {
      return (b.cuy_count || 0) - (a.cuy_count || 0);
    });
  } else if (communityFilter === "recientes") {
    list.sort(function(a, b) {
      return new Date(b.created_at) - new Date(a.created_at);
    });
  } else {
    list = list.filter(function(c) {
      return c.tag === communityFilter;
    });
    list.sort(function(a, b) {
      return (b.cuy_count || 0) - (a.cuy_count || 0);
    });
  }
  $("communityEmpty").hidden = list.length > 0;
  grid.innerHTML = list.map(function(c) {
    var tagInfo = COMMUNITY_TAG_MAP[c.tag];
    var tagLabel = tagInfo ? tagInfo.label : "General";
    var bgStyle = c.banner_url ? ' style="background-image:url(&quot;' + encodeURI(c.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
    var fallback = c.banner_url ? "" : '<span class="cc-fallback">' + escapeHtml((c.name || "?").charAt(0).toUpperCase()) + "</span>";
    var firstFlag = COMMUNITY_FIRST_FLAG[c.id] || null;
    var flagText = firstFlag ? firstFlag.text : tagLabel;
    var flagColor = firstFlag ? firstFlag.color || (typeof flagColorFor === "function" ? flagColorFor(firstFlag.text) : "#f0ab54") : "#f0ab54";
    var flagStyle = typeof flagChipStyle === "function" ? flagChipStyle(flagColor) : "";
    var previewMembers = COMMUNITY_PREVIEW_MEMBERS[c.id] || [];
    var avatarsHtml = previewMembers.slice(0, 4).map(function(m, i) {
      var av = avatarSpanHtml(m.username, m.avatar_url, "cc-avatar", m.uid);
      if (i === 3) return '<span class="cc-avatar-wrap cc-avatar-more">' + av + '<span class="cc-avatar-dots">···</span></span>';
      return '<span class="cc-avatar-wrap">' + av + "</span>";
    }).join("");
    var avatarsBlock = avatarsHtml ? '<div class="cc-avatars">' + avatarsHtml + "</div>" : "";
    var sunSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4.2" fill="currentColor"/><line x1="12" y1="2" x2="12" y2="4.6"/><line x1="12" y1="19.4" x2="12" y2="22"/><line x1="2" y1="12" x2="4.6" y2="12"/><line x1="19.4" y1="12" x2="22" y2="12"/><line x1="4.9" y1="4.9" x2="6.7" y2="6.7"/><line x1="17.3" y1="17.3" x2="19.1" y2="19.1"/><line x1="4.9" y1="19.1" x2="6.7" y2="17.3"/><line x1="17.3" y1="6.7" x2="19.1" y2="4.9"/></svg>';
    return '<div class="community-card cc2" data-slug="' + escapeHtml(c.slug) + '"' + bgStyle + ">" + fallback + communityActivityBadgeHtml(c) + '<div class="cc-shade"></div>' + '<div class="cc-content">' + '<span class="cc-flag" style="' + escapeHtml(flagStyle) + '">#' + escapeHtml(flagText) + "</span>" + '<div class="community-card-name cc-name">' + escapeHtml(c.name) + "</div>" + '<div class="cc-foot">' + avatarsBlock + '<span class="cc-cuy" title="Cuyes recibidos">' + sunSvg + "<b>" + z3tCompactCount(c.cuy_count) + "</b></span>" + "</div>" + "</div>" + "</div>";
  }).join("");
  qsa(".community-card", grid).forEach(function(el) {
    el.addEventListener("click", function() {
      openCommunity(el.getAttribute("data-slug"));
    });
  });
}

function showCommunitiesList() {
  minimizeActiveContexts();
  enterImmersive("community");
  activatePanel("panel-communities");
  loadCommunities();
  if (!state.suppressPush) {
    history.pushState({
      view: "communities"
    }, "", "/comunidades");
  }
  state.suppressPush = false;
}

var btnCommunitiesListBackEl = $("btnCommunitiesListBack");

if (btnCommunitiesListBackEl) btnCommunitiesListBackEl.addEventListener("click", function() {
  exitImmersive("community");
  if (typeof goHome === "function") goHome();
});

$("btnOpenCommunities").addEventListener("click", function() {
  closeDrawer();
  showCommunitiesList();
});

$("btnOpenMessages").addEventListener("click", function() {
  closeDrawer();
  showMessagesList();
});

if ($("btnFeedParties")) $("btnFeedParties").addEventListener("click", function() {
  showCommunitiesList();
});

if ($("btnFeedCircles")) $("btnFeedCircles").addEventListener("click", function() {
  showCirclesList();
});

function myCommunityRole() {
  if (!currentUser || !communityMembers.length) return null;
  var mine = communityMembers.filter(function(m) {
    return m.user_id === currentUser.id;
  })[0];
  return mine ? mine.role : null;
}

function communityMemberAvatarStackHtml(list) {
  return (list || communityMembers).slice(0, 5).map(function(m) {
    var name = m.profiles ? m.profiles.username : "usuario";
    var avatarUrl = m.profiles ? m.profiles.avatar_url : null;
    return avatarSpanHtml(name, avatarUrl, null, m.user_id);
  }).join("");
}

function openCommunity(slug) {
  return supabase.from("communities").select("*").eq("slug", slug).single().then(function(res) {
    if (res.error || !res.data) {
      toast(t("community.err_gone"));
      currentCommunity = null;
      resetToFeedOnMissingRoute("/comunidades/");
      return null;
    }
    currentCommunity = res.data;
    return loadCommunityMembers();
  }).then(function() {
    if (!currentCommunity) return;
    if (typeof communityVoiceMinimized !== "undefined" && communityVoiceMinimized && typeof voiceRoomCommunityId !== "undefined" && voiceRoomCommunityId === currentCommunity.id) {
      communityVoiceMinimized = false;
      communityVoiceReopenFn = null;
      if (typeof renderCommunityVoiceFloat === "function") renderCommunityVoiceFloat();
    }
    activatePanel("panel-community-detail");
    enterImmersive("community");
    renderCommunityDetail();
    loadCommunityMessages();
    voiceChatActive = !!(currentCommunity && currentCommunity.voice_active);
    renderVoiceBar();
    if (typeof ciAutoListen === "function") ciAutoListen();
    if (communityMessagesPollTimer) clearInterval(communityMessagesPollTimer);
    communityMessagesPollTimer = setInterval(function() {
      if (!document.hidden) loadCommunityMessages();
    }, 25e3);
    z3tRealtime("cmsg", "community_messages", "community_id=eq." + currentCommunity.id, function() {
      loadCommunityMessages();
    });
    if (communityActivityStatePollTimer) clearInterval(communityActivityStatePollTimer);
    communityActivityStatePollTimer = setInterval(pollCommunityActivityState, 5e3);
    if (communityAdminPresenceTimer) clearInterval(communityAdminPresenceTimer);
    communityAdminPresenceTimer = setInterval(function() {
      touchCommunityAdminPresence();
    }, 12e4);
    touchCommunityAdminPresence();
    if (!state.suppressPush) {
      history.pushState({
        view: "community",
        slug: slug
      }, "", "/comunidades/" + encodeURIComponent(slug));
    }
    state.suppressPush = false;
  }).catch(function(err) {
    console.error("[openCommunity] fallo consultando la comunidad:", err);
    toast(t("community.err_gone"));
    currentCommunity = null;
    resetToFeedOnMissingRoute("/comunidades/");
  });
}

function loadCommunityMembers() {
  return supabase.from("community_members").select("*, profiles(username, name, avatar_url, name_color, role, verified)").eq("community_id", currentCommunity.id).order("joined_at", {
    ascending: true
  }).then(function(res) {
    communityMembers = res.error ? [] : res.data || [];
  });
}

function openCommunityAdminPortal() {
  if (!currentCommunity) return;
  $("togglePortalMessages").checked = !currentCommunity.messages_locked;
  $("togglePortalAutoOffline").checked = !!currentCommunity.auto_offline;
  var myMembership = communityMembers.filter(function(m) {
    return currentUser && m.user_id === currentUser.id;
  })[0];
  var iAmMainAdmin = !!(myMembership && myMembership.role === "admin");
  $("btnPortalDeleteCommunity").hidden = !iAmMainAdmin;
  z3tSetCommunityPanelBg("panel-community-admin-portal", currentCommunity);
  activatePanel("panel-community-admin-portal");
}

var btnAdminPortalBackEl = $("btnAdminPortalBack");

if (btnAdminPortalBackEl) btnAdminPortalBackEl.addEventListener("click", function() {
  goBack("panel-community-detail");
});

var togglePortalMessagesEl = $("togglePortalMessages");

if (togglePortalMessagesEl) togglePortalMessagesEl.addEventListener("change", function() {
  var locked = !togglePortalMessagesEl.checked;
  supabase.from("communities").update({
    messages_locked: locked
  }).eq("id", currentCommunity.id).then(function(res) {
    if (res.error) {
      toast(t("community.err_save") + " " + res.error.message);
      togglePortalMessagesEl.checked = !locked;
      return;
    }
    currentCommunity.messages_locked = locked;
    toast(locked ? "Los miembros ya no pueden escribir." : "Los miembros ya pueden escribir de nuevo.");
  });
});

var togglePortalAutoOfflineEl = $("togglePortalAutoOffline");

if (togglePortalAutoOfflineEl) togglePortalAutoOfflineEl.addEventListener("change", function() {
  var on = togglePortalAutoOfflineEl.checked;
  supabase.from("communities").update({
    auto_offline: on
  }).eq("id", currentCommunity.id).then(function(res) {
    if (res.error) {
      toast(t("community.err_save") + " " + res.error.message);
      togglePortalAutoOfflineEl.checked = !on;
      return;
    }
    currentCommunity.auto_offline = on;
    toast(t("community.toast_saved"));
  });
});

var btnPortalDeleteCommunityEl = $("btnPortalDeleteCommunity");

if (btnPortalDeleteCommunityEl) btnPortalDeleteCommunityEl.addEventListener("click", function() {
  var name = currentCommunity.name;
  showAppAlert({
    title: '¿Eliminar "' + name + '"?',
    message: "Esto borra la comunidad, sus publicaciones y su historial para siempre. No se puede deshacer.",
    buttons: [ {
      label: "Eliminar",
      style: "danger",
      onClick: function() {
        var communityId = currentCommunity.id;
        supabase.from("communities").delete().eq("id", communityId).then(function(res) {
          if (res.error) {
            showErrorAlert(res.error.message);
            return;
          }
          toast(t("community.toast_deleted"));
          goHome();
        });
      }
    }, {
      label: "Cancelar"
    } ]
  });
});

var btnPortalInfoEl = $("btnPortalInfo");

if (btnPortalInfoEl) btnPortalInfoEl.addEventListener("click", function() {
  $("communitySettingsTitle").textContent = "Info de la Comunidad";
  $("communitySettingsBody").innerHTML = '<label class="field"><span>Biografía / descripción</span>' + '<textarea id="portalInfoDesc" rows="4" maxlength="500">' + escapeHtml(currentCommunity.description || "") + "</textarea>" + "</label>" + '' + flagFieldHtml("portalInfoFlag", "Banderas") + '<button class="terminal-btn full-width" id="btnPortalInfoSave" type="button">Guardar</button>';
  var infoFlagsLoaded = false;
  flagFieldSet("portalInfoFlag", []);
  flagFieldMax.portalInfoFlag = 10;
  loadEntityFlagTexts("community", currentCommunity.id).then(function(rows) {
    flagFieldSet("portalInfoFlag", rows.map(function(r) {
      return r.flags.display_text;
    }));
    infoFlagsLoaded = true;
  });
  $("btnPortalInfoSave").addEventListener("click", function() {
    var desc = $("portalInfoDesc").value.trim();
    var flagTexts = flagFieldGet("portalInfoFlag");
    supabase.from("communities").update({
      description: desc || null
    }).eq("id", currentCommunity.id).then(function(res) {
      if (res.error) {
        toast(t("community.err_save") + " " + res.error.message);
        return;
      }
      currentCommunity.description = desc || null;
      if (infoFlagsLoaded) syncEntityFlags("community", currentCommunity.id, flagTexts); else if (flagTexts.length) tagEntityWithFlags(flagTexts, "community", currentCommunity.id);
      toast(t("community.toast_info_updated"));
      $("communitySettingsBackdrop").classList.remove("open");
      refreshCommunityView(false);
    });
  });
  $("communitySettingsBackdrop").classList.add("open");
});

var btnPortalAffiliatesEl = $("btnPortalAffiliates");

if (btnPortalAffiliatesEl) btnPortalAffiliatesEl.addEventListener("click", function() {
  $("communitySettingsTitle").textContent = "Afiliados";
  $("communitySettingsBody").innerHTML = '<label class="field"><span>Círculos a los que pertenece esta comunidad (máx. 5)</span>' + '<button class="terminal-btn full-width" id="btnPortalOpenCircleSelect" type="button">Elegir círculos</button>' + '<div id="portalAffiliateCirclesList" class="profile-empty-hint">Cargando...</div>' + "</label>" + '' + flagFieldHtml("portalAffiliateFlag", "Vincular banderas") + '<div id="portalAffiliateFlagsList" class="flags-manage-list"><p class="profile-empty-hint">Cargando...</p></div>';
  if (typeof refreshFlagOptionsList === "function") refreshFlagOptionsList();
  function renderAffiliateCircles() {
    supabase.from("community_circles").select("circle_id, circles(id, name)").eq("community_id", currentCommunity.id).then(function(res) {
      var rows = (res.error ? [] : res.data || []).filter(function(r) {
        return r.circles;
      });
      var listEl = $("portalAffiliateCirclesList");
      if (!listEl) return;
      listEl.textContent = rows.length ? rows.map(function(r) {
        return r.circles.name;
      }).join(", ") : "Todavía no está en ningún círculo.";
      listEl.dataset.ids = JSON.stringify(rows.map(function(r) {
        return r.circle_id;
      }));
    });
  }
  renderAffiliateCircles();
  window.refreshCommunityAffiliateCircles = function() {
    if ($("portalAffiliateCirclesList")) renderAffiliateCircles();
  };
  $("btnPortalOpenCircleSelect").addEventListener("click", function() {
    var ids = [];
    try {
      ids = JSON.parse($("portalAffiliateCirclesList").dataset.ids || "[]");
    } catch (_e) {}
    $("communitySettingsBackdrop").classList.remove("open");
    openCircleSelectionMode(currentCommunity.id, ids);
  });
  function renderAffiliateFlags() {
    var wrap = $("portalAffiliateFlagsList");
    wrap.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
    supabase.from("flag_links").select("id, flags(id, display_text, color)").eq("entity_type", "community").eq("entity_id", currentCommunity.id).then(function(res) {
      var rows = (res.error ? [] : res.data || []).filter(function(r) {
        return r.flags;
      });
      flagFieldSet("portalAffiliateFlag", rows.map(function(r) {
        return r.flags.display_text;
      }));
      wrap.innerHTML = rows.length ? rows.map(function(r) {
        return '<div class="flag-edit-row" data-link-id="' + escapeHtml(r.id) + '">' + flagPennantHtml(r.flags.display_text, r.flags.color) + '<button class="icon-btn flag-remove-btn" type="button" aria-label="Quitar bandera">✕</button>' + "</div>";
      }).join("") : '<p class="profile-empty-hint">Esta comunidad todavía no tiene banderas.</p>';
      qsa(".flag-remove-btn", wrap).forEach(function(btn) {
        btn.addEventListener("click", function() {
          var linkId = btn.closest("[data-link-id]").getAttribute("data-link-id");
          supabase.from("flag_links").delete().eq("id", linkId).then(function(res2) {
            if (res2.error) {
              toast(t("community.err_flag_remove"));
              return;
            }
            renderAffiliateFlags();
          });
        });
      });
    });
  }
  renderAffiliateFlags();
  flagFieldMax.portalAffiliateFlag = 10;
  flagFieldHandlers.portalAffiliateFlag = function(list) {
    syncEntityFlags("community", currentCommunity.id, list).then(renderAffiliateFlags);
  };
  $("communitySettingsBackdrop").classList.add("open");
});

var btnPortalAppearanceEl = $("btnPortalAppearance");

if (btnPortalAppearanceEl) btnPortalAppearanceEl.addEventListener("click", function() {
  $("communitySettingsTitle").textContent = "Apariencia";
  var portalBannerFile = null, portalBackgroundFile = null;
  $("communitySettingsBody").innerHTML = '<label class="field"><span>Banner (arriba de todo)</span>' + '<div class="image-pick-preview" id="portalBannerPreview">' + (currentCommunity.banner_url ? '<img loading=lazy decoding=async src="' + escapeHtml(currentCommunity.banner_url) + '" alt="">' : "") + "</div>" + '<button type="button" class="terminal-btn" id="btnPortalPickBanner">Elegir imagen</button>' + '<input type="file" id="portalBannerFile" accept="image/*" hidden>' + "</label>" + '<label class="field"><span>Fondo de la comunidad</span>' + '<div class="image-pick-preview" id="portalBackgroundPreview">' + (currentCommunity.background_url ? '<img loading=lazy decoding=async src="' + escapeHtml(currentCommunity.background_url) + '" alt="">' : "") + "</div>" + '<button type="button" class="terminal-btn" id="btnPortalPickBackground">Elegir imagen</button>' + '<input type="file" id="portalBackgroundFile" accept="image/*" hidden>' + "</label>" + '<button class="terminal-btn full-width" id="btnPortalAppearanceSave" type="button">Guardar</button>';
  $("btnPortalPickBanner").addEventListener("click", function() {
    $("portalBannerFile").click();
  });
  $("portalBannerFile").addEventListener("change", function() {
    portalBannerFile = this.files && this.files[0] || null;
    renderImagePickPreview("portalBannerPreview", portalBannerFile);
  });
  $("btnPortalPickBackground").addEventListener("click", function() {
    $("portalBackgroundFile").click();
  });
  $("portalBackgroundFile").addEventListener("change", function() {
    portalBackgroundFile = this.files && this.files[0] || null;
    renderImagePickPreview("portalBackgroundPreview", portalBackgroundFile);
  });
  $("btnPortalAppearanceSave").addEventListener("click", function() {
    Promise.all([ uploadCommunityImage(currentCommunity.id, portalBannerFile, "banner").catch(function() {
      toast(t("community.err_banner_upload"));
      return null;
    }), uploadCommunityImage(currentCommunity.id, portalBackgroundFile, "background").catch(function() {
      toast(t("community.err_bg_upload"));
      return null;
    }) ]).then(function(urls) {
      var patch = {};
      if (urls[0]) patch.banner_url = urls[0];
      if (urls[1]) patch.background_url = urls[1];
      if (!Object.keys(patch).length) {
        $("communitySettingsBackdrop").classList.remove("open");
        return;
      }
      supabase.from("communities").update(patch).eq("id", currentCommunity.id).then(function(res) {
        if (res.error) {
          toast(t("community.err_save") + " " + res.error.message);
          return;
        }
        Object.assign(currentCommunity, patch);
        z3tSetCommunityPanelBg("panel-community-admin-portal", currentCommunity);
        toast(t("community.toast_appearance_updated"));
        $("communitySettingsBackdrop").classList.remove("open");
        refreshCommunityView(false);
      });
    });
  });
  $("communitySettingsBackdrop").classList.add("open");
});

var btnPortalRoleColorsEl = $("btnPortalRoleColors");

if (btnPortalRoleColorsEl) btnPortalRoleColorsEl.addEventListener("click", function() {
  var role = typeof myCommunityRole === "function" ? myCommunityRole() : null;
  if (!(role === "admin" || role === "co_admin" || currentUser && currentUser.role === "admin")) {
    toast("Solo los admins pueden cambiar los colores.");
    return;
  }
  $("communitySettingsTitle").textContent = "Colores de roles";
  $("communitySettingsBody").innerHTML = z3tRoleColorFieldsHtml(currentCommunity) + '<p class="field-error" id="portalRoleColorsErr" hidden></p>' + '<div class="edit-box-actions" style="margin-top:1rem">' + '<button class="terminal-btn" type="button" id="btnPortalRoleColorsSave">Guardar</button>' + '<button class="link-btn" type="button" id="btnPortalRoleColorsReset">Restablecer</button></div>';
  $("btnPortalRoleColorsReset").addEventListener("click", function() {
    [ "admin", "co_admin", "member" ].forEach(function(r) {
      var el = document.getElementById("settRoleColor_" + r);
      if (el) el.value = Z3T_ROLE_DEFAULTS[r] || "#9aa0a6";
    });
  });
  $("btnPortalRoleColorsSave").addEventListener("click", function() {
    var colors = z3tReadRoleColorFields();
    var btn = this, err = $("portalRoleColorsErr");
    err.hidden = true;
    btn.disabled = true;
    supabase.from("communities").update({
      role_colors: colors
    }).eq("id", currentCommunity.id).select("id").then(function(res) {
      btn.disabled = false;
      if (res.error || !res.data || !res.data.length) {
        err.textContent = "No se pudo guardar" + (res.error ? ": " + res.error.message : ". Verifica que eres admin de la comunidad.");
        err.hidden = false;
        return;
      }
      currentCommunity.role_colors = colors;
      var chat = document.getElementById("communityChat");
      if (chat) chat.dataset.msgSig = "";
      if (typeof renderCommunityChat === "function") renderCommunityChat();
      toast("Colores de roles guardados.");
      $("communitySettingsBackdrop").classList.remove("open");
    });
  });
  $("communitySettingsBackdrop").classList.add("open");
});

var btnPortalMembersEl = $("btnPortalMembers");

if (btnPortalMembersEl) btnPortalMembersEl.addEventListener("click", function() {
  activatePanel("panel-community-detail");
  openCommunityMembersView(true);
});

var btnPortalBlockedEl = $("btnPortalBlocked");

if (btnPortalBlockedEl) btnPortalBlockedEl.addEventListener("click", function() {
  activatePanel("panel-community-blocked");
  $("blockedMembersList").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("community_bans").select("user_id, created_at, profiles(username, avatar_url)").eq("community_id", currentCommunity.id).order("created_at", {
    ascending: false
  }).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    $("blockedMembersEmpty").hidden = rows.length > 0;
    $("blockedMembersList").innerHTML = rows.map(function(r) {
      var name = r.profiles ? r.profiles.username : "usuario";
      return '<div class="social-list-row blocked-member-row">' + avatarSpanHtml(name, r.profiles ? r.profiles.avatar_url : null, null, r.user_id) + '<div class="social-list-row-info"><div class="social-list-row-name">' + escapeHtml(name) + "</div>" + '<div class="collection-row-meta">Bloqueado el ' + new Date(r.created_at).toLocaleDateString("es") + "</div></div>" + '<button type="button" class="link-btn" data-unban="' + escapeHtml(r.user_id) + '">Desbloquear</button>' + "</div>";
    }).join("");
    qsa("[data-unban]", $("blockedMembersList")).forEach(function(btn) {
      btn.addEventListener("click", function() {
        var uid = btn.getAttribute("data-unban");
        if (!confirm("¿Desbloquear a este usuario?")) return;
        supabase.rpc("admin_unban_member", {
          p_community_id: currentCommunity.id,
          p_target_user_id: uid
        }).then(function(res2) {
          if (res2.error) {
            toast(t("community.err_unblock") + " " + res2.error.message);
            return;
          }
          toast(t("community.toast_unblocked"));
          btnPortalBlockedEl.click();
        });
      });
    });
  });
});

var btnBlockedBackEl = $("btnBlockedBack");

if (btnBlockedBackEl) btnBlockedBackEl.addEventListener("click", function() {
  goBack("panel-community-admin-portal");
});

var btnPortalAuditLogEl = $("btnPortalAuditLog");

if (btnPortalAuditLogEl) btnPortalAuditLogEl.addEventListener("click", function() {
  activatePanel("panel-community-audit-log");
  $("auditLogList").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  var ACTION_LABELS = {
    community_offline: "apagó la comunidad",
    community_online: "encendió la comunidad",
    kick: "expulsó a un usuario",
    kick_wipe: "expulsó a un usuario y borró su contenido",
    ban: "baneó a un usuario",
    unban: "desbloqueó a un usuario"
  };
  supabase.from("community_audit_log").select("action, created_at, actor_id, target_id, profiles!community_audit_log_actor_id_fkey(username)").eq("community_id", currentCommunity.id).order("created_at", {
    ascending: false
  }).limit(200).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    $("auditLogEmpty").hidden = rows.length > 0;
    $("auditLogList").innerHTML = rows.map(function(r) {
      var actorName = r.profiles ? r.profiles.username : "alguien";
      var label = ACTION_LABELS[r.action] || r.action;
      return '<div class="social-list-row audit-log-row"><div class="social-list-row-info">' + '<div class="social-list-row-name">' + escapeHtml(actorName) + " " + escapeHtml(label) + "</div>" + '<div class="audit-log-time">' + new Date(r.created_at).toLocaleString("es") + "</div>" + "</div></div>";
    }).join("");
  });
});

var btnAuditLogBackEl = $("btnAuditLogBack");

if (btnAuditLogBackEl) btnAuditLogBackEl.addEventListener("click", function() {
  goBack("panel-community-admin-portal");
});

function refreshCommunityView(keepMembersOpen) {
  return supabase.from("communities").select("*").eq("id", currentCommunity.id).single().then(function(res) {
    if (res.data) currentCommunity = res.data;
    return loadCommunityMembers();
  }).then(function() {
    renderCommunityDetail();
    loadCommunityMessages();
    if (keepMembersOpen) openCommunityMembersView(true);
  });
}

function closeCommunityDetail(forceDisconnectVoice) {
  z3tRealtimeStop("cmsg");
  z3tRealtimeStop("cmsg");
  if (communityMessagesPollTimer) {
    clearInterval(communityMessagesPollTimer);
    communityMessagesPollTimer = null;
  }
  if (communityActivityStatePollTimer) {
    clearInterval(communityActivityStatePollTimer);
    communityActivityStatePollTimer = null;
  }
  if (communityAdminPresenceTimer) {
    clearInterval(communityAdminPresenceTimer);
    communityAdminPresenceTimer = null;
  }
  if (communityCinemaPollTimer) {
    clearInterval(communityCinemaPollTimer);
    communityCinemaPollTimer = null;
  }
  if (ytPlayer && ytPlayer.destroy) {
    try {
      ytPlayer.destroy();
    } catch (_e) {}
    ytPlayer = null;
  }
  if (typeof stopRoleplayPanel === "function") stopRoleplayPanel();
  var slugToReopen = currentCommunity ? currentCommunity.slug : null;
  if (forceDisconnectVoice) {
    leaveVoiceChat();
  } else if (typeof minimizeVoiceChat === "function") {
    minimizeVoiceChat(slugToReopen ? function() {
      openCommunity(slugToReopen);
    } : null);
  } else {
    leaveVoiceChat();
  }
  if (typeof communityPresenceStop === "function") communityPresenceStop();
  currentCommunity = null;
  communityMembers = [];
  goBack("panel-communities");
  if (currentPanelId === "panel-communities") enterImmersive("community"); else exitImmersive("community");
  resetScrollToTop();
  loadCommunities();
}

function z3tCleanupStaleCinemaPlayer() {
  if (ytPlayer && ytPlayer.destroy) {
    try {
      ytPlayer.destroy();
    } catch (_e) {}
  }
  ytPlayer = null;
  var floatSlot = document.getElementById("communityVoiceFloatVideo");
  if (floatSlot) {
    while (floatSlot.firstChild) floatSlot.removeChild(floatSlot.firstChild);
    floatSlot.hidden = true;
  }
  if (typeof communityCinemaHomeParent !== "undefined") communityCinemaHomeParent = null;
}

function renderCommunityDetail() {
  z3tCleanupStaleCinemaPlayer();
  var c = currentCommunity;
  var role = myCommunityRole();
  var isStaff = role === "admin" || role === "co_admin";
  var bannerStyle = c.banner_url ? ' style="background-image:url(&quot;' + encodeURI(c.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
  var actionsHtml = "";
  if (isStaff && !c.is_offline) {
    actionsHtml += '<button class="icon-btn" id="btnCommunityGoOffline" type="button" aria-label="Apagar comunidad" title="Apagar comunidad">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>' + "</button>";
  }
  actionsHtml += '<div class="compose-icon-wrap community-kebab-wrap">' + '<button class="icon-btn" id="btnCommunityKebab" type="button" aria-label="Más opciones">⋮</button>' + '<div class="chat-actions-popup popup-below" id="communityKebabPopup">' + '<div class="chat-actions-panel">' + '<button class="chat-action-item" id="btnCommunityInfo" type="button">⚙️ <span>Configuración</span></button>' + '<button class="chat-action-item" id="btnCommunityShare" type="button">🔗 <span>Compartir comunidad</span></button>' + '<button class="chat-action-item" id="btnCommunityReport" type="button">🚩 <span>Reportar</span></button>' + (isStaff ? '<button class="chat-action-item" id="btnCommunityAdminPortal" type="button">🛡️ <span>Portal del Admin</span></button>' : "") + "</div>" + "</div>" + "</div>";
  if (role) {
    actionsHtml += '<button class="icon-btn" id="btnCommunityInvite" type="button" aria-label="Invitar">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>' + "</button>";
    actionsHtml += '<button class="icon-btn" id="btnCommunityLeave" type="button" aria-label="Salir">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>' + "</button>";
  }
  var html = '<div class="community-shell">' + '<div class="community-fixed-top">' + '<div class="community-header' + (currentCommunity.active_activity ? " community-header--activity" : "") + '">' + '<div class="community-banner-strip"' + bannerStyle + "></div>" + '<div class="community-header-bar">' + '<button class="icon-btn" id="btnCommunityDetailBack" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>"  + '<div class="community-header-name">' + "<h3>" + escapeHtml(c.name) + "</h3>" + '<div class="community-header-sub">' + c.member_count + " miembros" + (role ? " · " + (role === "admin" ? "Admin" : role === "co_admin" ? "Co-Admin" : "Miembro") : "") + "</div>" + "</div>" + '<div class="community-header-actions">' + actionsHtml + "</div>" + "</div>" + "</div>" + '<div class="community-presence-row" id="communityPresenceRow"></div>' + (currentCommunity.active_activity === "cinema" ? '<div class="cinema-player-wrap" id="cinemaPlayerWrap">' + '<div class="cinema-player-inner" id="communityCinemaPlayer"></div>' + '<div class="cinema-corner-controls">' + (currentCommunity.cinema_video_url ? '<button class="icon-btn" id="btnCommunityCinemaPlayPause" type="button" aria-label="Pausar/Reproducir">' + (currentCommunity.cinema_is_playing ? pauseSvg() : playSvg()) + "</button>" : "") + (isStaff ? '<button class="icon-btn" id="btnCinemaOptionsToggle" type="button" aria-label="Opciones de video">' + cinemaGearSvg() + "</button>" : "") + '<button class="icon-btn" id="btnCinemaExpandToggle" type="button" aria-label="Agrandar/Achicar">' + stageExpandSvg() + "</button>" + (isStaff ? '<button class="icon-btn" id="btnCinemaClose" type="button" aria-label="Apagar Sala de Cine" title="Apagar Sala de Cine">' + closeXSvg() + "</button>" : "") + "</div>" + (isStaff ? '<div class="cinema-options-popup" id="cinemaOptionsPopup">' + "<label>Videos y audios de esta sala</label>" + '<div class="cinema-library-list" id="cinemaLibraryList"><p class="profile-empty-hint">Cargando...</p></div>' + "<label>Video por URL</label>" + '<form class="cinema-option-row" id="communityCinemaVideoForm">' + '<input type="text" id="communityCinemaUrlInput" placeholder="YouTube, Spotify, o cualquier link...">' + '<button class="icon-btn" type="submit" aria-label="Poner video">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>' + "</button>" + "</form>" + "<label>O sube desde almacenamiento</label>" + '<button type="button" class="cinema-upload-btn" id="btnCinemaUploadVideo">' + cinemaUploadIconSvg() + " <span>Subir video</span></button>" + '<input type="file" id="cinemaVideoFileInput" accept="video/*" hidden>' + "<label>O sube un audio</label>" + '<button type="button" class="cinema-upload-btn" id="btnCinemaUploadAudio">' + cinemaUploadIconSvg() + " <span>Subir audio</span></button>" + '<input type="file" id="cinemaAudioFileInput" accept="audio/*" hidden>' + "</div>" : "") + "</div>" : "") + (currentCommunity.active_activity === "roleplay" ? '<div class="roleplay-wrap" id="communityRoleplayWrap"></div>' : "") + '<div class="community-voice-bar" id="communityVoiceBar" hidden></div>' + "</div>" + (c.is_offline ? function() {
    var adminMember = communityMembers.filter(function(m) {
      return m.role === "admin";
    })[0];
    var adminName = adminMember && adminMember.profiles ? adminMember.profiles.username : "el admin";
    var adminAvatar = adminMember && adminMember.profiles ? adminMember.profiles.avatar_url : null;
    var adminUid = adminMember ? adminMember.user_id : null;
    return '<div class="community-offline-card">' + "<h3>" + (isStaff ? "Tu comunidad está en modo offline" : "Esta comunidad está en modo offline") + "</h3>" + "<p>¡Sigue al Admin para recibir notificaciones cuando la comunidad vuelva al modo online!</p>" + '<div class="community-offline-admin-row">' + avatarSpanHtml(adminName, adminAvatar, null, adminUid) + "<span>" + escapeHtml(adminName) + "</span>" + (isStaff ? '<button class="terminal-btn community-offline-on-btn" id="btnCommunityGoOnline" type="button">Encender</button>' : '<button class="terminal-btn" id="btnCommunityOfflineFollow" type="button" data-uid="' + escapeHtml(adminUid || "") + '">Seguir</button>') + "</div>" + "</div>";
  }() : '<div class="community-chat" id="communityChat"></div>' + '<div class="community-members-list" id="communityMembersPanel" hidden></div>');
  if (role && !c.is_offline) {
    html += '<div class="community-composer-wrap">' + '<button class="cuy-btn cuy-btn-floating" id="btnCommunityCuy" type="button" aria-label="Dar un cuy a esta comunidad">' + '<img loading=lazy decoding=async id="cuyBtnImg" src="assets/cuy/state-active.webp" alt="">' + '<span class="cuy-btn-badge" id="cuyBtnBadge" hidden></span>' + "</button>" + '<form class="community-chat-input-row" id="communityChatForm">' + '<div class="composer-top-row">' + '<input type="text" id="communityChatInput" maxlength="1000" placeholder="Escribe algo para la comunidad..." autocomplete="off">' + '<button class="icon-btn composer-send-btn" type="submit" aria-label="Enviar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>' + "</div>" + '<div class="mention-popup" id="communityMentionPopup" hidden></div>' + '<div class="composer-icons-row">' + '<button class="icon-btn compose-icon" id="btnCommunityAudio" type="button" aria-label="Audio">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><line x1="4" y1="10" x2="4" y2="14"/><line x1="8" y1="6" x2="8" y2="18"/><line x1="12" y1="3" x2="12" y2="21"/><line x1="16" y1="6" x2="16" y2="18"/><line x1="20" y1="10" x2="20" y2="14"/></svg>' + "</button>" + '<button class="icon-btn compose-icon z3t-link-btn" type="button" data-link-for="communityChatInput" aria-label="Insertar enlace" title="Enlace">🔗</button>' + '<button class="icon-btn compose-icon" id="btnCommunityImage" type="button" aria-label="Imagen">' + '<img loading=lazy decoding=async src="assets/icons/ic-upload.png" alt="" class="upload-icon-img">' + "</button>" + '<input type="file" id="communityImageInput" accept="image/*" hidden>' + '<div class="compose-icon-wrap">' + '<button class="icon-btn compose-icon" id="communityChatActionsBtn" type="button" aria-label="Emojis"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 14s1.2 2 3.5 2 3.5-2 3.5-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg></button>' + '<div class="chat-actions-popup" id="chatActionsPopup">' + '<div class="chat-actions-panel" id="chatEmojiPanel"></div>' + "</div>" + "</div>" + '<div class="compose-icon-wrap">' + '<button class="icon-btn compose-icon" id="btnCommunityActivities" type="button" aria-label="Actividades">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 20h16z"/><line x1="12" y1="9" x2="12" y2="14"/><line x1="9" y1="6" x2="6" y2="2"/><line x1="15" y1="6" x2="18" y2="2"/></svg>' + "</button>" + '<div class="chat-actions-popup" id="activitiesPopup">' + '<div class="chat-actions-panel">' + '<button class="chat-action-item" id="btnActivityPickVoice" type="button">' + activityIconHtml("voice") + " <span>Chat de voz</span></button>" + '<button class="chat-action-item" id="btnActivityPickCinema" type="button">' + activityIconHtml("cinema") + " <span>Sala de Cine</span></button>" + '<button class="chat-action-item" id="btnActivityPickRoleplay" type="button">' + activityIconHtml("roleplay") + " <span>Roleplay</span></button>" + "</div>" + "</div>" + "</div>" + '<div class="compose-icon-wrap">' + '<button class="icon-btn compose-icon" id="btnCommunityMore" type="button" aria-label="Más">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>' + "</button>" + '<div class="chat-actions-popup" id="morePopup">' + '<div class="chat-actions-panel">' + '<button class="chat-action-item" id="btnActivityPickPoll" type="button">📊 <span>Encuesta</span></button>' + giftMenuItemHtml() + "</div>" + "</div>" + "</div>" + "</div>" + "</form>" + "</div>";
  } else if (!c.is_offline) {
    html += '<div class="community-join-bar"><span>Únete para escribir y participar en esta comunidad.</span>' + '<button class="terminal-btn" id="btnCommunityJoin" type="button">Unirme</button></div>';
  }
  html += "</div>";
  $("communityDetail").innerHTML = html;
  if (COMMUNITY_MESSAGES.length && COMMUNITY_MESSAGES[0].community_id === c.id && typeof renderCommunityChat === "function") renderCommunityChat();
  if (typeof communityPresenceStart === "function") communityPresenceStart();
  var shellEl = document.querySelector("#communityDetail .community-shell");
  if (c.background_url && shellEl) {
    shellEl.style.backgroundImage = 'linear-gradient(rgba(7,6,10,.78), rgba(7,6,10,.9)), url("' + encodeURI(c.background_url).replace(/"/g, "%22").replace(/'/g, "%27") + '")';
    shellEl.style.backgroundSize = "cover";
    shellEl.style.backgroundPosition = "center";
    shellEl.classList.add("has-comm-bg");
  } else if (shellEl) {
    shellEl.style.backgroundImage = "";
    shellEl.classList.remove("has-comm-bg");
  }
  $("btnCommunityDetailBack").addEventListener("click", function() {
    closeCommunityDetail();
  });
  var leaveBtn = $("btnCommunityLeave");
  if (leaveBtn) leaveBtn.addEventListener("click", handleCommunityLeaveClick);
  var inviteBtn = $("btnCommunityInvite");
  if (inviteBtn) inviteBtn.addEventListener("click", openCommunityInvitePicker);
  var portalBtnEl = $("btnCommunityAdminPortal");
  var teamRowEl = $("btnOpenAdminTeamList");
  if (teamRowEl) teamRowEl.addEventListener("click", function() {
    openCommunityMembersView();
  });
  var goOfflineBtn = $("btnCommunityGoOffline");
  if (goOfflineBtn) goOfflineBtn.addEventListener("click", function() {
    if (!confirm("¿Apagar esta comunidad? Nadie podrá escribir hasta que la enciendas de nuevo.")) return;
    supabase.rpc("rpc_toggle_community_offline", {
      cid: currentCommunity.id,
      new_state: true
    }).then(function(res) {
      if (res.error) {
        toast(t("community.err_turn_off") + " " + res.error.message);
        return;
      }
      toast(t("community.toast_off"));
      refreshCommunityView(false);
    });
  });
  var goOnlineBtn = $("btnCommunityGoOnline");
  if (goOnlineBtn) goOnlineBtn.addEventListener("click", function() {
    supabase.rpc("rpc_toggle_community_offline", {
      cid: currentCommunity.id,
      new_state: false
    }).then(function(res) {
      if (res.error) {
        toast(t("community.err_turn_on") + " " + res.error.message);
        return;
      }
      toast(t("community.toast_on"));
      refreshCommunityView(false);
    });
  });
  var offlineFollowBtn = $("btnCommunityOfflineFollow");
  if (offlineFollowBtn) offlineFollowBtn.addEventListener("click", function() {
    var uid = offlineFollowBtn.getAttribute("data-uid");
    if (uid && typeof openProfile === "function") openProfile(uid);
  });
  var membersStripClickEl = $("communityMembersStripClick");
  if (membersStripClickEl) membersStripClickEl.addEventListener("click", function() {
    openCommunityMembersView();
  });
  var kebabBtn = $("btnCommunityKebab");
  if (kebabBtn) {
    kebabBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      $("communityKebabPopup").classList.toggle("open");
    });
    var infoBtn = $("btnCommunityInfo");
    if (infoBtn) infoBtn.addEventListener("click", function() {
      $("communityKebabPopup").classList.remove("open");
      openCommunityInfo();
    });
    var shareBtn = $("btnCommunityShare");
    if (shareBtn) shareBtn.addEventListener("click", function() {
      $("communityKebabPopup").classList.remove("open");
      if (typeof shareTarget === "function") shareTarget("community", currentCommunity.id);
    });
    var reportBtn = $("btnCommunityReport");
    if (reportBtn) reportBtn.addEventListener("click", function() {
      $("communityKebabPopup").classList.remove("open");
      if (typeof openReportModal === "function") openReportModal("community", currentCommunity.id);
    });
    var portalBtn = $("btnCommunityAdminPortal");
    if (portalBtn) portalBtn.addEventListener("click", function() {
      $("communityKebabPopup").classList.remove("open");
      openCommunityAdminPortal();
    });
    document.addEventListener("click", function() {
      var popup = $("communityKebabPopup");
      if (popup) popup.classList.remove("open");
    });
  }
  var joinBtn = $("btnCommunityJoin");
  if (joinBtn) joinBtn.addEventListener("click", joinCurrentCommunity);
  var chatForm = $("communityChatForm");
  if (chatForm) chatForm.addEventListener("submit", sendCommunityMessage);
  wireCommunityMentionPicker();
  var cuyBtn = $("btnCommunityCuy");
  if (cuyBtn) {
    cuyBtn.addEventListener("click", tapCommunityCuy);
    loadCommunityCuyState();
  }
  if (role) renderChatActionsPopup();
  renderVoiceBar();
  if (c.active_activity === "cinema") {
    mountCommunityCinemaPlayer();
    var cinemaForm = $("communityCinemaVideoForm");
    if (cinemaForm) cinemaForm.addEventListener("submit", function(e) {
      e.preventDefault();
      var url = $("communityCinemaUrlInput").value.trim();
      if (url) {
        setCommunityCinemaVideo(url);
        var popup = $("cinemaOptionsPopup");
        if (popup) popup.classList.remove("open");
      }
    });
    var cinemaPlayPauseBtn = $("btnCommunityCinemaPlayPause");
    if (cinemaPlayPauseBtn) cinemaPlayPauseBtn.addEventListener("click", toggleCommunityCinemaPlayPause);
    var cinemaOptionsToggle = $("btnCinemaOptionsToggle");
    var cinemaOptionsPopupEl = $("cinemaOptionsPopup");
    if (cinemaOptionsToggle) cinemaOptionsToggle.addEventListener("click", function(e) {
      e.stopPropagation();
      if (cinemaOptionsPopupEl) cinemaOptionsPopupEl.classList.toggle("open");
    });
    if (cinemaOptionsPopupEl) cinemaOptionsPopupEl.addEventListener("click", function(e) {
      e.stopPropagation();
      var playBtn = e.target.closest(".cinema-library-play");
      if (playBtn) {
        playCinemaLibraryItemById(playBtn.getAttribute("data-id"));
        return;
      }
      var delBtn = e.target.closest(".cinema-library-delete");
      if (delBtn) {
        deleteCinemaLibraryItem(delBtn.getAttribute("data-id"));
        return;
      }
    });
    var cinemaExpandToggle = $("btnCinemaExpandToggle");
    if (cinemaExpandToggle) cinemaExpandToggle.addEventListener("click", function() {
      var wrap = $("cinemaPlayerWrap");
      if (!wrap) return;
      var expanded = wrap.classList.toggle("cinema-expanded");
      cinemaExpandToggle.innerHTML = expanded ? stageCompressSvg() : stageExpandSvg();
    });
    var cinemaCloseBtn = $("btnCinemaClose");
    if (cinemaCloseBtn) cinemaCloseBtn.addEventListener("click", function() {
      setCommunityActivity(null);
    });
    var cinemaUploadBtn = $("btnCinemaUploadVideo");
    var cinemaFileInput = $("cinemaVideoFileInput");
    if (cinemaUploadBtn && cinemaFileInput) {
      cinemaUploadBtn.addEventListener("click", function() {
        cinemaFileInput.click();
      });
      cinemaFileInput.addEventListener("change", function() {
        var file = cinemaFileInput.files && cinemaFileInput.files[0];
        if (!file || !currentCommunity) return;
        cinemaUploadBtn.disabled = true;
        cinemaUploadBtn.innerHTML = cinemaUploadIconSvg() + " <span>Subiendo...</span>";
        uploadFiles([ file ], "cinema/" + currentCommunity.id).then(function(uploaded) {
          cinemaFileInput.value = "";
          if (uploaded && uploaded[0]) setCommunityCinemaVideo(uploaded[0].url, {
            type: "direct",
            title: uploaded[0].name || null
          });
        }).catch(function(err) {
          toast(t("community.err_video_upload") + " " + (err && err.message ? err.message : t("community.err_unknown")));
        }).finally(function() {
          cinemaUploadBtn.disabled = false;
          cinemaUploadBtn.innerHTML = cinemaUploadIconSvg() + " <span>Subir video</span>";
        });
      });
    }
    var cinemaUploadAudioBtn = $("btnCinemaUploadAudio");
    var cinemaAudioFileInput = $("cinemaAudioFileInput");
    if (cinemaUploadAudioBtn && cinemaAudioFileInput) {
      cinemaUploadAudioBtn.addEventListener("click", function() {
        cinemaAudioFileInput.click();
      });
      cinemaAudioFileInput.addEventListener("change", function() {
        var file = cinemaAudioFileInput.files && cinemaAudioFileInput.files[0];
        if (!file || !currentCommunity) return;
        cinemaUploadAudioBtn.disabled = true;
        cinemaUploadAudioBtn.innerHTML = cinemaUploadIconSvg() + " <span>Subiendo...</span>";
        uploadFiles([ file ], "cinema/" + currentCommunity.id).then(function(uploaded) {
          cinemaAudioFileInput.value = "";
          if (uploaded && uploaded[0]) setCommunityCinemaVideo(uploaded[0].url, {
            type: "audio",
            title: uploaded[0].name || null
          });
        }).catch(function(err) {
          toast(t("community.err_audio_upload") + " " + (err && err.message ? err.message : t("community.err_unknown")));
        }).finally(function() {
          cinemaUploadAudioBtn.disabled = false;
          cinemaUploadAudioBtn.innerHTML = cinemaUploadIconSvg() + " <span>Subir audio</span>";
        });
      });
    }
    loadCinemaLibrary();
    if (communityCinemaPollTimer) clearInterval(communityCinemaPollTimer);
    communityCinemaPollTimer = setInterval(pollCommunityCinemaState, 4e3);
  } else if (communityCinemaPollTimer) {
    clearInterval(communityCinemaPollTimer);
    communityCinemaPollTimer = null;
  }
  if (c.active_activity === "roleplay") {
    if (typeof initRoleplayPanel === "function") initRoleplayPanel(c, role, "community");
  } else if (typeof stopRoleplayPanel === "function") {
    stopRoleplayPanel();
  }
}

function renderCommunityMembersPanel() {
  var role = myCommunityRole();
  var isAdmin = role === "admin";
  var isStaff = role === "admin" || role === "co_admin";
  var html = '<div class="community-member-row"><button class="link-btn" id="btnBackToChat" type="button">← Volver al chat</button></div>';
  html += communityMembers.map(function(m) {
    var name = m.profiles ? m.profiles.username : "usuario";
    var avatarUrl = m.profiles ? m.profiles.avatar_url : null;
    var nameColor = m.profiles ? m.profiles.name_color : null;
    var acctRole = m.profiles ? m.profiles.role : null;
    var acctVerified = m.profiles ? m.profiles.verified : null;
    var roleLabel = m.role === "admin" ? "Admin" : m.role === "co_admin" ? "Co-Admin" : "Miembro";
    var actions = "";
    if (isAdmin && m.role !== "admin") {
      if (m.role === "member") actions += '<button class="link-btn" data-action="promote" data-member="' + m.id + '" type="button">Hacer co-admin</button>'; else if (m.role === "co_admin") actions += '<button class="link-btn" data-action="demote" data-member="' + m.id + '" type="button">Quitar co-admin</button>';
    }
    if (isStaff && m.role === "member" && currentUser && m.user_id !== currentUser.id) {
      actions += '<button class="link-btn danger" data-action="kick" data-member="' + m.id + '" type="button">Expulsar</button>';
    }
    return '<div class="community-member-row">' + avatarSpanHtml(name, avatarUrl, null, m.user_id) + '<div class="community-member-name" data-uid="' + escapeHtml(m.user_id) + '"' + (nameColor ? ' style="color:' + escapeHtml(nameColor) + '"' : "") + ">" + escapeHtml(name) + roleBadgeHtml(acctRole, acctVerified) + "</div>" + '<span class="role-tag ' + m.role + '">' + roleLabel + "</span>" + '<div class="community-member-actions">' + actions + "</div>" + "</div>";
  }).join("");
  $("communityMembersPanel").innerHTML = html;
  $("btnBackToChat").addEventListener("click", function() {
    openCommunityMembersView(false);
    $("communityMembersPanel").hidden = true;
    $("communityChat").hidden = false;
  });
  qsa("[data-action]", $("communityMembersPanel")).forEach(function(btn) {
    btn.addEventListener("click", function() {
      var action = btn.getAttribute("data-action");
      var memberId = btn.getAttribute("data-member");
      if (action === "promote") updateMemberRole(memberId, "co_admin"); else if (action === "demote") updateMemberRole(memberId, "member"); else if (action === "kick") kickMember(memberId);
    });
  });
}

function updateMemberRole(memberId, newRole) {
  supabase.from("community_members").update({
    role: newRole
  }).eq("id", memberId).then(function(res) {
    if (res.error) {
      toast(t("community.err_role_change") + " " + res.error.message);
      return;
    }
    toast(newRole === "co_admin" ? "Ahora es Co-Admin." : "Ya no es Co-Admin.");
    refreshCommunityView(true);
  });
}

var kickTargetMember = null;

function kickMember(memberId) {
  var member = communityMembers.filter(function(m) {
    return String(m.id) === String(memberId);
  })[0];
  if (!member) return;
  kickTargetMember = member;
  var name = member.profiles ? member.profiles.username : "este miembro";
  showAppAlert({
    title: "¿Expulsar a " + name + "?",
    message: "Elige qué quieres hacer.",
    buttons: [ {
      label: "Expulsar",
      onClick: function() {
        performKick("kick");
      }
    }, {
      label: "Expulsar y borrar contenido",
      style: "",
      onClick: function() {
        performKick("kick_wipe");
      }
    }, {
      label: "Expulsar y banear",
      style: "danger",
      onClick: function() {
        performKick("ban");
      }
    }, {
      label: "Cancelar",
      onClick: function() {
        kickTargetMember = null;
      }
    } ]
  });
}

function performKick(mode) {
  if (!kickTargetMember || !currentCommunity) return;
  var member = kickTargetMember;
  supabase.rpc("admin_kick_member", {
    p_community_id: currentCommunity.id,
    p_target_user_id: member.user_id,
    p_mode: mode
  }).then(function(res) {
    if (res.error) {
      showErrorAlert(res.error.message);
      return;
    }
    toast(mode === "ban" ? "Miembro expulsado y baneado." : mode === "kick_wipe" ? "Miembro expulsado y su contenido fue borrado." : "Miembro expulsado.");
    kickTargetMember = null;
    refreshCommunityView(true);
  });
}

function joinCurrentCommunity() {
  if (!currentUser || !currentCommunity) return;
  supabase.from("community_bans").select("id").eq("community_id", currentCommunity.id).eq("user_id", currentUser.id).maybeSingle().then(function(banRes) {
    if (banRes.data) {
      toast(t("community.err_banned"));
      return Promise.reject(null);
    }
    return supabase.from("community_members").insert({
      community_id: currentCommunity.id,
      user_id: currentUser.id,
      role: "member"
    });
  }).then(function(res) {
    if (!res) return;
    if (res.error) {
      toast(t("community.err_join") + " " + res.error.message);
      return;
    }
    toast(t("community.toast_joined") + " " + currentCommunity.name + ".");
    refreshCommunityView(false);
  }).catch(function() {});
}

function openCommunityInvitePicker() {
  if (!currentCommunity || !currentUser) return;
  var body = $("communityInviteBody");
  body.innerHTML = '<p class="profile-empty-hint">Cargando tus seguidores...</p>';
  $("communityInviteBackdrop").classList.add("open");
  supabase.rpc("get_followers_list", {
    target_user_id: currentUser.id
  }).then(function(res) {
    var rows = (res.error ? [] : res.data || []).map(function(r) {
      return {
        id: r.user_id,
        username: r.username,
        avatar_url: r.avatar_url
      };
    });
    var memberIds = communityMembers.map(function(m) {
      return m.user_id;
    });
    rows = rows.filter(function(r) {
      return memberIds.indexOf(r.id) === -1;
    });
    if (!rows.length) {
      body.innerHTML = '<p class="profile-empty-hint">No tienes seguidores para invitar (o ya están todos en la comunidad).</p>';
      return;
    }
    body.innerHTML = '<div class="thread-list">' + rows.map(function(p) {
      return '<article class="dm-card" data-uid="' + escapeHtml(p.id) + '">' + avatarSpanHtml(p.username, p.avatar_url, null, p.id) + '<div class="dm-card-main"><div class="dm-card-top"><span class="dm-card-name">@' + escapeHtml(p.username) + "</span></div></div>" + '<button type="button" class="terminal-btn small" data-act="invite">Invitar</button>' + "</article>";
    }).join("") + "</div>";
    qsa(".dm-card", body).forEach(function(card) {
      var uid = card.getAttribute("data-uid");
      var btn = card.querySelector('[data-act="invite"]');
      btn.addEventListener("click", function() {
        btn.disabled = true;
        btn.textContent = "Invitando...";
        supabase.rpc("invite_to_community", {
          p_community_id: currentCommunity.id,
          p_invitee_id: uid
        }).then(function(res2) {
          if (res2.error) {
            toast(t("community.err_invite") + " " + res2.error.message);
            btn.disabled = false;
            btn.textContent = t("community.btn_invite");
            return;
          }
          btn.textContent = "Invitado ✓";
        });
      });
    });
  });
}

$("btnCommunityInviteClose").addEventListener("click", function() {
  $("communityInviteBackdrop").classList.remove("open");
});

$("communityInviteBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

function handleCommunityLeaveClick() {
  var role = myCommunityRole();
  var isSiteAdmin = currentUser && currentUser.role === "admin";
  if (!currentCommunity) return;
  if (role === "admin" || isSiteAdmin) {
    if (!confirm("Esto elimina la comunidad para siempre, junto con su chat y miembros. ¿Continuar?")) return;
    supabase.from("communities").delete().eq("id", currentCommunity.id).then(function(res) {
      if (res.error) {
        toast(t("community.err_delete") + " " + res.error.message);
        return;
      }
      toast(t("community.toast_deleted"));
      closeCommunityDetail(true);
    });
    return;
  }
  if (!confirm("¿Salir de esta comunidad?")) return;
  var mine = communityMembers.filter(function(m) {
    return currentUser && m.user_id === currentUser.id;
  })[0];
  if (!mine) return;
  supabase.from("community_members").delete().eq("id", mine.id).then(function(res) {
    if (res.error) {
      toast(t("community.err_leave") + " " + res.error.message);
      return;
    }
    toast(t("community.toast_left"));
    closeCommunityDetail(true);
  });
}

function loadCommunityMessages() {
  if (!currentCommunity) return Promise.resolve();
  return supabase.from("community_messages").select("*, profiles(username, name, avatar_url, name_color, role, verified)").eq("community_id", currentCommunity.id).order("created_at", {
    ascending: false
  }).limit(150).then(function(res) {
    if (res.error) {
      console.error("Error cargando mensajes de comunidad:", res.error);
      return;
    }
    COMMUNITY_MESSAGES = z3tProcessReplies((res.data || []).slice().reverse());
    renderCommunityChat();
  });
}

function renderCommunityChat() {
  var chat = $("communityChat");
  if (!chat) return;
  if (!COMMUNITY_MESSAGES.length) {
    chat.innerHTML = '<p class="empty-state">Todavía no hay mensajes. ¡Sé el primero en escribir!</p>';
    chat.dataset.msgSig = "";
    return;
  }
  var sig = messagesSignature(COMMUNITY_MESSAGES);
  if (chat.dataset.msgSig === sig) return;
  var lastCm = COMMUNITY_MESSAGES[COMMUNITY_MESSAGES.length - 1];
  var lastIsMine = !!(lastCm && currentUser && lastCm.sender_id === currentUser.id && lastCm.type !== "system");
  var wasNearBottom = !chat.dataset.msgSig || isNearBottom(chat, chat.clientHeight + 240) || lastIsMine && chat.dataset.lastMineId !== String(lastCm.id);
  chat.dataset.lastMineId = lastIsMine ? String(lastCm.id) : chat.dataset.lastMineId || "";
  chat.innerHTML = COMMUNITY_MESSAGES.map(function(m) {
    if (m.type === "system") return '<div class="chat-system-msg">' + escapeHtml(m.body) + "</div>";
    var realName = m.profiles ? m.profiles.name || m.profiles.username : "usuario";
    var realHandle = m.profiles ? m.profiles.username : "";
    var rpm = typeof rpDecodeMessage === "function" ? rpDecodeMessage(m) : null;
    var isCharacter = !!(m.roleplay_character_name || rpm);
    var name = m.roleplay_character_name ? m.roleplay_character_name : rpm ? rpm.name : realName;
    var avatarUrl = m.roleplay_character_name ? (m.roleplay_character_avatar || (m.roleplay_character_id && typeof rpCharacterById === "function" && rpCharacterById(m.roleplay_character_id) ? rpCharacterById(m.roleplay_character_id).avatar_url : null)) : rpm ? rpm.avatar : m.profiles ? m.profiles.avatar_url : null;
    var nameColor = isCharacter ? null : m.profiles ? m.profiles.name_color : null;
    var acctRole = m.profiles ? m.profiles.role : null;
    var acctVerified = m.profiles ? m.profiles.verified : null;
    var bodyHtml;
    if (m.type === "image") {
      bodyHtml = '<div class="chat-msg-image"><img src="' + safeUrlAttr(m.body) + '" alt="" loading="lazy"></div>';
    } else if (m.type === "audio") {
      bodyHtml = z3tAudioPlayerHtml(m.body);
    } else if (m.type === "poll") {
      bodyHtml = renderPollHtml(m);
    } else if (m.type === "gift") {
      bodyHtml = giftCardMessageHtml(m.body);
    } else {
      bodyHtml = '<div class="chat-msg-text">' + z3tRichText(rpm ? rpm.body : m.body) + "</div>";
    }
    var rpc = isCharacter && typeof rpMsgColor === "function" ? rpMsgColor(m, name) : null;
    var ra = z3tMsgRoleAttrs("community", m.sender_id);
    return '<div class="chat-msg' + ra.cls + '"' + ra.style + z3tMsgAttrs("community", m, name) + '>' + rpTintAvatar(avatarSpanHtml(name, avatarUrl, null, isCharacter ? null : m.sender_id), rpc) + '<div class="chat-msg-col">' + '<div class="chat-msg-name" data-uid="' + escapeHtml(m.sender_id || "") + '" title="' + escapeHtml(isCharacter ? "@" + realHandle : "") + '"' + (nameColor ? ' style="color:' + escapeHtml(nameColor) + '"' : "") + ">" + escapeHtml(name) + (isCharacter ? '<span class="rp-char-badge">' + activityIconHtml("roleplay") + " personaje</span>" : roleBadgeHtml(acctRole, acctVerified)) + (isCharacter ? "" : z3tRoleTagHtml(ra.role, z3tChatEntity("community"))) + "</div>" + z3tReplyQuoteHtml(m) + chatMsgBodyOpenTag(m.sender_id, rpc) + bodyHtml + "</div>" + z3tReactionsSlotHtml(m) + "</div>" + "</div>";
  }).join("");
  chat.dataset.msgSig = sig;
  if (wasNearBottom) chat.scrollTop = chat.scrollHeight;
  z3tAfterRender("community");
  qsa(".poll-option-btn", chat).forEach(function(btn) {
    btn.addEventListener("click", function() {
      voteCommunityPoll(btn.getAttribute("data-mid"), Number(btn.getAttribute("data-idx")));
    });
  });
}

function renderPollHtml(m) {
  var poll;
  try {
    poll = JSON.parse(m.body);
  } catch (_e) {
    return '<div class="chat-msg-text">Encuesta</div>';
  }
  var totalVotes = poll.options.reduce(function(sum, o) {
    return sum + (o.votes ? o.votes.length : 0);
  }, 0);
  var myVoteIdx = -1;
  if (currentUser) {
    poll.options.forEach(function(o, i) {
      if (o.votes && o.votes.indexOf(currentUser.id) !== -1) myVoteIdx = i;
    });
  }
  return '<div class="poll-card">' + '<div class="poll-question">📊 ' + escapeHtml(poll.question) + "</div>" + poll.options.map(function(o, i) {
    var count = o.votes ? o.votes.length : 0;
    var pct = totalVotes ? Math.round(count / totalVotes * 100) : 0;
    return '<button class="poll-option-btn' + (myVoteIdx === i ? " voted" : "") + '" data-mid="' + escapeHtml(m.id) + '" data-idx="' + i + '" type="button">' + '<div class="poll-option-fill" style="width:' + pct + '%"></div>' + '<span class="poll-option-label">' + escapeHtml(o.text) + "</span>" + '<span class="poll-option-pct">' + pct + "% (" + count + ")</span>" + "</button>";
  }).join("") + '<div class="poll-total">' + totalVotes + " voto" + (totalVotes === 1 ? "" : "s") + "</div>" + "</div>";
}

function voteCommunityPoll(messageId, optionIdx) {
  if (!currentUser) return;
  supabase.from("community_messages").select("*").eq("id", messageId).single().then(function(res) {
    if (res.error) return;
    var poll;
    try {
      poll = JSON.parse(res.data.body);
    } catch (_e) {
      return;
    }
    poll.options.forEach(function(o) {
      if (!o.votes) o.votes = [];
      var pos = o.votes.indexOf(currentUser.id);
      if (pos !== -1) o.votes.splice(pos, 1);
    });
    poll.options[optionIdx].votes.push(currentUser.id);
    supabase.from("community_messages").update({
      body: JSON.stringify(poll)
    }).eq("id", messageId).then(function() {
      loadCommunityMessages();
    });
  });
}

function openCommunityPollModal() {
  if (!currentUser || !currentCommunity) return;
  $("pollCreateBackdrop").classList.add("open");
  $("pollCreateForm").reset();
}

function submitCommunityPoll(question, options) {
  var poll = {
    question: question,
    options: options.map(function(t) {
      return {
        text: t,
        votes: []
      };
    })
  };
  supabase.from("community_messages").insert({
    community_id: currentCommunity.id,
    sender_id: currentUser.id,
    body: JSON.stringify(poll),
    type: "poll"
  }).then(function(res) {
    if (res.error) {
      toast(t("community.err_poll_create") + " " + res.error.message);
      return;
    }
    $("pollCreateBackdrop").classList.remove("open");
    loadCommunityMessages();
  });
}

function sendCommunityImage(file) {
  if (!currentUser || !currentCommunity) return;
  toast(t("community.toast_uploading_image"));
  uploadFiles([ file ], "community-chat/" + currentCommunity.id).then(function(results) {
    var url = results[0] ? results[0].url : null;
    if (!url) {
      toast(t("community.err_image_upload"));
      return;
    }
    supabase.from("community_messages").insert({
      community_id: currentCommunity.id,
      sender_id: currentUser.id,
      body: url,
      type: "image"
    }).then(function(res) {
      if (res.error) {
        toast(t("community.err_send") + " " + res.error.message);
        return;
      }
      loadCommunityMessages();
    });
  }).catch(function(err) {
    toast(t("community.err_image_upload2") + " " + (err && err.message ? err.message : t("community.err_unknown")));
  });
}

var communityAudioRecorder = null;

var communityAudioChunks = [];

function pickSupportedAudioMime() {
  var candidates = [ "audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus" ];
  if (typeof MediaRecorder === "undefined" || !MediaRecorder.isTypeSupported) return "";
  for (var i = 0; i < candidates.length; i++) {
    if (MediaRecorder.isTypeSupported(candidates[i])) return candidates[i];
  }
  return "";
}

function toggleCommunityAudioRecording() {
  if (communityAudioRecorder && communityAudioRecorder.state === "recording") {
    communityAudioRecorder.stop();
    return;
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    toast(t("community.err_no_audio_support"));
    return;
  }
  navigator.mediaDevices.getUserMedia({
    audio: true
  }).then(function(stream) {
    communityAudioChunks = [];
    var chosenMime = pickSupportedAudioMime();
    try {
      communityAudioRecorder = chosenMime ? new MediaRecorder(stream, {
        mimeType: chosenMime
      }) : new MediaRecorder(stream);
    } catch (_e) {
      stream.getTracks().forEach(function(t) {
        t.stop();
      });
      toast(t("community.err_no_audio_format"));
      return;
    }
    communityAudioRecorder.addEventListener("dataavailable", function(e) {
      if (e.data.size > 0) communityAudioChunks.push(e.data);
    });
    communityAudioRecorder.addEventListener("stop", function() {
      stream.getTracks().forEach(function(t) {
        t.stop();
      });
      var audioBtn = $("btnCommunityAudio");
      if (audioBtn) audioBtn.classList.remove("recording");
      var mimeType = communityAudioRecorder.mimeType || chosenMime || "audio/webm";
      var blob = new Blob(communityAudioChunks, {
        type: mimeType
      });
      if (blob.size < 500) {
        toast(t("community.err_recording_short"));
        return;
      }
      var ext = mimeType.indexOf("mp4") !== -1 ? "m4a" : mimeType.indexOf("ogg") !== -1 ? "ogg" : "webm";
      var file = new File([ blob ], "audio-" + Date.now() + "." + ext, {
        type: mimeType
      });
      toast(t("community.toast_sending_audio"));
      uploadFiles([ file ], "community-chat/" + currentCommunity.id).then(function(results) {
        var url = results[0] ? results[0].url : null;
        if (!url) {
          toast(t("community.err_audio_upload2"));
          return;
        }
        supabase.from("community_messages").insert({
          community_id: currentCommunity.id,
          sender_id: currentUser.id,
          body: url,
          type: "audio"
        }).then(function(res) {
          if (res.error) {
            toast(t("community.err_send") + " " + res.error.message);
            return;
          }
          loadCommunityMessages();
        });
      }).catch(function(err) {
        toast(t("community.err_audio_upload") + " " + (err && err.message ? err.message : t("community.err_unknown")));
      });
    });
    communityAudioRecorder.start();
    var audioBtn = $("btnCommunityAudio");
    if (audioBtn) audioBtn.classList.add("recording");
    toast(t("community.toast_recording"));
  }).catch(function() {
    toast(t("community.err_mic_access"));
  });
}

function sendCommunityMessage(e) {
  e.preventDefault();
  if (!currentUser || !currentCommunity) return;
  var input = $("communityChatInput");
  var body = input.value.trim();
  if (!body) return;
  input.disabled = true;
  var msgRow = {
    community_id: currentCommunity.id,
    sender_id: currentUser.id,
    body: z3tWithReply("community", body),
    type: "message"
  };
  var myChar = currentCommunity.active_activity === "roleplay" && typeof myActiveRoleplayCharacter === "function" ? myActiveRoleplayCharacter() : null;
  var sendP = myChar && typeof rpInsertMessage === "function" ? rpInsertMessage("community_messages", msgRow, myChar) : supabase.from("community_messages").insert(myChar ? Object.assign({}, msgRow, {
    roleplay_character_id: myChar.id,
    roleplay_character_name: myChar.name,
    roleplay_character_avatar: myChar.avatar_url || null
  }) : msgRow);
  sendP.then(function(res) {
    input.disabled = false;
    if (res.error) {
      console.error("Error enviando mensaje de comunidad:", res.error);
      toast(t("community.err_send") + " " + res.error.message);
      return;
    }
    input.value = "";
    z3tClearReply();
    input.focus();
    loadCommunityMessages().then(function() {
      var c = $("communityChat");
      if (c) c.scrollTop = c.scrollHeight;
    });
    touchCommunityAdminPresence();
  }).catch(function(err) {
    input.disabled = false;
    console.error("Error enviando mensaje de comunidad:", err);
    toast(t("community.err_send"));
  });
}

var mentionActive = false;

function wireCommunityMentionPicker() {
  var input = $("communityChatInput");
  var popup = $("communityMentionPopup");
  if (!input || !popup) return;
  input.addEventListener("input", function() {
    var m = input.value.match(/@([a-zA-Z0-9_]*)$/);
    if (!m) {
      popup.hidden = true;
      mentionActive = false;
      return;
    }
    mentionActive = true;
    var query = m[1].toLowerCase();
    var candidates = communityMembers.filter(function(cm) {
      return cm.user_id !== currentUser.id && cm.profiles && (cm.profiles.username || "").toLowerCase().indexOf(query) === 0;
    }).slice(0, 6);
    var rows = '<button type="button" class="mention-row" data-call="all"><span class="mention-row-name">📣 Llamar a todos</span></button>' + candidates.map(function(cm) {
      var name = cm.profiles.name || cm.profiles.username;
      return '<button type="button" class="mention-row" data-call="' + escapeHtml(cm.user_id) + '" data-username="' + escapeHtml(cm.profiles.username) + '">' + avatarSpanHtml(name, cm.profiles.avatar_url) + '<span class="mention-row-name">' + escapeHtml(name) + ' <span class="mention-row-handle">@' + escapeHtml(cm.profiles.username) + "</span></span>" + "</button>";
    }).join("");
    popup.innerHTML = rows;
    popup.hidden = false;
    qsa(".mention-row", popup).forEach(function(btn) {
      btn.addEventListener("click", function() {
        var callTarget = btn.getAttribute("data-call");
        var replaced = input.value.replace(/@([a-zA-Z0-9_]*)$/, callTarget === "all" ? "@todos " : "@" + btn.getAttribute("data-username") + " ");
        input.value = replaced;
        popup.hidden = true;
        mentionActive = false;
        input.focus();
        if (callTarget === "all") {
          supabase.rpc("call_community_all", {
            p_community_id: currentCommunity.id
          }).then(function(res) {
            if (res.error) {
              showErrorAlert(res.error.message);
              return;
            }
            toast(t("community.toast_called_all"));
          });
        } else {
          supabase.rpc("call_community_member", {
            p_community_id: currentCommunity.id,
            p_target_user_id: callTarget
          }).then(function(res) {
            if (res.error) {
              showErrorAlert(res.error.message);
              return;
            }
            toast(t("community.toast_notified_waiting"));
          });
        }
      });
    });
  });
  document.addEventListener("click", function(e) {
    if (mentionActive && !e.target.closest("#communityMentionPopup") && e.target !== input) {
      popup.hidden = true;
      mentionActive = false;
    }
  });
}

function loadCommunityCuyState() {
  communityCuyTapsToday = 0;
  if (communityCuyCooldownTimer) {
    clearInterval(communityCuyCooldownTimer);
    communityCuyCooldownTimer = null;
  }
  if (!currentUser || !currentCommunity) {
    updateCuyBadge();
    return;
  }
  var todayStr = (new Date).toISOString().slice(0, 10);
  supabase.from("community_cuy_taps").select("taps").eq("community_id", currentCommunity.id).eq("user_id", currentUser.id).eq("tap_date", todayStr).maybeSingle().then(function(res) {
    communityCuyTapsToday = res.data && res.data.taps || 0;
    updateCuyBadge();
  });
}

function setCuyBtnImage(state) {
  var img = $("cuyBtnImg");
  if (img) img.src = CUY_STATE_IMG[state] || CUY_STATE_IMG.active;
}

function updateCuyBadge(remainingSeconds) {
  var badge = $("cuyBtnBadge");
  var btn = $("btnCommunityCuy");
  if (!badge || !btn) return;
  if (remainingSeconds) {
    badge.hidden = false;
    badge.className = "cuy-btn-badge cooldown";
    badge.textContent = remainingSeconds + "s";
    btn.disabled = true;
    setCuyBtnImage("waiting");
  } else if (communityCuyTapsToday >= CUY_DAILY_LIMIT) {
    badge.hidden = false;
    badge.className = "cuy-btn-badge cooldown";
    badge.textContent = "✓";
    btn.disabled = true;
    setCuyBtnImage("disabled");
  } else {
    btn.disabled = false;
    setCuyBtnImage("active");
    var left = CUY_DAILY_LIMIT - communityCuyTapsToday;
    if (left <= CUY_DAILY_LIMIT - 5) {
      badge.hidden = false;
      badge.className = "cuy-btn-badge";
      badge.textContent = left;
    } else {
      badge.hidden = true;
    }
  }
}

function tapCommunityCuy() {
  if (!currentUser) {
    toast(t("community.login_cuy"));
    return;
  }
  if (!currentCommunity) return;
  if (communityCuyTapsToday >= CUY_DAILY_LIMIT) {
    toast(t("community.err_cuy_limit"));
    return;
  }
  var btn = $("btnCommunityCuy");
  spawnCuyParticles(btn);
  if (btn) {
    btn.classList.remove("cuy-pulse");
    void btn.offsetWidth;
    btn.classList.add("cuy-pulse");
  }
  var tapIndexBeforeThis = communityCuyTapsToday;
  var isFinalTap = tapIndexBeforeThis === CUY_DAILY_LIMIT - 1;
  communityCuyTapsToday += 1;
  supabase.rpc("tap_community_cuy", {
    p_community_id: currentCommunity.id
  }).then(function(res) {
    if (res.error) {
      communityCuyTapsToday -= 1;
      toast(t("community.err_cuy_give") + " " + res.error.message);
      updateCuyBadge();
      return;
    }
    var row = Array.isArray(res.data) ? res.data[0] : res.data;
    if (row) {
      communityCuyTapsToday = row.out_taps;
      if (typeof row.out_cuy_count === "number" || typeof row.out_cuy_count === "string") {
        currentCommunity.cuy_count = Number(row.out_cuy_count);
      }
    }
    if (isFinalTap) spawnCuyCompleteBurst(btn);
    if (tapIndexBeforeThis >= 5 && tapIndexBeforeThis < CUY_DAILY_LIMIT) {
      startCuyCooldown(CUY_COOLDOWNS[tapIndexBeforeThis - 5] || 1);
    } else {
      updateCuyBadge();
    }
  });
}

function startCuyCooldown(seconds) {
  var remaining = seconds;
  updateCuyBadge(remaining);
  if (communityCuyCooldownTimer) clearInterval(communityCuyCooldownTimer);
  communityCuyCooldownTimer = setInterval(function() {
    remaining -= 1;
    if (remaining <= 0) {
      clearInterval(communityCuyCooldownTimer);
      communityCuyCooldownTimer = null;
      updateCuyBadge();
      return;
    }
    updateCuyBadge(remaining);
  }, 1e3);
}

function spawnCuyParticles(btn) {
  if (!btn) return;
  var rect = btn.getBoundingClientRect();
  var originX = rect.left + rect.width / 2;
  var originY = rect.top + rect.height / 2;
  var count = 8;
  for (var i = 0; i < count; i++) {
    var img = document.createElement("img");
    img.className = "cuy-particle";
    img.src = CUY_PARTICLE_GLYPHS[Math.floor(Math.random() * CUY_PARTICLE_GLYPHS.length)];
    img.alt = "";
    var angle = Math.PI * 2 * (i / count) + (Math.random() * .6 - .3);
    var distance = 46 + Math.random() * 46;
    var tx = Math.cos(angle) * distance;
    var ty = Math.sin(angle) * distance - 18;
    img.style.setProperty("--cuy-tx", tx.toFixed(0) + "px");
    img.style.setProperty("--cuy-ty", ty.toFixed(0) + "px");
    img.style.setProperty("--cuy-rot", (Math.random() * 140 - 70).toFixed(0) + "deg");
    img.style.left = originX + "px";
    img.style.top = originY + "px";
    document.body.appendChild(img);
    (function(el) {
      setTimeout(function() {
        if (el.parentNode) el.parentNode.removeChild(el);
      }, 1e3);
    })(img);
  }
}

function spawnCuyCompleteBurst(btn) {
  if (!btn) return;
  var rect = btn.getBoundingClientRect();
  var originX = rect.left + rect.width / 2;
  var originY = rect.top + rect.height / 2;
  var count = 10;
  for (var i = 0; i < count; i++) {
    var img = document.createElement("img");
    img.className = "cuy-particle cuy-particle-qi";
    img.src = CUY_QI_GLYPHS[i % CUY_QI_GLYPHS.length];
    img.alt = "";
    var angle = Math.PI * 2 * (i / count);
    var distance = 60 + Math.random() * 54;
    var tx = Math.cos(angle) * distance;
    var ty = Math.sin(angle) * distance - 24;
    img.style.setProperty("--cuy-tx", tx.toFixed(0) + "px");
    img.style.setProperty("--cuy-ty", ty.toFixed(0) + "px");
    img.style.setProperty("--cuy-rot", (Math.random() * 200 - 100).toFixed(0) + "deg");
    img.style.left = originX + "px";
    img.style.top = originY + "px";
    document.body.appendChild(img);
    (function(el) {
      setTimeout(function() {
        if (el.parentNode) el.parentNode.removeChild(el);
      }, 1200);
    })(img);
  }
}