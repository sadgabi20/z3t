"use strict";

/* =====================================================================
   Acciones de mensaje estilo WhatsApp (chats de comunidad, grupo y DM)
   - Mantener presionado un mensaje -> semipantalla con reaccionar,
     responder, reportar (solo ajenos) y borrar (propios / staff).
   - Respuestas con cita (se guardan como prefijo en el body).
   - Reacciones con emojis (tabla message_reactions).
   - Selector de emojis grande con pestañas Emojis | Stickers.
   ===================================================================== */

var Z3T_LONGPRESS_MS = 500; /* tiempo que hay que mantener presionado */
var Z3T_QUICK_REACTIONS = [ "👍", "❤️", "😂", "🌸", "😮", "😢", "🙏" ];

/* ------------------------- Respuestas (prefijo en body) ------------------------- */

var Z3T_REPLY_RE = /^((?:\[\[rp\|[^|\]]*\|[^|\]]*\]\])?)\[\[re\|([^|\]]*)\|([^|\]]*)\|([^|\]]*)\]\]/;

function z3tReplyEncode(draft) {
  return "[[re|" + encodeURIComponent(draft.id) + "|" + encodeURIComponent(draft.name || "") + "|" + encodeURIComponent(draft.snippet || "") + "]]";
}

/* Quita el prefijo de respuesta de cada mensaje y lo deja en m._reply */
function z3tProcessReplies(list) {
  (list || []).forEach(function(m) {
    if (!m || typeof m.body !== "string") return;
    var mt = m.body.match(Z3T_REPLY_RE);
    if (!mt) return;
    try {
      m._reply = {
        id: decodeURIComponent(mt[2]),
        name: decodeURIComponent(mt[3]),
        snippet: decodeURIComponent(mt[4])
      };
    } catch (_e) {
      m._reply = null;
    }
    m.body = mt[1] + m.body.slice(mt[0].length);
  });
  return list;
}

function z3tReplyQuoteHtml(m) {
  if (!m || !m._reply) return "";
  return '<div class="reply-quote" data-reply-id="' + escapeHtml(m._reply.id) + '">' + '<div class="reply-quote-name">' + escapeHtml(m._reply.name || "mensaje") + "</div>" + '<div class="reply-quote-text">' + escapeHtml(m._reply.snippet || "") + "</div>" + "</div>";
}

/* Atributos del contenedor .chat-msg para poder localizar el mensaje */
function z3tMsgAttrs(kind, m, name) {
  if (!m || !m.id) return "";
  return ' data-mid="' + escapeHtml(String(m.id)) + '" data-mkind="' + escapeHtml(kind) + '" data-mname="' + escapeHtml(name || "") + '"';
}

function z3tReactionsSlotHtml(m) {
  if (!m || !m.id) return "";
  return '<div class="msg-reactions" data-react-for="' + escapeHtml(String(m.id)) + '" hidden></div>';
}

/* ------------------------- Utilidades de mensaje ------------------------- */

var Z3T_CHAT_KINDS = {
  community: {
    box: "communityChat",
    input: "communityChatInput",
    table: "community_messages"
  },
  group: {
    box: "groupChat",
    input: "groupChatInput",
    table: "private_group_messages"
  },
  dm: {
    box: "conversationMessages",
    input: "dmInput",
    table: "dm_messages"
  }
};

function z3tMsgList(kind) {
  if (kind === "dm") return typeof DM_MESSAGES !== "undefined" ? DM_MESSAGES : [];
  if (kind === "group") return typeof GROUP_MESSAGES !== "undefined" ? GROUP_MESSAGES : [];
  return typeof COMMUNITY_MESSAGES !== "undefined" ? COMMUNITY_MESSAGES : [];
}

function z3tFindMsg(kind, id) {
  return z3tMsgList(kind).filter(function(m) {
    return String(m.id) === String(id);
  })[0] || null;
}

function z3tMsgSnippet(m) {
  if (!m) return "";
  if (m.type === "image") return "📷 Foto";
  if (m.type === "audio") return "🎤 Audio";
  if (m.type === "gift") return "🎁 Regalo";
  if (m.type === "poll") {
    try {
      return "📊 " + (JSON.parse(m.body).question || "Encuesta");
    } catch (_e) {
      return "📊 Encuesta";
    }
  }
  var text = m.body || "";
  if (typeof rpStripBody === "function") text = rpStripBody(text);
  var parsed = typeof parseAttachments === "function" ? parseAttachments(text) : {
    text: text,
    attachments: []
  };
  var plain = (parsed.text || "").replace(/\s+/g, " ").trim();
  if (!plain && parsed.attachments && parsed.attachments.length) {
    var first = parsed.attachments[0] || {};
    var isImg = /^image\//.test(first.type || "") || /\.(png|jpe?g|gif|webp)(\?|$)/i.test(first.url || "");
    return isImg ? "📷 Foto" : "📎 Archivo";
  }
  return plain.length > 90 ? plain.slice(0, 90) + "…" : plain;
}

function z3tMsgPlainText(m) {
  if (!m || m.type === "image" || m.type === "audio" || m.type === "gift" || m.type === "poll") return "";
  var text = m.body || "";
  if (typeof rpStripBody === "function") text = rpStripBody(text);
  var parsed = typeof parseAttachments === "function" ? parseAttachments(text) : {
    text: text
  };
  return (parsed.text || "").trim();
}

function z3tCanDeleteMsg(kind, m) {
  if (!currentUser || !m || m.type === "system") return false;
  if (m.sender_id && m.sender_id === currentUser.id) return true;
  if (kind === "dm") return false;
  return typeof z3tCanDeleteChatMsg === "function" ? z3tCanDeleteChatMsg(kind, m) : false;
}

/* ------------------------- Reacciones ------------------------- */

var z3tReactCache = {};

function z3tReactKey(kind, id) {
  return kind + ":" + id;
}

function z3tPaintReactions(box, kind) {
  if (!box) return;
  var myId = currentUser ? currentUser.id : null;
  box.querySelectorAll(".msg-reactions[data-react-for]").forEach(function(slot) {
    var id = slot.getAttribute("data-react-for");
    var rows = z3tReactCache[z3tReactKey(kind, id)] || [];
    if (!rows.length) {
      slot.innerHTML = "";
      slot.hidden = true;
      return;
    }
    var groups = {};
    var order = [];
    rows.forEach(function(r) {
      if (!groups[r.emoji]) {
        groups[r.emoji] = {
          n: 0,
          mine: false
        };
        order.push(r.emoji);
      }
      groups[r.emoji].n++;
      if (r.user_id === myId) groups[r.emoji].mine = true;
    });
    order.sort(function(x, y) {
      return groups[y].n - groups[x].n;
    });
    slot.innerHTML = order.map(function(em) {
      var g = groups[em];
      return '<button type="button" class="react-pill' + (g.mine ? " mine" : "") + '" data-react-emoji="' + escapeHtml(em) + '" data-mid="' + escapeHtml(id) + '" data-mkind="' + escapeHtml(kind) + '">' + escapeHtml(em) + (g.n > 1 ? "<span>" + g.n + "</span>" : "") + "</button>";
    }).join("");
    slot.hidden = false;
  });
}

function z3tRefreshReactions(kind) {
  var cfg = Z3T_CHAT_KINDS[kind];
  var box = cfg ? document.getElementById(cfg.box) : null;
  if (!box || !currentUser) return Promise.resolve();
  var ids = [];
  box.querySelectorAll(".msg-reactions[data-react-for]").forEach(function(s) {
    ids.push(s.getAttribute("data-react-for"));
  });
  z3tPaintReactions(box, kind);
  if (!ids.length) return Promise.resolve();
  var chunks = [];
  for (var i = 0; i < ids.length; i += 50) chunks.push(ids.slice(i, i + 50));
  return Promise.all(chunks.map(function(chunk) {
    return supabase.from("message_reactions").select("message_id,user_id,emoji").eq("kind", kind).in("message_id", chunk).then(function(res) {
      if (res.error) return;
      chunk.forEach(function(id) {
        z3tReactCache[z3tReactKey(kind, id)] = [];
      });
      (res.data || []).forEach(function(r) {
        z3tReactCache[z3tReactKey(kind, r.message_id)].push(r);
      });
    });
  })).then(function() {
    z3tPaintReactions(document.getElementById(cfg.box), kind);
  });
}

/* Llamar después de cada render de mensajes */
function z3tAfterRender(kind) {
  z3tRefreshReactions(kind);
}

function z3tReact(kind, mid, emoji) {
  if (!currentUser) {
    toast("Inicia sesión para reaccionar.");
    return;
  }
  var key = z3tReactKey(kind, mid);
  var rows = (z3tReactCache[key] || []).slice();
  var mine = rows.filter(function(r) {
    return r.user_id === currentUser.id;
  })[0];
  var op;
  if (mine && mine.emoji === emoji) {
    rows = rows.filter(function(r) {
      return r !== mine;
    });
    op = supabase.from("message_reactions").delete().eq("kind", kind).eq("message_id", mid).eq("user_id", currentUser.id);
  } else if (mine) {
    mine.emoji = emoji;
    op = supabase.from("message_reactions").update({
      emoji: emoji
    }).eq("kind", kind).eq("message_id", mid).eq("user_id", currentUser.id);
  } else {
    rows.push({
      message_id: mid,
      user_id: currentUser.id,
      emoji: emoji
    });
    op = supabase.from("message_reactions").insert({
      kind: kind,
      message_id: mid,
      user_id: currentUser.id,
      emoji: emoji
    });
  }
  z3tReactCache[key] = rows;
  z3tPaintReactions(document.getElementById(Z3T_CHAT_KINDS[kind].box), kind);
  op.then(function(res) {
    if (res && res.error) {
      console.error("[reacciones]", res.error);
      toast("No se pudo guardar la reacción.");
    }
    z3tRefreshReactions(kind);
  });
}

/* ------------------------- Respuesta: barra sobre el compositor ------------------------- */

var z3tReplyDraft = null;

function z3tClearReply() {
  z3tReplyDraft = null;
  document.querySelectorAll(".reply-draft-bar").forEach(function(b) {
    b.remove();
  });
}

function z3tSetReply(kind, m, name) {
  var cfg = Z3T_CHAT_KINDS[kind];
  var input = cfg ? document.getElementById(cfg.input) : null;
  if (!input) return;
  z3tClearReply();
  z3tReplyDraft = {
    kind: kind,
    id: String(m.id),
    name: name || "",
    snippet: z3tMsgSnippet(m).slice(0, 80),
    input: input
  };
  var bar = document.createElement("div");
  bar.className = "reply-draft-bar";
  bar.innerHTML = '<div class="reply-draft-main"><div class="reply-quote-name">' + escapeHtml("Respondiendo a " + (name || "mensaje")) + '</div><div class="reply-quote-text">' + escapeHtml(z3tReplyDraft.snippet) + "</div></div>" + '<button type="button" class="reply-draft-close" aria-label="Cancelar respuesta">✕</button>';
  bar.querySelector(".reply-draft-close").addEventListener("click", z3tClearReply);
  var row = input.closest(".composer-top-row") || input.parentElement;
  row.parentElement.insertBefore(bar, row);
  input.focus();
}

/* Devuelve el body con el prefijo de respuesta si hay una pendiente para este chat */
function z3tWithReply(kind, body) {
  var d = z3tReplyDraft;
  if (!d || d.kind !== kind) return body;
  var cfg = Z3T_CHAT_KINDS[kind];
  var input = document.getElementById(cfg.input);
  if (!input || input !== d.input || !document.body.contains(d.input)) {
    z3tClearReply();
    return body;
  }
  return z3tReplyEncode(d) + body;
}

/* ------------------------- Semipantalla del mensaje ------------------------- */

var z3tSheetOpenedAt = 0;

function z3tCloseSheet() {
  var bd = document.getElementById("z3tMsgSheetBackdrop");
  if (bd) bd.classList.remove("open");
}

function z3tOpenMsgSheet(el) {
  var kind = el.getAttribute("data-mkind");
  var mid = el.getAttribute("data-mid");
  var m = z3tFindMsg(kind, mid);
  if (!m || !currentUser) return;
  var mine = m.sender_id === currentUser.id;
  var name = el.getAttribute("data-mname") || "";
  var canDelete = z3tCanDeleteMsg(kind, m);
  var plain = z3tMsgPlainText(m);
  var when = "";
  try {
    when = new Date(m.created_at).toLocaleString("es", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch (_e) {}
  var bd = document.getElementById("z3tMsgSheetBackdrop");
  if (!bd) {
    bd = document.createElement("div");
    bd.id = "z3tMsgSheetBackdrop";
    bd.className = "z3t-sheet-backdrop";
    document.body.appendChild(bd);
    bd.addEventListener("click", function(e) {
      if (Date.now() - z3tSheetOpenedAt < 400) return;
      if (e.target === bd) z3tCloseSheet();
    });
  }
  var myReaction = (z3tReactCache[z3tReactKey(kind, mid)] || []).filter(function(r) {
    return r.user_id === currentUser.id;
  })[0];
  bd.innerHTML = '<div class="z3t-sheet" role="dialog" aria-label="Opciones del mensaje">' + '<div class="z3t-sheet-grip"></div>' + '<div class="z3t-sheet-reactions">' + Z3T_QUICK_REACTIONS.map(function(em) {
    return '<button type="button" class="z3t-sheet-react' + (myReaction && myReaction.emoji === em ? " mine" : "") + '" data-sheet-react="' + escapeHtml(em) + '">' + em + "</button>";
  }).join("") + '<button type="button" class="z3t-sheet-react more" data-sheet-more aria-label="Más emojis">＋</button>' + "</div>" + '<div class="z3t-sheet-preview"><div class="reply-quote-name">' + escapeHtml(name || "Mensaje") + (when ? ' <span class="z3t-sheet-when">· ' + escapeHtml(when) + "</span>" : "") + '</div><div class="reply-quote-text">' + escapeHtml(z3tMsgSnippet(m)) + "</div></div>" + '<div class="z3t-sheet-actions">' + '<button type="button" class="z3t-sheet-item" data-sheet-act="reply"><span>↩️</span>¿Quieres responder el mensaje?</button>' + (plain ? '<button type="button" class="z3t-sheet-item" data-sheet-act="copy"><span>📋</span>Copiar texto</button>' : "") + (!mine ? '<button type="button" class="z3t-sheet-item danger" data-sheet-act="report"><span>🚩</span>¿Quieres reportar este mensaje?</button>' : "") + (canDelete ? '<button type="button" class="z3t-sheet-item danger" data-sheet-act="delete"><span>🗑️</span>' + (mine ? "¿Quieres borrar tu mensaje?" : "Borrar mensaje") + "</button>" : "") + "</div>" + "</div>";
  bd.onclick = function(e) {
    if (Date.now() - z3tSheetOpenedAt < 400) return;
    var react = e.target.closest("[data-sheet-react]");
    var more = e.target.closest("[data-sheet-more]");
    var act = e.target.closest("[data-sheet-act]");
    if (react) {
      z3tCloseSheet();
      z3tReact(kind, mid, react.getAttribute("data-sheet-react"));
    } else if (more) {
      z3tCloseSheet();
      z3tOpenEmojiPanel({
        mode: "react",
        onPick: function(em) {
          z3tReact(kind, mid, em);
        }
      });
    } else if (act) {
      var a = act.getAttribute("data-sheet-act");
      z3tCloseSheet();
      if (a === "reply") z3tSetReply(kind, m, name);
      else if (a === "copy") {
        if (navigator.clipboard) navigator.clipboard.writeText(plain).then(function() {
          toast("Texto copiado.");
        });
      } else if (a === "report") {
        if (typeof openReportModal === "function") openReportModal("message", mid);
      } else if (a === "delete") {
        if (typeof z3tDeleteChatMessage === "function") z3tDeleteChatMessage(Z3T_CHAT_KINDS[kind].table, mid);
      }
    } else if (e.target === bd) z3tCloseSheet();
  };
  z3tSheetOpenedAt = Date.now();
  bd.classList.add("open");
  try {
    if (navigator.vibrate) navigator.vibrate(12);
  } catch (_e) {}
}

/* ------------------------- Detección de pulsación larga ------------------------- */

(function wireLongPress() {
  var timer = null;
  var startX = 0, startY = 0;
  var firedAt = 0;

  function cancel() {
    if (timer) clearTimeout(timer);
    timer = null;
  }

  function msgFrom(target) {
    var el = target && target.closest ? target.closest(".chat-msg[data-mid]") : null;
    return el || null;
  }

  document.addEventListener("pointerdown", function(e) {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    if (e.target.closest && e.target.closest(".react-pill, .reply-quote, audio, video")) return;
    var el = msgFrom(e.target);
    if (!el) return;
    cancel();
    startX = e.clientX;
    startY = e.clientY;
    timer = setTimeout(function() {
      timer = null;
      firedAt = Date.now();
      z3tOpenMsgSheet(el);
    }, Z3T_LONGPRESS_MS);
  }, true);
  document.addEventListener("pointermove", function(e) {
    if (!timer) return;
    if (Math.abs(e.clientX - startX) > 10 || Math.abs(e.clientY - startY) > 10) cancel();
  }, true);
  ["pointerup", "pointercancel", "scroll"].forEach(function(ev) {
    document.addEventListener(ev, cancel, true);
  });
  /* clic derecho en escritorio */
  document.addEventListener("contextmenu", function(e) {
    var el = msgFrom(e.target);
    if (!el) return;
    e.preventDefault();
    cancel();
    if (Date.now() - firedAt < 800) return;
    firedAt = Date.now();
    z3tOpenMsgSheet(el);
  }, true);
  /* Evita que el soltar el dedo active enlaces/imágenes del mensaje recién presionado */
  document.addEventListener("click", function(e) {
    if (Date.now() - firedAt < 700 && msgFrom(e.target)) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);
})();

/* Clic en una cita -> ir al mensaje original; clic en una reacción -> alternarla */
document.addEventListener("click", function(e) {
  var pill = e.target.closest ? e.target.closest(".react-pill") : null;
  if (pill) {
    e.stopPropagation();
    z3tReact(pill.getAttribute("data-mkind"), pill.getAttribute("data-mid"), pill.getAttribute("data-react-emoji"));
    return;
  }
  var q = e.target.closest ? e.target.closest(".reply-quote[data-reply-id]") : null;
  if (q) {
    var box = q.closest(".community-chat, .conversation-messages, #communityChat, #groupChat");
    var target = box ? box.querySelector('.chat-msg[data-mid="' + q.getAttribute("data-reply-id") + '"]') : null;
    if (target) {
      target.scrollIntoView({
        block: "center",
        behavior: "smooth"
      });
      target.classList.add("flash");
      setTimeout(function() {
        target.classList.remove("flash");
      }, 1400);
    } else if (box) toast("El mensaje original ya no está cargado.");
  }
}, false);

/* Refresco periódico de reacciones mientras hay un chat abierto */
setInterval(function() {
  if (document.hidden || !currentUser) return;
  Object.keys(Z3T_CHAT_KINDS).forEach(function(kind) {
    var box = document.getElementById(Z3T_CHAT_KINDS[kind].box);
    if (box && box.offsetParent !== null) z3tRefreshReactions(kind);
  });
}, 12000);

/* ------------------------- Selector de emojis (estilo WhatsApp) ------------------------- */

var Z3T_EMOJI_CATS = [ {
  id: "recent",
  icon: "🕒",
  name: "Recientes",
  list: []
}, {
  id: "smileys",
  icon: "😀",
  name: "Caras",
  list: "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 🤥 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 ☠️ 💩 🤡 👹 👺 👻 👽 👾 🤖 🫠 🫣 🫢 🥹 🫡".split(" ")
}, {
  id: "people",
  icon: "👍",
  name: "Gestos",
  list: "👍 👎 👊 ✊ 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✌️ 🤞 🤟 🤘 👌 🤏 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤙 💪 🦾 🖕 ✍️ 🤳 💅 👀 👁️ 👅 👄 🧠 🫶 🫂 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 🙋 🙆 🙅 🤷 🤦 💁 🙇".split(" ")
}, {
  id: "hearts",
  icon: "❤️",
  name: "Símbolos",
  list: "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💯 💢 💥 💫 💦 💨 💬 💭 💤 ✨ ⭐ 🌟 ⚡ 🔥 ✅ ❌ ❗ ❓ ‼️ ⚠️ 🚫 ➕ ➖ ➗ ✖️ ♾️ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟤 🔺 🔻 ⬆️ ⬇️ ⬅️ ➡️ 🔄 🔁 🆗 🆒 🆕 🔞".split(" ")
}, {
  id: "animals",
  icon: "🐶",
  name: "Naturaleza",
  list: "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦀 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦛 🐪 🦒 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🕊️ 🐇 🦔 🌵 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🌹 🌺 🌻 🌼 🌸 🌈 ☀️ 🌙 ☁️ 🌧️ ⛈️ ❄️ 🌊".split(" ")
}, {
  id: "food",
  icon: "🍔",
  name: "Comida",
  list: "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🍆 🌽 🌶️ 🥕 🥔 🍞 🥐 🥖 🧀 🥚 🍳 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🌮 🌯 🥙 🍝 🍜 🍲 🍣 🍱 🍤 🍙 🍚 🍦 🍧 🍨 🍩 🍪 🎂 🍰 🧁 🍫 🍬 🍭 🍿 ☕ 🍵 🥤 🍺 🍻 🥂 🍷 🍸 🍹 🧃 🥛".split(" ")
}, {
  id: "activities",
  icon: "⚽",
  name: "Actividades",
  list: "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥊 🥋 ⛳ 🎣 🎿 🛹 🏆 🥇 🥈 🥉 🏅 🎖️ 🎮 🕹️ 🎲 🧩 🎯 🎳 🎰 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎸 🎺 🎻 🎭 🎪 🎉 🎊 🎈 🎁 🎀".split(" ")
}, {
  id: "travel",
  icon: "🚗",
  name: "Viajes",
  list: "🚗 🚕 🚙 🚌 🏎️ 🚓 🚑 🚒 🛻 🚚 🏍️ 🛵 🚲 🛴 ✈️ 🚀 🛸 🚁 ⛵ 🚤 🛳️ ⚓ 🚂 🚇 🏠 🏡 🏢 🏫 🏥 🏦 🏨 🏪 ⛪ 🕌 🗽 🗼 🏰 ⛺ 🌋 🏝️ 🏖️ 🏜️ 🗺️ 🧭 🌍 🌎 🌏".split(" ")
}, {
  id: "objects",
  icon: "💡",
  name: "Objetos",
  list: "⌚ 📱 💻 🖥️ ⌨️ 🖱️ 💾 📷 📸 📹 🎥 📞 ☎️ 📺 📻 🎙️ ⏰ ⌛ 🔋 🔌 💡 🔦 🕯️ 💰 💵 💎 🔧 🔨 ⚙️ 🔑 🔒 🔓 🛡️ ⚔️ 💣 📦 📌 📍 ✂️ 📎 📝 📚 📖 📅 🔍 🔔 🔕 🔗 🧲 🧪 💊 🚪 🛏️ 🧸".split(" ")
} ];

var z3tEmojiState = null; /* { mode, onPick, inputId, tab, cat, shifted } */

function z3tRecentEmojis() {
  try {
    return JSON.parse(localStorage.getItem("z3t_emoji_recent") || "[]").slice(0, 32);
  } catch (_e) {
    return [];
  }
}

function z3tPushRecentEmoji(em) {
  try {
    var list = z3tRecentEmojis().filter(function(x) {
      return x !== em;
    });
    list.unshift(em);
    localStorage.setItem("z3t_emoji_recent", JSON.stringify(list.slice(0, 32)));
  } catch (_e) {}
}

function z3tCloseEmojiPanel() {
  var bd = document.getElementById("z3tEmojiBackdrop");
  var panel = document.getElementById("z3tEmojiPanel");
  if (bd) bd.classList.remove("open");
  if (panel) panel.classList.remove("open");
  if (z3tEmojiState && z3tEmojiState.shifted) {
    z3tEmojiState.shifted.style.marginBottom = z3tEmojiState.shiftedPrev || "";
  }
  document.body.classList.remove("emoji-panel-open");
  z3tEmojiState = null;
}

function z3tEmojiInsert(em) {
  var st = z3tEmojiState;
  if (!st) return;
  z3tPushRecentEmoji(em);
  if (st.mode === "react") {
    var cb = st.onPick;
    z3tCloseEmojiPanel();
    if (cb) cb(em);
    return;
  }
  var input = document.getElementById(st.inputId);
  if (!input) return;
  var s = typeof input.selectionStart === "number" ? input.selectionStart : input.value.length;
  var e = typeof input.selectionEnd === "number" ? input.selectionEnd : s;
  input.value = input.value.slice(0, s) + em + input.value.slice(e);
  var pos = s + em.length;
  try {
    input.setSelectionRange(pos, pos);
  } catch (_e) {}
  input.dispatchEvent(new Event("input", {
    bubbles: true
  }));
}

function z3tRenderEmojiPanel() {
  var st = z3tEmojiState;
  var panel = document.getElementById("z3tEmojiPanel");
  if (!st || !panel) return;
  var body;
  if (st.tab === "stickers") {
    body = '<div class="z3t-stickers-empty"><div class="z3t-stickers-emoji">🪄</div><div class="z3t-stickers-title">Stickers</div><div class="z3t-stickers-sub">Muy pronto podrás enviar stickers aquí.</div></div>';
  } else {
    var cat = Z3T_EMOJI_CATS.filter(function(c) {
      return c.id === st.cat;
    })[0] || Z3T_EMOJI_CATS[1];
    var list = cat.id === "recent" ? z3tRecentEmojis() : cat.list;
    body = list.length ? '<div class="z3t-emoji-title">' + escapeHtml(cat.name) + "</div>" + '<div class="z3t-emoji-grid">' + list.map(function(em) {
      return '<button type="button" data-z3t-emoji="' + escapeHtml(em) + '">' + em + "</button>";
    }).join("") + "</div>" : '<div class="z3t-emoji-title">' + escapeHtml(cat.name) + '</div><div class="z3t-emoji-empty">Aún no has usado emojis.</div>';
  }
  panel.innerHTML = '<div class="z3t-emoji-top">' + '<button type="button" class="z3t-emoji-tab' + (st.tab === "emojis" ? " active" : "") + '" data-z3t-tab="emojis">😀 Emojis</button>' + '<button type="button" class="z3t-emoji-tab' + (st.tab === "stickers" ? " active" : "") + '" data-z3t-tab="stickers">✨ Stickers</button>' + '<button type="button" class="z3t-emoji-close" data-z3t-close aria-label="Cerrar">✕</button>' + "</div>" + (st.tab === "emojis" ? '<div class="z3t-emoji-cats">' + Z3T_EMOJI_CATS.map(function(c) {
    return '<button type="button" class="z3t-emoji-cat' + (c.id === st.cat ? " active" : "") + '" data-z3t-cat="' + c.id + '" aria-label="' + escapeHtml(c.name) + '">' + c.icon + "</button>";
  }).join("") + "</div>" : "") + '<div class="z3t-emoji-body">' + body + "</div>";
}

function z3tOpenEmojiPanel(opts) {
  z3tCloseEmojiPanel();
  var bd = document.getElementById("z3tEmojiBackdrop");
  var panel = document.getElementById("z3tEmojiPanel");
  if (!bd) {
    bd = document.createElement("div");
    bd.id = "z3tEmojiBackdrop";
    bd.className = "z3t-emoji-backdrop";
    document.body.appendChild(bd);
    bd.addEventListener("click", z3tCloseEmojiPanel);
  }
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "z3tEmojiPanel";
    panel.className = "z3t-emoji-panel";
    document.body.appendChild(panel);
    panel.addEventListener("click", function(e) {
      e.stopPropagation();
      var em = e.target.closest("[data-z3t-emoji]");
      var tab = e.target.closest("[data-z3t-tab]");
      var cat = e.target.closest("[data-z3t-cat]");
      if (em) z3tEmojiInsert(em.getAttribute("data-z3t-emoji"));
      else if (tab && z3tEmojiState) {
        z3tEmojiState.tab = tab.getAttribute("data-z3t-tab");
        z3tRenderEmojiPanel();
      } else if (cat && z3tEmojiState) {
        z3tEmojiState.cat = cat.getAttribute("data-z3t-cat");
        z3tRenderEmojiPanel();
      } else if (e.target.closest("[data-z3t-close]")) z3tCloseEmojiPanel();
    });
  }
  z3tEmojiState = {
    mode: opts.mode || "compose",
    onPick: opts.onPick || null,
    inputId: opts.inputId || null,
    tab: "emojis",
    cat: z3tRecentEmojis().length ? "recent" : "smileys",
    shifted: null,
    shiftedPrev: ""
  };
  z3tRenderEmojiPanel();
  bd.classList.toggle("dim", z3tEmojiState.mode === "react");
  bd.classList.add("open");
  panel.classList.add("open");
  document.body.classList.add("emoji-panel-open");
  /* En el compositor: sube la barra de escribir por encima del panel (como WhatsApp) */
  if (z3tEmojiState.mode === "compose") {
    var input = document.getElementById(z3tEmojiState.inputId);
    var shell = input ? input.closest(".conversation-shell, .community-shell") : null;
    var child = input;
    while (child && child.parentElement && child.parentElement !== shell) child = child.parentElement;
    if (shell && child && child.parentElement === shell) {
      z3tEmojiState.shifted = child;
      z3tEmojiState.shiftedPrev = child.style.marginBottom;
      child.style.marginBottom = panel.offsetHeight + "px";
      bd.classList.add("compose");
      var chat = shell.querySelector(".community-chat, .conversation-messages");
      if (chat) chat.scrollTop = chat.scrollHeight;
    }
  }
}

/* Al tocar la barra de escribir, el panel de emojis cede paso al teclado */
document.addEventListener("focusin", function(e) {
  if (z3tEmojiState && z3tEmojiState.mode === "compose" && e.target && e.target.id === z3tEmojiState.inputId) z3tCloseEmojiPanel();
});

/* Los botones de emoji de los compositores abren el nuevo selector (se captura antes que el popup viejo) */
document.addEventListener("click", function(e) {
  var btn = e.target.closest ? e.target.closest("#btnDmEmoji, #btnGroupEmoji, #communityChatActionsBtn") : null;
  if (!btn) return;
  e.preventDefault();
  e.stopImmediatePropagation();
  var inputId = btn.id === "btnDmEmoji" ? "dmInput" : btn.id === "btnGroupEmoji" ? "groupChatInput" : "communityChatInput";
  if (z3tEmojiState && z3tEmojiState.inputId === inputId) {
    z3tCloseEmojiPanel();
    return;
  }
  [ "chatActionsPopup", "dmEmojiPopup", "groupEmojiPopup" ].forEach(function(id) {
    var p = document.getElementById(id);
    if (p) p.classList.remove("open");
  });
  z3tOpenEmojiPanel({
    mode: "compose",
    inputId: inputId
  });
}, true);
