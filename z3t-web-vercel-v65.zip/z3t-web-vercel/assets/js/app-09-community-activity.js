"use strict";

var ytPlayer = null;

var ytApiPromise = null;

var communityCinemaPollTimer = null;

var CINEMA_LIBRARY = [];

function loadYouTubeApi() {
  if (window.YT && window.YT.Player) return Promise.resolve(window.YT);
  if (ytApiPromise) return ytApiPromise;
  ytApiPromise = new Promise(function(resolve, reject) {
    var prevReady = window.onYouTubeIframeAPIReady;
    var timer = setTimeout(function() {
      ytApiPromise = null;
      reject(new Error("timeout"));
    }, 12e3);
    window.onYouTubeIframeAPIReady = function() {
      clearTimeout(timer);
      if (prevReady) try {
        prevReady();
      } catch (_e) {}
      resolve(window.YT);
    };
    var tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    tag.onerror = function() {
      clearTimeout(timer);
      ytApiPromise = null;
      reject(new Error("blocked"));
    };
    document.head.appendChild(tag);
  });
  return ytApiPromise;
}

function parseVideoUrl(url) {
  var yt = url.match(/(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([a-zA-Z0-9_-]{6,})/);
  if (yt) return {
    type: "youtube",
    id: yt[1]
  };
  return {
    type: "direct",
    id: null
  };
}

function playSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>';
}

function pauseSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="6" y1="4" x2="6" y2="20"/><line x1="18" y1="4" x2="18" y2="20"/></svg>';
}

function setCommunityActivity(mode) {
  if (!currentUser || !currentCommunity) return;
  var role = myCommunityRole();
  if (role !== "admin" && role !== "co_admin") {
    toast("Solo un admin o co-admin puede cambiar la actividad.");
    return;
  }
  var prevMode = currentCommunity.active_activity;
  var newMode = mode === null ? null : prevMode === mode ? null : mode;
  var closedMode = newMode ? null : mode || prevMode;
  var patch = {
    active_activity: newMode
  };
  patch.voice_active = newMode === "voice";
  if (newMode === "cinema" && prevMode !== "cinema") {
    patch.cinema_video_url = null;
    patch.cinema_is_playing = false;
    patch.cinema_position_seconds = 0;
  }
  supabase.from("communities").update(patch).eq("id", currentCommunity.id).select().single().then(function(res) {
    if (res.error) {
      toast("No se pudo cambiar la actividad: " + res.error.message);
      return;
    }
    currentCommunity = res.data;
    if ((prevMode === "roleplay" || prevMode === "cinema") && prevMode !== newMode && voiceRoom) {
      try {
        voiceRoom.disconnect();
      } catch (_e) {}
      voiceRoom = null;
      voiceRoomCommunityId = null;
      voiceJoined = false;
      voiceMuted = false;
      voiceChatActive = false;
      voiceSpeakingIdentities = {};
      qsa("[data-livekit-audio]", document.body).forEach(function(mediaEl) {
        mediaEl.remove();
      });
    }
    var involvesVoice = newMode === "voice" || closedMode === "voice";
    if (!involvesVoice) {
      postVoiceSystemMessage(currentUser.username + " (" + roleLabel(role) + ") " + (newMode ? "activó " + activityLabelFor(newMode) : "cerró " + activityLabelFor(closedMode)) + ".");
      renderCommunityDetail();
      return;
    }
    var proceed = Promise.resolve();
    proceed.then(function() {
      if (newMode === "voice") {
        voiceChatActive = true;
        voiceChatStartedBy = currentUser.username;
        broadcastVoiceEvent({
          type: "voice_on",
          by: currentUser.username,
          role: role
        });
        postVoiceSystemMessage(currentUser.username + " (" + roleLabel(role) + ") activó " + activityLabelFor(newMode) + ".");
      } else {
        voiceChatActive = false;
        broadcastVoiceEvent({
          type: "voice_off",
          by: currentUser.username
        });
        postVoiceSystemMessage(currentUser.username + " (" + roleLabel(role) + ") cerró " + activityLabelFor(closedMode) + ".");
        if (voiceRoom) {
          try {
            voiceRoom.disconnect();
          } catch (_e) {}
        }
        voiceRoom = null;
        voiceRoomCommunityId = null;
        voiceJoined = false;
        voiceMuted = false;
        voiceSpeakingIdentities = {};
        qsa("[data-livekit-audio]", document.body).forEach(function(mediaEl) {
          mediaEl.remove();
        });
      }
      renderCommunityDetail();
    }).catch(function(err) {
      console.error("Fallo al conectar la sala de voz:", err);
      renderCommunityDetail();
    });
  }).catch(function(err) {
    console.error("Fallo al cambiar la actividad de la comunidad:", err);
    toast("No se pudo cambiar la actividad. Revisa tu conexión e intenta de nuevo.");
  });
}

function communityCinemaPosition(c) {
  var base = Number(c.cinema_position_seconds) || 0;
  if (c.cinema_is_playing && c.cinema_updated_at) {
    base += (Date.now() - new Date(c.cinema_updated_at).getTime()) / 1e3;
  }
  return Math.max(0, base);
}

function mountCommunityCinemaPlayer() {
  var wrap = $("communityCinemaPlayer");
  if (!wrap) return;
  var c = currentCommunity;
  if (!c.cinema_video_url) {
    wrap.innerHTML = '<div class="cinema-player-empty">Todavía no hay ningún video puesto. Pega una URL abajo.</div>';
    return;
  }
  var startPos = communityCinemaPosition(c);
  if (c.cinema_video_type === "youtube") {
    var parsed = parseVideoUrl(c.cinema_video_url);
    wrap.innerHTML = '<div id="ytPlayerMount"></div>';
    var ytOpenUrl = escapeHtml(c.cinema_video_url);
    var ytFail = function(msg) {
      var w = $("communityCinemaPlayer");
      if (w) w.innerHTML = '<div class="cinema-player-empty">' + msg + ' <a href="' + ytOpenUrl + '" target="_blank" rel="noopener noreferrer">Abrir en YouTube ↗</a></div>';
    };
    loadYouTubeApi().then(function(YT) {
      if (!$("ytPlayerMount")) return;
      ytPlayer = new YT.Player("ytPlayerMount", {
        videoId: parsed.id,
        host: "https://www.youtube.com",
        playerVars: {
          autoplay: c.cinema_is_playing ? 1 : 0,
          start: Math.floor(startPos),
          playsinline: 1,
          rel: 0,
          origin: location.origin
        },
        events: {
          onReady: function(ev) {
            if (c.cinema_is_playing) ev.target.playVideo(); else ev.target.pauseVideo();
          },
          onError: function(ev) {
            var code = ev && ev.data;
            ytFail(code === 101 || code === 150 ? "El dueño de este video no permite reproducirlo fuera de YouTube." : code === 100 ? "Este video no existe o es privado." : "No se pudo reproducir este video.");
          }
        }
      });
    }).catch(function() {
      ytFail("No se pudo cargar el reproductor de YouTube.");
    });
  } else if (c.cinema_video_type === "audio") {
    wrap.innerHTML = cinemaAudioCoverHtml() + '<audio id="cinemaAudioEl" src="' + escapeHtml(c.cinema_video_url) + '" ' + (c.cinema_is_playing ? "autoplay" : "") + "></audio>";
    var a = $("cinemaAudioEl");
    if (a) {
      a.currentTime = startPos;
      if (!c.cinema_is_playing) a.pause();
    }
  } else {
    wrap.innerHTML = '<video id="directVideoEl" src="' + safeUrlAttr(c.cinema_video_url) + '" ' + (c.cinema_is_playing ? "autoplay" : "") + ' playsinline preload="metadata" controls></video>';
    var v = $("directVideoEl");
    if (v) {
      v.addEventListener("error", function() {
        var w = $("communityCinemaPlayer");
        if (w) w.innerHTML = '<div class="cinema-player-empty">Este navegador no puede reproducir ese archivo (formato no compatible, por ejemplo .mov). Sube el video en MP4 o WebM. <a href="' + safeUrlAttr(c.cinema_video_url) + '" target="_blank" rel="noopener noreferrer">Abrir archivo ↗</a></div>';
      });
      v.currentTime = startPos;
      if (!c.cinema_is_playing) v.pause();
    }
  }
}

function cinemaAudioCoverHtml() {
  return '<div class="cinema-audio-cover">' + '<div class="cinema-audio-cover-art"></div>' + '<span class="cinema-audio-note n1">♪</span>' + '<span class="cinema-audio-note n2">♫</span>' + '<span class="cinema-audio-note n3">♪</span>' + "</div>";
}

function loadCinemaLibrary() {
  if (!currentCommunity) return;
  supabase.from("cinema_items").select("*").eq("community_id", currentCommunity.id).order("created_at", {
    ascending: false
  }).then(function(res) {
    CINEMA_LIBRARY = res.error ? [] : res.data || [];
    renderCinemaLibraryList();
  });
}

function renderCinemaLibraryList() {
  var el = $("cinemaLibraryList");
  if (!el) return;
  if (!CINEMA_LIBRARY.length) {
    el.innerHTML = '<p class="profile-empty-hint">Todavía no hay nada agregado.</p>';
    return;
  }
  var role = myCommunityRole();
  var isStaff = role === "admin" || role === "co_admin";
  el.innerHTML = CINEMA_LIBRARY.map(function(item) {
    return cinemaLibraryItemHtml(item, isStaff);
  }).join("");
}

function cinemaLibraryItemHtml(item, isStaff) {
  var icon = item.type === "audio" ? "🎵" : item.type === "youtube" ? "▶️" : "🎬";
  var label = item.title || item.url;
  return '<div class="cinema-library-item">' + '<button type="button" class="cinema-library-play" data-id="' + escapeHtml(item.id) + '">' + icon + " <span>" + escapeHtml(label) + "</span></button>" + (isStaff ? '<button type="button" class="icon-btn cinema-library-delete" data-id="' + escapeHtml(item.id) + '" aria-label="Borrar de la lista">✕</button>' : "") + "</div>";
}

function addCinemaLibraryItem(type, url, title) {
  if (!currentUser || !currentCommunity) return;
  supabase.from("cinema_items").insert({
    community_id: currentCommunity.id,
    type: type,
    url: url,
    title: title || null,
    added_by: currentUser.id
  }).then(function(res) {
    if (res.error) {
      console.error("[addCinemaLibraryItem]", res.error);
      return;
    }
    loadCinemaLibrary();
  });
}

function playCinemaLibraryItemById(id) {
  var item = CINEMA_LIBRARY.filter(function(i) {
    return String(i.id) === String(id);
  })[0];
  if (!item) return;
  setCommunityCinemaVideo(item.url, {
    type: item.type,
    skipLibraryInsert: true,
    title: item.title
  });
}

function deleteCinemaLibraryItem(id) {
  if (!currentUser || !currentCommunity) return;
  var item = CINEMA_LIBRARY.filter(function(i) {
    return String(i.id) === String(id);
  })[0];
  var wasActive = item && currentCommunity.cinema_video_url === item.url;
  supabase.from("cinema_items").delete().eq("id", id).then(function(res) {
    if (res.error) {
      toast("No se pudo borrar: " + res.error.message);
      return;
    }
    if (wasActive) {
      supabase.from("communities").update({
        cinema_video_url: null,
        cinema_video_type: null,
        cinema_is_playing: false,
        cinema_position_seconds: 0,
        cinema_updated_at: (new Date).toISOString()
      }).eq("id", currentCommunity.id).select().single().then(function(res2) {
        if (!res2.error) currentCommunity = res2.data;
        renderCommunityDetail();
      });
    } else {
      loadCinemaLibrary();
    }
  });
}

function setCommunityCinemaVideo(url, opts) {
  if (!currentUser || !currentCommunity) return;
  opts = opts || {};
  var type = opts.type || parseVideoUrl(url).type;
  supabase.from("communities").update({
    cinema_video_url: url,
    cinema_video_type: type,
    cinema_is_playing: true,
    cinema_position_seconds: 0,
    cinema_updated_at: (new Date).toISOString()
  }).eq("id", currentCommunity.id).select().single().then(function(res) {
    if (res.error) {
      toast("No se pudo poner el video: " + res.error.message);
      return;
    }
    currentCommunity = res.data;
    renderCommunityDetail();
    if (!opts.skipLibraryInsert) addCinemaLibraryItem(type, url, opts.title || null);
  });
}

function toggleCommunityCinemaPlayPause() {
  if (!currentUser || !currentCommunity) return;
  var c = currentCommunity;
  var newPlaying = !c.cinema_is_playing;
  var pos = communityCinemaPosition(c);
  supabase.from("communities").update({
    cinema_is_playing: newPlaying,
    cinema_position_seconds: pos,
    cinema_updated_at: (new Date).toISOString()
  }).eq("id", c.id).select().single().then(function(res) {
    if (res.error) return;
    currentCommunity = res.data;
    applySyncedCommunityCinemaState(res.data);
    var btn = $("btnCommunityCinemaPlayPause");
    if (btn) btn.innerHTML = res.data.cinema_is_playing ? pauseSvg() : playSvg();
  });
}

function applySyncedCommunityCinemaState(c) {
  var pos = communityCinemaPosition(c);
  if (c.cinema_video_type === "youtube" && ytPlayer && ytPlayer.seekTo) {
    ytPlayer.seekTo(pos, true);
    if (c.cinema_is_playing) ytPlayer.playVideo(); else ytPlayer.pauseVideo();
  } else {
    var v = $(c.cinema_video_type === "audio" ? "cinemaAudioEl" : "directVideoEl");
    if (v) {
      v.currentTime = pos;
      if (c.cinema_is_playing) v.play().catch(function() {}); else v.pause();
    }
  }
}

function pollCommunityCinemaState() {
  if (!currentCommunity || currentCommunity.active_activity !== "cinema") return;
  supabase.from("communities").select("*").eq("id", currentCommunity.id).single().then(function(res) {
    if (res.error || !res.data) return;
    var c = res.data;
    var changed = c.cinema_updated_at !== currentCommunity.cinema_updated_at || c.active_activity !== currentCommunity.active_activity;
    var videoChanged = c.cinema_video_url !== currentCommunity.cinema_video_url;
    currentCommunity = c;
    if (!changed) return;
    if (videoChanged || c.active_activity !== "cinema") {
      renderCommunityDetail();
    } else {
      applySyncedCommunityCinemaState(c);
      var btn = $("btnCommunityCinemaPlayPause");
      if (btn) btn.innerHTML = c.cinema_is_playing ? pauseSvg() : playSvg();
    }
  });
}

var COMMON_EMOJIS = [ "😀", "😂", "😅", "😍", "😎", "🤔", "😢", "😡", "👍", "👎", "🙏", "🔥", "💀", "👻", "🎉", "❤️", "💯", "🤝", "🫡", "😴", "😱", "🥳", "😏", "👀" ];

function renderChatActionsPopup() {
  var popup = $("chatActionsPopup");
  if (!popup) return;
  $("chatEmojiPanel").innerHTML = '<div class="emoji-grid">' + COMMON_EMOJIS.map(function(em) {
    return '<button type="button" data-emoji="' + em + '">' + em + "</button>";
  }).join("") + "</div>";
  qsa("[data-emoji]", $("chatEmojiPanel")).forEach(function(btn) {
    btn.addEventListener("click", function() {
      var input = $("communityChatInput");
      if (input) {
        input.value += btn.getAttribute("data-emoji");
        input.focus();
      }
    });
  });
  var actionsBtn = $("communityChatActionsBtn");
  if (actionsBtn) actionsBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    $("activitiesPopup").classList.remove("open");
    popup.classList.toggle("open");
  });
  popup.addEventListener("click", function(e) {
    e.stopPropagation();
  });
  var activitiesPopup = $("activitiesPopup");
  var activitiesBtn = $("btnCommunityActivities");
  if (activitiesBtn) activitiesBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    popup.classList.remove("open");
    activitiesPopup.classList.toggle("open");
  });
  activitiesPopup.addEventListener("click", function(e) {
    e.stopPropagation();
  });
  $("btnActivityPickVoice").addEventListener("click", function() {
    activitiesPopup.classList.remove("open");
    setCommunityActivity("voice");
  });
  $("btnActivityPickCinema").addEventListener("click", function() {
    activitiesPopup.classList.remove("open");
    setCommunityActivity("cinema");
  });
  var roleplayPickBtn = $("btnActivityPickRoleplay");
  if (roleplayPickBtn) roleplayPickBtn.addEventListener("click", function() {
    activitiesPopup.classList.remove("open");
    setCommunityActivity("roleplay");
  });
  var morePopup = $("morePopup");
  var moreBtn = $("btnCommunityMore");
  if (moreBtn) moreBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    activitiesPopup.classList.remove("open");
    if (morePopup) morePopup.classList.toggle("open");
  });
  if (morePopup) morePopup.addEventListener("click", function(e) {
    e.stopPropagation();
  });
  var pollBtn = $("btnActivityPickPoll");
  if (pollBtn) pollBtn.addEventListener("click", function() {
    if (morePopup) morePopup.classList.remove("open");
    openCommunityPollModal();
  });
  var giftBtn = morePopup ? morePopup.querySelector('[data-act="open-gift-send"]') : null;
  if (giftBtn) giftBtn.addEventListener("click", function() {
    if (morePopup) morePopup.classList.remove("open");
    openGiftSend("community", currentCommunity.id, null, null);
  });
  var imageBtn = $("btnCommunityImage");
  var imageInput = $("communityImageInput");
  if (imageBtn) imageBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    imageInput.click();
  });
  if (imageInput) imageInput.addEventListener("change", function() {
    var file = imageInput.files[0];
    if (file) sendCommunityImage(file);
    imageInput.value = "";
  });
  var audioBtn = $("btnCommunityAudio");
  if (audioBtn) audioBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    toggleCommunityAudioRecording();
  });
}

document.addEventListener("click", function() {
  var popup = $("chatActionsPopup");
  if (popup) popup.classList.remove("open");
  var activitiesPopup = $("activitiesPopup");
  if (activitiesPopup) activitiesPopup.classList.remove("open");
  var morePopupEl = $("morePopup");
  if (morePopupEl) morePopupEl.classList.remove("open");
  var cinemaPopup = $("cinemaOptionsPopup");
  if (cinemaPopup) cinemaPopup.classList.remove("open");
});