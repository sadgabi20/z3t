"use strict";

var activityVoiceRoom = null;

var activityVoiceMuted = false;

var activityVoiceJoined = false;

var activityVoiceSpeaking = {};

var activityVoiceActive = false;

var activityVoiceKind = null;

var activityVoiceRoomId = null;

var activityVoiceMountId = null;

var activityRoleFn = null;

var activityVoiceGraceTimer = null;

function ensureActivityVoiceConnected(kind, roomId, roleFn) {
  activityVoiceKind = kind;
  activityVoiceRoomId = roomId;
  activityVoiceMountId = kind === "group" ? "groupVoiceBar" : kind === "meet" ? "meetVoiceBar" : kind === "dm" ? "dmVoiceBar" : "cinemaVoiceBar";
  activityRoleFn = roleFn || function() {
    return null;
  };
  if (!currentUser) return Promise.resolve();
  if (typeof LivekitClient === "undefined") {
    toast("No cargó el motor de voz. Recarga la página e inténtalo de nuevo.");
    return Promise.resolve();
  }
  if (activityVoiceRoom && (activityVoiceRoom.state === "connected" || activityVoiceRoom.state === "connecting")) {
    if (activityVoiceMinimized) {
      activityVoiceMinimized = false;
      activityVoiceReopenFn = null;
      renderActivityVoiceFloat();
    }
    renderActivityVoiceBar();
    return Promise.resolve();
  }
  return supabase.rpc("create_activity_livekit_token", {
    p_room_kind: kind,
    p_room_id: roomId
  }).then(function(res) {
    if (res.error || !res.data) {
      toast("No se pudo iniciar la llamada" + (res.error && res.error.message ? ": " + res.error.message : "."));
      renderActivityVoiceBar();
      return;
    }
    var token = res.data.token || res.data;
    activityVoiceRoom = new LivekitClient.Room({
      adaptiveStream: true,
      dynacast: true
    });
    wireActivityVoiceEvents(activityVoiceRoom);
    return activityVoiceRoom.connect(LIVEKIT_WS_URL, token);
  }).then(function() {
    var persisted = kind === "group" && typeof currentGroup !== "undefined" && currentGroup ? !!currentGroup.voice_active : false;
    activityVoiceActive = persisted || getActivityVoiceSpeakers().length > 0;
    renderActivityVoiceBar();
  }).catch(function() {
    renderActivityVoiceBar();
  });
}

function wireActivityVoiceEvents(room) {
  room.on(LivekitClient.RoomEvent.TrackSubscribed, function(track, _pub, participant) {
    if (track.kind === "audio") {
      var mediaEl = track.attach();
      mediaEl.setAttribute("data-activity-livekit-audio", participant.identity);
      mediaEl.style.display = "none";
      document.body.appendChild(mediaEl);
    }
    renderActivityVoiceBar();
  });
  room.on(LivekitClient.RoomEvent.TrackUnsubscribed, function(track) {
    track.detach().forEach(function(mediaEl) {
      mediaEl.remove();
    });
    renderActivityVoiceBar();
  });
  room.on(LivekitClient.RoomEvent.ParticipantConnected, renderActivityVoiceBar);
  room.on(LivekitClient.RoomEvent.ParticipantDisconnected, renderActivityVoiceBar);
  room.on(LivekitClient.RoomEvent.LocalTrackPublished, renderActivityVoiceBar);
  room.on(LivekitClient.RoomEvent.LocalTrackUnpublished, renderActivityVoiceBar);
  room.on(LivekitClient.RoomEvent.ActiveSpeakersChanged, function(speakers) {
    activityVoiceSpeaking = {};
    speakers.forEach(function(p) {
      activityVoiceSpeaking[p.identity] = true;
    });
    qsa(".voice-participant", document).forEach(function(el) {
      el.classList.toggle("speaking", !!activityVoiceSpeaking[el.getAttribute("data-identity")]);
    });
    if (activityVoiceMinimized) renderActivityVoiceFloat();
  });
  room.on(LivekitClient.RoomEvent.Reconnecting, function() {
    toast(t("activity.toast_reconnecting"));
  });
  room.on(LivekitClient.RoomEvent.Reconnected, renderActivityVoiceBar);
  room.on(LivekitClient.RoomEvent.Disconnected, function() {
    activityVoiceRoom = null;
    activityVoiceMuted = false;
    activityVoiceActive = false;
    qsa("[data-activity-livekit-audio]", document.body).forEach(function(mediaEl) {
      mediaEl.remove();
    });
    renderActivityVoiceBar();
  });
  room.on(LivekitClient.RoomEvent.DataReceived, function(payload) {
    var msg = null;
    try {
      msg = JSON.parse((new TextDecoder).decode(payload));
    } catch (_e) {
      return;
    }
    if (!msg || !msg.type) return;
    if (msg.type === "voice_on") {
      activityVoiceActive = true;
      renderActivityVoiceBar();
    } else if (msg.type === "voice_off") {
      activityVoiceActive = false;
      if (activityVoiceRoom && activityVoiceRoom.localParticipant && activityVoiceRoom.localParticipant.isMicrophoneEnabled) {
        activityVoiceRoom.localParticipant.setMicrophoneEnabled(false).then(renderActivityVoiceBar);
      } else {
        renderActivityVoiceBar();
      }
      toast(t("activity.toast_voice_off"));
    }
  });
}

function broadcastActivityVoiceEvent(obj) {
  if (!activityVoiceRoom || !activityVoiceRoom.localParticipant) return;
  try {
    var payload = (new TextEncoder).encode(JSON.stringify(obj));
    activityVoiceRoom.localParticipant.publishData(payload, {
      reliable: true
    });
  } catch (_e) {}
}

function remoteMicMuted(p) {
  if (!p.isMicrophoneEnabled) return true;
  var pub = p.getTrackPublication ? p.getTrackPublication(LivekitClient.Track.Source.Microphone) : null;
  return !!(pub && pub.isMuted);
}

function getActivityVoiceSpeakers() {
  if (!activityVoiceRoom) return [];
  var list = [];
  if (activityVoiceRoom.localParticipant) {
    list.push({
      identity: activityVoiceRoom.localParticipant.identity,
      name: currentUser && currentUser.username || "tú",
      isLocal: true,
      muted: !!activityVoiceMuted
    });
  }
  if (activityVoiceRoom.remoteParticipants) {
    activityVoiceRoom.remoteParticipants.forEach(function(p) {
      list.push({
        identity: p.identity,
        name: p.name || "usuario",
        isLocal: false,
        muted: remoteMicMuted(p)
      });
    });
  }
  return list;
}

function activityMemberRoleFor(identity) {
  if (activityVoiceKind === "group") {
    var m = groupMembers.filter(function(x) {
      return x.user_id === identity;
    })[0];
    return m ? m.role : null;
  }
  return null;
}

function activityVoiceParticipantProfile(p) {
  if (p.isLocal) {
    return currentUser ? {
      avatarUrl: currentUser.avatarUrl,
      nameColor: currentUser.nameColor,
      role: currentUser.role,
      verified: currentUser.verified
    } : null;
  }
  if (activityVoiceKind === "group") {
    var m = groupMembers.filter(function(x) {
      return x.user_id === p.identity;
    })[0];
    if (!m || !m.profiles) return null;
    return {
      avatarUrl: m.profiles.avatar_url,
      nameColor: m.profiles.name_color,
      role: m.profiles.role,
      verified: m.profiles.verified
    };
  }
  if (activityVoiceKind === "dm" && currentConversation && currentConversation.otherId === p.identity) {
    return {
      avatarUrl: currentConversation.otherAvatar,
      nameColor: currentConversation.otherNameColor,
      role: currentConversation.otherRole,
      verified: currentConversation.otherVerified
    };
  }
  return null;
}

function renderActivityVoiceBar() {
  renderActivityVoiceFloat();
  var el = $(activityVoiceMountId);
  if (!el) return;
  if (!activityVoiceRoom) {
    el.hidden = true;
    el.innerHTML = "";
    return;
  }
  var myRole = activityRoleFn ? activityRoleFn() : null;
  var isStaff = myRole === "admin" || myRole === "co_admin";
  var speakers = getActivityVoiceSpeakers();
  var amSpeaking = activityVoiceJoined && !!activityVoiceRoom.localParticipant;
  el.hidden = false;
  var isCinemaBar = activityVoiceMountId === "cinemaVoiceBar" || !!activityVoiceFloatCinemaPlayerId();
  var participantsHtml = speakers.length ? voicePagerHtml("activity-" + activityVoiceMountId, speakers.map(function(p) {
    var pRole = p.isLocal ? myRole : activityMemberRoleFor(p.identity);
    var roleTagHtml = pRole ? '<span class="role-tag ' + pRole + '">' + (pRole === "admin" ? "Admin" : pRole === "co_admin" ? "Co-Admin" : "Miembro") + "</span>" : "";
    var profile = activityVoiceParticipantProfile(p);
    var avatarUrl = profile ? profile.avatarUrl : null;
    var nameColor = profile ? profile.nameColor : null;
    var acctRole = profile ? profile.role : null;
    var acctVerified = profile ? profile.verified : null;
    var displayName = p.isLocal ? "Tú" : p.name;
    var rpIdentity = activityVoiceKind === "group" && typeof roleplayVoiceIdentityFor === "function" ? roleplayVoiceIdentityFor(p.identity, "group") : null;
    var rpBadgeHtml = "";
    if (rpIdentity) {
      displayName = rpIdentity.name;
      if (rpIdentity.avatarUrl) avatarUrl = rpIdentity.avatarUrl;
      nameColor = null;
      rpBadgeHtml = '<span class="rp-char-badge">' + activityIconHtml("roleplay") + "</span>";
    }
    return '<div class="voice-participant' + (p.muted ? " is-muted" : "") + '" data-identity="' + escapeHtml(p.identity) + '" data-role="' + (pRole || "") + '" data-uid="' + escapeHtml(p.identity) + '">' + avatarSpanHtml(displayName, avatarUrl, "voice-participant-avatar", rpIdentity ? null : p.identity) + '<span class="voice-participant-name"' + (nameColor ? ' style="color:' + escapeHtml(nameColor) + '"' : "") + ">" + escapeHtml(displayName) + "</span>" + (p.muted ? '<span class="voice-participant-muted-icon" title="Muteado">' + micOffSvg() + "</span>" : "") + (rpIdentity ? rpBadgeHtml : roleBadgeHtml(acctRole, acctVerified)) + roleTagHtml + "</div>";
  }), isCinemaBar ? CINEMA_PAGE_SIZE : VOICE_PAGE_SIZE) : activityVoiceActive ? '<div class="voice-bar-empty">' + voiceIconSvg() + " Chat de voz activo — nadie está hablando ahora</div>" : '<div class="voice-bar-empty">' + voiceIconSvg() + " Chat de voz apagado" + (isStaff ? " — enciéndelo" : "") + "</div>";
  var controlsHtml = "";
  if (amSpeaking) {
    controlsHtml = '<button class="voice-control-btn mic" id="btnActivityVoiceMuteToggle" aria-label="Silenciar">' + (activityVoiceMuted ? micOffSvg() : micOnSvg()) + "</button>" + '<button class="voice-control-btn down" id="btnActivityVoiceStepDown" type="button" aria-label="Bajar">' + downArrowSvg() + "</button>";
  } else if (myRole && activityVoiceActive) {
    controlsHtml = '<button class="voice-control-btn up pill" id="btnActivityVoiceJoin" type="button" aria-label="Unirme"><span>👋</span> Unirme</button>';
  } else if (myRole && !isStaff) {
    controlsHtml = '<span class="voice-bar-hint">Un admin debe encender el chat de voz</span>';
  }
  if (isStaff) {
    controlsHtml += activityVoiceActive ? '<button class="voice-control-btn down" id="btnActivityVoiceDeactivate" type="button" aria-label="Apagar chat de voz" title="Apagar chat de voz">' + downArrowSvg() + "</button>" : '<button class="voice-control-btn up" id="btnActivityVoiceActivate" type="button" aria-label="Encender chat de voz" title="Encender chat de voz">' + voiceIconSvg() + "</button>";
  }
  el.innerHTML = '<div class="voice-bar-title">' + voiceIconSvg() + " Chat de voz</div>" + '<div class="voice-bar-row"><div class="voice-participants-row">' + participantsHtml + "</div></div>" + (controlsHtml ? '<div class="voice-call-controls">' + controlsHtml + "</div>" : "");
  voicePagerWire(el, "activity-" + activityVoiceMountId);
  qsa(".voice-participant", el).forEach(function(pEl) {
    pEl.classList.toggle("speaking", !!activityVoiceSpeaking[pEl.getAttribute("data-identity")]);
  });
  var joinBtn = $("btnActivityVoiceJoin");
  if (joinBtn) joinBtn.addEventListener("click", activityRaiseHand);
  var stepDownBtn = $("btnActivityVoiceStepDown");
  if (stepDownBtn) stepDownBtn.addEventListener("click", activityStepDown);
  var muteBtn = $("btnActivityVoiceMuteToggle");
  if (muteBtn) muteBtn.addEventListener("click", activityToggleMute);
  var activateBtn = $("btnActivityVoiceActivate");
  if (activateBtn) activateBtn.addEventListener("click", activityActivateVoice);
  var deactivateBtn = $("btnActivityVoiceDeactivate");
  if (deactivateBtn) deactivateBtn.addEventListener("click", activityDeactivateVoice);
}

function activityActivateVoice() {
  var myRole = activityRoleFn ? activityRoleFn() : null;
  if (myRole !== "admin" && myRole !== "co_admin") {
    toast(t("activity.err_no_perm_on"));
    return;
  }
  activityVoiceActive = true;
  if (activityVoiceKind === "group") supabase.rpc("set_voice_active", {
    p_kind: "group",
    p_id: activityVoiceRoomId,
    p_active: true
  }).then(function() {});
  broadcastActivityVoiceEvent({
    type: "voice_on",
    by: currentUser.username
  });
  renderActivityVoiceBar();
}

function activityDeactivateVoice() {
  var myRole = activityRoleFn ? activityRoleFn() : null;
  if (myRole !== "admin" && myRole !== "co_admin") {
    toast(t("activity.err_no_perm_off"));
    return;
  }
  activityVoiceActive = false;
  if (activityVoiceKind === "group") supabase.rpc("set_voice_active", {
    p_kind: "group",
    p_id: activityVoiceRoomId,
    p_active: false
  }).then(function() {});
  broadcastActivityVoiceEvent({
    type: "voice_off",
    by: currentUser.username
  });
  if (activityVoiceRoom && activityVoiceRoom.localParticipant && activityVoiceRoom.localParticipant.isMicrophoneEnabled) {
    activityVoiceRoom.localParticipant.setMicrophoneEnabled(false).then(renderActivityVoiceBar);
  } else {
    renderActivityVoiceBar();
  }
}

function activityRaiseHand() {
  if (!currentUser) return;
  if (!activityVoiceJoined && getActivityVoiceSpeakers().length >= VOICE_MAX_USERS) {
    toast("Se alcanzó el límite de " + VOICE_MAX_USERS + " usuarios en el chat de voz.");
    return;
  }
  var myRole = activityRoleFn ? activityRoleFn() : null;
  if (!myRole) {
    toast(t("activity.err_join_first"));
    return;
  }
  var isStaff = myRole === "admin" || myRole === "co_admin";
  if (!activityVoiceActive && !isStaff) {
    toast(t("activity.err_admin_must_start"));
    return;
  }
  var otherActivity = typeof activeVoiceActivityElsewhere === "function" ? activeVoiceActivityElsewhere(activityVoiceKind, activityVoiceRoomId) : null;
  if (otherActivity) {
    toast("Ya tienes una actividad de voz activa en " + otherActivity + ". Sal de ahí antes de unirte aquí.");
    return;
  }
  var proceed = activityVoiceRoom ? Promise.resolve() : ensureActivityVoiceConnected(activityVoiceKind, activityVoiceRoomId, activityRoleFn);
  proceed.then(function() {
    if (!activityVoiceRoom) {
      toast(t("activity.err_connect"));
      return;
    }
    return activityVoiceRoom.localParticipant.setMicrophoneEnabled(true);
  }).then(function() {
    activityVoiceMuted = false;
    activityVoiceJoined = true;
    if (!activityVoiceActive && isStaff) {
      activityVoiceActive = true;
      broadcastActivityVoiceEvent({
        type: "voice_on",
        by: currentUser.username
      });
    }
    renderActivityVoiceBar();
  }).catch(function() {
    toast(t("activity.err_mic"));
  });
}

function activityStepDown() {
  if (!activityVoiceRoom) return;
  activityVoiceJoined = false;
  activityVoiceMuted = false;
  activityVoiceRoom.localParticipant.setMicrophoneEnabled(false).then(renderActivityVoiceBar);
}

function activityToggleMute() {
  if (!activityVoiceRoom || !activityVoiceRoom.localParticipant) return;
  var micPub = activityVoiceRoom.localParticipant.getTrackPublication ? activityVoiceRoom.localParticipant.getTrackPublication(LivekitClient.Track.Source.Microphone) : null;
  if (!micPub || !micPub.track) return;
  activityVoiceMuted = !activityVoiceMuted;
  Promise.resolve(activityVoiceMuted ? micPub.track.mute() : micPub.track.unmute()).then(renderActivityVoiceBar);
}

function leaveActivityVoice() {
  if (activityVoiceGraceTimer) {
    clearTimeout(activityVoiceGraceTimer);
    activityVoiceGraceTimer = null;
  }
  if (activityVoiceRoom) {
    try {
      activityVoiceRoom.disconnect();
    } catch (_e) {}
    activityVoiceRoom = null;
  }
  activityVoiceMuted = false;
  activityVoiceActive = false;
  activityVoiceSpeaking = {};
  qsa("[data-activity-livekit-audio]", document.body).forEach(function(mediaEl) {
    mediaEl.remove();
  });
  activityVoiceMinimized = false;
  activityVoiceReopenFn = null;
  renderActivityVoiceFloat();
}

var activityVoiceMinimized = false;

var activityVoiceReopenFn = null;

var activityVoiceFloatPos = null;

var activityVoiceFloatDrag = null;

function minimizeActivityVoice(reopenFn) {
  if (!activityVoiceRoom) return;
  activityVoiceMinimized = true;
  activityVoiceReopenFn = reopenFn || null;
  renderActivityVoiceFloat();
}

function restoreActivityVoiceFromFloat() {
  if (!activityVoiceMinimized) return;
  activityVoiceMinimized = false;
  var reopen = activityVoiceReopenFn;
  activityVoiceReopenFn = null;
  renderActivityVoiceFloat();
  if (reopen) reopen();
}

function activityVoiceFloatCurrentSpeaker() {
  var speakers = getActivityVoiceSpeakers();
  var talking = speakers.filter(function(p) {
    return activityVoiceSpeaking[p.identity];
  });
  var p = talking[0] || speakers[0];
  if (!p) return null;
  var profile = activityVoiceParticipantProfile(p) || {};
  var displayName = p.isLocal ? "Tú" : p.name;
  var avatarUrl = profile.avatarUrl;
  var rpIdentity = activityVoiceKind === "group" && typeof roleplayVoiceIdentityFor === "function" ? roleplayVoiceIdentityFor(p.identity, "group") : null;
  if (rpIdentity) {
    displayName = rpIdentity.name;
    if (rpIdentity.avatarUrl) avatarUrl = rpIdentity.avatarUrl;
  }
  return {
    name: displayName,
    avatarUrl: avatarUrl,
    isSpeaking: !!activityVoiceSpeaking[p.identity],
    uid: rpIdentity ? null : p.identity
  };
}

function ensureActivityVoiceFloatEl() {
  var el = $("activityVoiceFloat");
  if (el) return el;
  el = document.createElement("div");
  el.id = "activityVoiceFloat";
  el.className = "activity-voice-float";
  el.hidden = true;
  el.innerHTML = '<button type="button" class="activity-voice-float-x" id="activityVoiceFloatClose" aria-label="Cerrar y salir">×</button>' + '<div class="activity-voice-float-body" id="activityVoiceFloatBody">' + '<div class="activity-voice-float-avatar" id="activityVoiceFloatAvatar"></div>' + '<div class="activity-voice-float-label" id="activityVoiceFloatLabel"></div>' + '<div class="activity-voice-float-video" id="activityVoiceFloatVideo" hidden></div>' + "</div>";
  document.body.appendChild(el);
  $("activityVoiceFloatClose").addEventListener("click", function(e) {
    e.stopPropagation();
    if (confirm("Vas a salir de este chat de voz y ya no vas a estar en la sala o actividad. ¿Seguro que quieres salir?")) {
      leaveActivityVoice();
    }
  });
  $("activityVoiceFloatBody").addEventListener("click", function(e) {
    if (activityVoiceFloatDrag && activityVoiceFloatDrag.moved) return;
    restoreActivityVoiceFromFloat();
  });
  wireActivityVoiceFloatDrag(el);
  return el;
}

function wireActivityVoiceFloatDrag(el) {
  function startDrag(clientX, clientY) {
    var rect = el.getBoundingClientRect();
    activityVoiceFloatDrag = {
      startX: clientX,
      startY: clientY,
      startRight: window.innerWidth - rect.right,
      startBottom: window.innerHeight - rect.bottom,
      moved: false
    };
  }
  function moveDrag(clientX, clientY) {
    if (!activityVoiceFloatDrag) return;
    var dx = clientX - activityVoiceFloatDrag.startX;
    var dy = clientY - activityVoiceFloatDrag.startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) activityVoiceFloatDrag.moved = true;
    var right = Math.max(6, activityVoiceFloatDrag.startRight - dx);
    var bottom = Math.max(6, activityVoiceFloatDrag.startBottom - dy);
    activityVoiceFloatPos = {
      right: right,
      bottom: bottom
    };
    el.style.right = right + "px";
    el.style.bottom = bottom + "px";
  }
  function endDrag() {
    activityVoiceFloatDrag = null;
  }
  el.addEventListener("mousedown", function(e) {
    if (e.target.id === "activityVoiceFloatClose") return;
    startDrag(e.clientX, e.clientY);
    e.preventDefault();
  });
  document.addEventListener("mousemove", function(e) {
    moveDrag(e.clientX, e.clientY);
  });
  document.addEventListener("mouseup", endDrag);
  el.addEventListener("touchstart", function(e) {
    if (e.target.id === "activityVoiceFloatClose") return;
    var t = e.touches[0];
    startDrag(t.clientX, t.clientY);
  }, {
    passive: true
  });
  document.addEventListener("touchmove", function(e) {
    if (!activityVoiceFloatDrag) return;
    var t = e.touches[0];
    moveDrag(t.clientX, t.clientY);
  }, {
    passive: true
  });
  document.addEventListener("touchend", endDrag);
}

var activityCinemaHomeParent = null;

function activityVoiceFloatCinemaPlayerId() {
  if (activityVoiceKind === "group" && typeof currentGroup !== "undefined" && currentGroup && currentGroup.active_activity === "cinema") return "groupCinemaPlayer";
  if (activityVoiceKind === "dm" && typeof currentConversation !== "undefined" && currentConversation && currentConversation.dmRow && currentConversation.dmRow.active_activity === "cinema") return "dmCinemaPlayer";
  return null;
}

function renderActivityVoiceFloat() {
  var show = activityVoiceMinimized && !!activityVoiceRoom;
  var el = show ? ensureActivityVoiceFloatEl() : $("activityVoiceFloat");
  if (!el) return;
  el.hidden = !show;
  var playerId = show ? activityVoiceFloatCinemaPlayerId() : null;
  var isCinema = !!playerId;
  el.classList.toggle("cinema", isCinema);
  var videoSlot = $("activityVoiceFloatVideo");
  var player = playerId ? $(playerId) : null;
  if (isCinema && player) {
    if (!activityCinemaHomeParent) activityCinemaHomeParent = player.parentNode;
    if (videoSlot && player.parentNode !== videoSlot) videoSlot.appendChild(player);
    if (videoSlot) videoSlot.hidden = false;
  } else if (activityCinemaHomeParent) {
    [ "groupCinemaPlayer", "dmCinemaPlayer" ].forEach(function(id) {
      var p = $(id);
      if (p && p.parentNode === videoSlot) activityCinemaHomeParent.appendChild(p);
    });
    if (videoSlot) videoSlot.hidden = true;
  }
  if (!show) return;
  if (activityVoiceFloatPos) {
    el.style.right = activityVoiceFloatPos.right + "px";
    el.style.bottom = activityVoiceFloatPos.bottom + "px";
  }
  var avatarEl = $("activityVoiceFloatAvatar");
  var labelEl = $("activityVoiceFloatLabel");
  if (isCinema) {
    if (avatarEl) avatarEl.hidden = true;
    if (labelEl) labelEl.hidden = true;
    return;
  }
  if (avatarEl) avatarEl.hidden = false;
  if (labelEl) labelEl.hidden = false;
  var speaker = activityVoiceFloatCurrentSpeaker();
  if (avatarEl) {
    avatarEl.innerHTML = avatarSpanHtml(speaker ? speaker.name : "", speaker ? speaker.avatarUrl : null, "activity-voice-float-avatar-inner", speaker ? speaker.uid : null);
    avatarEl.classList.toggle("speaking", !!(speaker && speaker.isSpeaking));
  }
  if (labelEl) labelEl.textContent = speaker ? speaker.name : activityVoiceActive ? "Chat de voz activo" : "Chat de voz";
}

var ACTIVITY_VOICE_GRACE_MS = 12e4;

function isWatchingActivityCinemaNow() {
  if (activityVoiceKind === "group" && typeof currentGroup !== "undefined" && currentGroup) {
    return currentGroup.active_activity === "cinema";
  }
  if (activityVoiceKind === "dm" && typeof currentConversation !== "undefined" && currentConversation && currentConversation.dmRow) {
    return currentConversation.dmRow.active_activity === "cinema";
  }
  return false;
}

document.addEventListener("visibilitychange", function() {
  if (!activityVoiceRoom) return;
  if (isWatchingActivityCinemaNow()) return;
  if (document.hidden) {
    if (activityVoiceGraceTimer) clearTimeout(activityVoiceGraceTimer);
    activityVoiceGraceTimer = setTimeout(function() {
      activityVoiceGraceTimer = null;
      if (document.hidden && activityVoiceRoom) {
        leaveActivityVoice();
        renderActivityVoiceBar();
      }
    }, ACTIVITY_VOICE_GRACE_MS);
  } else if (activityVoiceGraceTimer) {
    clearTimeout(activityVoiceGraceTimer);
    activityVoiceGraceTimer = null;
  }
});