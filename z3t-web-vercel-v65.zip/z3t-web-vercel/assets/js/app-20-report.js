"use strict";

var REPORT_LABELS = {
  message: "este mensaje",
  post: "esta publicación",
  profile: "este perfil",
  frame: "este marco",
  bubble: "esta burbuja",
  community: "esta comunidad",
  attachment: "esta imagen"
};

function kebabMenuHtml(targetType, targetId, isOwner, opts) {
  if (!targetId) return "";
  var delTable = opts && opts.deleteTable ? opts.deleteTable : "";
  var canEdit = isOwner && (targetType === "frame" || targetType === "bubble");
  return "" + '<div class="kebab-menu" data-kebab-menu>' + '<button type="button" class="icon-btn kebab-btn" data-kebab-toggle data-target-type="' + escapeHtml(targetType) + '" data-target-id="' + escapeHtml(String(targetId)) + '"' + (delTable ? ' data-delete-table="' + escapeHtml(delTable) + '"' : "") + ' aria-label="Más opciones">⋮</button>' + '<div class="kebab-dropdown" hidden>' + (canEdit ? '<button type="button" class="kebab-item" data-kebab-action="edit">✏️ Editar</button>' : "") + (canEdit ? '<button type="button" class="kebab-item" data-kebab-action="mint">🪙 Acuñar ' + (targetType === "frame" ? "marco" : "burbuja") + "</button>" : "") + (delTable ? '<button type="button" class="kebab-item kebab-item-danger" data-kebab-action="delete">🗑️ Borrar mensaje</button>' : "") + '<button type="button" class="kebab-item" data-kebab-action="share">🔗 Compartir</button>' + '<button type="button" class="kebab-item kebab-item-danger" data-kebab-action="report">🚩 Reportar</button>' + "</div>" + "</div>";
}

function closeAllKebabDropdowns() {
  qsa(".kebab-dropdown").forEach(function(dd) {
    dd.hidden = true;
  });
}

function shareTarget(targetType, targetId) {
  var url = location.origin + location.pathname + "#" + targetType + "=" + encodeURIComponent(targetId);
  if (navigator.share) {
    navigator.share({
      url: url
    }).catch(function() {});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(url).then(function() {
      toast("Enlace copiado.");
    });
  } else toast(url);
}

function editKebabTarget(targetType, targetId) {
  if (typeof STORE_ITEMS === "undefined" || typeof openStoreEdit !== "function") return;
  var item = STORE_ITEMS.filter(function(i) {
    return String(i.id) === String(targetId);
  })[0];
  if (!item) {
    toast("No se encontró para editar.");
    return;
  }
  openStoreEdit(targetType, item);
}

var reportTarget = null;

var reportFiles = {
  1: null,
  2: null
};

function openReportModal(targetType, targetId) {
  if (!currentUser) {
    toast("Inicia sesión para reportar.");
    return;
  }
  reportTarget = {
    type: targetType,
    id: targetId
  };
  reportFiles = {
    1: null,
    2: null
  };
  var label = REPORT_LABELS[targetType] || "esto";
  $("reportModalTitle").textContent = "Reportar " + label;
  $("reportReason").value = "";
  $("reportAccept").checked = false;
  $("reportShot1").value = "";
  $("reportShot2").value = "";
  $("reportShot1Name").textContent = "Sin archivo";
  $("reportShot2Name").textContent = "Sin archivo";
  updateReportSubmitState();
  $("reportBackdrop").classList.add("open");
}

function updateReportSubmitState() {
  var btn = $("reportSubmitBtn");
  if (!btn) return;
  var reasonOk = $("reportReason").value.trim().length >= 10;
  var ok = !!reportFiles[1] && !!reportFiles[2] && reasonOk && $("reportAccept").checked;
  btn.disabled = !ok;
}

function submitReport() {
  if (!reportTarget || !currentUser) return;
  var btn = $("reportSubmitBtn");
  btn.disabled = true;
  btn.textContent = "Enviando...";
  uploadFiles([ reportFiles[1], reportFiles[2] ], "reports/" + currentUser.id).then(function(uploaded) {
    return supabase.from("reports").insert({
      reporter_id: currentUser.id,
      target_type: reportTarget.type,
      target_id: String(reportTarget.id),
      reason: $("reportReason").value.trim(),
      screenshot1_url: uploaded[0] ? uploaded[0].url : null,
      screenshot2_url: uploaded[1] ? uploaded[1].url : null
    });
  }).then(function(res) {
    if (res && res.error) throw res.error;
    toast("Reporte enviado. El equipo lo va a revisar.");
    $("reportBackdrop").classList.remove("open");
  }).catch(function(err) {
    console.error("[submitReport]", err);
    toast("No se pudo enviar el reporte" + (err && err.message ? ": " + err.message : "."));
  }).then(function() {
    btn.disabled = false;
    btn.textContent = "Enviar reporte";
    updateReportSubmitState();
  });
}

document.addEventListener("click", function(e) {
  var toggle = e.target.closest("[data-kebab-toggle]");
  if (toggle) {
    e.stopPropagation();
    var dd = toggle.parentElement.querySelector(".kebab-dropdown");
    var wasOpen = dd && !dd.hidden;
    closeAllKebabDropdowns();
    if (dd) dd.hidden = wasOpen;
    return;
  }
  var action = e.target.closest("[data-kebab-action]");
  if (action) {
    e.stopPropagation();
    var menu = action.closest("[data-kebab-menu]");
    var toggleBtn = menu.querySelector("[data-kebab-toggle]");
    var targetType = toggleBtn.getAttribute("data-target-type");
    var targetId = toggleBtn.getAttribute("data-target-id");
    closeAllKebabDropdowns();
    var kebabAction = action.getAttribute("data-kebab-action");
    if (kebabAction === "delete") {
      if (typeof z3tDeleteChatMessage === "function") z3tDeleteChatMessage(toggleBtn.getAttribute("data-delete-table"), targetId);
    } else if (kebabAction === "share") shareTarget(targetType, targetId); else if (kebabAction === "edit") editKebabTarget(targetType, targetId); else if (kebabAction === "mint") {
      if (typeof openMintModal === "function") openMintModal(targetType, targetId);
    } else openReportModal(targetType, targetId);
    return;
  }
  if (!e.target.closest(".kebab-dropdown")) closeAllKebabDropdowns();
}, true);

document.addEventListener("DOMContentLoaded", function() {
  var shot1 = $("reportShot1"), shot2 = $("reportShot2");
  if (shot1) shot1.addEventListener("change", function() {
    reportFiles[1] = shot1.files[0] || null;
    $("reportShot1Name").textContent = reportFiles[1] ? reportFiles[1].name : "Sin archivo";
    updateReportSubmitState();
  });
  if (shot2) shot2.addEventListener("change", function() {
    reportFiles[2] = shot2.files[0] || null;
    $("reportShot2Name").textContent = reportFiles[2] ? reportFiles[2].name : "Sin archivo";
    updateReportSubmitState();
  });
  var reason = $("reportReason");
  if (reason) reason.addEventListener("input", updateReportSubmitState);
  var accept = $("reportAccept");
  if (accept) accept.addEventListener("change", updateReportSubmitState);
  var submitBtn = $("reportSubmitBtn");
  if (submitBtn) submitBtn.addEventListener("click", submitReport);
  var closeBtn = $("reportClose");
  if (closeBtn) closeBtn.addEventListener("click", function() {
    $("reportBackdrop").classList.remove("open");
  });
  var backdrop = $("reportBackdrop");
  if (backdrop) backdrop.addEventListener("click", function(e) {
    if (e.target === this) this.classList.remove("open");
  });
});