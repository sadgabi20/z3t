"use strict";

/* Ajustes en una sola pantalla: Roleplay, Sala de Cine y Editar perfil.
   - Los popups pequeños se muestran como pantalla completa con encabezado y botón de cerrar.
   - Los selectores de color tienen una paleta lista para tocar. */
var Z3T_SWATCHES = [ "#ffffff", "#efe9e1", "#ff4d6d", "#ff8a3d", "#ffd23f", "#7CFF6B", "#2ee6a6", "#3dd5f3", "#4d7cff", "#a855f7", "#f472b6", "#ff2b2b" ];

function z3tSheetTitle(pop) {
  if (pop.classList.contains("rp-settings-popup")) return "Ajustes de Roleplay";
  if (pop.classList.contains("cinema-options-popup")) return "Ajustes de Sala de Cine";
  return "Ajustes";
}

function z3tEnsureSheetHead(pop) {
  if (!pop.classList.contains("open")) return;
  if (!document.body.classList.contains("z3t-sheet-open")) document.body.classList.add("z3t-sheet-open");
  if (pop.querySelector(":scope > .z3t-sheet-head")) return;
  var head = document.createElement("div");
  head.className = "z3t-sheet-head";
  head.innerHTML = "<h3>" + z3tSheetTitle(pop) + '</h3><button type="button" class="icon-btn z3t-sheet-close" aria-label="Cerrar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></svg></button>';
  head.querySelector("button").addEventListener("click", function(e) {
    e.stopPropagation();
    pop.classList.remove("open");
    if (document.body.classList.contains("z3t-sheet-open")) document.body.classList.remove("z3t-sheet-open");
  });
  pop.insertBefore(head, pop.firstChild);
}

function z3tScanSheets() {
  qsa(".rp-settings-popup, .cinema-options-popup").forEach(z3tEnsureSheetHead);
  if (!qsa(".rp-settings-popup.open, .cinema-options-popup.open").length && document.body.classList.contains("z3t-sheet-open")) document.body.classList.remove("z3t-sheet-open");
}

function z3tAddSwatches(input) {
  if (!input || input.getAttribute("data-swatches")) return;
  input.setAttribute("data-swatches", "1");
  var row = document.createElement("div");
  row.className = "color-swatches";
  row.innerHTML = Z3T_SWATCHES.map(function(c) {
    return '<button type="button" class="color-swatch" data-color="' + c + '" style="background:' + c + '" aria-label="' + c + '"></button>';
  }).join("");
  row.addEventListener("click", function(e) {
    var b = e.target.closest(".color-swatch");
    if (!b) return;
    e.preventDefault();
    input.value = b.getAttribute("data-color");
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    z3tMarkSwatch(row, input.value);
  });
  var anchor = input.closest(".color-field-row") || input.closest(".flag-edit-row") || input.parentNode;
  anchor.parentNode.insertBefore(row, anchor.nextSibling);
  input.addEventListener("input", function() {
    z3tMarkSwatch(row, input.value);
  });
  z3tMarkSwatch(row, input.value);
}

function z3tMarkSwatch(row, value) {
  qsa(".color-swatch", row).forEach(function(b) {
    b.classList.toggle("on", b.getAttribute("data-color").toLowerCase() === String(value).toLowerCase());
  });
}

function z3tScanSettings() {
  qsa('#settingsModal input[type="color"], #communitySettingsModal input[type="color"], #chatBgModal input[type="color"], #createCommunityModal input[type="color"], #groupCreateModal input[type="color"]').forEach(z3tAddSwatches);
  var modal = $("settingsModal");
  if (!modal) return;
  var nameIn = $("nameInput"), colorIn = $("nameColorInput");
  if (nameIn && colorIn && !$("nameColorPreview")) {
    var prev = document.createElement("div");
    prev.id = "nameColorPreview";
    prev.className = "name-color-preview";
    var row = colorIn.closest(".color-field-row");
    if (row) row.parentNode.insertBefore(prev, row);
    var upd = function() {
      prev.textContent = nameIn.value || "Tu nombre";
      prev.style.color = colorIn.value;
    };
    nameIn.addEventListener("input", upd);
    colorIn.addEventListener("input", upd);
    colorIn.addEventListener("change", upd);
    upd();
    var reset = $("btnResetNameColor");
    if (reset) reset.addEventListener("click", function() {
      setTimeout(upd, 0);
    });
  }
}

var z3tScanQueued = false;

var z3tSheetObserver = new MutationObserver(function(muts) {
  var relevant = muts.some(function(m) {
    return m.target !== document.body && m.target !== document.documentElement;
  });
  if (!relevant || z3tScanQueued) return;
  z3tScanQueued = true;
  setTimeout(function() {
    z3tScanQueued = false;
    z3tScanSheets();
    z3tScanSettings();
  }, 120);
});

document.addEventListener("DOMContentLoaded", function() {
  z3tSheetObserver.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: [ "class" ] });
  z3tScanSheets();
  z3tScanSettings();
});
