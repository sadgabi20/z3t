if ("caches" in window) {
  caches.keys().then(function(keys) {
    keys.filter(function(k) {
      return /^z3t-data-/.test(k);
    }).forEach(function(k) {
      caches.delete(k);
    });
  }).catch(function() {});
}

"use strict";

if ("serviceWorker" in navigator) {
  var swReloadedOnce = false;
  navigator.serviceWorker.addEventListener("controllerchange", function() {
    if (swReloadedOnce) return;
    swReloadedOnce = true;
    location.reload();
  });
  window.addEventListener("load", function() {
    navigator.serviceWorker.register("/sw.js", {
      scope: "/"
    }).then(function(reg) {
      if (reg && reg.update) reg.update();
    }).catch(function(err) {
      console.warn("[sw] no se pudo registrar el service worker:", err);
    });
  });
}

var deferredInstallPrompt = null;

function showInstallButtons(show) {
  var l = $("btnInstallLanding");
  if (l) l.hidden = !show;
  var a = $("btnInstallApp");
  if (a) a.hidden = !show;
}

window.addEventListener("beforeinstallprompt", function(e) {
  e.preventDefault();
  deferredInstallPrompt = e;
  showInstallButtons(true);
});

function triggerInstall(e) {
  if (e && e.preventDefault) e.preventDefault();
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  deferredInstallPrompt.userChoice.then(function() {
    deferredInstallPrompt = null;
    showInstallButtons(false);
  });
}

var btnInstallLanding = $("btnInstallLanding");

if (btnInstallLanding) btnInstallLanding.addEventListener("click", triggerInstall);

var btnInstallApp = $("btnInstallApp");

if (btnInstallApp) btnInstallApp.addEventListener("click", triggerInstall);

window.addEventListener("appinstalled", function() {
  showInstallButtons(false);
  toast("App instalada. Ya la tienes en tu pantalla de inicio.");
});

function hasStoredSessionToken() {
  try {
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k && k.indexOf("sb-") === 0 && k.indexOf("-auth-token") !== -1) return true;
    }
  } catch (e) {}
  return false;
}

var sessionResolved = false;

var hadStoredSession = hasStoredSessionToken();

var fallbackRetries = 0;

function showLoggedOutView() {
  if (z3tRecoveryLinkExpired) {
    z3tRecoveryLinkExpired = false;
    showView("forgot-password");
    toast("El enlace expiró o ya se usó. Pide uno nuevo.");
    return;
  }
  if (location.pathname === "/login") {
    showView("login");
  } else if (location.pathname === "/registro") {
    showView("register");
  } else if (typeof pendingRoute !== "undefined" && pendingRoute) {
    showView("login");
  } else {
    showView("landing");
  }
}

function appLoadingFallback() {
  if (sessionResolved) return;
  if (hadStoredSession && fallbackRetries < 4) {
    fallbackRetries++;
    appLoadingFallbackTimer = setTimeout(appLoadingFallback, 4e3);
    return;
  }
  showLoggedOutView();
}

var appLoadingFallbackTimer = setTimeout(appLoadingFallback, 8e3);

I18N.applyLanguage(I18N.langForRegion(detectRegion()));

var Z3T_PROFILE_CACHE_KEY = "z3t_profile_cache_v1";

function z3tCacheProfile(p) {
  try {
    if (!p || !p.id) return;
    var copy = JSON.parse(JSON.stringify(p));
    delete copy.ip;
    delete copy.device;
    delete copy.location;
    localStorage.setItem(Z3T_PROFILE_CACHE_KEY, JSON.stringify(copy));
  } catch (e) {}
}

function z3tClearCachedProfile() {
  try {
    localStorage.removeItem(Z3T_PROFILE_CACHE_KEY);
  } catch (e) {}
}

function z3tReadCachedProfile(uid) {
  try {
    var p = JSON.parse(localStorage.getItem(Z3T_PROFILE_CACHE_KEY) || "null");
    return p && p.id && (!uid || p.id === uid) ? p : null;
  } catch (e) {
    return null;
  }
}

function z3tStoredSessionUserId() {
  try {
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k && k.indexOf("sb-") === 0 && k.indexOf("-auth-token") !== -1) {
        var v = JSON.parse(localStorage.getItem(k) || "null");
        if (v && v.user && v.user.id) return v.user.id;
      }
    }
  } catch (e) {}
  return null;
}

var z3tOptimisticEntered = false;

function z3tBootstrap() {
(function optimisticEntry() {
  if (z3tIsRecoveryMode()) return;
  var uid = z3tStoredSessionUserId();
  var cached = uid ? z3tReadCachedProfile(uid) : null;
  if (!cached || cached.banned === true) return;
  z3tOptimisticEntered = true;
  sessionResolved = true;
  clearTimeout(appLoadingFallbackTimer);
  currentUser = cached;
  enterForum();
})();

supabase.auth.getSession().then(function(res) {
  sessionResolved = true;
  clearTimeout(appLoadingFallbackTimer);
  var session = res.data && res.data.session;
  if (z3tIsRecoveryMode()) {
    if (session) {
      showView("reset-password");
      return;
    }
    z3tSetRecoveryMode(false);
  }
  if (!session) {
    if (z3tOptimisticEntered) {
      z3tClearCachedProfile();
      currentUser = null;
    }
    showLoggedOutView();
    return;
  }
  if (z3tOptimisticEntered && currentUser && currentUser.id === session.user.id) {
    recordLoginStreak(currentUser.id);
    fetchProfile(session.user.id).then(function(fresh) {
      if (!fresh) return;
      currentUser = fresh;
      z3tCacheProfile(fresh);
      if (fresh.banned === true) showView("banned");
    }).catch(function() {});
    return;
  }
  fetchProfile(session.user.id).then(function(profile) {
    if (!profile) {
      showLoggedOutView();
      return;
    }
    currentUser = profile;
    z3tCacheProfile(profile);
    enterForum();
    recordLoginStreak(profile.id);
  }).catch(function(err) {
    console.error("[bootstrap] no se pudo cargar el perfil:", err);
    var again = z3tReadCachedProfile(session.user.id);
    if (again && again.banned !== true) {
      currentUser = again;
      enterForum();
      return;
    }
    showLoggedOutView();
  });
}).catch(function(err) {
  sessionResolved = true;
  clearTimeout(appLoadingFallbackTimer);
  console.error("[bootstrap] getSession() falló:", err);
  showLoggedOutView();
});
}

/* Se arranca cuando ya cargaron todos los scripts (así enterForum encuentra todas sus funciones) */
if (document.readyState === "complete") z3tBootstrap(); else document.addEventListener("DOMContentLoaded", z3tBootstrap);
