"use strict";

function openAdminPanel() {
  if (!currentUser || currentUser.role !== "admin") return;
  $("adminSearchInput").value = "";
  $("adminDetailView").hidden = true;
  $("adminSearchView").hidden = false;
  $("adminBackdrop").classList.add("open");
  loadAllAdminUsers();
}

var btnOpenAdminPanelEl = $("btnOpenAdminPanel");

if (btnOpenAdminPanelEl) btnOpenAdminPanelEl.addEventListener("click", openAdminPanel);

$("adminClose").addEventListener("click", function() {
  $("adminBackdrop").classList.remove("open");
});

$("adminBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

$("adminBackBtn").addEventListener("click", function() {
  $("adminDetailView").hidden = true;
  $("adminSearchView").hidden = false;
});

var adminGlobalGrantBtnEl = $("adminGlobalGrantBtn");

if (adminGlobalGrantBtnEl) adminGlobalGrantBtnEl.addEventListener("click", function() {
  var stars = parseInt($("adminGlobalGrantStars").value, 10) || 0;
  var coin = parseInt($("adminGlobalGrantCoin").value, 10) || 0;
  if (stars <= 0 && coin <= 0) {
    toast("Pon un monto en Diamantes o Z-Coins.");
    return;
  }
  if (!confirm("¿Enviar " + (stars > 0 ? stars + " Diamantes " : "") + (coin > 0 ? coin + " Z-Coins" : "") + " a TODOS los usuarios? Esto no se puede deshacer.")) return;
  adminGlobalGrantBtnEl.disabled = true;
  supabase.rpc("admin_grant_currency_all", {
    p_stars: stars,
    p_coin: coin
  }).then(function(res) {
    adminGlobalGrantBtnEl.disabled = false;
    if (res.error) {
      toast("No se pudo enviar: " + res.error.message);
      return;
    }
    toast("Enviado a " + (res.data || 0) + " cuentas.");
    $("adminGlobalGrantStars").value = "";
    $("adminGlobalGrantCoin").value = "";
  });
});

function adminUserRowHtml(u) {
  if (u && u.id) markBannedUser(u.id, u.banned === true);
  return '<div class="social-list-row admin-result-row" data-uid="' + escapeHtml(u.id) + '">' + avatarSpanHtml(u.username, u.avatar_url, "avatar-md", u.id) + '<div class="social-list-row-info">' + '<div class="social-list-row-name">' + escapeHtml(u.username) + roleBadgeHtml(u.role, u.verified) + (u.is_volunteer ? ' <span class="admin-volunteer-tag">Volunteer</span>' : "") + (u.banned ? ' <span class="admin-banned-tag">Baneado</span>' : "") + "</div>" + '<div class="admin-row-actions">' + '<button type="button" class="terminal-btn small admin-row-act" data-act="verify">' + (u.verified ? "Quitar verificado" : "Verificar") + "</button>" + '<button type="button" class="terminal-btn small admin-row-act" data-act="volunteer">' + (u.is_volunteer ? "Quitar volunteer" : "Hacer volunteer") + "</button>" + '<button type="button" class="terminal-btn small btn-danger admin-row-act" data-act="ban">' + (u.banned ? "Quitar baneo" : "Banear") + "</button>" + '<button type="button" class="terminal-btn small admin-row-act" data-act="coins">Dar monedas</button>' + "</div>" + "</div>" + "</div>";
}

function wireAdminRow(row, u, wrap) {
  row.addEventListener("click", function(e) {
    if (e.target.closest(".admin-row-act")) return;
    openAdminDetail(u.id);
  });
  var verifyBtn = row.querySelector('[data-act="verify"]');
  verifyBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    verifyBtn.disabled = true;
    supabase.from("profiles").update({
      verified: !u.verified
    }).eq("id", u.id).then(function(res) {
      verifyBtn.disabled = false;
      if (res.error) {
        toast("No se pudo actualizar: " + (res.error && res.error.message ? res.error.message : "error desconocido"));
        console.error(res.error);
        return;
      }
      u.verified = !u.verified;
      toast(u.verified ? "Cuenta verificada." : "Verificado retirado.");
      var fresh = adminUserRowFrom(u);
      row.outerHTML = fresh;
      wireAdminRow(wrap.querySelector('.admin-result-row[data-uid="' + CSSEscape(u.id) + '"]'), u, wrap);
    });
  });
  var volunteerBtn = row.querySelector('[data-act="volunteer"]');
  volunteerBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    volunteerBtn.disabled = true;
    supabase.from("profiles").update({
      is_volunteer: !u.is_volunteer
    }).eq("id", u.id).then(function(res) {
      volunteerBtn.disabled = false;
      if (res.error) {
        toast("No se pudo actualizar: " + (res.error && res.error.message ? res.error.message : "error desconocido"));
        console.error(res.error);
        return;
      }
      u.is_volunteer = !u.is_volunteer;
      toast(u.is_volunteer ? "Ahora es volunteer." : "Ya no es volunteer.");
      var fresh = adminUserRowFrom(u);
      row.outerHTML = fresh;
      wireAdminRow(wrap.querySelector('.admin-result-row[data-uid="' + CSSEscape(u.id) + '"]'), u, wrap);
    });
  });
  var banBtn = row.querySelector('[data-act="ban"]');
  banBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    var confirmMsg = u.banned ? "¿Quitar el baneo a @" + u.username + "?" : "¿Banear a @" + u.username + "? No podrá volver a iniciar sesión.";
    if (!confirm(confirmMsg)) return;
    banBtn.disabled = true;
    supabase.from("profiles").update({
      banned: !u.banned
    }).eq("id", u.id).then(function(res) {
      banBtn.disabled = false;
      if (res.error) {
        toast("No se pudo actualizar: " + (res.error && res.error.message ? res.error.message : "error desconocido"));
        console.error(res.error);
        return;
      }
      u.banned = !u.banned;
      toast(u.banned ? "Cuenta baneada." : "Baneo retirado.");
      var fresh = adminUserRowFrom(u);
      row.outerHTML = fresh;
      wireAdminRow(wrap.querySelector('.admin-result-row[data-uid="' + CSSEscape(u.id) + '"]'), u, wrap);
    });
  });
  var coinsBtn = row.querySelector('[data-act="coins"]');
  coinsBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    var stars = parseInt(prompt("¿Cuántos Diamantes darle a @" + u.username + "? (0 si no aplica)", "0") || "0", 10) || 0;
    var coin = parseInt(prompt("¿Cuántos Z-Coins darle a @" + u.username + "? (0 si no aplica)", "0") || "0", 10) || 0;
    if (stars <= 0 && coin <= 0) {
      return;
    }
    coinsBtn.disabled = true;
    supabase.rpc("admin_grant_currency", {
      p_recipient: u.id,
      p_stars: stars,
      p_coin: coin
    }).then(function(res) {
      coinsBtn.disabled = false;
      if (res.error) {
        toast("No se pudo enviar (revisa que tu cuenta sea admin en la base de datos).");
        return;
      }
      toast("Enviado a @" + u.username + ": " + (stars > 0 ? stars + " Diamantes " : "") + (coin > 0 ? coin + " Z-Coins" : ""));
    });
  });
}

function adminUserRowFrom(u) {
  return adminUserRowHtml(u);
}

function CSSEscape(s) {
  return window.CSS && CSS.escape ? CSS.escape(s) : s;
}

function renderAdminUserList(rows) {
  var wrap = $("adminSearchResults");
  if (!rows.length) {
    wrap.innerHTML = '<p class="profile-empty-hint">No se encontraron cuentas.</p>';
    return;
  }
  wrap.innerHTML = rows.map(adminUserRowHtml).join("");
  qsa(".admin-result-row", wrap).forEach(function(row) {
    var uid = row.getAttribute("data-uid");
    var u = rows.filter(function(r) {
      return r.id === uid;
    })[0];
    if (u) wireAdminRow(row, u, wrap);
  });
}

function adminFetchUsers(q) {
  return supabase.rpc("rpc_admin_search_profiles", {
    q: q || null,
    target_id: null
  }).then(function(res) {
    if (!res.error) return {
      rows: res.data || []
    };
    console.error("[admin] rpc_admin_search_profiles falló, uso consulta directa:", res.error);
    return fetchProfilesFallback(q).then(function(r2) {
      if (r2.error) return {
        rows: [],
        error: r2.error
      };
      return {
        rows: r2.data || []
      };
    });
  });
}

function showAdminUsers(out) {
  if (out.error) {
    $("adminSearchResults").innerHTML = '<p class="profile-empty-hint">No se pudo cargar la lista: ' + escapeHtml(out.error.message || "error desconocido") + "</p>";
    return;
  }
  renderAdminUserList(out.rows);
}

var adminReqId = 0;

function loadAllAdminUsers() {
  var wrap = $("adminSearchResults");
  wrap.innerHTML = '<p class="profile-empty-hint">Cargando usuarios...</p>';
  var id = ++adminReqId;
  adminFetchUsers(null).then(function(out) {
    if (id === adminReqId) showAdminUsers(out);
  });
}

function adminSearch() {
  var q = $("adminSearchInput").value.trim();
  if (!q) {
    loadAllAdminUsers();
    return;
  }
  var wrap = $("adminSearchResults");
  wrap.innerHTML = '<p class="profile-empty-hint">Buscando...</p>';
  var id = ++adminReqId;
  adminFetchUsers(q).then(function(out) {
    if (id === adminReqId) showAdminUsers(out);
  });
}

$("adminSearchBtn").addEventListener("click", adminSearch);

$("adminSearchInput").addEventListener("keydown", function(e) {
  if (e.key === "Enter") adminSearch();
});

var adminSearchDebounce = null;

$("adminSearchInput").addEventListener("input", function() {
  if (adminSearchDebounce) clearTimeout(adminSearchDebounce);
  adminSearchDebounce = setTimeout(adminSearch, 300);
});

function openAdminDetail(uid) {
  $("adminSearchView").hidden = true;
  $("adminDetailView").hidden = false;
  $("adminChatMessages").hidden = true;
  $("adminChatMessages").innerHTML = "";
  $("adminUserHead").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  $("adminCircleInfo").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  $("adminChatsList").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  $("adminThreadsList").innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.rpc("rpc_admin_search_profiles", {
    q: null,
    target_id: uid
  }).then(function(res) {
    var row = res.data && res.data[0];
    if (res.error || !row) {
      $("adminUserHead").innerHTML = '<p class="profile-empty-hint">No se pudo cargar la cuenta.</p>';
      return;
    }
    var u = row;
    if (u && u.id) markBannedUser(u.id, u.banned === true);
    $("adminUserHead").innerHTML = avatarSpanHtml(u.username, u.avatar_url, "avatar-md", u.id) + '<div class="social-list-row-info"><div class="social-list-row-name">' + escapeHtml(u.username) + roleBadgeHtml(u.role, u.verified) + (u.is_volunteer ? ' <span class="admin-volunteer-tag">Volunteer</span>' : "") + "</div></div>";
    var banBtn = $("adminBanBtn");
    var isBanned = u.banned === true;
    banBtn.textContent = isBanned ? "Quitar baneo" : "Banear";
    banBtn.onclick = function() {
      var confirmMsg = isBanned ? "¿Quitar el baneo a @" + u.username + "?" : "¿Banear a @" + u.username + "? No podrá volver a iniciar sesión.";
      if (!confirm(confirmMsg)) return;
      banBtn.disabled = true;
      supabase.from("profiles").update({
        banned: !isBanned
      }).eq("id", uid).then(function(res2) {
        banBtn.disabled = false;
        if (res2.error) {
          toast("No se pudo actualizar: " + (res2.error && res2.error.message ? res2.error.message : "error desconocido"));
          console.error(res2.error);
          return;
        }
        toast(isBanned ? "Baneo retirado." : "Cuenta baneada.");
        openAdminDetail(uid);
      });
    };
    var ownerAdminBtn = $("adminOwnerAdminBtn");
    if (!currentUser.isOwner || u.id === currentUser.id) {
      ownerAdminBtn.hidden = true;
    } else {
      var isAdminAlready = u.role === "admin";
      ownerAdminBtn.hidden = false;
      ownerAdminBtn.textContent = isAdminAlready ? "Quitar admin" : "Hacer admin";
      ownerAdminBtn.onclick = function() {
        var confirmMsg = isAdminAlready ? "¿Quitarle el rol de admin a @" + u.username + "?" : "¿Hacer admin a @" + u.username + "? Podrá banear, verificar y moderar contenido de cualquier cuenta.";
        if (!confirm(confirmMsg)) return;
        var newRole = isAdminAlready ? "user" : "admin";
        ownerAdminBtn.disabled = true;
        supabase.from("profiles").update({
          role: newRole
        }).eq("id", uid).then(function(res2) {
          ownerAdminBtn.disabled = false;
          if (res2.error) {
            toast("No se pudo actualizar (revisa que tu cuenta tenga is_owner = true en la base de datos).");
            return;
          }
          toast(isAdminAlready ? "Ya no es admin." : "Ahora es admin.");
          openAdminDetail(uid);
        });
      };
    }
    var verifyBtn = $("adminVerifyBtn");
    var isVerified = u.verified === true;
    verifyBtn.hidden = false;
    verifyBtn.textContent = isVerified ? "Quitar verificado" : "Verificar cuenta";
    verifyBtn.onclick = function() {
      verifyBtn.disabled = true;
      supabase.from("profiles").update({
        verified: !isVerified
      }).eq("id", uid).then(function(res2) {
        verifyBtn.disabled = false;
        if (res2.error) {
          toast("No se pudo actualizar: " + (res2.error && res2.error.message ? res2.error.message : "error desconocido"));
          console.error(res2.error);
          return;
        }
        toast(isVerified ? "Verificado retirado." : "Cuenta verificada.");
        openAdminDetail(uid);
      });
    };
    var volunteerBtn = $("adminVolunteerBtn");
    if (volunteerBtn && u.id !== currentUser.id) {
      var isVolunteerAlready = u.is_volunteer === true;
      volunteerBtn.hidden = false;
      volunteerBtn.textContent = isVolunteerAlready ? "Quitar volunteer" : "Hacer volunteer";
      volunteerBtn.onclick = function() {
        var confirmMsg = isVolunteerAlready ? "¿Quitarle el rol de volunteer a @" + u.username + "?" : "¿Hacer volunteer a @" + u.username + "? Podrá verificar cuentas y enviar regalos masivos.";
        if (!confirm(confirmMsg)) return;
        volunteerBtn.disabled = true;
        supabase.from("profiles").update({
          is_volunteer: !isVolunteerAlready
        }).eq("id", uid).then(function(res2) {
          volunteerBtn.disabled = false;
          if (res2.error) {
            toast("No se pudo actualizar: " + (res2.error && res2.error.message ? res2.error.message : "error desconocido"));
            console.error(res2.error);
            return;
          }
          toast(isVolunteerAlready ? "Ya no es volunteer." : "Ahora es volunteer.");
          openAdminDetail(uid);
        });
      };
    } else if (volunteerBtn) {
      volunteerBtn.hidden = true;
    }
    var grantBtn = $("adminGrantBtn");
    grantBtn.onclick = function() {
      var stars = parseInt($("adminGrantStars").value, 10) || 0;
      var coin = parseInt($("adminGrantCoin").value, 10) || 0;
      if (stars <= 0 && coin <= 0) {
        toast("Pon un monto en Diamantes o Z-Coins.");
        return;
      }
      grantBtn.disabled = true;
      supabase.rpc("admin_grant_currency", {
        p_recipient: uid,
        p_stars: stars,
        p_coin: coin
      }).then(function(res2) {
        grantBtn.disabled = false;
        if (res2.error) {
          toast("No se pudo enviar (revisa que tu cuenta sea admin en la base de datos).");
          return;
        }
        toast("Enviado a @" + u.username + ": " + (stars > 0 ? stars + " Diamantes " : "") + (coin > 0 ? coin + " Z-Coins" : ""));
        $("adminGrantStars").value = "";
        $("adminGrantCoin").value = "";
      });
    };
    supabase.from("circle_members").select("circles(name,slug)").eq("user_id", uid).then(function(cRes) {
      var rows = (cRes.error ? [] : cRes.data || []).filter(function(r) {
        return r.circles;
      });
      $("adminCircleInfo").innerHTML = rows.length ? rows.map(function(r) {
        return "<p>" + escapeHtml(r.circles.name) + " — @" + escapeHtml(r.circles.slug) + "</p>";
      }).join("") : '<p class="profile-empty-hint">No pertenece a ningún círculo.</p>';
    });
  });
  supabase.from("dm_conversations").select("*").or("user_a.eq." + uid + ",user_b.eq." + uid).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    if (!rows.length) {
      $("adminChatsList").innerHTML = '<p class="profile-empty-hint">No tiene chats.</p>';
      return;
    }
    var otherIds = rows.map(function(c) {
      return c.user_a === uid ? c.user_b : c.user_a;
    });
    supabase.from("profiles").select("id,username").in("id", otherIds).then(function(pRes) {
      var names = {};
      (pRes.data || []).forEach(function(p) {
        names[p.id] = p.username;
      });
      $("adminChatsList").innerHTML = rows.map(function(c) {
        var otherId = c.user_a === uid ? c.user_b : c.user_a;
        return '<div class="social-list-row admin-chat-row" data-conv-id="' + escapeHtml(c.id) + '">' + '<div class="social-list-row-info"><div class="social-list-row-name">Con @' + escapeHtml(names[otherId] || "usuario") + "</div></div>" + "</div>";
      }).join("");
      qsa(".admin-chat-row", $("adminChatsList")).forEach(function(row) {
        row.addEventListener("click", function() {
          openAdminChat(row.getAttribute("data-conv-id"));
        });
      });
    });
  });
  supabase.from("threads").select("id,title,slug,created_at").eq("author_id", uid).order("created_at", {
    ascending: false
  }).limit(30).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    if (!rows.length) {
      $("adminThreadsList").innerHTML = '<p class="profile-empty-hint">No tiene publicaciones.</p>';
      return;
    }
    $("adminThreadsList").innerHTML = rows.map(function(t) {
      return '<div class="admin-thread-row" data-id="' + escapeHtml(t.id) + '">' + '<span class="admin-thread-title">' + escapeHtml(t.title) + "</span>" + '<button class="terminal-btn btn-danger admin-thread-del" type="button">Eliminar</button>' + "</div>";
    }).join("");
    qsa(".admin-thread-del", $("adminThreadsList")).forEach(function(btn, i) {
      btn.addEventListener("click", function() {
        if (!confirm("¿Eliminar esta publicación? No se puede deshacer.")) return;
        supabase.from("threads").delete().eq("id", rows[i].id).then(function(res2) {
          if (res2.error) {
            toast("No se pudo eliminar.");
            return;
          }
          toast("Publicación eliminada.");
          openAdminDetail(uid);
        });
      });
    });
  });
}

function openAdminChat(convId) {
  var wrap = $("adminChatMessages");
  wrap.hidden = false;
  wrap.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("dm_messages").select("*").eq("conversation_id", convId).order("created_at").limit(200).then(function(res) {
    var rows = res.error ? [] : res.data || [];
    if (!rows.length) {
      wrap.innerHTML = '<p class="profile-empty-hint">Sin mensajes.</p>';
      return;
    }
    wrap.innerHTML = rows.map(function(m) {
      return '<div class="admin-chat-msg"><span class="admin-chat-msg-time">' + timeAgo(m.created_at) + "</span> " + escapeHtml(m.body || "") + "</div>";
    }).join("");
  });
}