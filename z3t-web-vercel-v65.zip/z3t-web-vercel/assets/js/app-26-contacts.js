"use strict";

(function() {
  function normalizePhone(raw) {
    return (raw || "").replace(/[^\d]/g, "");
  }
  function sha256Hex(text) {
    var enc = (new TextEncoder).encode(text);
    return crypto.subtle.digest("SHA-256", enc).then(function(buf) {
      return Array.from(new Uint8Array(buf)).map(function(b) {
        return b.toString(16).padStart(2, "0");
      }).join("");
    });
  }
  function openContactsModal() {
    $("contactsModalBackdrop").classList.add("open");
    $("contactsResultsList").innerHTML = "";
  }
  var btnMenuEl = $("btnProfileMenuContacts");
  if (btnMenuEl) btnMenuEl.addEventListener("click", function() {
    if (typeof closeProfileMenu === "function") closeProfileMenu();
    openContactsModal();
  });
  var closeBtnEl = $("contactsModalClose");
  if (closeBtnEl) closeBtnEl.addEventListener("click", function() {
    $("contactsModalBackdrop").classList.remove("open");
  });
  var backdropEl = $("contactsModalBackdrop");
  if (backdropEl) backdropEl.addEventListener("click", function(e) {
    if (e.target === backdropEl) backdropEl.classList.remove("open");
  });
  $("btnSaveMyPhone").addEventListener("click", function() {
    var raw = $("contactsMyPhoneInput").value.trim();
    var normalized = normalizePhone(raw);
    if (normalized.length < 7) {
      toast(t("contacts.err_invalid_phone"));
      return;
    }
    var btn = $("btnSaveMyPhone");
    btn.disabled = true;
    sha256Hex(normalized).then(function(hash) {
      return supabase.rpc("set_my_phone_hash", {
        p_hash: hash
      });
    }).then(function(res) {
      btn.disabled = false;
      if (res.error) {
        toast(t("contacts.err_save_phone") + " " + res.error.message);
        return;
      }
      toast(t("contacts.toast_phone_saved"));
      $("contactsMyPhoneInput").value = "";
    })["catch"](function() {
      btn.disabled = false;
      toast(t("contacts.err_save_phone"));
    });
  });
  function renderContactResults(rows) {
    var wrap = $("contactsResultsList");
    if (!rows.length) {
      wrap.innerHTML = '<p class="profile-empty-hint">' + escapeHtml(t("contacts.no_matches")) + "</p>";
      return;
    }
    wrap.innerHTML = rows.map(function(r) {
      return '<div class="dm-card" data-uid="' + escapeHtml(r.user_id) + '">' + avatarSpanHtml(r.name || r.username, r.avatar_url, "", r.user_id) + '<div class="dm-card-main">' + '<div class="dm-card-name">' + escapeHtml(r.name || r.username) + "</div>" + '<div class="dm-card-preview">@' + escapeHtml(r.username) + (r.contact_name ? " · " + escapeHtml(t("contacts.saved_as")) + ' "' + escapeHtml(r.contact_name) + '"' : "") + "</div>" + "</div>" + "</div>";
    }).join("");
  }
  $("btnSyncContacts").addEventListener("click", function() {
    var btn = $("btnSyncContacts");
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform() && window.Capacitor.Plugins && window.Capacitor.Plugins.Contacts)) {
      toast(t("contacts.err_native_only"));
      return;
    }
    btn.disabled = true;
    btn.textContent = t("contacts.syncing");
    window.Capacitor.Plugins.Contacts.getContacts().then(function(res) {
      var contacts = res.contacts || [];
      var seen = {};
      var normalized = [];
      contacts.forEach(function(c) {
        var n = normalizePhone(c.number);
        if (n.length < 7 || seen[n]) return;
        seen[n] = true;
        normalized.push({
          name: c.name || "",
          number: n
        });
      });
      return Promise.all(normalized.map(function(c) {
        return sha256Hex(c.number).then(function(hash) {
          return {
            hash: hash,
            name: c.name
          };
        });
      }));
    }).then(function(hashed) {
      var hashes = hashed.map(function(h) {
        return h.hash;
      });
      var names = hashed.map(function(h) {
        return h.name;
      });
      return supabase.rpc("sync_my_contacts", {
        p_hashes: hashes,
        p_names: names
      });
    }).then(function(res) {
      if (res.error) {
        throw res.error;
      }
      return supabase.rpc("match_my_contacts");
    }).then(function(res) {
      btn.disabled = false;
      btn.textContent = t("contacts.btn_sync");
      if (res.error) {
        toast(t("contacts.err_sync") + " " + res.error.message);
        return;
      }
      renderContactResults(res.data || []);
    })["catch"](function(err) {
      btn.disabled = false;
      btn.textContent = t("contacts.btn_sync");
      toast(t("contacts.err_sync") + " " + (err && err.message ? err.message : ""));
    });
  });
})();