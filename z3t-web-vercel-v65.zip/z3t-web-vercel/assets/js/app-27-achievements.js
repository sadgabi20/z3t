"use strict";

var ACHV_CAT_LABELS = {
  bienvenida: "Bienvenida",
  contenido: "Contenido",
  social: "Social",
  comunidad: "Comunidad",
  dedicacion: "Dedicación",
  especial: "Especiales",
  general: "Otros"
};

var achvCurrentCat = "all";

var achvCatalogCache = null;

var achvSyncInFlight = false;

function achvTier(rewardCoins) {
  if (rewardCoins >= 90) return "mythic";
  if (rewardCoins >= 32) return "gold";
  if (rewardCoins >= 18) return "silver";
  return "bronze";
}

window.syncAchievements = function syncAchievements() {
  if (!currentUser || achvSyncInFlight) return Promise.resolve([]);
  achvSyncInFlight = true;
  return supabase.rpc("sync_achievements").then(function(res) {
    achvSyncInFlight = false;
    if (res.error || !res.data || !res.data.length) return [];
    var unlocked = res.data;
    unlocked.forEach(function(a, i) {
      setTimeout(function() {
        var coinTxt = a.reward_coins > 0 ? " · reclama +" + a.reward_coins + " 🪙 en Logros" : "";
        toast("🏆 Logro desbloqueado: " + (a.icon ? a.icon + " " : "") + a.name + coinTxt);
      }, i * 1600);
    });
    if (window.updateAchvMenuBadge) window.updateAchvMenuBadge();
    if ($("panel-achievements") && $("panel-achievements").classList.contains("active")) {
      renderAchievementsPanel();
    }
    return unlocked;
  }).catch(function() {
    achvSyncInFlight = false;
    return [];
  });
};

window.updateAchvMenuBadge = function updateAchvMenuBadge() {
  if (!currentUser) return;
  supabase.from("user_achievements").select("id,claimed").eq("user_id", currentUser.id).eq("claimed", false).then(function(res) {
    var badge = $("profileMenuAchvBadge");
    if (!badge) return;
    var n = !res.error && res.data ? res.data.length : 0;
    badge.textContent = String(n);
    badge.hidden = n === 0;
  }).catch(function() {});
};

function achvLoadCatalog() {
  if (achvCatalogCache) return Promise.resolve(achvCatalogCache);
  return supabase.from("achievements").select("id,key,code,name,icon,icon_url,description,category,reward_coins").then(function(res) {
    achvCatalogCache = !res.error && res.data ? res.data : [];
    return achvCatalogCache;
  });
}

function renderAchievementsPanel() {
  var grid = $("achvFullGrid");
  if (!currentUser) {
    grid.innerHTML = '<p class="profile-empty-hint">Inicia sesión para ver tus logros.</p>';
    return;
  }
  grid.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  Promise.all([ achvLoadCatalog(), supabase.from("user_achievements").select("id,achievement_id,earned_at,claimed,equipped").eq("user_id", currentUser.id) ]).then(function(results) {
    var catalog = results[0] || [];
    var mineRes = results[1];
    var mine = !mineRes.error && mineRes.data ? mineRes.data : [];
    var earnedMap = {};
    mine.forEach(function(r) {
      earnedMap[r.achievement_id] = r;
    });
    var total = catalog.length;
    var earnedCount = mine.length;
    var claimedCoins = 0;
    mine.forEach(function(r) {
      if (r.claimed) {
        var a = catalog.filter(function(c) {
          return c.id === r.achievement_id;
        })[0];
        if (a) claimedCoins += a.reward_coins || 0;
      }
    });
    var unclaimedCount = mine.filter(function(r) {
      return !r.claimed;
    }).length;
    $("achvHeroCount").textContent = earnedCount + "/" + total;
    $("achvHeroCoins").innerHTML = '<img class="coin-icon" src="assets/icons/coin-z.png" alt="Coin" loading="lazy" decoding="async">' + claimedCoins + " Coin ganados con logros";
    var pct = total ? earnedCount / total : 0;
    var circumference = 2 * Math.PI * 44;
    var ringFill = $("achvHeroRingFill");
    if (ringFill) {
      ringFill.style.strokeDasharray = circumference.toFixed(1);
      ringFill.style.strokeDashoffset = (circumference * (1 - pct)).toFixed(1);
    }
    var banner = $("achvUnclaimedBanner");
    if (unclaimedCount > 0) {
      banner.hidden = false;
      $("achvUnclaimedCount").textContent = String(unclaimedCount);
    } else {
      banner.hidden = true;
    }
    if (!total) {
      grid.innerHTML = '<p class="profile-empty-hint">Todavía no hay logros configurados en el sitio.</p>';
      return;
    }
    var visible = catalog.filter(function(a) {
      return achvCurrentCat === "all" || (a.category || "general") === achvCurrentCat;
    });
    visible.sort(function(a, b) {
      var ea = earnedMap[a.id], eb = earnedMap[b.id];
      var rank = function(e) {
        if (!e) return 2;
        return e.claimed ? 1 : 0;
      };
      var ra = rank(ea), rb = rank(eb);
      if (ra !== rb) return ra - rb;
      return (a.reward_coins || 0) - (b.reward_coins || 0);
    });
    grid.innerHTML = visible.map(function(a) {
      var mineRow = earnedMap[a.id];
      var tier = achvTier(a.reward_coins || 0);
      var state = mineRow ? mineRow.claimed ? "claimed" : "unclaimed" : "locked";
      var iconHtml = achievementIconHtml(a, state === "locked" ? "achv-full-icon-locked" : "");
      var actionHtml = "";
      if (state === "unclaimed") {
        actionHtml = '<button type="button" class="terminal-btn small achv-claim-btn" data-achv-id="' + escapeHtml(a.id) + '">Reclamar' + (a.reward_coins > 0 ? " +" + a.reward_coins + ' <img class="coin-icon" src="assets/icons/coin-z.png" alt="Coin" loading="lazy" decoding="async">' : "") + "</button>";
      } else if (state === "claimed") {
        var equipped = !!mineRow.equipped;
        actionHtml = '<button type="button" class="achv-equip-btn' + (equipped ? " equipped" : "") + '" data-row-id="' + escapeHtml(mineRow.id) + '">' + (equipped ? "★ Equipada" : "☆ Equipar en perfil") + "</button>" + '<div class="achv-full-date">Obtenido el ' + new Date(mineRow.earned_at).toLocaleDateString() + "</div>";
      } else {
        actionHtml = '<div class="achv-full-locked-tag">🔒 Bloqueado' + (a.reward_coins > 0 ? " · +" + a.reward_coins + ' <img class="coin-icon" src="assets/icons/coin-z.png" alt="Coin" loading="lazy" decoding="async">' : "") + "</div>";
      }
      return '<div class="achv-card-full tier-' + tier + " state-" + state + '">' + '<span class="achv-full-icon">' + iconHtml + "</span>" + '<div class="achv-full-name">' + escapeHtml(a.name) + "</div>" + (a.description ? '<div class="achv-full-desc">' + escapeHtml(a.description) + "</div>" : "") + '<div class="achv-full-action">' + actionHtml + "</div>" + "</div>";
    }).join("");
    qsa(".achv-claim-btn", grid).forEach(function(btn) {
      btn.addEventListener("click", function() {
        btn.disabled = true;
        btn.textContent = "Reclamando...";
        var achvId = btn.getAttribute("data-achv-id");
        supabase.rpc("claim_achievement", {
          p_achievement_id: achvId
        }).then(function(res) {
          if (res.error) {
            toast(res.error.message || "No se pudo reclamar el logro.");
            btn.disabled = false;
            return;
          }
          toast("🪙 ¡Logro reclamado!");
          if (typeof refreshWalletDisplay === "function") refreshWalletDisplay();
          if (window.updateAchvMenuBadge) window.updateAchvMenuBadge();
          if (typeof renderAchievementManageList === "function") renderAchievementManageList(currentUser.id);
          if (typeof renderProfileBadges === "function") renderProfileBadges(currentUser.id);
          renderAchievementsPanel();
        });
      });
    });
    qsa(".achv-equip-btn", grid).forEach(function(btn) {
      btn.addEventListener("click", function() {
        achvToggleEquip(btn.getAttribute("data-row-id"));
      });
    });
  });
}

function achvToggleEquip(rowId) {
  var uid = currentUser.id;
  supabase.from("user_achievements").select("*").eq("user_id", uid).eq("equipped", true).then(function(res) {
    if (res.error) {
      toast("No se pudo revisar tus medallas equipadas: " + res.error.message);
      return;
    }
    var equippedRows = res.data || [];
    var isThisEquipped = equippedRows.some(function(r) {
      return r.id === rowId;
    });
    if (isThisEquipped) {
      supabase.from("user_achievements").update({
        equipped: false,
        equip_slot: null
      }).eq("id", rowId).select().then(function(r) {
        if (r.error) {
          toast("No se pudo quitar la medalla: " + r.error.message);
          return;
        }
        achvAfterEquipChange(uid);
      });
      return;
    }
    if (equippedRows.length >= 3) {
      toast(t("profile.err_achievements_max"));
      return;
    }
    var usedSlots = equippedRows.map(function(r) {
      return r.equip_slot;
    });
    var slot = [ 1, 2, 3 ].filter(function(s) {
      return usedSlots.indexOf(s) === -1;
    })[0];
    supabase.from("user_achievements").update({
      equipped: true,
      equip_slot: slot
    }).eq("id", rowId).select().then(function(r) {
      if (r.error) {
        toast("No se pudo equipar la medalla: " + r.error.message);
        return;
      }
      achvAfterEquipChange(uid);
    });
  });
}

function achvAfterEquipChange(uid) {
  renderAchievementsPanel();
  if (typeof renderAchievementManageList === "function") renderAchievementManageList(uid);
  if (typeof renderProfileBadges === "function") renderProfileBadges(uid);
}

document.addEventListener("DOMContentLoaded", function() {
  var openBtn = $("btnProfileMenuAchievements");
  if (openBtn) openBtn.addEventListener("click", function() {
    $("profileMenu").classList.remove("open");
    $("profileMenuBackdrop").classList.remove("open");
    activatePanel("panel-achievements");
    achvCurrentCat = "all";
    qsa(".achv-tab", $("achvTabs")).forEach(function(tb) {
      tb.classList.toggle("active", tb.getAttribute("data-cat") === "all");
    });
    renderAchievementsPanel();
    window.syncAchievements();
  });
  var settingsBtn = $("btnSettingsOpenAchievements");
  if (settingsBtn) settingsBtn.addEventListener("click", function() {
    $("settingsBackdrop").classList.remove("open");
    activatePanel("panel-achievements");
    renderAchievementsPanel();
    window.syncAchievements();
  });
  var backBtn = $("btnAchvPanelBack");
  if (backBtn) backBtn.addEventListener("click", function() {
    goBack("panel-list");
  });
  var tabs = $("achvTabs");
  if (tabs) tabs.addEventListener("click", function(e) {
    var btn = e.target.closest(".achv-tab");
    if (!btn) return;
    achvCurrentCat = btn.getAttribute("data-cat");
    qsa(".achv-tab", tabs).forEach(function(tb) {
      tb.classList.toggle("active", tb === btn);
    });
    renderAchievementsPanel();
  });
});