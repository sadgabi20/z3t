var CI_VIEW_WINDOW_MS = 100000; // se considera "viendo ahora" si hubo latido en los últimos ~100 s
var ciPresenceMap = {};
var ciTouchTimer = null;
var ciLoadTimer = null;
var ciSheetMode = null; // "people" | "members" | "admins"

function ciRank(role) {
  return role === "admin" ? 0 : role === "co_admin" ? 1 : 2;
}

function ciName(m) {
  var p = m.profiles || {};
  return p.name || p.username || "usuario";
}

function ciLastSeenMs(m) {
  var row = ciPresenceMap[m.user_id];
  return row ? new Date(row).getTime() : 0;
}

function ciIsViewing(m) {
  if (currentUser && m.user_id === currentUser.id) return !!currentCommunity;
  var t = ciLastSeenMs(m);
  return !!t && Date.now() - t < CI_VIEW_WINDOW_MS;
}

function ciSorted(list) {
  return list.slice().sort(function(a, b) {
    var r = ciRank(a.role) - ciRank(b.role);
    if (r) return r;
    var v = (ciIsViewing(b) ? 1 : 0) - (ciIsViewing(a) ? 1 : 0);
    if (v) return v;
    return ciLastSeenMs(b) - ciLastSeenMs(a);
  });
}

function ciPill(role) {
  if (role === "admin") return '<span class="ci-pill ci-pill--admin">Admin</span>';
  if (role === "co_admin") return '<span class="ci-pill ci-pill--co">Co-Admin</span>';
  return "";
}

function ciStatusHtml(m) {
  if (ciIsViewing(m)) return '<div class="ci-row-status on">Viendo ahora</div>';
  var t = ciLastSeenMs(m);
  if (t) return '<div class="ci-row-status">Visto ' + timeAgo(new Date(t).toISOString()) + "</div>";
  return "";
}

function ciRowHtml(m, withActions) {
  var p = m.profiles || {};
  var color = p.name_color ? ' style="color:' + escapeHtml(p.name_color) + '"' : "";
  var actions = "";
  if (withActions && currentUser) {
    var myRole = myCommunityRole();
    var isAdmin = myRole === "admin";
    var isStaff = isAdmin || myRole === "co_admin";
    if (isAdmin && m.role !== "admin") {
      actions += m.role === "co_admin" ? '<button class="ci-act" data-action="demote" data-member="' + escapeHtml(m.id) + '" type="button">Quitar co-admin</button>' : '<button class="ci-act" data-action="promote" data-member="' + escapeHtml(m.id) + '" type="button">Hacer co-admin</button>';
    }
    if (isStaff && m.role === "member" && m.user_id !== currentUser.id) {
      actions += '<button class="ci-act ci-act--danger" data-action="kick" data-member="' + escapeHtml(m.id) + '" type="button">Expulsar</button>';
    }
  }
  return '<div class="ci-row" data-uid="' + escapeHtml(m.user_id) + '">' + avatarSpanHtml(ciName(m), p.avatar_url, "ci-av", m.user_id) + '<div class="ci-row-main">' + '<div class="ci-row-name"><span' + color + ">" + escapeHtml(ciName(m)) + "</span>" + ciPill(m.role) + "</div>" + (p.username ? '<div class="ci-row-sub">@' + escapeHtml(p.username) + "</div>" : "") + ciStatusHtml(m) + "</div>" + (actions ? '<div class="ci-actions">' + actions + "</div>" : "") + "</div>";
}

function zSheetEl() {
  return $("zSheet");
}

function zSheetOpen(title, bodyHtml, mode) {
  var sheet = zSheetEl();
  if (!sheet) return;
  ciSheetMode = mode || null;
  $("zSheetTitle").textContent = title;
  var body = $("zSheetBody");
  var keep = !sheet.hidden ? body.scrollTop : 0;
  body.innerHTML = bodyHtml;
  body.scrollTop = keep;
  if (sheet.hidden) {
    sheet.querySelector(".bio-sheet-panel").style.transform = "";
    sheet.hidden = false;
    requestAnimationFrame(function() {
      sheet.classList.add("open");
    });
    document.body.classList.add("bio-sheet-lock");
  }
}

function zSheetClose() {
  var sheet = zSheetEl();
  if (!sheet || sheet.hidden) return;
  ciSheetMode = null;
  sheet.classList.remove("open");
  document.body.classList.remove("bio-sheet-lock");
  setTimeout(function() {
    if (!sheet.classList.contains("open")) {
      sheet.hidden = true;
      sheet.querySelector(".bio-sheet-panel").style.transform = "";
    }
  }, 260);
}

function ciGoProfile(uid) {
  zSheetClose();
  ciInfoClose();
  openProfile(uid);
}

function ciBindList(root) {
  root.querySelectorAll(".ci-row").forEach(function(row) {
    row.addEventListener("click", function(e) {
      if (e.target.closest("button") || e.target.closest(".avatar-link")) return;
      ciGoProfile(row.getAttribute("data-uid"));
    });
  });
  root.querySelectorAll(".ci-act").forEach(function(btn) {
    btn.addEventListener("click", function(e) {
      e.stopPropagation();
      var action = btn.getAttribute("data-action");
      var memberId = btn.getAttribute("data-member");
      if (action === "promote") updateMemberRole(memberId, "co_admin");
      else if (action === "demote") updateMemberRole(memberId, "member");
      else if (action === "kick") kickMember(memberId);
    });
  });
}

function ciPeopleBody() {
  var all = ciSorted(communityMembers);
  var viewing = all.filter(ciIsViewing);
  var rest = all.filter(function(m) {
    return !ciIsViewing(m);
  });
  var html = "";
  html += '<div class="ci-section-title">Viendo ahora (' + viewing.length + ")</div>";
  html += viewing.length ? viewing.map(function(m) {
    return ciRowHtml(m, false);
  }).join("") : '<p class="profile-empty-hint">Nadie más está viendo la comunidad en este momento.</p>';
  html += '<div class="ci-section-title">Demás miembros (' + rest.length + ")</div>";
  html += rest.length ? rest.map(function(m) {
    return ciRowHtml(m, false);
  }).join("") : '<p class="profile-empty-hint">Todos los miembros están viendo la comunidad.</p>';
  return html;
}

function openCommunityPeopleSheet() {
  if (!currentCommunity) return;
  zSheetOpen("Miembros de la comunidad", ciPeopleBody(), "people");
  ciBindList($("zSheetBody"));
}

function ciListBody(list) {
  return list.length ? list.map(function(m) {
    return ciRowHtml(m, true);
  }).join("") : '<p class="profile-empty-hint">Todavía no hay nadie aquí.</p>';
}

function openCommunityMembersSheet() {
  if (!currentCommunity) return;
  var list = ciSorted(communityMembers);
  zSheetOpen("Miembros (" + list.length + ")", ciListBody(list), "members");
  ciBindList($("zSheetBody"));
}

function openCommunityAdminsSheet() {
  if (!currentCommunity) return;
  var list = ciSorted(communityMembers.filter(function(m) {
    return m.role === "admin" || m.role === "co_admin";
  }));
  zSheetOpen("Equipo de Admins (" + list.length + ")", ciListBody(list), "admins");
  ciBindList($("zSheetBody"));
}

function renderCommunityPresenceRow() {
  var host = $("communityPresenceRow");
  if (!host || !currentCommunity) return;
  var all = ciSorted(communityMembers);
  var viewing = all.filter(ciIsViewing);
  var shown = (viewing.length ? viewing : all).slice(0, 60);
  var avatars = shown.map(function(m) {
    var p = m.profiles || {};
    return avatarSpanHtml(ciName(m), p.avatar_url, "cpr-av", null);
  }).join("");
  host.innerHTML = '<div class="cpr-inner" id="communityPresenceBtn" role="button" tabindex="0" aria-label="Ver miembros de la comunidad">' + '<span class="cpr-cluster">' + avatars + "</span>" + "</div>";
  var btn = $("communityPresenceBtn");
  btn.addEventListener("click", openCommunityPeopleSheet);
  btn.addEventListener("keydown", function(e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      openCommunityPeopleSheet();
    }
  });
}

function ciTouch() {
  if (!currentCommunity || document.hidden) return;
  supabase.rpc("touch_community_presence", {
    p_community_id: currentCommunity.id
  }).then(function() {}, function() {});
}

function ciLoadPresence() {
  if (!currentCommunity) return;
  var cid = currentCommunity.id;
  supabase.rpc("get_community_presence", {
    p_community_id: cid
  }).then(function(res) {
    if (!currentCommunity || currentCommunity.id !== cid) return;
    var map = {};
    (res.error ? [] : res.data || []).forEach(function(r) {
      map[r.user_id] = r.last_seen_at;
    });
    ciPresenceMap = map;
    renderCommunityPresenceRow();
    var sheet = zSheetEl();
    if (sheet && !sheet.hidden && ciSheetMode === "people") {
      $("zSheetBody").innerHTML = ciPeopleBody();
      ciBindList($("zSheetBody"));
    }
  }, function() {});
}

function communityPresenceStart() {
  renderCommunityPresenceRow();
  ciTouch();
  ciLoadPresence();
  if (!ciTouchTimer) ciTouchTimer = setInterval(ciTouch, 45000);
  if (!ciLoadTimer) ciLoadTimer = setInterval(ciLoadPresence, 20000);
  communityInfoRefresh();
}

function communityPresenceStop() {
  if (ciTouchTimer) clearInterval(ciTouchTimer);
  if (ciLoadTimer) clearInterval(ciLoadTimer);
  ciTouchTimer = null;
  ciLoadTimer = null;
  ciPresenceMap = {};
  zSheetClose();
  ciInfoClose();
}

function ciInfoEl() {
  var el = $("communityInfo");
  if (el) return el;
  el = document.createElement("div");
  el.id = "communityInfo";
  el.className = "community-info";
  el.hidden = true;
  document.body.appendChild(el);
  return el;
}

function ciAvatarRow(list, max) {
  return '<div class="ci-avrow">' + list.slice(0, max).map(function(m) {
    var p = m.profiles || {};
    return '<div class="ci-avitem">' + avatarSpanHtml(ciName(m), p.avatar_url, "ci-avrow-av", null) + '<span class="ci-avname">' + escapeHtml(ciName(m)) + "</span></div>";
  }).join("") + "</div>";
}

function ciSectionHtml(id, title, count, list, max) {
  return '<button class="ci-section" id="' + id + '" type="button">' + '<span class="ci-sec-head"><span class="about-row-bar"></span><span class="ci-sec-title">' + title + " (" + count + ")</span>" + '<svg class="about-row-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg></span>' + (list.length ? ciAvatarRow(list, max) : '<span class="profile-empty-hint">Todavía no hay nadie aquí.</span>') + "</button>";
}

function ciInfoRender() {
  var el = ciInfoEl();
  var c = currentCommunity;
  if (!c) return;
  var role = myCommunityRole();
  var isStaff = role === "admin" || role === "co_admin";
  var all = ciSorted(communityMembers);
  var staff = all.filter(function(m) {
    return m.role === "admin" || m.role === "co_admin";
  });
  var creatorId = c.created_by || c.creator_id;
  var creator = communityMembers.filter(function(m) {
    return m.user_id === creatorId;
  })[0] || communityMembers.filter(function(m) {
    return m.role === "admin";
  })[0];
  var bannerStyle = c.banner_url ? ' style="background-image:url(&quot;' + encodeURI(c.banner_url).replace(/"/g, "%22").replace(/'/g, "%27") + '&quot;)"' : "";
  var by = creator ? '<span>Creada por <b>' + escapeHtml(ciName(creator)) + "</b></span>" : "";
  el.innerHTML = '<div class="ci-top">' + '<button class="icon-btn" id="ciBack" type="button" aria-label="Volver"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg></button>' + "<h3>Configuración</h3></div>" + '<div class="ci-scroll"><div class="ci-wrap">' + '<div class="ci-banner"' + bannerStyle + "></div>" + '<h2 class="ci-name">' + escapeHtml(c.name) + "</h2>" + '<div class="ci-meta">' + by + "<span>" + c.member_count + " miembros</span>" + (c.tag ? '<span class="ci-tag">' + escapeHtml(c.tag) + "</span>" : "") + "</div>" + '<div class="ci-flags" id="ciFlags"></div>' + (c.description && c.description.trim() ? '<div class="ci-desc"><h4>Acerca de</h4><p>' + escapeHtml(c.description).replace(/\r?\n/g, "<br>") + "</p></div>" : "") + ciSectionHtml("ciAdmins", "Equipo de Admins", staff.length, staff, 5) + ciSectionHtml("ciMembers", "Miembros", all.length, all, 6) + (isStaff ? '<button class="terminal-btn full-width ci-portal" id="ciPortal" type="button">Abrir Portal del Admin</button>' : "") + "</div></div>";
  if (c.background_url) {
    el.style.backgroundImage = 'linear-gradient(rgba(7,6,10,.78), rgba(7,6,10,.9)), url("' + encodeURI(c.background_url).replace(/"/g, "%22").replace(/'/g, "%27") + '")';
    el.style.backgroundSize = "cover";
    el.style.backgroundPosition = "center";
  } else {
    el.style.backgroundImage = "";
  }
  $("ciBack").addEventListener("click", ciInfoClose);
  $("ciAdmins").addEventListener("click", openCommunityAdminsSheet);
  $("ciMembers").addEventListener("click", openCommunityMembersSheet);
  var portal = $("ciPortal");
  if (portal) portal.addEventListener("click", function() {
    ciInfoClose();
    if (typeof openCommunityAdminPortal === "function") openCommunityAdminPortal();
  });
  ciLoadFlags(c.id);
}

function ciLoadFlags(cid) {
  supabase.from("flag_links").select("id, flags(id, display_text, color)").eq("entity_type", "community").eq("entity_id", cid).then(function(res) {
    var host = $("ciFlags");
    if (!host || !currentCommunity || currentCommunity.id !== cid) return;
    var rows = (res.error ? [] : res.data || []).filter(function(r) {
      return r.flags;
    });
    if (!rows.length) {
      var role = myCommunityRole();
      host.innerHTML = role === "admin" || role === "co_admin" ? '<span class="profile-empty-hint">Esta comunidad aún no tiene banderas. Añádelas desde el Portal del Admin.</span>' : "";
      return;
    }
    host.innerHTML = rows.map(function(r) {
      return flagPennantHtml(r.flags.display_text, r.flags.color);
    }).join("");
  });
}

function openCommunityInfo() {
  if (!currentCommunity) return;
  var el = ciInfoEl();
  ciInfoRender();
  el.hidden = false;
  el.scrollTop = 0;
}

function ciInfoClose() {
  var el = $("communityInfo");
  if (el) el.hidden = true;
}

function communityInfoRefresh() {
  var el = $("communityInfo");
  if (el && !el.hidden && currentCommunity) ciInfoRender();
}

function openCommunityMembersView(forceOpen) {
  if (forceOpen === false) {
    zSheetClose();
    return;
  }
  if (ciSheetMode === "admins" && zSheetEl() && !zSheetEl().hidden) {
    openCommunityAdminsSheet();
    return;
  }
  openCommunityMembersSheet();
}

(function ciInit() {
  var sheet = zSheetEl();
  if (!sheet) return;
  sheet.querySelector(".bio-sheet-backdrop").addEventListener("click", zSheetClose);
  $("zSheetClose").addEventListener("click", zSheetClose);
  document.addEventListener("keydown", function(e) {
    if (e.key !== "Escape") return;
    if (!sheet.hidden) zSheetClose();
    else ciInfoClose();
  });
  sheet.addEventListener("click", function(e) {
    if (e.target.closest && e.target.closest(".avatar-link")) {
      zSheetClose();
      ciInfoClose();
    }
  }, true);
  var panel = sheet.querySelector(".bio-sheet-panel");
  var head = sheet.querySelector(".bio-sheet-head");
  var startY = null, dy = 0;
  head.addEventListener("touchstart", function(e) {
    startY = e.touches[0].clientY;
    dy = 0;
    panel.style.transition = "none";
  }, { passive: true });
  head.addEventListener("touchmove", function(e) {
    if (startY === null) return;
    dy = Math.max(0, e.touches[0].clientY - startY);
    panel.style.transform = "translateY(" + dy + "px)";
  }, { passive: true });
  head.addEventListener("touchend", function() {
    panel.style.transition = "";
    if (dy > 90) zSheetClose();
    else panel.style.transform = "";
    startY = null;
  });
})();
