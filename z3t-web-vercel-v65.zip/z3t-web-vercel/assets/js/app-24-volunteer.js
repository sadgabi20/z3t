"use strict";

function canActAsVolunteer() {
  return !!currentUser && (currentUser.isVolunteer === true || currentUser.role === "admin");
}

function openVolunteerPanel() {
  if (!canActAsVolunteer()) return;
  $("volunteerSearchInput").value = "";
  $("volunteerBackdrop").classList.add("open");
  loadAllVolunteerUsers();
}

var btnOpenMassGiftSendEl = $("btnOpenMassGiftSend");

if (btnOpenMassGiftSendEl) btnOpenMassGiftSendEl.addEventListener("click", function() {
  $("volunteerBackdrop").classList.remove("open");
  openMassGiftSend();
});

$("volunteerClose").addEventListener("click", function() {
  $("volunteerBackdrop").classList.remove("open");
});

$("volunteerBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

function volunteerUserRowHtml(u) {
  return '<div class="social-list-row admin-result-row" data-uid="' + escapeHtml(u.id) + '">' + avatarSpanHtml(u.username, u.avatar_url, "avatar-md", u.id) + '<div class="social-list-row-info">' + '<div class="social-list-row-name">' + escapeHtml(u.username) + roleBadgeHtml(u.role, u.verified) + "</div>" + '<div class="admin-row-actions">' + '<button type="button" class="terminal-btn small admin-row-act" data-act="verify">' + (u.verified ? "Quitar verificado" : "Verificar") + "</button>" + '<button type="button" class="terminal-btn small admin-row-act" data-act="coins">🪙 Dar monedas</button>' + "</div>" + "</div>" + "</div>";
}

/* Ventana para darle Diamantes / Z-Coins a una persona */
function openVolunteerGiveCoins(u) {
  if (!canActAsVolunteer()) return;
  var old = document.getElementById("volunteerCoinsBackdrop");
  if (old) old.remove();
  var bd = document.createElement("div");
  bd.className = "modal-backdrop";
  bd.id = "volunteerCoinsBackdrop";
  bd.innerHTML = '<div class="modal" role="dialog" aria-modal="true">' + '<div class="modal-head"><h3>🎁 Dar monedas a @' + escapeHtml(u.username) + "</h3>" + '<button class="icon-btn" type="button" id="volCoinsClose" aria-label="Cerrar">\u2715</button></div>' + '<label class="field"><span>' + coinIconHtml("stars") + ' Diamantes</span><input type="number" inputmode="numeric" id="volCoinsStars" min="0" max="1000000" step="1" placeholder="0"></label>' + '<label class="field"><span>' + coinIconHtml("coin") + ' Z-Coins</span><input type="number" inputmode="numeric" id="volCoinsCoin" min="0" max="1000000" step="1" placeholder="0"></label>' + '<p class="field-error" id="volCoinsErr" hidden></p>' + '<button type="button" class="terminal-btn full-width" id="volCoinsSend">Enviar regalo</button></div>';
  document.body.appendChild(bd);
  requestAnimationFrame(function() {
    bd.classList.add("open");
  });
  function close() {
    bd.classList.remove("open");
    setTimeout(function() {
      bd.remove();
    }, 200);
  }
  bd.addEventListener("click", function(e) {
    if (e.target === bd) close();
  });
  document.getElementById("volCoinsClose").addEventListener("click", close);
  var send = document.getElementById("volCoinsSend");
  send.addEventListener("click", function() {
    var stars = parseInt(document.getElementById("volCoinsStars").value, 10) || 0;
    var coin = parseInt(document.getElementById("volCoinsCoin").value, 10) || 0;
    var err = document.getElementById("volCoinsErr");
    err.hidden = true;
    if (stars < 0 || coin < 0 || stars <= 0 && coin <= 0) {
      err.textContent = "Pon una cantidad en Diamantes o Z-Coins.";
      err.hidden = false;
      return;
    }
    if (stars > 1e6 || coin > 1e6) {
      err.textContent = "El máximo por envío es 1,000,000.";
      err.hidden = false;
      return;
    }
    send.disabled = true;
    supabase.rpc("volunteer_grant_currency", {
      p_recipient: u.id,
      p_stars: stars,
      p_coin: coin
    }).then(function(res) {
      send.disabled = false;
      if (res.error) {
        err.textContent = "No se pudo enviar: " + (res.error.message || "error desconocido");
        err.hidden = false;
        return;
      }
      toast("🎁 Enviado a @" + u.username + ": " + (stars > 0 ? stars + " Diamantes " : "") + (coin > 0 ? coin + " Z-Coins" : ""));
      close();
    });
  });
}

function wireVolunteerRow(row, u) {
  var coinsBtn = row.querySelector('[data-act="coins"]');
  if (coinsBtn) coinsBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    openVolunteerGiveCoins(u);
  });
  var verifyBtn = row.querySelector('[data-act="verify"]');
  verifyBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    verifyBtn.disabled = true;
    supabase.rpc("volunteer_verify_user", {
      p_user_id: u.id,
      p_verified: !u.verified
    }).then(function(res) {
      verifyBtn.disabled = false;
      if (res.error) {
        toast("No se pudo actualizar: " + res.error.message);
        return;
      }
      u.verified = !u.verified;
      var fresh = volunteerUserRowHtml(u);
      row.outerHTML = fresh;
      var wrap = $("volunteerSearchResults");
      wireVolunteerRow(wrap.querySelector('.admin-result-row[data-uid="' + CSSEscape(u.id) + '"]'), u);
      toast(u.verified ? "Cuenta verificada." : "Verificado retirado.");
    });
  });
}

function renderVolunteerUserList(rows) {
  var wrap = $("volunteerSearchResults");
  if (!rows.length) {
    wrap.innerHTML = '<p class="profile-empty-hint">No se encontraron cuentas.</p>';
    return;
  }
  wrap.innerHTML = rows.map(volunteerUserRowHtml).join("");
  qsa(".admin-result-row", wrap).forEach(function(row) {
    var uid = row.getAttribute("data-uid");
    var u = rows.filter(function(r) {
      return r.id === uid;
    })[0];
    if (u) wireVolunteerRow(row, u);
  });
}

function fetchProfilesFallback(q) {
  var query = supabase.from("profiles").select("id, username, avatar_url, role, verified, banned, is_volunteer").order("joined_at", {
    ascending: false
  }).limit(300);
  if (q) query = query.ilike("username", "%" + q.replace(/[%,]/g, "") + "%");
  return query;
}

function volunteerFetchUsers(q) {
  return supabase.rpc("rpc_volunteer_search_profiles", {
    q: q || null
  }).then(function(res) {
    if (!res.error) return {
      rows: res.data || []
    };
    console.error("[volunteer] rpc_volunteer_search_profiles falló, uso consulta directa:", res.error);
    return fetchProfilesFallback(q).then(function(r2) {
      if (r2.error) return {
        rows: [],
        error: r2.error
      };
      return {
        rows: r2.data || []
      };
    });
  });
}

function showVolunteerUsers(out) {
  if (out.error) {
    $("volunteerSearchResults").innerHTML = '<p class="profile-empty-hint">No se pudo cargar la lista: ' + escapeHtml(out.error.message || "error desconocido") + "</p>";
    return;
  }
  renderVolunteerUserList(out.rows);
}

var volunteerReqId = 0;

function loadAllVolunteerUsers() {
  var wrap = $("volunteerSearchResults");
  wrap.innerHTML = '<p class="profile-empty-hint">Cargando usuarios...</p>';
  var id = ++volunteerReqId;
  volunteerFetchUsers(null).then(function(out) {
    if (id === volunteerReqId) showVolunteerUsers(out);
  });
}

function volunteerSearch() {
  var q = $("volunteerSearchInput").value.trim();
  if (!q) {
    loadAllVolunteerUsers();
    return;
  }
  var wrap = $("volunteerSearchResults");
  wrap.innerHTML = '<p class="profile-empty-hint">Buscando...</p>';
  var id = ++volunteerReqId;
  volunteerFetchUsers(q).then(function(out) {
    if (id === volunteerReqId) showVolunteerUsers(out);
  });
}

$("volunteerSearchBtn").addEventListener("click", volunteerSearch);

$("volunteerSearchInput").addEventListener("keydown", function(e) {
  if (e.key === "Enter") volunteerSearch();
});

var volunteerSearchDebounce = null;

$("volunteerSearchInput").addEventListener("input", function() {
  if (volunteerSearchDebounce) clearTimeout(volunteerSearchDebounce);
  volunteerSearchDebounce = setTimeout(volunteerSearch, 300);
});

var massGiftDraft = null;

var MASS_GIFT_MAX_TOTAL = 2147483647;

var MASS_GIFT_MAX_USERS = 100000;

function openMassGiftSend() {
  if (!canActAsVolunteer()) return;
  massGiftDraft = null;
  $("massGiftSendBackdrop").classList.add("open");
  renderMassGiftTypeStep();
}

$("massGiftSendClose").addEventListener("click", function() {
  $("massGiftSendBackdrop").classList.remove("open");
});

$("massGiftSendBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

function renderMassGiftTypeStep() {
  var body = $("massGiftSendBody");
  body.innerHTML = "<h4>🎁 ¿Qué quieres regalar?</h4>" + '<div class="gift-type-grid">' + '<button type="button" class="gift-type-btn" data-type="stars">' + coinIconHtml("stars") + "<span>Diamantes</span></button>" + '<button type="button" class="gift-type-btn" data-type="coin">' + coinIconHtml("coin") + "<span>Z-Coins</span></button>" + '<button type="button" class="gift-type-btn" data-type="frame">🖼️<span>Marco</span></button>' + '<button type="button" class="gift-type-btn" data-type="bubble">💬<span>Burbuja</span></button>' + "</div>";
  qsa(".gift-type-btn", body).forEach(function(btn) {
    btn.addEventListener("click", function() {
      var type = btn.getAttribute("data-type");
      massGiftDraft = {
        giftType: type,
        amount: null,
        frameId: null,
        bubbleId: null
      };
      if (type === "stars" || type === "coin") renderMassGiftAmountStep(); else renderMassGiftItemStep(type);
    });
  });
}

function renderMassGiftAmountStep() {
  var body = $("massGiftSendBody");
  var label = massGiftDraft.giftType === "coin" ? coinIconHtml("coin") + " Z-Coins" : coinIconHtml("stars") + " Diamantes";
  body.innerHTML = '<button type="button" class="link-btn" id="massGiftBack">← Elegir otro tipo</button>' + "<h4>" + label + " — ¿cuánto le toca a cada quien?</h4>" + '<label class="field"><span>Cantidad por persona</span><input type="number" inputmode="numeric" id="massGiftAmount" min="1" max="2147483647" step="1" placeholder="100"></label>' + '<button type="button" class="terminal-btn full-width" id="massGiftAmountNext">Siguiente</button>';
  $("massGiftBack").addEventListener("click", renderMassGiftTypeStep);
  $("massGiftAmountNext").addEventListener("click", function() {
    var amount = parseInt($("massGiftAmount").value, 10);
    if (!amount || amount <= 0) {
      toast("Pon una cantidad válida.");
      return;
    }
    if (amount > MASS_GIFT_MAX_TOTAL) {
      toast("Esa cantidad es demasiado grande. El máximo por persona es " + MASS_GIFT_MAX_TOTAL.toLocaleString() + ".");
      return;
    }
    massGiftDraft.amount = amount;
    renderMassGiftCountStep();
  });
}

function renderMassGiftItemStep(type) {
  var body = $("massGiftSendBody");
  body.innerHTML = '<p class="profile-empty-hint">Cargando lo que tienes en tu monedero...</p>';
  var stockQuery = type === "frame" ? supabase.from("frames").select("id, name, thumbnail_url, creator_stock").eq("creator_id", currentUser.id).gt("creator_stock", 0) : supabase.from("chat_bubbles").select("id, name, thumbnail_url, creator_stock").eq("creator_id", currentUser.id).gt("creator_stock", 0);
  stockQuery.then(function(res) {
    var rows = res.error ? [] : res.data || [];
    var backHtml = '<button type="button" class="link-btn" id="massGiftBack">← Elegir otro tipo</button>';
    if (!rows.length) {
      body.innerHTML = backHtml + '<p class="profile-empty-hint">No te queda stock de ' + (type === "frame" ? "marcos" : "burbujas") + " sin vender en tu monedero. Créalos primero en la tienda.</p>";
      $("massGiftBack").addEventListener("click", renderMassGiftTypeStep);
      return;
    }
    body.innerHTML = backHtml + '<h4>Elige qué regalar</h4><div class="gift-item-grid">' + rows.map(function(r) {
      return '<button type="button" class="gift-item-card" data-id="' + escapeHtml(r.id) + '">' + '<span class="gift-item-thumb" style="background-image:url(&quot;' + escapeHtml(r.thumbnail_url || "") + '&quot;)"></span>' + '<span class="gift-item-name">' + escapeHtml(r.name) + " — " + r.creator_stock + " sin vender</span>" + "</button>";
    }).join("") + "</div>";
    $("massGiftBack").addEventListener("click", renderMassGiftTypeStep);
    qsa(".gift-item-card", body).forEach(function(card) {
      card.addEventListener("click", function() {
        var id = card.getAttribute("data-id");
        if (type === "frame") massGiftDraft.frameId = id; else massGiftDraft.bubbleId = id;
        renderMassGiftCountStep();
      });
    });
  });
}

function renderMassGiftCountStep() {
  var body = $("massGiftSendBody");
  body.innerHTML = "<h4>¿A cuántos usuarios se lo das?</h4>" + '<p class="profile-empty-hint">Cada usuario recibe la cantidad completa que elegiste (no se divide). Se lo llevan los primeros que lo reclamen y nadie puede reclamarlo dos veces.</p>' + '<label class="field"><span>Cantidad de usuarios</span><input type="number" inputmode="numeric" id="massGiftCount" min="1" max="100000" step="1" placeholder="10"></label>' + '<button type="button" class="terminal-btn full-width" id="massGiftSendConfirm">Enviar regalo masivo</button>';
  $("massGiftSendConfirm").addEventListener("click", function() {
    var count = parseInt($("massGiftCount").value, 10);
    if (!count || count <= 0) {
      toast("Pon una cantidad válida de usuarios.");
      return;
    }
    if (count > MASS_GIFT_MAX_USERS) {
      toast("El máximo es " + MASS_GIFT_MAX_USERS.toLocaleString() + " usuarios por regalo.");
      return;
    }
    var btn = $("massGiftSendConfirm");
    btn.disabled = true;
    supabase.rpc("send_mass_gift", {
      p_gift_type: massGiftDraft.giftType,
      p_amount: massGiftDraft.amount,
      p_frame_id: massGiftDraft.frameId,
      p_bubble_id: massGiftDraft.bubbleId,
      p_recipient_count: count
    }).then(function(res) {
      btn.disabled = false;
      if (res.error) {
        var m = res.error.message || "";
        toast("No se pudo enviar: " + (/out of range|overflow/i.test(m) ? "el servidor sigue multiplicando cantidad × usuarios; hay que actualizar send_mass_gift en Supabase." : m));
        return;
      }
      toast("🎁 Regalo masivo enviado — disponible para " + count + " usuarios.");
      $("massGiftSendBackdrop").classList.remove("open");
    });
  });
}

var massGiftPollTimer = null;

var massGiftQueue = [];

function checkOpenMassGifts() {
  if (!currentUser) return;
  supabase.rpc("get_open_mass_gifts").then(function(res) {
    if (res.error) return;
    massGiftQueue = res.data || [];
    var banner = $("massGiftBanner");
    if (!banner) return;
    banner.hidden = massGiftQueue.length === 0;
  });
}

function startMassGiftPolling() {
  checkOpenMassGifts();
  if (massGiftPollTimer) clearInterval(massGiftPollTimer);
  massGiftPollTimer = setInterval(function() {
    if (!document.hidden) checkOpenMassGifts();
  }, 12e4);
}

var massGiftBannerEl = $("massGiftBanner");

if (massGiftBannerEl) massGiftBannerEl.addEventListener("click", function() {
  if (!massGiftQueue.length) return;
  openMassGiftClaim(massGiftQueue[0]);
});

function openMassGiftClaim(mg) {
  var boxImg = $("giftOpenBoxImg");
  if (boxImg) boxImg.src = "assets/gifts/gift-closed.webp";
  $("giftOpenBox").classList.remove("gift-shaking");
  $("giftOpenBox").style.transform = "";
  $("giftOpenReveal").hidden = true;
  $("giftOpenBox").hidden = false;
  $("giftOpenHint").hidden = false;
  $("giftOpenConfetti").innerHTML = "";
  $("giftOpenFrom").textContent = (mg.sender_name || mg.sender_username || "Un volunteer") + " regaló esto para " + mg.recipient_count + " personas (" + (mg.recipient_count - mg.claimed_count) + " cupos libres):";
  $("giftOpenBackdrop").classList.add("open");
  var taps = 0;
  $("giftOpenBox").onclick = function() {
    taps++;
    $("giftOpenBox").classList.add("gift-shaking");
    $("giftOpenBox").style.transform = "scale(" + (1 + Math.min(taps, 6) * .04) + ") rotate(" + (taps % 2 ? 1 : -1) * 4 + "deg)";
    burstConfettiBit();
    if (taps >= 6) revealMassGift(mg);
  };
}

function revealMassGift(mg) {
  var boxImg = $("giftOpenBoxImg");
  if (boxImg) boxImg.src = "assets/gifts/gift-open.webp";
  $("giftOpenBox").classList.remove("gift-shaking");
  setTimeout(function() {
    $("giftOpenBox").hidden = true;
    $("giftOpenHint").hidden = true;
    supabase.rpc("claim_mass_gift", {
      p_mass_gift_id: mg.id
    }).then(function(res) {
      var row = !res.error && res.data && res.data[0] ? res.data[0] : null;
      if (!row) {
        supabase.from("mass_gift_claims").select("id").eq("mass_gift_id", mg.id).eq("user_id", currentUser.id).maybeSingle().then(function(cr) {
          var already = !!(cr && cr.data);
          $("giftOpenRevealIcon").innerHTML = already ? "✅" : "💨";
          $("giftOpenRevealText").textContent = already ? "Ya reclamaste este regalo. Cada cuenta lo recibe una sola vez." : "Uy, ya no quedan cupos de este regalo.";
          $("giftOpenReveal").hidden = false;
          checkOpenMassGifts();
        });
        return;
      }
      for (var i = 0; i < 24; i++) setTimeout(burstConfettiBit, i * 60);
      var icon = "🎁", text = "";
      if (row.gift_type === "stars") {
        icon = coinIconHtml("stars");
        text = "+" + row.amount + " Diamantes";
      } else if (row.gift_type === "coin") {
        icon = coinIconHtml("coin");
        text = "+" + row.amount + " Z-Coins";
      } else if (row.gift_type === "frame") {
        icon = "🖼️";
        text = "Un marco de perfil nuevo";
      } else if (row.gift_type === "bubble") {
        icon = "💬";
        text = "Una burbuja de chat nueva";
      }
      $("giftOpenRevealIcon").innerHTML = icon;
      $("giftOpenRevealText").textContent = text;
      $("giftOpenReveal").hidden = false;
      checkOpenMassGifts();
    });
  }, 420);
}