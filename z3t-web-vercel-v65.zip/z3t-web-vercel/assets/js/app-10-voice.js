"use strict";

var VOICE_PAGE_SIZE = 8;

var CINEMA_PAGE_SIZE = 4;

var VOICE_MAX_USERS = 2000;

var voicePagerPage = {};

function voicePagerHtml(key, items, pageSize) {
  items = (items || []).slice(0, VOICE_MAX_USERS);
  var pages = Math.max(1, Math.ceil(items.length / pageSize));
  if ((voicePagerPage[key] || 0) > pages - 1) voicePagerPage[key] = pages - 1;
  var cur = voicePagerPage[key] || 0;
  var html = '<div class="vp-pager" data-vp="' + key + '">';
  for (var p = 0; p < pages; p++) {
    html += '<div class="vp-page"><div class="vp-grid vp-cols-4">' + items.slice(p * pageSize, (p + 1) * pageSize).join("") + "</div></div>";
  }
  html += "</div>";
  if (pages > 1) {
    html += '<div class="rp-dots vp-dots" data-vp-dots="' + key + '">';
    for (var d = 0; d < pages; d++) {
      html += '<button type="button" class="rp-dot' + (d === cur ? " active" : "") + '" data-dot="' + d + '" aria-label="Página ' + (d + 1) + '"></button>';
    }
    html += "</div>";
  }
  return html;
}

function voicePagerWire(root, key) {
  var pager = root.querySelector('[data-vp="' + key + '"]');
  if (!pager) return;
  var dots = qsa(".rp-dot", root);
  var setDots = function(i) {
    dots.forEach(function(d, idx) {
      d.classList.toggle("active", idx === i);
    });
  };
  pager.scrollLeft = (voicePagerPage[key] || 0) * pager.clientWidth;
  pager.addEventListener("scroll", function() {
    var i = Math.round(pager.scrollLeft / (pager.clientWidth || 1));
    if (i !== voicePagerPage[key]) {
      voicePagerPage[key] = i;
      setDots(i);
    }
  }, {
    passive: true
  });
  dots.forEach(function(d) {
    d.addEventListener("click", function(e) {
      e.stopPropagation();
      var i = parseInt(d.getAttribute("data-dot"), 10) || 0;
      voicePagerPage[key] = i;
      pager.scrollTo({
        left: i * pager.clientWidth,
        behavior: "smooth"
      });
      setDots(i);
    });
  });
}

var LIVEKIT_WS_URL = "wss://hell-uvpt1098.livekit.cloud";

var voiceRoom = null;

var voiceRoomCommunityId = null;

var voiceMuted = false;

var voiceJoined = false;

var voiceSpeakingIdentities = {};

var voiceStageExpanded = false;

var voiceChatActive = false;

var voiceChatStartedBy = null;

var voiceGraceTimer = null;

function micOnSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/></svg>';
}

function micOffSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="2" y1="2" x2="22" y2="22"/><path d="M9 9v3a3 3 0 0 0 4.83 2.37"/><path d="M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M19 10v2a7 7 0 0 1-9.9 6.4"/><line x1="12" y1="19" x2="12" y2="23"/></svg>';
}

function voiceIconSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/></svg>';
}

function upArrowSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>';
}

function downArrowSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>';
}

function chevronRightSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 6 15 12 9 18"/></svg>';
}

function hexagonSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 20.66 7v10L12 22 3.34 17V7z"/></svg>';
}

function closeXSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
}

function stageListSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="7" y1="9" x2="17" y2="9"/><line x1="7" y1="14" x2="13" y2="14"/></svg>';
}

function stageMinusSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>';
}

function stageExpandSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>';
}

function stageCompressSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/><line x1="14" y1="10" x2="21" y2="3"/><line x1="3" y1="21" x2="10" y2="14"/></svg>';
}

function cinemaGearSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
}

function cinemaUploadIconSvg() {
  return '<img loading=lazy decoding=async src="assets/icons/ic-upload.png" alt="" class="upload-icon-img">';
}

function hangupPhoneSvg() {
  return '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 15.5c-2.9 0-5.6-.8-7.9-2.1-.5-.3-.6-1-.2-1.4l2-2.2c.3-.3.8-.4 1.2-.2 1 .4 2 .6 3 .7.5.1.9.5.9 1v2.2c0 .5.3.9.8 1 .07.02.13.03.2.02z" opacity="0"/><path d="M21.6 15.2c-1.2-1.2-4.8-3.1-8.2-3.4-4.6-.4-8.4 1.6-10.9 3.4-.7.5-.8 1.5-.2 2.1l2.1 2.1c.5.5 1.3.6 1.9.2.9-.6 2.1-1.2 2.1-1.2.4-.2.6-.6.5-1l-.4-1.7c1.7-.5 3.6-.5 5.3 0l-.4 1.7c-.1.4.1.8.5 1 0 0 1.2.6 2.1 1.2.6.4 1.4.3 1.9-.2l2.1-2.1c.6-.6.5-1.6-.2-2.1z"/></svg>';
}

function stageMicOffBadgeSvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="2" y1="2" x2="22" y2="22"/><path d="M9 9v3a3 3 0 0 0 4.83 2.37"/><path d="M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M19 10v2a7 7 0 0 1-9.9 6.4"/></svg>';
}

function emojiSmileySvg() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 14s1.2 2 3.5 2 3.5-2 3.5-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>';
}

function ensureVoiceRoomConnected() {
  if (!currentUser || !currentCommunity) return Promise.resolve();
  if (typeof LivekitClient === "undefined") return Promise.resolve();
  if (voiceRoom && voiceRoomCommunityId !== currentCommunity.id) {
    try {
      voiceRoom.disconnect();
    } catch (_e) {}
    voiceRoom = null;
    voiceRoomCommunityId = null;
    voiceMuted = false;
    voiceChatActive = false;
    voiceChatStartedBy = null;
    qsa("[data-livekit-audio]", document.body).forEach(function(mediaEl) {
      mediaEl.remove();
    });
  }
  if (voiceRoom && (voiceRoom.state === "connected" || voiceRoom.state === "connecting")) return Promise.resolve();
  return supabase.rpc("create_livekit_token", {
    p_community_id: currentCommunity.id
  }).then(function(res) {
    if (res.error || !res.data) return;
    var token = res.data;
    voiceRoomCommunityId = currentCommunity.id;
    voiceRoom = new LivekitClient.Room({
      adaptiveStream: true,
      dynacast: true
    });
    wireVoiceRoomEvents(voiceRoom);
    return voiceRoom.connect(LIVEKIT_WS_URL, token);
  }).then(function() {
    voiceChatActive = !!(currentCommunity && currentCommunity.voice_active) || getVoiceSpeakers().length > 0;
    renderVoiceBar();
  }).catch(function() {});
}

function ciAutoListen() {
  if (!currentUser || !currentCommunity) return;
  var act = currentCommunity.active_activity;
  if (act === "roleplay") return;
  if (!currentCommunity.voice_active && act !== "cinema") return;
  if (voiceRoom && voiceRoomCommunityId === currentCommunity.id && (voiceRoom.state === "connected" || voiceRoom.state === "connecting")) return;
  ensureVoiceRoomConnected();
}

function wireVoiceRoomEvents(room) {
  room.on(LivekitClient.RoomEvent.TrackSubscribed, function(track, _pub, participant) {
    if (track.kind === "audio") {
      var mediaEl = track.attach();
      mediaEl.setAttribute("data-livekit-audio", participant.identity);
      mediaEl.style.display = "none";
      document.body.appendChild(mediaEl);
    }
    renderVoiceBar();
  });
  room.on(LivekitClient.RoomEvent.TrackUnsubscribed, function(track) {
    track.detach().forEach(function(mediaEl) {
      mediaEl.remove();
    });
    renderVoiceBar();
  });
  room.on(LivekitClient.RoomEvent.ParticipantConnected, renderVoiceBar);
  room.on(LivekitClient.RoomEvent.ParticipantDisconnected, renderVoiceBar);
  room.on(LivekitClient.RoomEvent.LocalTrackPublished, renderVoiceBar);
  room.on(LivekitClient.RoomEvent.LocalTrackUnpublished, renderVoiceBar);
  room.on(LivekitClient.RoomEvent.ActiveSpeakersChanged, function(speakers) {
    voiceSpeakingIdentities = {};
    speakers.forEach(function(p) {
      voiceSpeakingIdentities[p.identity] = true;
    });
    qsa(".voice-participant", document).forEach(function(el) {
      el.classList.toggle("speaking", !!voiceSpeakingIdentities[el.getAttribute("data-identity")]);
    });
    if (communityVoiceMinimized) renderCommunityVoiceFloat();
  });
  room.on(LivekitClient.RoomEvent.Reconnecting, function() {
    toast("Reconectando el chat de voz...");
  });
  room.on(LivekitClient.RoomEvent.Reconnected, function() {
    renderVoiceBar();
  });
  room.on(LivekitClient.RoomEvent.Disconnected, function() {
    voiceRoom = null;
    voiceRoomCommunityId = null;
    voiceMuted = false;
    voiceChatActive = false;
    voiceChatStartedBy = null;
    qsa("[data-livekit-audio]", document.body).forEach(function(mediaEl) {
      mediaEl.remove();
    });
    renderVoiceBar();
  });
  room.on(LivekitClient.RoomEvent.DataReceived, function(payload) {
    var msg = null;
    try {
      msg = JSON.parse((new TextDecoder).decode(payload));
    } catch (_e) {
      return;
    }
    if (!msg || !msg.type) return;
    if (msg.type === "voice_on") {
      voiceChatActive = true;
      voiceChatStartedBy = msg.by || null;
      renderVoiceBar();
    } else if (msg.type === "voice_off") {
      voiceChatActive = false;
      voiceChatStartedBy = null;
      if (voiceRoom) {
        try {
          voiceRoom.disconnect();
        } catch (_e) {}
      }
      voiceRoom = null;
      voiceRoomCommunityId = null;
      voiceJoined = false;
      voiceMuted = false;
      voiceSpeakingIdentities = {};
      qsa("[data-livekit-audio]", document.body).forEach(function(mediaEl) {
        mediaEl.remove();
      });
      renderVoiceBar();
      toast("Un admin apagó el chat de voz.");
    }
  });
}

function broadcastVoiceEvent(obj) {
  if (!voiceRoom || !voiceRoom.localParticipant) return;
  try {
    var payload = (new TextEncoder).encode(JSON.stringify(obj));
    voiceRoom.localParticipant.publishData(payload, {
      reliable: true
    });
  } catch (_e) {}
}

function postVoiceSystemMessage(body) {
  if (!currentUser || !currentCommunity) return;
  supabase.from("community_messages").insert({
    community_id: currentCommunity.id,
    sender_id: currentUser.id,
    body: body,
    type: "system"
  }).then(function() {
    loadCommunityMessages();
  });
}

function roleLabel(role) {
  return role === "admin" ? "Admin" : role === "co_admin" ? "Co-Admin" : "Miembro";
}

function activityLabelFor(mode) {
  return mode === "cinema" ? "la Sala de Cine" : mode === "roleplay" ? "el Roleplay" : mode === "voice" ? "el chat de voz" : "la actividad";
}

function activateVoiceChat() {
  if (!currentUser || !currentCommunity) return;
  var role = myCommunityRole();
  if (role !== "admin" && role !== "co_admin") {
    toast("Solo un admin o co-admin puede encender el chat de voz.");
    return;
  }
  voiceChatActive = true;
  voiceChatStartedBy = currentUser.username;
  supabase.rpc("set_voice_active", {
    p_kind: "community",
    p_id: currentCommunity.id,
    p_active: true
  }).then(function() {});
  if (currentCommunity) currentCommunity.voice_active = true;
  broadcastVoiceEvent({
    type: "voice_on",
    by: currentUser.username,
    role: role
  });
  postVoiceSystemMessage(currentUser.username + " (" + roleLabel(role) + ") encendió el chat de voz.");
  renderVoiceBar();
}

function deactivateVoiceChat() {
  if (!currentUser || !currentCommunity) return;
  var role = myCommunityRole();
  if (role !== "admin" && role !== "co_admin") {
    toast("Solo un admin o co-admin puede apagar el chat de voz.");
    return;
  }
  voiceChatActive = false;
  voiceChatStartedBy = null;
  supabase.rpc("set_voice_active", {
    p_kind: "community",
    p_id: currentCommunity.id,
    p_active: false
  }).then(function() {});
  if (currentCommunity) currentCommunity.voice_active = false;
  broadcastVoiceEvent({
    type: "voice_off",
    by: currentUser.username
  });
  postVoiceSystemMessage(currentUser.username + " (" + roleLabel(role) + ") apagó el chat de voz.");
  if (voiceRoom) {
    try {
      voiceRoom.disconnect();
    } catch (_e) {}
  }
  voiceRoom = null;
  voiceRoomCommunityId = null;
  voiceJoined = false;
  voiceMuted = false;
  voiceSpeakingIdentities = {};
  qsa("[data-livekit-audio]", document.body).forEach(function(mediaEl) {
    mediaEl.remove();
  });
  renderVoiceBar();
}

function getVoiceSpeakers() {
  if (!voiceRoom) return [];
  var list = [];
  if (voiceRoom.localParticipant && voiceJoined) {
    list.push({
      identity: voiceRoom.localParticipant.identity,
      name: currentUser && currentUser.username || "tú",
      isLocal: true,
      muted: !!voiceMuted
    });
  }
  if (voiceRoom.remoteParticipants) {
    voiceRoom.remoteParticipants.forEach(function(p) {
      if (!p.isMicrophoneEnabled) return;
      var micPub = p.getTrackPublication ? p.getTrackPublication(LivekitClient.Track.Source.Microphone) : null;
      list.push({
        identity: p.identity,
        name: p.name || "usuario",
        isLocal: false,
        muted: !!(micPub && micPub.isMuted)
      });
    });
  }
  return list;
}

function memberRoleFor(userId) {
  var m = communityMembers.filter(function(x) {
    return x.user_id === userId;
  })[0];
  return m ? m.role : null;
}

function voiceParticipantProfile(p) {
  if (p.isLocal) {
    return currentUser ? {
      avatarUrl: currentUser.avatarUrl,
      nameColor: currentUser.nameColor,
      role: currentUser.role,
      verified: currentUser.verified
    } : null;
  }
  var m = communityMembers.filter(function(x) {
    return x.user_id === p.identity;
  })[0];
  if (!m || !m.profiles) return null;
  return {
    avatarUrl: m.profiles.avatar_url,
    nameColor: m.profiles.name_color,
    role: m.profiles.role,
    verified: m.profiles.verified
  };
}

function voiceParticipantRoleplayIdentity(p) {
  if (!currentCommunity || currentCommunity.active_activity !== "roleplay") return null;
  if (typeof roleplayVoiceIdentityFor !== "function") return null;
  return roleplayVoiceIdentityFor(p.identity, "community");
}

function renderVoiceBar() {
  if (typeof renderCommunityVoiceFloat === "function") renderCommunityVoiceFloat();
  var el = $("communityVoiceBar");
  if (!el) return;
  var activity = currentCommunity ? currentCommunity.active_activity : null;
  var isCinemaActivity = activity === "cinema";
  if (!voiceRoom && !voiceChatActive && !isCinemaActivity || activity === "roleplay") {
    el.hidden = true;
    el.innerHTML = "";
    voiceStageExpanded = false;
    if (activity === "roleplay" && typeof rpEntity !== "undefined" && rpEntity && typeof renderRoleplayWrap === "function") {
      renderRoleplayWrap();
    }
    return;
  }
  var myRole = myCommunityRole();
  var isStaff = myRole === "admin" || myRole === "co_admin";
  var speakers = getVoiceSpeakers();
  var amSpeaking = voiceJoined && !!voiceRoom.localParticipant;
  var activityLabel = activity === "cinema" ? "Sala de Cine" : activity === "roleplay" ? "Roleplay" : "Chat de voz";
  var isCinema = activity === "cinema";
  var voiceIsOfferedHere = voiceChatActive || isCinema;
  el.hidden = false;
  el.classList.toggle("expanded", voiceStageExpanded && !isCinema);
  var participantsHtml = speakers.length ? voicePagerHtml("community", speakers.map(function(p) {
    var pRole = p.isLocal ? myRole : memberRoleFor(p.identity);
    var roleTagHtml = pRole ? '<span class="role-tag ' + pRole + '">' + (pRole === "admin" ? "Admin" : pRole === "co_admin" ? "Co-Admin" : "Miembro") + "</span>" : "";
    var muted = p.muted;
    var profile = voiceParticipantProfile(p);
    var rpIdentity = voiceParticipantRoleplayIdentity(p);
    var avatarUrl = rpIdentity ? rpIdentity.avatarUrl : profile ? profile.avatarUrl : null;
    var nameColor = rpIdentity ? null : profile ? profile.nameColor : null;
    var acctRole = rpIdentity ? null : profile ? profile.role : null;
    var acctVerified = rpIdentity ? null : profile ? profile.verified : null;
    var displayName = rpIdentity ? rpIdentity.name : p.isLocal ? "Tú" : p.name;
    return '<div class="voice-participant" data-identity="' + escapeHtml(p.identity) + '" data-role="' + (pRole || "") + '" data-uid="' + escapeHtml(p.identity) + '">' + '<div class="voice-participant-avatar-wrap">' + avatarSpanHtml(rpIdentity ? rpIdentity.name : p.name, avatarUrl, "voice-participant-avatar", rpIdentity ? null : p.identity) + (muted ? '<span class="voice-mute-badge">' + stageMicOffBadgeSvg() + "</span>" : "") + "</div>" + '<span class="voice-participant-name"' + (nameColor ? ' style="color:' + escapeHtml(nameColor) + '"' : "") + ">" + escapeHtml(displayName) + "</span>" + (rpIdentity ? '<span class="rp-char-badge">' + activityIconHtml("roleplay") + "</span>" : roleBadgeHtml(acctRole, acctVerified)) + roleTagHtml + "</div>";
  }), isCinema ? CINEMA_PAGE_SIZE : VOICE_PAGE_SIZE) : voiceIsOfferedHere ? '<div class="voice-bar-empty">' + voiceIconSvg() + " " + activityLabel + " activo — nadie está hablando ahora</div>" : '<div class="voice-bar-empty">' + voiceIconSvg() + " Sin actividad activa" + (isStaff ? " — elige una abajo" : " — un admin debe activar una") + "</div>";
  var controlsHtml = "";
  if (amSpeaking) {
    controlsHtml = '<button class="voice-control-btn mic" id="btnVoiceMuteToggle" aria-label="Silenciar">' + (voiceMuted ? micOffSvg() : micOnSvg()) + "</button>" + '<button class="voice-control-btn hangup" id="btnVoiceStepDown" type="button" aria-label="Bajar">' + hangupPhoneSvg() + "</button>";
  } else if (myRole && voiceIsOfferedHere) {
    controlsHtml = '<button class="voice-control-btn up pill" id="btnVoiceJoin" type="button" aria-label="Unirme"><span>👋</span> Unirme</button>';
  } else if (myRole && !isStaff) {
    controlsHtml = '<span class="voice-bar-hint">Un admin debe activar una actividad</span>';
  } else if (!myRole) {
    controlsHtml = '<span class="voice-bar-hint">Únete para participar</span>';
  }
  var headerHtml = !isCinema ? '<div class="voice-stage-header">' + '<button class="voice-stage-title" id="btnVoiceStageToggle" type="button">' + voiceIconSvg() + " <span>" + activityLabel + "</span> " + chevronRightSvg() + "</button>" + '<div class="voice-stage-header-actions">' + (isStaff ? '<button class="icon-btn" id="btnVoiceStageOptions" type="button" aria-label="Opciones">' + hexagonSvg() + "</button>" : "") + '<button class="icon-btn" id="btnVoiceStageClose" type="button" aria-label="Cerrar">' + closeXSvg() + "</button>" + "</div>" + "</div>" : "";
  var extraControlsHtml = !isCinema ? '<button class="voice-control-btn ghost" id="btnVoiceStageList" type="button" aria-label="Miembros">' + stageListSvg() + "</button>" : "";
  var extraControlsHtmlEnd = !isCinema ? '<button class="voice-control-btn ghost" id="btnVoiceStageMinus" type="button" aria-label="Minimizar">' + stageMinusSvg() + "</button>" + '<button class="voice-control-btn ghost" id="btnVoiceStageExpand" type="button" aria-label="Expandir">' + stageExpandSvg() + "</button>" : "";
  el.innerHTML = headerHtml + '<div class="voice-bar-row"><div class="voice-participants-row">' + participantsHtml + "</div></div>" + (controlsHtml ? '<div class="voice-call-controls' + (isCinema ? " cinema-mode" : "") + '">' + extraControlsHtml + controlsHtml + extraControlsHtmlEnd + "</div>" : "");
  voicePagerWire(el, "community");
  qsa(".voice-participant", el).forEach(function(pEl) {
    pEl.classList.toggle("speaking", !!voiceSpeakingIdentities[pEl.getAttribute("data-identity")]);
  });
  var joinBtn = $("btnVoiceJoin");
  if (joinBtn) joinBtn.addEventListener("click", raiseHandToSpeak);
  var stepDownBtn = $("btnVoiceStepDown");
  if (stepDownBtn) stepDownBtn.addEventListener("click", stepDownFromSpeaking);
  var muteBtn = $("btnVoiceMuteToggle");
  if (muteBtn) muteBtn.addEventListener("click", toggleVoiceMute);
  var stageToggleBtn = $("btnVoiceStageToggle");
  if (stageToggleBtn) stageToggleBtn.addEventListener("click", function() {
    voiceStageExpanded = !voiceStageExpanded;
    renderVoiceBar();
  });
  var stageExpandBtn = $("btnVoiceStageExpand");
  if (stageExpandBtn) stageExpandBtn.addEventListener("click", function() {
    voiceStageExpanded = true;
    renderVoiceBar();
  });
  var stageMinusBtn = $("btnVoiceStageMinus");
  if (stageMinusBtn) stageMinusBtn.addEventListener("click", function() {
    voiceStageExpanded = false;
    renderVoiceBar();
  });
  var stageCloseBtn = $("btnVoiceStageClose");
  if (stageCloseBtn) stageCloseBtn.addEventListener("click", function() {
    voiceStageExpanded = false;
    if (!isStaff) {
      toast("Solo un admin o co-admin puede apagar el chat de voz.");
      return;
    }
    if (isCinema) {
      if (typeof setCommunityActivity === "function") setCommunityActivity(null);
    } else {
      deactivateVoiceChat();
    }
  });
  var stageListBtn = $("btnVoiceStageList");
  if (stageListBtn) stageListBtn.addEventListener("click", function() {
    openCommunityMembersView();
  });
  var stageOptionsBtn = $("btnVoiceStageOptions");
  if (stageOptionsBtn) stageOptionsBtn.addEventListener("click", function() {
    var popup = $("activitiesPopup");
    if (popup) popup.classList.toggle("open");
  });
}

function raiseHandToSpeak() {
  if (!voiceJoined && getVoiceSpeakers().length >= VOICE_MAX_USERS) {
    toast("Se alcanzó el límite de " + VOICE_MAX_USERS + " usuarios en el chat de voz.");
    return;
  }
  if (!currentUser || !currentCommunity) return;
  var role = myCommunityRole();
  if (!role) {
    toast("Únete a la comunidad para poder hablar.");
    return;
  }
  var isStaff = role === "admin" || role === "co_admin";
  var activity = currentCommunity.active_activity;
  var activityAllowsVoice = activity === "cinema" || activity === "roleplay" && currentCommunity.roleplay_voice_enabled !== false;
  if (!voiceChatActive && !isStaff && !activityAllowsVoice) {
    toast("Un admin o co-admin debe encender el chat de voz primero.");
    return;
  }
  var otherActivity = typeof activeVoiceActivityElsewhere === "function" ? activeVoiceActivityElsewhere("community", currentCommunity.id) : null;
  if (otherActivity) {
    toast("Ya tienes una actividad de voz activa en " + otherActivity + ". Sal de ahí antes de unirte aquí.");
    return;
  }
  var proceed = voiceRoom ? Promise.resolve() : ensureVoiceRoomConnected();
  proceed.then(function() {
    if (!voiceRoom) {
      toast("No se pudo conectar al chat de voz.");
      return;
    }
    return voiceRoom.localParticipant.setMicrophoneEnabled(true);
  }).then(function() {
    voiceMuted = false;
    voiceJoined = true;
    if (!voiceChatActive && isStaff && !activityAllowsVoice) {
      voiceChatActive = true;
      voiceChatStartedBy = currentUser.username;
      supabase.rpc("set_voice_active", {
        p_kind: "community",
        p_id: currentCommunity.id,
        p_active: true
      }).then(function() {});
      if (currentCommunity) currentCommunity.voice_active = true;
      broadcastVoiceEvent({
        type: "voice_on",
        by: currentUser.username,
        role: role
      });
      postVoiceSystemMessage(currentUser.username + " (" + roleLabel(role) + ") encendió el chat de voz.");
    }
    renderVoiceBar();
  }).catch(function() {
    toast("No se pudo activar tu micrófono. Revisa los permisos del navegador.");
  });
}

function stepDownFromSpeaking() {
  if (!voiceRoom) return;
  voiceJoined = false;
  voiceMuted = false;
  voiceRoom.localParticipant.setMicrophoneEnabled(false).then(function() {
    renderVoiceBar();
  });
}

var voiceMuteToggleBusy = false;

function toggleVoiceMute() {
  if (!voiceRoom || !voiceRoom.localParticipant || voiceMuteToggleBusy) return;
  var micPub = voiceRoom.localParticipant.getTrackPublication ? voiceRoom.localParticipant.getTrackPublication(LivekitClient.Track.Source.Microphone) : null;
  if (!micPub || !micPub.track) {
    return;
  }
  var nextMuted = !voiceMuted;
  voiceMuteToggleBusy = true;
  Promise.resolve(nextMuted ? micPub.track.mute() : micPub.track.unmute()).then(function() {
    voiceMuteToggleBusy = false;
    voiceMuted = nextMuted;
    renderVoiceBar();
  }).catch(function() {
    voiceMuteToggleBusy = false;
    renderVoiceBar();
    toast("No se pudo cambiar el micrófono. Intenta de nuevo.");
  });
}

function leaveVoiceChat() {
  if (voiceGraceTimer) {
    clearTimeout(voiceGraceTimer);
    voiceGraceTimer = null;
  }
  if (voiceRoom) {
    try {
      voiceRoom.disconnect();
    } catch (_e) {}
    voiceRoom = null;
  }
  voiceRoomCommunityId = null;
  voiceMuted = false;
  voiceChatActive = false;
  voiceChatStartedBy = null;
  voiceSpeakingIdentities = {};
  qsa("[data-livekit-audio]", document.body).forEach(function(mediaEl) {
    mediaEl.remove();
  });
  communityVoiceMinimized = false;
  communityVoiceReopenFn = null;
  renderVoiceBar();
  renderCommunityVoiceFloat();
}

var communityVoiceMinimized = false;

var communityVoiceReopenFn = null;

var communityVoiceFloatPos = null;

var communityVoiceFloatDrag = null;

function minimizeVoiceChat(reopenFn) {
  if (!voiceRoom) {
    return;
  }
  communityVoiceMinimized = true;
  communityVoiceReopenFn = reopenFn || null;
  renderCommunityVoiceFloat();
}

function restoreCommunityVoiceFromFloat() {
  if (!communityVoiceMinimized) return;
  communityVoiceMinimized = false;
  var reopen = communityVoiceReopenFn;
  communityVoiceReopenFn = null;
  renderCommunityVoiceFloat();
  if (reopen) reopen();
}

function communityVoiceFloatCurrentSpeaker() {
  var speakers = getVoiceSpeakers();
  var talking = speakers.filter(function(p) {
    return voiceSpeakingIdentities[p.identity];
  });
  var p = talking[0] || speakers[0];
  if (!p) return null;
  var rpIdentity = voiceParticipantRoleplayIdentity(p);
  var profile = voiceParticipantProfile(p) || {};
  return {
    name: rpIdentity ? rpIdentity.name : p.isLocal ? "Tú" : p.name,
    avatarUrl: rpIdentity && rpIdentity.avatarUrl ? rpIdentity.avatarUrl : profile.avatarUrl,
    isSpeaking: !!voiceSpeakingIdentities[p.identity],
    uid: rpIdentity ? null : p.identity
  };
}

function communityVoiceFloatIsCinema() {
  return !!(currentCommunity && currentCommunity.active_activity === "cinema");
}

function ensureCommunityVoiceFloatEl() {
  var el = $("communityVoiceFloat");
  if (el) return el;
  el = document.createElement("div");
  el.id = "communityVoiceFloat";
  el.className = "activity-voice-float";
  el.hidden = true;
  el.innerHTML = '<button type="button" class="activity-voice-float-x" id="communityVoiceFloatClose" aria-label="Cerrar y salir">×</button>' + '<div class="activity-voice-float-body" id="communityVoiceFloatBody">' + '<div class="activity-voice-float-avatar" id="communityVoiceFloatAvatar"></div>' + '<div class="activity-voice-float-label" id="communityVoiceFloatLabel"></div>' + '<div class="activity-voice-float-video" id="communityVoiceFloatVideo" hidden></div>' + "</div>";
  document.body.appendChild(el);
  $("communityVoiceFloatClose").addEventListener("click", function(e) {
    e.stopPropagation();
    if (confirm("Vas a salir del chat de voz de la comunidad. ¿Seguro que quieres colgar?")) {
      leaveVoiceChat();
    }
  });
  $("communityVoiceFloatBody").addEventListener("click", function(e) {
    if (communityVoiceFloatDrag && communityVoiceFloatDrag.moved) return;
    restoreCommunityVoiceFromFloat();
  });
  wireCommunityVoiceFloatDrag(el);
  return el;
}

function wireCommunityVoiceFloatDrag(el) {
  function startDrag(clientX, clientY) {
    var rect = el.getBoundingClientRect();
    communityVoiceFloatDrag = {
      startX: clientX,
      startY: clientY,
      startRight: window.innerWidth - rect.right,
      startBottom: window.innerHeight - rect.bottom,
      moved: false
    };
  }
  function moveDrag(clientX, clientY) {
    if (!communityVoiceFloatDrag) return;
    var dx = clientX - communityVoiceFloatDrag.startX;
    var dy = clientY - communityVoiceFloatDrag.startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) communityVoiceFloatDrag.moved = true;
    var right = Math.max(6, communityVoiceFloatDrag.startRight - dx);
    var bottom = Math.max(6, communityVoiceFloatDrag.startBottom - dy);
    communityVoiceFloatPos = {
      right: right,
      bottom: bottom
    };
    el.style.right = right + "px";
    el.style.bottom = bottom + "px";
  }
  function endDrag() {
    communityVoiceFloatDrag = null;
  }
  el.addEventListener("mousedown", function(e) {
    if (e.target.id === "communityVoiceFloatClose") return;
    startDrag(e.clientX, e.clientY);
    e.preventDefault();
  });
  document.addEventListener("mousemove", function(e) {
    moveDrag(e.clientX, e.clientY);
  });
  document.addEventListener("mouseup", endDrag);
  el.addEventListener("touchstart", function(e) {
    if (e.target.id === "communityVoiceFloatClose") return;
    var t = e.touches[0];
    startDrag(t.clientX, t.clientY);
  }, {
    passive: true
  });
  document.addEventListener("touchmove", function(e) {
    if (!communityVoiceFloatDrag) return;
    var t = e.touches[0];
    moveDrag(t.clientX, t.clientY);
  }, {
    passive: true
  });
  document.addEventListener("touchend", endDrag);
}

var communityCinemaHomeParent = null;

function renderCommunityVoiceFloat() {
  var show = communityVoiceMinimized && !!voiceRoom;
  var el = show ? ensureCommunityVoiceFloatEl() : $("communityVoiceFloat");
  if (!el) return;
  el.hidden = !show;
  var isCinema = show && communityVoiceFloatIsCinema();
  el.classList.toggle("cinema", isCinema);
  var videoSlot = $("communityVoiceFloatVideo");
  var player = $("communityCinemaPlayer");
  if (communityCinemaHomeParent && !communityCinemaHomeParent.isConnected) communityCinemaHomeParent = null;
  if (isCinema && player) {
    if (!communityCinemaHomeParent) communityCinemaHomeParent = player.parentNode;
    if (videoSlot && player.parentNode !== videoSlot) {
      videoSlot.appendChild(player);
    }
    if (videoSlot) videoSlot.hidden = false;
  } else if (player && communityCinemaHomeParent && player.parentNode !== communityCinemaHomeParent) {
    communityCinemaHomeParent.appendChild(player);
    if (videoSlot) videoSlot.hidden = true;
  }
  if (!show) return;
  if (communityVoiceFloatPos) {
    el.style.right = communityVoiceFloatPos.right + "px";
    el.style.bottom = communityVoiceFloatPos.bottom + "px";
  }
  var avatarEl = $("communityVoiceFloatAvatar");
  var labelEl = $("communityVoiceFloatLabel");
  if (isCinema) {
    if (avatarEl) avatarEl.hidden = true;
    if (labelEl) labelEl.hidden = true;
    return;
  }
  if (avatarEl) avatarEl.hidden = false;
  if (labelEl) labelEl.hidden = false;
  var speaker = communityVoiceFloatCurrentSpeaker();
  if (avatarEl) {
    avatarEl.innerHTML = avatarSpanHtml(speaker ? speaker.name : "", speaker ? speaker.avatarUrl : null, "activity-voice-float-avatar-inner", speaker ? speaker.uid : null);
    avatarEl.classList.toggle("speaking", !!(speaker && speaker.isSpeaking));
  }
  if (labelEl) labelEl.textContent = speaker ? speaker.name : voiceChatActive ? "Chat de voz activo" : "Chat de voz";
}

var VOICE_GRACE_MS = 12e4;

document.addEventListener("visibilitychange", function() {
  if (!voiceRoom) return;
  if (currentCommunity && currentCommunity.active_activity === "cinema") return;
  if (document.hidden) {
    if (voiceGraceTimer) clearTimeout(voiceGraceTimer);
    voiceGraceTimer = setTimeout(function() {
      voiceGraceTimer = null;
      if (document.hidden && voiceRoom) {
        leaveVoiceChat();
      }
    }, VOICE_GRACE_MS);
  } else if (voiceGraceTimer) {
    clearTimeout(voiceGraceTimer);
    voiceGraceTimer = null;
  }
});