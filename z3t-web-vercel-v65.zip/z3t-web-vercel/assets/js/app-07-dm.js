"use strict";

var DM_CONVERSATIONS = [];

var currentConversation = null;

var DM_MESSAGES = [];

var dmMessagesPollTimer = null;

var dmListPollTimer = null;

function loadConversations() {
  if (!currentUser) return Promise.resolve();
  return supabase.from("dm_conversations").select("*").or("user_a.eq." + currentUser.id + ",user_b.eq." + currentUser.id).neq("status", "none").order("last_message_at", {
    ascending: false,
    nullsFirst: false
  }).then(function(res) {
    if (res.error) {
      DM_CONVERSATIONS = [];
      renderConversationList();
      updateDmBadge();
      return;
    }
    var rows = (res.data || []).filter(function(r) {
      return !(r.hidden_for || []).includes(currentUser.id);
    });
    var otherIds = rows.map(function(r) {
      return r.user_a === currentUser.id ? r.user_b : r.user_a;
    });
    if (!otherIds.length) {
      DM_CONVERSATIONS = [];
      renderConversationList();
      updateDmBadge();
      return;
    }
    return supabase.from("profiles").select("id,username,name,avatar_url,name_color,role,verified").in("id", otherIds).then(function(pRes) {
      var profileMap = {};
      (pRes.data || []).forEach(function(p) {
        profileMap[p.id] = p;
      });
      DM_CONVERSATIONS = rows.map(function(row) {
        var otherId = row.user_a === currentUser.id ? row.user_b : row.user_a;
        var other = profileMap[otherId];
        var myLastRead = row.user_a === currentUser.id ? row.last_read_a : row.last_read_b;
        var unread = !!(row.last_sender_id && row.last_sender_id !== currentUser.id && (!myLastRead || new Date(row.last_message_at) > new Date(myLastRead)));
        return {
          id: row.id,
          otherId: otherId,
          otherUsername: other ? other.username : "usuario",
          otherName: other ? other.name || other.username : "usuario",
          otherAvatar: other ? other.avatar_url : null,
          otherNameColor: other ? other.name_color : null,
          otherRole: other ? other.role : null,
          otherVerified: other ? other.verified : null,
          lastMessage: typeof rpStripBody === "function" ? rpStripBody(row.last_message) : row.last_message,
          lastMessageAt: row.last_message_at,
          status: row.status || "accepted",
          requestedByMe: row.requested_by === currentUser.id,
          unread: unread
        };
      });
      renderConversationList();
      updateDmBadge();
    });
  });
}

function updateDmBadge() {
  var badge = $("dmBadge");
  if (!badge) return;
  badge.hidden = !DM_CONVERSATIONS.some(function(c) {
    return c.unread || c.status === "pending" && !c.requestedByMe;
  });
}

function renderConversationList() {
  renderMergedPrivadoList();
}

function pinStorageKey(kind) {
  var uid = currentUser ? currentUser.id : "anon";
  return "z3t_pinned_" + kind + "_" + uid;
}

function getPinnedIds(kind) {
  try {
    return JSON.parse(localStorage.getItem(pinStorageKey(kind)) || "[]");
  } catch (e) {
    return [];
  }
}

function setPinnedIds(kind, ids) {
  try {
    localStorage.setItem(pinStorageKey(kind), JSON.stringify(ids));
  } catch (e) {}
}

function togglePin(kind, id) {
  var ids = getPinnedIds(kind);
  var i = ids.indexOf(id);
  if (i === -1) ids.push(id); else ids.splice(i, 1);
  setPinnedIds(kind, ids);
  renderMergedPrivadoList();
}

function openChatRowActionMenu(kind, id, onDelete) {
  var pinned = getPinnedIds(kind).indexOf(id) !== -1;
  $("chatRowActionPin").textContent = pinned ? "Desfijar" : "Fijar";
  $("chatRowActionPin").onclick = function() {
    togglePin(kind, id);
    $("chatRowActionBackdrop").classList.remove("open");
  };
  var dmData = kind === "dm" ? DM_CONVERSATIONS.filter(function(c) {
    return c.id === id;
  })[0] : null;
  var markReadBtn = $("chatRowActionMarkRead");
  if (dmData && dmData.unread) {
    markReadBtn.hidden = false;
    markReadBtn.onclick = function() {
      markConversationReadById(id);
      $("chatRowActionBackdrop").classList.remove("open");
    };
  } else {
    markReadBtn.hidden = true;
  }
  $("chatRowActionDelete").onclick = function() {
    $("chatRowActionBackdrop").classList.remove("open");
    onDelete();
  };
  $("chatRowActionBackdrop").classList.add("open");
}

$("chatRowActionBackdrop").addEventListener("click", function(e) {
  if (e.target === this) this.classList.remove("open");
});

function wireLongPressPin(el, kind, id, onDelete) {
  var timer = null, fired = false;
  function start() {
    fired = false;
    timer = setTimeout(function() {
      fired = true;
      openChatRowActionMenu(kind, id, onDelete);
    }, 500);
  }
  function cancel() {
    if (timer) clearTimeout(timer);
    timer = null;
  }
  el.addEventListener("mousedown", start);
  el.addEventListener("mouseup", cancel);
  el.addEventListener("mouseleave", cancel);
  el.addEventListener("touchstart", start, {
    passive: true
  });
  el.addEventListener("touchend", cancel);
  el.addEventListener("touchmove", cancel);
  el.addEventListener("click", function(e) {
    if (fired) {
      e.stopPropagation();
      e.preventDefault();
    }
  }, true);
}

function renderMergedPrivadoList() {
  var listEl = $("dmConversationList");
  if (!listEl) return;
  var groups = typeof PRIVATE_GROUPS !== "undefined" ? PRIVATE_GROUPS : [];
  var items = DM_CONVERSATIONS.map(function(c) {
    return {
      kind: "dm",
      id: c.id,
      ts: c.lastMessageAt ? new Date(c.lastMessageAt).getTime() : 0,
      data: c
    };
  }).concat(groups.map(function(g) {
    return {
      kind: "group",
      id: g.slug,
      ts: g.lastActivityAt ? new Date(g.lastActivityAt).getTime() : 0,
      data: g
    };
  }));
  items.sort(function(a, b) {
    return b.ts - a.ts;
  });
  $("dmEmptyState").hidden = items.length > 0;
  listEl.innerHTML = items.map(function(item) {
    if (item.kind === "group") return groupCardHtml(item.data);
    var c = item.data;
    var lastParsed = parseAttachments(c.lastMessage || "");
    var previewText = lastParsed.text || (lastParsed.attachments.length ? "📷 Te enviaron una imagen" : "Empieza la conversación");
    var pendingClass = "";
    if (c.status === "pending") {
      pendingClass = " pending";
      previewText = c.requestedByMe ? "Solicitud enviada — esperando respuesta" : "Te mandó una solicitud de chat";
    }
    return '<article class="dm-card' + (c.unread ? " unread" : "") + pendingClass + '" data-kind="dm" data-id="' + escapeHtml(c.id) + '" data-other-id="' + escapeHtml(c.otherId) + '">' + avatarSpanHtml(c.otherName, c.otherAvatar, null, c.otherId) + '<div class="dm-card-main">' + '<div class="dm-card-top">' + '<span class="dm-card-name"' + (c.otherNameColor ? ' style="color:' + escapeHtml(c.otherNameColor) + '"' : "") + ">" + escapeHtml(c.otherName) + roleBadgeHtml(c.otherRole, c.otherVerified) + "</span>" + (c.lastMessageAt ? '<span class="dm-card-time">' + timeAgo(c.lastMessageAt) + "</span>" : "") + "</div>" + '<div class="dm-card-preview">' + escapeHtml(previewText) + "</div>" + "</div>" + (c.status === "pending" && !c.requestedByMe ? '<span class="dm-card-dot"></span>' : c.unread ? '<span class="dm-card-dot"></span>' : "") + "</article>";
  }).join("");
  qsa(".dm-card", listEl).forEach(function(card) {
    var kind = card.getAttribute("data-kind");
    if (kind === "group") {
      var slug = card.getAttribute("data-slug");
      var g = groups.filter(function(x) {
        return x.slug === slug;
      })[0];
      wireLongPressPin(card, "group", slug, function() {
        if (!g) return;
        if (!confirm('¿Salir de "' + g.name + '"? Ya no verás este chat.')) return;
        supabase.rpc("leave_private_group", {
          p_group_id: g.id
        }).then(function(res) {
          if (res.error) {
            toast(t("dm.err_leave_group"));
            return;
          }
          toast(t("dm.toast_left_group") + ' "' + g.name + '".');
          if (typeof loadPrivateGroups === "function") loadPrivateGroups();
        });
      });
      card.addEventListener("click", function() {
        openGroup(slug);
      });
    } else {
      var id = card.getAttribute("data-id");
      wireLongPressPin(card, "dm", id, function() {
        if (!confirm("¿Eliminar esta conversación? Se quita solo de tu lista.")) return;
        supabase.rpc("hide_dm_conversation", {
          p_conversation_id: id
        }).then(function(res) {
          if (res.error) {
            toast(t("dm.err_delete"));
            return;
          }
          toast(t("dm.toast_conv_deleted"));
          loadConversations();
        });
      });
      card.addEventListener("click", function() {
        var c = DM_CONVERSATIONS.filter(function(x) {
          return x.id === id;
        })[0];
        if (c) openConversation(c.id, c.otherId, c.otherUsername, c.otherName, c.otherAvatar, c.otherNameColor, c.otherRole, c.otherVerified);
      });
    }
  });
  renderPinnedRows(items);
}

function pinnedAvatarChipHtml(name, avatarUrl, uid) {
  return '<button type="button" class="pinned-chip">' + avatarSpanHtml(name, avatarUrl, null, uid) + '<span class="pinned-chip-name">' + escapeHtml(name) + "</span>" + "</button>";
}

function renderPinnedRows(items) {
  var wrap = $("pinnedRows");
  var usersRow = $("pinnedUsersRow");
  var chatsRow = $("pinnedChatsRow");
  if (!wrap || !usersRow || !chatsRow) return;
  var pinnedDmIds = getPinnedIds("dm");
  var pinnedGroupIds = getPinnedIds("group");
  var pinnedDms = items.filter(function(it) {
    return it.kind === "dm" && pinnedDmIds.indexOf(it.id) !== -1;
  });
  var pinnedGroups = items.filter(function(it) {
    return it.kind === "group" && pinnedGroupIds.indexOf(it.id) !== -1;
  });
  wrap.hidden = !(pinnedDms.length || pinnedGroups.length);
  usersRow.innerHTML = pinnedDms.map(function(it) {
    return pinnedAvatarChipHtml(it.data.otherName, it.data.otherAvatar, it.data.otherId);
  }).join("");
  chatsRow.innerHTML = pinnedGroups.map(function(it) {
    return pinnedAvatarChipHtml(it.data.name, it.data.avatarUrl, null);
  }).join("");
  qsa(".pinned-chip", usersRow).forEach(function(chip, i) {
    chip.addEventListener("click", function() {
      var c = pinnedDms[i].data;
      openConversation(c.id, c.otherId, c.otherUsername, c.otherName, c.otherAvatar, c.otherNameColor, c.otherRole, c.otherVerified);
    });
  });
  qsa(".pinned-chip", chatsRow).forEach(function(chip, i) {
    chip.addEventListener("click", function() {
      openGroup(pinnedGroups[i].data.slug);
    });
  });
}

function showMessagesList() {
  minimizeActiveContexts();
  exitAllImmersive();
  activatePanel("panel-messages");
  loadConversations();
  if (typeof loadPrivateGroups === "function") loadPrivateGroups();
}

function getOrCreateConversation(otherId) {
  var pair = [ currentUser.id, otherId ].sort();
  var a = pair[0], b = pair[1];
  return supabase.from("dm_conversations").select("*").eq("user_a", a).eq("user_b", b).maybeSingle().then(function(res) {
    if (res.data) return res.data;
    return supabase.from("dm_conversations").insert({
      user_a: a,
      user_b: b
    }).select().single().then(function(insRes) {
      if (insRes.error) {
        toast(t("dm.err_start_conv"));
        return null;
      }
      return insRes.data;
    });
  });
}

function resolveConversationById(conversationId) {
  var found = DM_CONVERSATIONS.filter(function(c) {
    return c.id === conversationId;
  })[0];
  if (!found) {
    toast(t("dm.err_conv_gone"));
    resetToFeedOnMissingRoute("/mensajes/");
    return;
  }
  openConversation(found.id, found.otherId, found.otherUsername, found.otherName, found.otherAvatar, found.otherNameColor, found.otherRole, found.otherVerified);
}

function openConversation(conversationId, otherId, otherUsername, otherName, otherAvatar, otherNameColor, otherRole, otherVerified) {
  currentConversation = {
    id: conversationId,
    otherId: otherId,
    otherUsername: otherUsername || "usuario",
    otherName: otherName || otherUsername || "usuario",
    otherAvatar: otherAvatar || null,
    otherNameColor: otherNameColor || null,
    otherRole: otherRole || null,
    otherVerified: otherVerified || null
  };
  if (typeof activityVoiceMinimized !== "undefined" && activityVoiceMinimized && activityVoiceKind === "dm" && activityVoiceRoomId === conversationId) {
    activityVoiceMinimized = false;
    activityVoiceReopenFn = null;
    if (typeof renderActivityVoiceFloat === "function") renderActivityVoiceFloat();
  }
  enterImmersive("conversation");
  activatePanel("panel-conversation");
  $("conversationDetail").innerHTML = '<div class="conversation-shell">' + '<div class="conversation-header">' + '<button class="icon-btn" id="btnConversationBack" type="button" aria-label="Volver">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>' + "</button>" + avatarSpanHtml(currentConversation.otherName, currentConversation.otherAvatar, null, currentConversation.otherId) + '<div class="conversation-header-name" id="conversationHeaderName" data-uid="' + escapeHtml(currentConversation.otherId || "") + '"' + (currentConversation.otherNameColor ? ' style="color:' + escapeHtml(currentConversation.otherNameColor) + '"' : "") + ">" + escapeHtml(currentConversation.otherName) + roleBadgeHtml(currentConversation.otherRole, currentConversation.otherVerified) + "</div>" + "</div>" + '<div class="community-voice-bar" id="dmVoiceBar" hidden></div>' + '<div id="dmCinemaWrap"></div>' + '<div class="dm-request-banner" id="dmRequestBanner" hidden></div>' + '<div class="conversation-messages" id="conversationMessages"></div>' + '<div class="conversation-input-row">' + '<input type="file" id="dmImageInput" accept="image/*" multiple hidden>' + '<div class="composer-top-row">' + '<input type="text" id="dmInput" placeholder="Escribe un mensaje..." autocomplete="off">' + '<button class="icon-btn composer-send-btn" id="btnSendDm" type="button" aria-label="Enviar">' + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>' + "</button>" + "</div>" + '<div class="composer-icons-row">' + '<button class="icon-btn compose-icon" id="btnDmAudio" type="button" aria-label="Audio"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><line x1="4" y1="10" x2="4" y2="14"/><line x1="8" y1="6" x2="8" y2="18"/><line x1="12" y1="3" x2="12" y2="21"/><line x1="16" y1="6" x2="16" y2="18"/><line x1="20" y1="10" x2="20" y2="14"/></svg></button>' + '<button class="icon-btn compose-icon z3t-link-btn" type="button" data-link-for="dmInput" aria-label="Insertar enlace" title="Enlace">🔗</button>' + '<button class="icon-btn compose-icon" id="btnDmAttachImage" type="button" aria-label="Enviar imagen"><img loading=lazy decoding=async src="assets/icons/ic-upload.png" alt="" class="upload-icon-img"></button>' + '<div class="compose-icon-wrap"><button class="icon-btn compose-icon" id="btnDmEmoji" type="button" aria-label="Emojis"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 14s1.2 2 3.5 2 3.5-2 3.5-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg></button><div class="chat-actions-popup" id="dmEmojiPopup"></div></div>' + '<div class="compose-icon-wrap"><button class="icon-btn compose-icon" id="btnDmActivities" type="button" aria-label="Actividades"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 20h16z"/><line x1="12" y1="9" x2="12" y2="14"/><line x1="9" y1="6" x2="6" y2="2"/><line x1="15" y1="6" x2="18" y2="2"/></svg></button><div class="chat-actions-popup" id="dmActivitiesPopup"><div class="chat-actions-panel"><button class="chat-action-item" id="btnDmActivityVoice" type="button">' + activityIconHtml("voice") + ' <span>Chat de voz</span></button><button class="chat-action-item" id="btnDmActivityCinema" type="button">' + activityIconHtml("cinema") + ' <span>Sala de Cine</span></button><button class="chat-action-item" id="btnDmActivityRoleplay" type="button">' + activityIconHtml("roleplay") + ' <span>Modo roleplay</span></button></div></div></div>' + '<div class="compose-icon-wrap"><button class="icon-btn compose-icon" id="btnDmMore" type="button" aria-label="Más"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button><div class="chat-actions-popup" id="dmMorePopup"><div class="chat-actions-panel">' + giftMenuItemHtml() + '</div></div></div>' + "</div>" + "</div>" + "</div>";
  $("btnConversationBack").addEventListener("click", closeConversation);
  $("conversationHeaderName").addEventListener("click", function() {
    openProfile(currentConversation.otherId);
  });
  $("btnSendDm").addEventListener("click", function() {
    sendDmMessage();
  });
  $("dmInput").addEventListener("keydown", function(e) {
    if (e.key === "Enter") {
      e.preventDefault();
      sendDmMessage();
    }
  });
  applyChatBackground($("conversationMessages"));
  loadDmMessages().then(markConversationRead);
  if (dmMessagesPollTimer) clearInterval(dmMessagesPollTimer);
  dmMessagesPollTimer = setInterval(function() {
    if (!document.hidden) loadDmMessages().then(markConversationRead);
  }, 25e3);
  z3tRealtime("dmsg", "dm_messages", "conversation_id=eq." + conversationId, function() {
    loadDmMessages().then(markConversationRead);
  });
  if (!state.suppressPush) history.pushState({
    view: "conversation",
    id: conversationId
  }, "", "/mensajes/" + encodeURIComponent(conversationId));
  state.suppressPush = false;
  var emojiBtn = $("btnDmEmoji"), emojiPopup = $("dmEmojiPopup");
  if (emojiBtn && emojiPopup) {
    emojiPopup.innerHTML = '<div class="emoji-grid">' + COMMON_EMOJIS.map(function(em) {
      return '<button type="button" data-emoji="' + em + '">' + em + "</button>";
    }).join("") + "</div>";
    emojiBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      emojiPopup.classList.toggle("open");
    });
    emojiPopup.addEventListener("click", function(e) {
      e.stopPropagation();
      var btn = e.target.closest("[data-emoji]");
      if (!btn) return;
      var input = $("dmInput");
      input.value += btn.getAttribute("data-emoji");
      input.focus();
      emojiPopup.classList.remove("open");
    });
  }
  var dmImageInput = $("dmImageInput"), attachImageBtn = $("btnDmAttachImage");
  if (attachImageBtn && dmImageInput) {
    attachImageBtn.addEventListener("click", function() {
      dmImageInput.click();
    });
    dmImageInput.addEventListener("change", function() {
      if (!dmImageInput.files || !dmImageInput.files.length) return;
      attachImageBtn.setAttribute("disabled", "true");
      uploadFiles(dmImageInput.files, "dm/" + currentConversation.id).then(function(attachments) {
        dmImageInput.value = "";
        attachImageBtn.removeAttribute("disabled");
        sendDmMessage(encodeAttachments(attachments));
      }).catch(function() {
        attachImageBtn.removeAttribute("disabled");
        toast(t("dm.err_image_upload"));
      });
    });
  }
  var activitiesBtn = $("btnDmActivities"), activitiesPopup = $("dmActivitiesPopup");
  var morePopup = $("dmMorePopup"), moreBtn = $("btnDmMore");
  function closeDmPopups() {
    [ "dmActivitiesPopup", "dmMorePopup", "dmEmojiPopup" ].forEach(function(id) {
      var el = $(id);
      if (el) el.classList.remove("open");
    });
  }
  if (activitiesBtn) activitiesBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    var wasOpen = activitiesPopup.classList.contains("open");
    closeDmPopups();
    if (!wasOpen) activitiesPopup.classList.add("open");
  });
  if (moreBtn) moreBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    var wasOpen = morePopup.classList.contains("open");
    closeDmPopups();
    if (!wasOpen) morePopup.classList.add("open");
  });
  [ activitiesPopup, morePopup ].forEach(function(pop) {
    if (pop) pop.addEventListener("click", function(e) {
      e.stopPropagation();
    });
  });
  var voicePick = $("btnDmActivityVoice");
  if (voicePick) voicePick.addEventListener("click", function() {
    closeDmPopups();
    toggleDmVoiceCall();
  });
  var cinemaPick = $("btnDmActivityCinema");
  if (cinemaPick) cinemaPick.addEventListener("click", function() {
    closeDmPopups();
    var active = currentConversation.dmRow && currentConversation.dmRow.active_activity === "cinema";
    setDmActivity(active ? null : "cinema");
  });
  var rpPick = $("btnDmActivityRoleplay");
  if (rpPick) rpPick.addEventListener("click", function() {
    closeDmPopups();
    var rpActive = currentConversation.dmRow && currentConversation.dmRow.active_activity === "roleplay";
    setDmActivity(rpActive ? null : "roleplay");
  });
  var dmGiftBtn = morePopup ? morePopup.querySelector('[data-act="open-gift-send"]') : null;
  if (dmGiftBtn) dmGiftBtn.addEventListener("click", function() {
    closeDmPopups();
    openGiftSend("dm", currentConversation.id, currentConversation.otherId, currentConversation.otherName);
  });
  var audioBtn = $("btnDmAudio");
  if (audioBtn) audioBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    z3tToggleAudioRecording(audioBtn, function(file) {
      toast("Enviando audio…");
      uploadFiles([ file ], "dm/" + currentConversation.id).then(function(attachments) {
        sendDmMessage(encodeAttachments(attachments));
      }).catch(function(err) {
        toast("No se pudo enviar el audio. " + (err && err.message ? err.message : ""));
      });
    });
  });
  supabase.from("dm_conversations").select("*").eq("id", conversationId).single().then(function(res) {
    if (res.error || !res.data) return;
    currentConversation.dmRow = res.data;
    renderDmCinemaBlock();
    renderDmRequestState();
    if (dmCinemaPollTimer) clearInterval(dmCinemaPollTimer);
    dmCinemaPollTimer = setInterval(pollDmCinemaState, 4e3);
  });
}

function renderDmRequestState() {
  var banner = $("dmRequestBanner");
  var input = $("dmInput");
  var sendBtn = $("btnSendDm");
  if (!banner || !currentConversation || !currentConversation.dmRow) return;
  var row = currentConversation.dmRow;
  var status = row.status || "accepted";
  if (status !== "pending") {
    banner.hidden = true;
    banner.innerHTML = "";
    if (input) input.disabled = false;
    if (sendBtn) sendBtn.disabled = false;
    return;
  }
  if (input) input.disabled = true;
  if (sendBtn) sendBtn.disabled = true;
  banner.hidden = false;
  if (row.requested_by === currentUser.id) {
    banner.innerHTML = '<div class="dm-request-waiting">Solicitud de chat enviada. Espera a que ' + escapeHtml(currentConversation.otherName) + " la acepte para poder seguir escribiendo.</div>";
  } else {
    banner.innerHTML = '<div class="dm-request-ask">' + escapeHtml(currentConversation.otherName) + " quiere chatear contigo.</div>" + '<div class="dm-request-actions">' + '<button class="btn-primary" id="btnDmRequestAccept" type="button">Aceptar solicitud</button>' + '<button class="btn-ghost" id="btnDmRequestReject" type="button">Rechazar</button>' + "</div>";
    var acceptBtn = $("btnDmRequestAccept");
    if (acceptBtn) acceptBtn.addEventListener("click", function() {
      acceptBtn.disabled = true;
      supabase.rpc("respond_dm_request", {
        p_conversation_id: currentConversation.id,
        p_accept: true
      }).then(function(res) {
        if (res.error) {
          acceptBtn.disabled = false;
          toast(t("dm.err_accept") + " " + res.error.message);
          return;
        }
        currentConversation.dmRow = res.data;
        renderDmRequestState();
        loadDmMessages();
      });
    });
    var rejectBtn = $("btnDmRequestReject");
    if (rejectBtn) rejectBtn.addEventListener("click", function() {
      if (!confirm("¿Rechazar esta solicitud de chat? Se borrará este mensaje.")) return;
      rejectBtn.disabled = true;
      supabase.rpc("respond_dm_request", {
        p_conversation_id: currentConversation.id,
        p_accept: false
      }).then(function(res) {
        if (res.error) {
          rejectBtn.disabled = false;
          toast(t("dm.err_reject") + " " + res.error.message);
          return;
        }
        toast(t("dm.toast_rejected"));
        closeConversation();
      });
    });
  }
}

function closeConversation() {
  z3tRealtimeStop("dmsg");
  z3tRealtimeStop("dmsg");
  if (dmMessagesPollTimer) {
    clearInterval(dmMessagesPollTimer);
    dmMessagesPollTimer = null;
  }
  if (dmCinemaPollTimer) {
    clearInterval(dmCinemaPollTimer);
    dmCinemaPollTimer = null;
  }
  if (typeof stopRoleplayPanel === "function" && typeof rpScope !== "undefined" && rpScope === "dm") stopRoleplayPanel();
  var c = currentConversation;
  minimizeActivityVoice(c ? function() {
    openConversation(c.id, c.otherId, c.otherUsername, c.otherName, c.otherAvatar, c.otherNameColor, c.otherRole, c.otherVerified);
  } : null);
  currentConversation = null;
  exitImmersive("conversation");
  $("panel-conversation").classList.remove("active");
  goBack("panel-messages");
  loadConversations();
  if (typeof loadPrivateGroups === "function") loadPrivateGroups();
}

function dmRoleFn() {
  return "admin";
}

function toggleDmVoiceCall() {
  if (!currentUser || !currentConversation) return;
  if (activityVoiceRoom && activityVoiceKind === "dm") {
    leaveActivityVoice();
    renderActivityVoiceBar();
    return;
  }
  ensureActivityVoiceConnected("dm", currentConversation.id, dmRoleFn).then(function() {
    if (activityVoiceRoom) activityRaiseHand();
  });
}

var dmCinemaPollTimer = null;

var dmYtPlayer = null;

function setDmActivity(mode) {
  if (!currentUser || !currentConversation) return;
  var convId = currentConversation.id;
  var patch = {
    active_activity: mode
  };
  var prev = currentConversation.dmRow || {};
  if (mode === "cinema" && prev.active_activity !== "cinema") {
    patch.cinema_video_url = null;
    patch.cinema_is_playing = false;
    patch.cinema_position_seconds = 0;
  }
  currentConversation.dmRow = Object.assign({}, prev, patch);
  renderDmCinemaBlock();
  supabase.from("dm_conversations").update(patch).eq("id", convId).select().then(function(res) {
    if (res.error) {
      toast(t("dm.err_activity_change") + " " + res.error.message);
      currentConversation.dmRow = prev;
      renderDmCinemaBlock();
      return;
    }
    if (!res.data || !res.data.length) {
      toast(t("dm.err_activity_change"));
      currentConversation.dmRow = prev;
      renderDmCinemaBlock();
      return;
    }
    if (currentConversation && currentConversation.id === convId) {
      currentConversation.dmRow = res.data[0];
      renderDmCinemaBlock();
    }
  });
}

function dmCinemaPosition(row) {
  var base = Number(row.cinema_position_seconds) || 0;
  if (row.cinema_is_playing && row.cinema_updated_at) {
    base += (Date.now() - new Date(row.cinema_updated_at).getTime()) / 1e3;
  }
  return Math.max(0, base);
}

function renderDmCinemaBlock() {
  var wrap = $("dmCinemaWrap");
  if (!wrap) return;
  var row = currentConversation.dmRow;
  if (row && row.active_activity === "roleplay") {
    if (typeof activityVoiceRoom !== "undefined" && activityVoiceRoom && activityVoiceKind === "dm") leaveActivityVoice();
    var dmVb = $("dmVoiceBar");
    if (dmVb) {
      dmVb.hidden = true;
      dmVb.innerHTML = "";
    }
    if (!$("dmRoleplayWrap")) wrap.innerHTML = '<div class="roleplay-wrap" id="dmRoleplayWrap"></div>';
    if (typeof initRoleplayPanel === "function") initRoleplayPanel(row, "admin", "dm");
    return;
  }
  if (typeof stopRoleplayPanel === "function" && typeof rpScope !== "undefined" && rpScope === "dm") stopRoleplayPanel();
  if (!row || row.active_activity !== "cinema") {
    wrap.innerHTML = "";
    return;
  }
  wrap.innerHTML = '<div class="cinema-player-wrap" id="dmCinemaPlayerWrap">' + '<div class="cinema-player-inner" id="dmCinemaPlayer"></div>' + '<div class="cinema-corner-controls">' + (row.cinema_video_url ? '<button class="icon-btn" id="btnDmCinemaPlayPause" type="button" aria-label="Reproducir/Pausar">' + (row.cinema_is_playing ? pauseSvg() : playSvg()) + "</button>" : "") + '<button class="icon-btn" id="btnDmCinemaOptionsToggle" type="button" aria-label="Opciones de video">' + cinemaGearSvg() + "</button>" + '<button class="icon-btn" id="btnDmCinemaExpandToggle" type="button" aria-label="Agrandar/Achicar">' + stageExpandSvg() + "</button>" + '<button class="icon-btn" id="btnDmCinemaClose" type="button" aria-label="Apagar Sala de Cine" title="Apagar Sala de Cine">' + closeXSvg() + "</button>" + "</div>" + '<div class="cinema-options-popup" id="dmCinemaOptionsPopup">' + "<label>Video por URL</label>" + '<form class="cinema-option-row" id="dmCinemaVideoForm">' + '<input type="text" id="dmCinemaUrlInput" placeholder="Pega una URL de YouTube o de video...">' + '<button class="icon-btn" type="submit" aria-label="Poner video">' + playSvg() + "</button>" + "</form>" + "</div>" + "</div>";
  mountDmCinemaPlayer();
  var playPauseBtn = $("btnDmCinemaPlayPause");
  if (playPauseBtn) playPauseBtn.addEventListener("click", toggleDmCinemaPlayPause);
  var expandBtn = $("btnDmCinemaExpandToggle");
  if (expandBtn) expandBtn.addEventListener("click", function() {
    var w = $("dmCinemaPlayerWrap");
    if (w) {
      w.classList.toggle("cinema-expanded");
      expandBtn.innerHTML = w.classList.contains("cinema-expanded") ? stageCompressSvg() : stageExpandSvg();
    }
  });
  var cinemaCloseBtn = $("btnDmCinemaClose");
  if (cinemaCloseBtn) cinemaCloseBtn.addEventListener("click", function() {
    if (confirm("¿Apagar la Sala de Cine de esta conversación?")) setDmActivity(null);
  });
  var cinemaOptionsToggle = $("btnDmCinemaOptionsToggle"), cinemaOptionsPopup = $("dmCinemaOptionsPopup");
  if (cinemaOptionsToggle) cinemaOptionsToggle.addEventListener("click", function(e) {
    e.stopPropagation();
    cinemaOptionsPopup.classList.toggle("open");
  });
  if (cinemaOptionsPopup) cinemaOptionsPopup.addEventListener("click", function(e) {
    e.stopPropagation();
  });
  var cinemaForm = $("dmCinemaVideoForm");
  if (cinemaForm) cinemaForm.addEventListener("submit", function(e) {
    e.preventDefault();
    var url = $("dmCinemaUrlInput").value.trim();
    if (url) {
      setDmCinemaVideo(url);
      if (cinemaOptionsPopup) cinemaOptionsPopup.classList.remove("open");
    }
  });
}

function mountDmCinemaPlayer() {
  var wrap = $("dmCinemaPlayer");
  if (!wrap) return;
  var row = currentConversation.dmRow;
  if (!row.cinema_video_url) {
    wrap.innerHTML = '<div class="cinema-player-empty">Todavía no hay ningún video puesto.</div>';
    return;
  }
  var startPos = dmCinemaPosition(row);
  if (row.cinema_video_type === "youtube") {
    var parsed = parseVideoUrl(row.cinema_video_url);
    wrap.innerHTML = '<div id="dmYtPlayerMount"></div>';
    loadYouTubeApi().then(function(YT) {
      if (!$("dmYtPlayerMount")) return;
      dmYtPlayer = new YT.Player("dmYtPlayerMount", {
        videoId: parsed.id,
        playerVars: {
          autoplay: row.cinema_is_playing ? 1 : 0,
          start: Math.floor(startPos)
        },
        events: {
          onReady: function(ev) {
            if (row.cinema_is_playing) ev.target.playVideo(); else ev.target.pauseVideo();
          }
        }
      });
    });
  } else {
    wrap.innerHTML = '<video id="dmDirectVideoEl" src="' + safeUrlAttr(row.cinema_video_url) + '" ' + (row.cinema_is_playing ? "autoplay" : "") + " controls></video>";
    var v = $("dmDirectVideoEl");
    if (v) {
      v.currentTime = startPos;
      if (!row.cinema_is_playing) v.pause();
    }
  }
}

function setDmCinemaVideo(url) {
  if (!currentUser || !currentConversation) return;
  var parsed = parseVideoUrl(url);
  supabase.from("dm_conversations").update({
    cinema_video_url: url,
    cinema_video_type: parsed.type,
    cinema_is_playing: true,
    cinema_position_seconds: 0,
    cinema_updated_at: (new Date).toISOString()
  }).eq("id", currentConversation.id).select().single().then(function(res) {
    if (res.error) {
      toast(t("dm.err_video_set") + " " + res.error.message);
      return;
    }
    currentConversation.dmRow = res.data;
    renderDmCinemaBlock();
  });
}

function toggleDmCinemaPlayPause() {
  if (!currentUser || !currentConversation) return;
  var row = currentConversation.dmRow;
  var newPlaying = !row.cinema_is_playing;
  var pos = dmCinemaPosition(row);
  supabase.from("dm_conversations").update({
    cinema_is_playing: newPlaying,
    cinema_position_seconds: pos,
    cinema_updated_at: (new Date).toISOString()
  }).eq("id", currentConversation.id).select().single().then(function(res) {
    if (res.error) return;
    currentConversation.dmRow = res.data;
    applySyncedDmCinemaState(res.data);
    var btn = $("btnDmCinemaPlayPause");
    if (btn) btn.innerHTML = res.data.cinema_is_playing ? pauseSvg() : playSvg();
  });
}

function applySyncedDmCinemaState(row) {
  var pos = dmCinemaPosition(row);
  if (row.cinema_video_type === "youtube" && dmYtPlayer && dmYtPlayer.seekTo) {
    dmYtPlayer.seekTo(pos, true);
    if (row.cinema_is_playing) dmYtPlayer.playVideo(); else dmYtPlayer.pauseVideo();
  } else {
    var v = $("dmDirectVideoEl");
    if (v) {
      v.currentTime = pos;
      if (row.cinema_is_playing) v.play().catch(function() {}); else v.pause();
    }
  }
}

function pollDmCinemaState() {
  if (!currentConversation) return;
  supabase.from("dm_conversations").select("*").eq("id", currentConversation.id).single().then(function(res) {
    if (res.error || !res.data) return;
    var row = res.data;
    var prev = currentConversation.dmRow || {};
    var changed = row.cinema_updated_at !== prev.cinema_updated_at || row.active_activity !== prev.active_activity;
    var videoChanged = row.cinema_video_url !== prev.cinema_video_url;
    currentConversation.dmRow = row;
    if (!changed) return;
    if (videoChanged || row.active_activity !== "cinema") {
      renderDmCinemaBlock();
    } else {
      applySyncedDmCinemaState(row);
      var btn = $("btnDmCinemaPlayPause");
      if (btn) btn.innerHTML = row.cinema_is_playing ? pauseSvg() : playSvg();
    }
  });
}

document.addEventListener("click", function() {
  var p = $("dmActivitiesPopup");
  if (p) p.classList.remove("open");
  var mp = $("dmMorePopup");
  if (mp) mp.classList.remove("open");
  var c = $("dmCinemaOptionsPopup");
  if (c) c.classList.remove("open");
});

function loadDmMessages() {
  if (!currentConversation) return Promise.resolve();
  return supabase.from("dm_messages").select("*").eq("conversation_id", currentConversation.id).order("created_at", {
    ascending: false
  }).limit(200).then(function(res) {
    if (res.error) {
      console.error("Error cargando mensajes directos:", res.error);
      return;
    }
    DM_MESSAGES = z3tProcessReplies((res.data || []).slice().reverse());
    renderDmMessages();
  });
}

function renderDmMessages() {
  var chat = $("conversationMessages");
  if (!chat) return;
  if (!DM_MESSAGES.length) {
    chat.innerHTML = '<p class="empty-state">Todavía no hay mensajes. ¡Escribe el primero!</p>';
    chat.dataset.msgSig = "";
    return;
  }
  var sig = messagesSignature(DM_MESSAGES);
  if (chat.dataset.msgSig === sig) return;
  var wasNearBottom = !chat.dataset.msgSig || isNearBottom(chat);
  var prevGroupKey = null;
  chat.innerHTML = DM_MESSAGES.map(function(m) {
    var mine = currentUser && m.sender_id === currentUser.id;
    var name = mine ? currentUser.name || currentUser.username : currentConversation.otherName;
    var avatarUrl = mine ? currentUser.avatarUrl : currentConversation.otherAvatar;
    var nameColor = mine ? currentUser.nameColor : currentConversation.otherNameColor;
    var acctRole = mine ? currentUser.role : currentConversation.otherRole;
    var acctVerified = mine ? currentUser.verified : currentConversation.otherVerified;
    var uid = mine ? currentUser.id : currentConversation.otherId;
    var dmRpm = typeof rpDecodeMessage === "function" && m.type !== "gift" ? rpDecodeMessage(m) : null;
    if (dmRpm) {
      name = dmRpm.name;
      avatarUrl = dmRpm.avatar;
      nameColor = null;
      acctRole = null;
      acctVerified = null;
    }
    var bodyHtml;
    if (m.type === "gift") {
      bodyHtml = giftCardMessageHtml(m.body);
    } else {
      var parsedDm = parseAttachments(dmRpm ? dmRpm.body : m.body);
      bodyHtml = (parsedDm.text ? '<div class="chat-msg-text">' + z3tRichText(parsedDm.text) + "</div>" : "") + renderAttachments(parsedDm.attachments);
    }
    var rpc = dmRpm && typeof rpMsgColor === "function" ? rpMsgColor(m, name) : null;
    var groupKey = (dmRpm ? "rp:" + dmRpm.name : "u:" + uid) + (m.type === "gift" ? ":gift" : "");
    var isCont = prevGroupKey === groupKey;
    prevGroupKey = groupKey;
    return '<div class="chat-msg' + (mine ? " mine" : "") + (isCont ? " chat-msg-cont" : "") + '"' + z3tMsgAttrs("dm", m, name) + '>' + rpTintAvatar(avatarSpanHtml(name, avatarUrl, null, dmRpm ? null : uid), rpc) + '<div class="chat-msg-col">' + '<div class="chat-msg-name" data-uid="' + escapeHtml(dmRpm ? "" : uid || "") + '"' + (nameColor ? ' style="color:' + escapeHtml(nameColor) + '"' : "") + ">" + escapeHtml(name) + roleBadgeHtml(acctRole, acctVerified) + "</div>" + z3tReplyQuoteHtml(m) + chatMsgBodyOpenTag(uid, rpc) + bodyHtml + "</div>" + z3tReactionsSlotHtml(m) + "</div>" + "</div>";
  }).join("");
  chat.dataset.msgSig = sig;
  if (wasNearBottom) chat.scrollTop = chat.scrollHeight;
  z3tAfterRender("dm");
}

function sendDmMessage(attachSuffix) {
  if (!currentUser || !currentConversation) return;
  var input = $("dmInput");
  var body = input.value.trim() + (attachSuffix || "");
  if (!body.trim()) return;
  var dmCh = currentConversation.dmRow && currentConversation.dmRow.active_activity === "roleplay" && typeof myActiveRoleplayCharacter === "function" ? myActiveRoleplayCharacter() : null;
  if (dmCh && typeof rpEncodeBody === "function") body = rpEncodeBody(dmCh, body);
  body = z3tWithReply("dm", body);
  input.disabled = true;
  supabase.rpc("send_dm_message", {
    p_conversation_id: currentConversation.id,
    p_body: body
  }).then(function(res) {
    if (res.error) {
      input.disabled = false;
      toast(t("dm.err_send") + " " + res.error.message);
      return;
    }
    input.disabled = false;
    input.value = "";
    z3tClearReply();
    input.focus();
    loadDmMessages();
    markConversationRead();
    awardAchievement(currentUser.id, "first_chat");
    supabase.from("dm_conversations").select("*").eq("id", currentConversation.id).single().then(function(convRes) {
      if (convRes.error || !convRes.data) return;
      currentConversation.dmRow = convRes.data;
      renderDmRequestState();
    });
  });
}

function markConversationReadById(conversationId) {
  var c = DM_CONVERSATIONS.filter(function(x) {
    return x.id === conversationId;
  })[0];
  if (!c || !currentUser) return Promise.resolve();
  var pair = [ currentUser.id, c.otherId ].sort();
  var isA = pair[0] === currentUser.id;
  var patch = {};
  patch[isA ? "last_read_a" : "last_read_b"] = (new Date).toISOString();
  return supabase.from("dm_conversations").update(patch).eq("id", conversationId).then(function() {
    c.unread = false;
    renderMergedPrivadoList();
    if (typeof updateDmBadge === "function") updateDmBadge();
  });
}

function markConversationRead() {
  if (!currentUser || !currentConversation) return;
  return markConversationReadById(currentConversation.id);
}

var CHATS_TAB = "privado";

function switchChatsTab(tab) {
  CHATS_TAB = tab;
  qsa(".chats-tab", $("chatsTabbar")).forEach(function(btn) {
    btn.classList.toggle("active", btn.getAttribute("data-chats-tab") === tab);
  });
  $("dmChatsTab").hidden = tab !== "privado";
  $("salasChatsTab").hidden = tab !== "salas";
  $("invitacionesChatsTab").hidden = tab !== "invitaciones";
  $("gestionadosChatsTab").hidden = tab !== "gestionados";
  $("pinnedRows").hidden = tab !== "privado" || $("pinnedRows").hidden;
  if ($("chatsSearchInput")) $("chatsSearchInput").value = "";
  if (tab === "salas") loadSalasTab(); else if (tab === "invitaciones") loadInvitacionesTab(); else if (tab === "gestionados") loadGestionadosTab();
}

qsa(".chats-tab", $("chatsTabbar")).forEach(function(btn) {
  btn.addEventListener("click", function() {
    switchChatsTab(btn.getAttribute("data-chats-tab"));
  });
});

if ($("chatsSearchInput")) {
  $("chatsSearchInput").addEventListener("input", function() {
    var q = this.value.trim().toLowerCase();
    var activePanelMap = {
      privado: "dmChatsTab",
      salas: "salasChatsTab",
      invitaciones: "invitacionesChatsTab",
      gestionados: "gestionadosChatsTab"
    };
    var panel = $(activePanelMap[CHATS_TAB]);
    if (!panel) return;
    qsa(".dm-card", panel).forEach(function(card) {
      var name = (card.querySelector(".dm-card-name") || {}).textContent || "";
      card.hidden = q.length > 0 && name.toLowerCase().indexOf(q) === -1;
    });
  });
}

function communityRowHtml(c, footText) {
  return '<article class="dm-card" data-kind="community" data-id="' + escapeHtml(c.id) + '" data-slug="' + escapeHtml(c.slug) + '">' + avatarSpanHtml(c.name, c.thumbnail_url || c.banner_url) + '<div class="dm-card-main">' + '<div class="dm-card-top"><span class="dm-card-name">' + escapeHtml(c.name) + "</span></div>" + '<div class="dm-card-preview">' + escapeHtml(footText || "") + "</div>" + "</div>" + "</article>";
}

function loadSalasTab() {
  if (!currentUser) return;
  var list = $("salasList");
  list.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("community_members").select("role, communities(*)").eq("user_id", currentUser.id).then(function(res) {
    var rows = (res.error ? [] : res.data || []).filter(function(r) {
      return r.communities;
    });
    $("salasEmptyState").hidden = rows.length > 0;
    list.innerHTML = rows.map(function(r) {
      return communityRowHtml(r.communities, r.role === "admin" ? "Creador/Admin" : r.role === "co_admin" ? "Co-Admin" : "Miembro");
    }).join("");
    qsa(".dm-card", list).forEach(function(card, i) {
      var slug = card.getAttribute("data-slug");
      var id = card.getAttribute("data-id");
      var c = rows[i].communities;
      wireLongPressPin(card, "community", id, function() {
        if (!confirm('¿Salir de "' + c.name + '"?')) return;
        supabase.rpc("leave_community", {
          p_community_id: id
        }).then(function(res2) {
          if (res2.error) {
            toast(t("dm.err_leave_community"));
            return;
          }
          toast(t("dm.toast_left_community") + ' "' + c.name + '".');
          loadSalasTab();
        });
      });
      card.addEventListener("click", function() {
        openCommunity(slug);
      });
    });
  });
}

function loadInvitacionesTab() {
  if (!currentUser) return;
  var list = $("invitacionesList");
  list.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("community_invites").select("id, communities(*), profiles!community_invites_inviter_id_fkey(username, name)").eq("invitee_id", currentUser.id).eq("status", "pending").then(function(res) {
    var rows = (res.error ? [] : res.data || []).filter(function(r) {
      return r.communities;
    });
    $("invitacionesTabDot").hidden = !rows.length;
    $("invitacionesEmptyState").hidden = rows.length > 0;
    list.innerHTML = rows.map(function(r) {
      var inviterName = r.profiles ? r.profiles.name || r.profiles.username : "alguien";
      return '<article class="dm-card" data-invite-id="' + escapeHtml(r.id) + '">' + avatarSpanHtml(r.communities.name, r.communities.thumbnail_url || r.communities.banner_url) + '<div class="dm-card-main">' + '<div class="dm-card-top"><span class="dm-card-name">' + escapeHtml(r.communities.name) + "</span></div>" + '<div class="dm-card-preview">' + escapeHtml(inviterName) + " te invitó</div>" + "</div>" + '<div class="chat-invite-actions">' + '<button type="button" class="link-btn" data-act="decline">Rechazar</button>' + '<button type="button" class="terminal-btn small" data-act="accept">Unirme</button>' + "</div>" + "</article>";
    }).join("");
    qsa(".dm-card", list).forEach(function(card, i) {
      var inviteId = card.getAttribute("data-invite-id");
      var row = rows[i];
      card.querySelector('[data-act="accept"]').addEventListener("click", function(e) {
        e.stopPropagation();
        supabase.rpc("respond_community_invite", {
          p_invite_id: inviteId,
          p_accept: true
        }).then(function(res2) {
          if (res2.error) {
            toast(t("dm.err_accept2"));
            return;
          }
          toast(t("dm.toast_joined_community") + ' "' + row.communities.name + '"!');
          loadInvitacionesTab();
        });
      });
      card.querySelector('[data-act="decline"]').addEventListener("click", function(e) {
        e.stopPropagation();
        supabase.rpc("respond_community_invite", {
          p_invite_id: inviteId,
          p_accept: false
        }).then(function(res2) {
          if (res2.error) {
            toast(t("dm.err_reject2"));
            return;
          }
          loadInvitacionesTab();
        });
      });
    });
  });
}

function loadGestionadosTab() {
  if (!currentUser) return;
  var list = $("gestionadosList");
  list.innerHTML = '<p class="profile-empty-hint">Cargando...</p>';
  supabase.from("community_members").select("role, communities(*)").eq("user_id", currentUser.id).in("role", [ "admin", "co_admin" ]).then(function(res) {
    var rows = (res.error ? [] : res.data || []).filter(function(r) {
      return r.communities;
    });
    $("gestionadosEmptyState").hidden = rows.length > 0;
    list.innerHTML = rows.map(function(r) {
      return communityRowHtml(r.communities, r.role === "admin" ? "Creador/Admin" : "Co-Admin");
    }).join("");
    qsa(".dm-card", list).forEach(function(card, i) {
      var slug = card.getAttribute("data-slug");
      var id = card.getAttribute("data-id");
      var c = rows[i].communities;
      wireLongPressPin(card, "community", id, function() {
        if (!confirm('¿Salir de "' + c.name + '"? Sigues siendo admin/co-admin para los demás hasta que vuelvas a entrar.')) return;
        supabase.rpc("leave_community", {
          p_community_id: id
        }).then(function(res2) {
          if (res2.error) {
            toast(t("dm.err_leave_community"));
            return;
          }
          toast(t("dm.toast_left_community") + ' "' + c.name + '".');
          loadGestionadosTab();
        });
      });
      card.addEventListener("click", function() {
        openCommunity(slug);
      });
    });
  });
}

function refreshInvitacionesBadge() {
  if (!currentUser) return;
  supabase.from("community_invites").select("id", {
    count: "exact",
    head: true
  }).eq("invitee_id", currentUser.id).eq("status", "pending").then(function(res) {
    $("invitacionesTabDot").hidden = !(res.count > 0);
  });
}