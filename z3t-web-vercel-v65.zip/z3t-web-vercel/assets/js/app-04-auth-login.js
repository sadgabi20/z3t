"use strict";

function selfHealProfile(userId) {
  return supabase.auth.getUser().then(function(res) {
    var u = res.data && res.data.user;
    if (!u || u.id !== userId) return null;
    var meta = u.user_metadata || {};
    var base = meta.username || meta.user_name || meta.preferred_username || meta.full_name || meta.name || (u.email ? u.email.split("@")[0] : null) || "usuario_" + userId.slice(0, 8);
    var username = String(base).toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 24) || "usuario_" + userId.slice(0, 8);
    return supabase.from("profiles").insert({
      id: userId,
      username: username,
      avatar_url: meta.avatar_url || meta.picture || null
    }).then(function(insRes) {
      if (insRes.error) {
        username = username + "_" + userId.slice(0, 4);
        return supabase.from("profiles").insert({
          id: userId,
          username: username,
          avatar_url: meta.avatar_url || meta.picture || null
        });
      }
      return insRes;
    }).then(function(insRes2) {
      if (insRes2 && insRes2.error) throw insRes2.error;
      return fetchIpAndLocation().then(function(net) {
        return supabase.from("profile_private").insert({
          id: userId,
          ip: net.ip,
          device: detectDevice(),
          location: net.location
        }).then(function(privRes) {
          if (privRes && privRes.error) console.error("[selfHealProfile] profiles OK pero profile_private falló:", privRes.error);
        });
      });
    }).catch(function(err) {
      console.error("[selfHealProfile] no se pudo autocrear el perfil:", err);
      throw err;
    });
  });
}

function fetchProfile(userId, attempt) {
  return supabase.rpc("rpc_get_my_profile").then(function(rpcRes) {
    var row = rpcRes.data && rpcRes.data[0];
    var res = row ? {
      data: row
    } : {
      error: rpcRes.error || {
        message: "not found"
      }
    };
    if (res.error || !res.data) {
      if ((attempt || 0) < 3) {
        return new Promise(function(resolve) {
          setTimeout(resolve, 400);
        }).then(function() {
          return fetchProfile(userId, (attempt || 0) + 1);
        });
      }
      if ((attempt || 0) === 3) {
        return selfHealProfile(userId).catch(function(err) {
          fetchProfile.lastSelfHealError = err;
          return null;
        }).then(function() {
          return fetchProfile(userId, 99);
        });
      }
      return null;
    }
    return {
      id: res.data.id,
      username: res.data.username,
      avatarUrl: res.data.avatar_url,
      bannerUrl: res.data.banner_url,
      zcardAvatarUrl: res.data.zcard_avatar_url,
      bio: res.data.bio,
      profileLocation: res.data.location_public,
      chatBackgroundUrl: res.data.chat_background_url,
      circleId: res.data.circle_id,
      notifyCircleIds: res.data.notify_circle_ids || [],
      handleSet: res.data.handle_set === true,
      ip: res.data.ip,
      device: res.data.device,
      location: res.data.location,
      region: res.data.region || "LATAM",
      joinedAt: res.data.joined_at,
      threadsCount: res.data.threads_count,
      repliesCount: res.data.replies_count,
      followersCount: res.data.followers_count,
      followingCount: res.data.following_count,
      role: res.data.role || "user",
      verified: res.data.verified === true,
      isVolunteer: res.data.is_volunteer === true,
      banned: res.data.banned === true,
      nameColor: res.data.name_color || null,
      name: res.data.name || null,
      isOwner: res.data.is_owner === true
    };
  });
}

var deviceSessionPollTimer = null;

function stopDeviceSessionWatch() {
  if (deviceSessionPollTimer) {
    clearInterval(deviceSessionPollTimer);
    deviceSessionPollTimer = null;
  }
}

function forceLogoutOtherDevice() {
  stopDeviceSessionWatch();
  toast("Tu cuenta se inició en otro dispositivo. Se cerró la sesión aquí.");
  supabase.auth.signOut().then(function() {
    currentUser = null;
    showView("landing");
  });
}

function checkDeviceSessionNow(deviceId) {
  if (!currentUser) return;
  supabase.rpc("check_device_session", {
    p_device_id: deviceId
  }).then(function(res) {
    if (res.error) return;
    if (res.data === false) forceLogoutOtherDevice();
  });
}

function startDeviceSessionWatch(deviceId) {
  stopDeviceSessionWatch();
  deviceSessionPollTimer = setInterval(function() {
    if (!document.hidden) checkDeviceSessionNow(deviceId);
  }, 9e4);
}

document.addEventListener("visibilitychange", function() {
  if (!document.hidden && currentUser && deviceSessionPollTimer) checkDeviceSessionNow(getDeviceId());
});

function claimDeviceSession() {
  var deviceId = getDeviceId();
  supabase.rpc("claim_device_session", {
    p_device_id: deviceId
  }).then(function() {}, function() {});
  startDeviceSessionWatch(deviceId);
}

function enterForum() {
  if (currentUser && currentUser.region) I18N.applyLanguage(currentUser.region);
  if (currentUser && currentUser.banned === true) {
    showView("banned");
    return;
  }
  if (currentUser && currentUser.handleSet !== true) {
    showHandleGate();
    return;
  }
  enterForumInner();
}

var btnBannedLogoutEl = $("btnBannedLogout");

if (btnBannedLogoutEl) btnBannedLogoutEl.addEventListener("click", function() {
  stopDeviceSessionWatch();
  supabase.auth.signOut().then(function() {
    currentUser = null;
    showView("landing");
  });
});

function showHandleGate() {
  var name = currentUser && currentUser.name || currentUser && currentUser.username || "usuario";
  generateAvailableHandle(name, currentUser.id).then(function(handle) {
    return supabase.from("profiles").update({
      username: handle,
      handle_set: true
    }).eq("id", currentUser.id);
  }).then(function(res) {
    if (!res || !res.error) {
      supabase.from("profiles").select("username").eq("id", currentUser.id).single().then(function(r) {
        if (r.data) currentUser.username = r.data.username;
        currentUser.handleSet = true;
        enterForumInner();
      });
    } else {
      currentUser.handleSet = true;
      enterForumInner();
    }
  }).catch(function() {
    currentUser.handleSet = true;
    enterForumInner();
  });
}

function enterForumInner() {
  claimDeviceSession();
  if (window.Z3TAccountPrefs) window.Z3TAccountPrefs.pull();
  setAvatarEl($("topAvatar"), currentUser.username, currentUser.avatarUrl);
  $("topAvatar").setAttribute("data-uid", currentUser.id);
  queueFrameLookup(currentUser.id);
  $("topUsername").textContent = currentUser.username;
  state.query = "";
  state.sort = "recent";
  $("searchInput").value = "";
  qsa(".tab", $("tabs")).forEach(function(t) {
    t.classList.toggle("active", t.getAttribute("data-sort") === "recent");
  });
  activatePanel("panel-list");
  showView("app");
  Promise.all([ loadThreads(), loadCommunities(), loadCircles(), loadConversations() ].map(function(p) {
    return p.catch(function(err) {
      console.error("[enterForumInner] fallo cargando datos iniciales:", err);
      return null;
    });
  })).then(function() {
    renderSidebar();
    renderThreadList();
    renderTopCommunitiesStrip();
    if (typeof renderExploreCircles === "function") renderExploreCircles();
    if (typeof loadAnnouncements === "function") loadAnnouncements();
    loadMeetOrbit();
    resolvePendingRoute();
  });
  loadNotifications();
  if (notifPollTimer) clearInterval(notifPollTimer);
  notifPollTimer = setInterval(function() {
    if (!document.hidden) loadNotifications();
  }, 12e4);
  z3tRealtime("notif", "notifications", "recipient_id=eq." + currentUser.id, function() {
    loadNotifications();
  }, "*");
  if (typeof z3tAutoEnableDeviceNotifs === "function") z3tAutoEnableDeviceNotifs();
  startGiftPolling();
  if (typeof startMassGiftPolling === "function") startMassGiftPolling();
  if (typeof startCommunityActivityBadgePolling === "function") startCommunityActivityBadgePolling();
}