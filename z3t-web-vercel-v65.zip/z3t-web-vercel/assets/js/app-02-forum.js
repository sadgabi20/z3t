"use strict";

var THREADS = [];

function mapThreadRow(row) {
  return {
    id: row.id,
    slug: row.slug,
    pinned: row.pinned,
    title: row.title,
    author: "usuario",
    authorId: row.author_id,
    authorAvatar: null,
    time: row.created_at,
    replies: row.replies,
    views: row.views,
    tags: row.tags || [],
    excerpt: row.excerpt,
    coverImage: row.cover_image_url || null,
    coverImages: row.cover_images || [],
    circleId: row.circle_id || null,
    circleName: row.circles ? row.circles.name : null,
    postType: row.post_type === "info" ? "info" : "normal",
    posts: null
  };
}

var THREAD_LIKES = {};

function loadThreads() {
  var limit = state.threadLimit || 30;
  var q = supabase.from("threads").select("*");
  q = q.eq("region", currentUser && currentUser.region || "LATAM");
  var s = String(state.query || "").trim().replace(/[%,()*\\:"']/g, " ").replace(/\s+/g, " ").slice(0, 60);
  if (s) q = q.or("title.ilike.%" + s + "%,excerpt.ilike.%" + s + "%");
  if (state.sort === "popular") {
    q = q.order("replies", {
      ascending: false
    });
  } else if (state.sort === "unanswered") {
    q = q.lt("replies", 15).order("replies", {
      ascending: true
    });
  } else {
    q = q.order("pinned", {
      ascending: false
    });
  }
  return q.order("created_at", {
    ascending: false
  }).limit(limit + 1).then(function(res) {
    if (res.error) {
      toast(t("forum.err_threads"));
      return;
    }
    Z3T_THREADS_HAS_MORE = res.data.length > limit;
    THREADS = res.data.slice(0, limit).map(mapThreadRow);
    return Promise.all([ loadThreadAuthors(), loadThreadCircleNames(), loadThreadLikes() ]);
  });
}

function loadThreadAuthors() {
  var authorIds = THREADS.map(function(t) {
    return t.authorId;
  }).filter(function(id) {
    return id;
  });
  authorIds = authorIds.filter(function(id, i) {
    return authorIds.indexOf(id) === i;
  });
  if (!authorIds.length) return Promise.resolve();
  return supabase.from("profiles").select("id, username, name, avatar_url, name_color, role, verified").in("id", authorIds).then(function(res) {
    if (res.error) return;
    var profileMap = {};
    (res.data || []).forEach(function(p) {
      profileMap[p.id] = p;
    });
    THREADS.forEach(function(t) {
      var p = profileMap[t.authorId];
      if (p) {
        t.author = p.name || p.username;
        t.authorAvatar = p.avatar_url;
        t.authorNameColor = p.name_color;
        t.authorRole = p.role;
        t.authorVerified = p.verified;
      }
    });
  });
}

function loadThreadCircleNames() {
  var circleIds = THREADS.map(function(t) {
    return t.circleId;
  }).filter(function(id) {
    return id;
  });
  circleIds = circleIds.filter(function(id, i) {
    return circleIds.indexOf(id) === i;
  });
  if (!circleIds.length) return Promise.resolve();
  return supabase.from("circles").select("id, name").in("id", circleIds).then(function(res) {
    if (res.error) return;
    var nameMap = {};
    (res.data || []).forEach(function(c) {
      nameMap[c.id] = c.name;
    });
    THREADS.forEach(function(t) {
      if (t.circleId && nameMap[t.circleId]) t.circleName = nameMap[t.circleId];
    });
  });
}

var POST_QUICK_REACTIONS = [ "❤️", "😂", "🌸", "😍", "👍", "🔥", "😢", "🙏" ];

function emptyReactionState() {
  return {
    count: 0,
    likedByMe: false,
    myEmoji: null,
    byEmoji: {}
  };
}

function loadThreadLikes() {
  var ids = THREADS.map(function(t) {
    return t.id;
  });
  if (!ids.length) return Promise.resolve();
  return supabase.from("thread_likes").select("thread_id, user_id, emoji").in("thread_id", ids).then(function(res) {
    THREAD_LIKES = {};
    ids.forEach(function(id) {
      THREAD_LIKES[id] = emptyReactionState();
    });
    (res.data || []).forEach(function(row) {
      var st = THREAD_LIKES[row.thread_id];
      if (!st) return;
      var em = row.emoji || "❤️";
      st.count++;
      st.byEmoji[em] = (st.byEmoji[em] || 0) + 1;
      if (currentUser && row.user_id === currentUser.id) {
        st.likedByMe = true;
        st.myEmoji = em;
      }
    });
  });
}

/* Lista de reacciones de una publicación, de la más usada a la menos usada */
function threadReactionPillsHtml(threadId) {
  var st = THREAD_LIKES[threadId];
  if (!st || !st.count) return "";
  var list = Object.keys(st.byEmoji).filter(function(em) {
    return st.byEmoji[em] > 0;
  }).sort(function(x, y) {
    return st.byEmoji[y] - st.byEmoji[x];
  });
  if (!list.length) return "";
  return '<div class="post-reactions">' + list.map(function(em) {
    return '<button type="button" class="react-pill' + (st.myEmoji === em ? " mine" : "") + '" data-action="react-pill" data-id="' + escapeHtml(threadId) + '" data-emoji="' + escapeHtml(em) + '">' + escapeHtml(em) + "<span>" + st.byEmoji[em] + "</span></button>";
  }).join("") + "</div>";
}

function setThreadReaction(threadId, emoji) {
  if (!currentUser) {
    toast(t("forum.login_react"));
    return;
  }
  if (!emoji || emoji.length > 16) return;
  var st = THREAD_LIKES[threadId] || (THREAD_LIKES[threadId] = emptyReactionState());
  var prev = st.myEmoji;
  var removing = prev === emoji;
  if (prev) {
    st.byEmoji[prev] = Math.max(0, (st.byEmoji[prev] || 1) - 1);
    st.count = Math.max(0, st.count - 1);
  }
  if (removing) {
    st.likedByMe = false;
    st.myEmoji = null;
  } else {
    st.byEmoji[emoji] = (st.byEmoji[emoji] || 0) + 1;
    st.count++;
    st.likedByMe = true;
    st.myEmoji = emoji;
  }
  renderThreadList();
  var del = function() {
    return supabase.from("thread_likes").delete().eq("thread_id", threadId).eq("user_id", currentUser.id);
  };
  var op = removing ? del() : prev ? del().then(function(r) {
    return r.error ? r : supabase.from("thread_likes").insert({
      thread_id: threadId,
      user_id: currentUser.id,
      emoji: emoji
    });
  }) : supabase.from("thread_likes").insert({
    thread_id: threadId,
    user_id: currentUser.id,
    emoji: emoji
  });
  op.then(function(res) {
    if (res && res.error) {
      toast("No se pudo guardar la reacción.");
      loadThreadLikes().then(renderThreadList);
    } else if (!removing && !prev) {
      awardAchievement(currentUser.id, "first_like");
    }
  });
}

function closePostReactPicker() {
  var old = document.getElementById("postReactPicker");
  if (old) old.remove();
}

function openPostReactPicker(threadId, anchor) {
  closePostReactPicker();
  if (!currentUser) {
    toast(t("forum.login_react"));
    return;
  }
  var st = THREAD_LIKES[threadId] || emptyReactionState();
  var box = document.createElement("div");
  box.id = "postReactPicker";
  box.className = "post-react-picker";
  box.innerHTML = POST_QUICK_REACTIONS.map(function(em) {
    return '<button type="button" class="z3t-sheet-react' + (st.myEmoji === em ? " mine" : "") + '" data-em="' + escapeHtml(em) + '">' + em + "</button>";
  }).join("") + '<button type="button" class="z3t-sheet-react more" data-more aria-label="Más emojis">＋</button>';
  document.body.appendChild(box);
  var r = anchor.getBoundingClientRect();
  var w = box.offsetWidth;
  var left = Math.min(Math.max(8, r.left), window.innerWidth - w - 8);
  var top = r.top - box.offsetHeight - 8;
  if (top < 8) top = r.bottom + 8;
  box.style.left = left + "px";
  box.style.top = top + "px";
  box.addEventListener("click", function(e) {
    e.stopPropagation();
    var em = e.target.closest("[data-em]");
    var more = e.target.closest("[data-more]");
    if (em) {
      closePostReactPicker();
      setThreadReaction(threadId, em.getAttribute("data-em"));
    } else if (more) {
      closePostReactPicker();
      if (typeof z3tOpenEmojiPanel === "function") z3tOpenEmojiPanel({
        mode: "react",
        onPick: function(em2) {
          setThreadReaction(threadId, em2);
        }
      });
    }
  });
  setTimeout(function() {
    document.addEventListener("click", closePostReactPicker, {
      once: true
    });
  }, 0);
}

function loadThreadPosts(threadId) {
  return supabase.from("posts").select("*").eq("thread_id", threadId).order("created_at", {
    ascending: true
  }).then(function(res) {
    if (res.error) {
      console.error("[comentarios] no se pudieron cargar:", res.error);
      return null;
    }
    var posts = res.data.map(function(p) {
      return {
        id: p.id,
        author: "usuario",
        authorId: p.author_id,
        authorAvatar: null,
        authorNameColor: null,
        authorRole: null,
        authorVerified: null,
        time: p.created_at,
        body: p.body
      };
    });
    var authorIds = posts.map(function(p) {
      return p.authorId;
    }).filter(function(id) {
      return id;
    });
    authorIds = authorIds.filter(function(id, i) {
      return authorIds.indexOf(id) === i;
    });
    if (!authorIds.length) return posts;
    return supabase.from("profiles").select("id, username, name, avatar_url, name_color, role, verified").in("id", authorIds).then(function(pRes) {
      if (pRes.error) return posts;
      var map = {};
      (pRes.data || []).forEach(function(p) {
        map[p.id] = p;
      });
      posts.forEach(function(p) {
        var prof = map[p.authorId];
        if (prof) {
          p.author = prof.name || prof.username;
          p.authorAvatar = prof.avatar_url;
          p.authorNameColor = prof.name_color;
          p.authorRole = prof.role;
          p.authorVerified = prof.verified;
        }
      });
      return posts;
    });
  });
}

var state = {
  sort: "recent",
  query: "",
  suppressPush: false
};

function parseRoute(pathname) {
  var m;
  if (m = pathname.match(/^\/temas\/([^\/]+)\/?$/)) return {
    type: "thread",
    slug: decodeURIComponent(m[1])
  };
  if (m = pathname.match(/^\/perfiles\/([^\/]+)\/?$/)) return {
    type: "profile",
    username: decodeURIComponent(m[1])
  };
  if (m = pathname.match(/^\/archivos\/([^\/]+)\/?$/)) return {
    type: "file",
    slug: decodeURIComponent(m[1])
  };
  if (m = pathname.match(/^\/comunidades\/([^\/]+)\/?$/)) return {
    type: "community",
    slug: decodeURIComponent(m[1])
  };
  if (pathname.match(/^\/comunidades\/?$/)) return {
    type: "communities"
  };
  if (m = pathname.match(/^\/grupos\/([^\/]+)\/?$/)) return {
    type: "group",
    slug: decodeURIComponent(m[1])
  };
  if (m = pathname.match(/^\/mensajes\/([^\/]+)\/?$/)) return {
    type: "conversation",
    id: decodeURIComponent(m[1])
  };
  if (m = pathname.match(/^\/circulos\/([^\/]+)\/?$/)) return {
    type: "circle",
    slug: decodeURIComponent(m[1])
  };
  if (pathname.match(/^\/circulos\/?$/)) return {
    type: "circles"
  };
  if (pathname.match(/^\/notificaciones\/?$/)) return {
    type: "notifications"
  };
  if (pathname.match(/^\/monedero\/?$/)) return {
    type: "wallet"
  };
  if (pathname.match(/^\/tienda\/?$/)) return {
    type: "store"
  };
  return null;
}

var pendingRoute = parseRoute(location.pathname);

function resolveThreadBySlug(slug) {
  var existing = THREADS.filter(function(x) {
    return x.slug === slug;
  })[0];
  if (existing) {
    openThread(existing.id);
    return;
  }
  supabase.from("threads").select("*").eq("slug", slug).single().then(function(res) {
    if (res.error || !res.data) {
      toast(t("forum.err_thread_gone"));
      resetToFeedOnMissingRoute("/temas/");
      return;
    }
    var mappedThread = mapThreadRow(res.data);
    THREADS.push(mappedThread);
    openThread(mappedThread.id);
    loadThreadAuthors();
  }).catch(function(err) {
    console.error("[resolveThreadBySlug] fallo consultando el tema:", err);
    toast(t("forum.err_thread_gone"));
    resetToFeedOnMissingRoute("/temas/");
  });
}

function resolveProfileByUsername(username) {
  supabase.from("profiles").select("id").eq("username", username).single().then(function(res) {
    if (res.error || !res.data) {
      toast(t("forum.err_profile_gone"));
      resetToFeedOnMissingRoute("/perfiles/");
      return;
    }
    openProfile(res.data.id);
  }).catch(function(err) {
    console.error("[resolveProfileByUsername] fallo consultando el perfil:", err);
    toast(t("forum.err_profile_gone"));
    resetToFeedOnMissingRoute("/perfiles/");
  });
}

function resolvePendingRoute() {
  if (!pendingRoute) return;
  var r = pendingRoute;
  pendingRoute = null;
  state.suppressPush = true;
  if (r.type === "thread") resolveThreadBySlug(r.slug); else if (r.type === "profile") resolveProfileByUsername(r.username); else if (r.type === "file") openFileView(r.slug); else if (r.type === "community") openCommunity(r.slug); else if (r.type === "communities") showCommunitiesList(); else if (r.type === "group") openGroup(r.slug); else if (r.type === "circle") openCircle(r.slug); else if (r.type === "conversation") resolveConversationById(r.id); else if (r.type === "notifications") {
    if (typeof openNotificationsPanel === "function") openNotificationsPanel();
  } else if (r.type === "wallet") {
    if (typeof openWalletPanel === "function") openWalletPanel();
  } else if (r.type === "store") {
    if (typeof openStore === "function") openStore();
  } else state.suppressPush = false;
}

function minimizeActiveContexts() {
  if (typeof currentCommunity !== "undefined" && currentCommunity) {
    var communitySlugToReopen = currentCommunity.slug;
    if (typeof minimizeVoiceChat === "function") {
      minimizeVoiceChat(function() {
        openCommunity(communitySlugToReopen);
      });
    } else if (typeof leaveVoiceChat === "function") {
      leaveVoiceChat();
    }
    exitImmersive("community");
    currentCommunity = null;
  }
  if (typeof currentGroup !== "undefined" && currentGroup) {
    var groupSlugToReopen = currentGroup.slug;
    if (typeof minimizeActivityVoice === "function") {
      minimizeActivityVoice(function() {
        openGroup(groupSlugToReopen);
      });
    }
    exitImmersive("group");
    currentGroup = null;
  }
  if (typeof currentConversation !== "undefined" && currentConversation) {
    var conv = currentConversation;
    if (typeof minimizeActivityVoice === "function") {
      minimizeActivityVoice(function() {
        openConversation(conv.id, conv.otherId, conv.otherUsername, conv.otherName, conv.otherAvatar, conv.otherNameColor, conv.otherRole, conv.otherVerified);
      });
    }
    exitImmersive("conversation");
    currentConversation = null;
  }
  if (typeof currentCircle !== "undefined" && currentCircle) {
    exitImmersive("circle");
    currentCircle = null;
  }
}

window.addEventListener("popstate", function() {
  var r = parseRoute(location.pathname);
  $("profileBackdrop").classList.remove("open");
  $("fileBackdrop").classList.remove("open");
  var fallbackPanel = null;
  if (currentCommunity && (!r || r.type !== "community")) {
    var communitySlugToReopen = currentCommunity.slug;
    if (typeof minimizeVoiceChat === "function") {
      minimizeVoiceChat(function() {
        openCommunity(communitySlugToReopen);
      });
    } else {
      leaveVoiceChat();
    }
    exitImmersive("community");
    currentCommunity = null;
    fallbackPanel = "panel-communities";
  }
  if (typeof currentGroup !== "undefined" && currentGroup && (!r || r.type !== "group")) {
    var groupSlugToReopen = currentGroup.slug;
    if (typeof minimizeActivityVoice === "function") {
      minimizeActivityVoice(function() {
        openGroup(groupSlugToReopen);
      });
    }
    exitImmersive("group");
    currentGroup = null;
    fallbackPanel = "panel-messages";
  }
  if (typeof currentConversation !== "undefined" && currentConversation && (!r || r.type !== "conversation")) {
    var conv = currentConversation;
    if (typeof minimizeActivityVoice === "function") {
      minimizeActivityVoice(function() {
        openConversation(conv.id, conv.otherId, conv.otherUsername, conv.otherName, conv.otherAvatar, conv.otherNameColor, conv.otherRole, conv.otherVerified);
      });
    }
    exitImmersive("conversation");
    currentConversation = null;
    fallbackPanel = "panel-messages";
  }
  if (typeof currentCircle !== "undefined" && currentCircle && (!r || r.type !== "circle")) {
    exitImmersive("circle");
    currentCircle = null;
    fallbackPanel = "panel-circles";
  }
  if (!r) {
    goBack(fallbackPanel || "panel-list");
    if (currentPanelId === "panel-communities") enterImmersive("community");
    resetScrollToTop();
    return;
  }
  state.suppressPush = true;
  if (r.type === "thread") resolveThreadBySlug(r.slug); else if (r.type === "profile") resolveProfileByUsername(r.username); else if (r.type === "file") openFileView(r.slug); else if (r.type === "community") openCommunity(r.slug); else if (r.type === "communities") showCommunitiesList(); else if (r.type === "group" && typeof openGroup === "function") openGroup(r.slug); else if (r.type === "circle" && typeof openCircle === "function") openCircle(r.slug); else if (r.type === "circles" && typeof showCirclesList === "function") showCirclesList(); else if (r.type === "notifications" && typeof openNotificationsPanel === "function") openNotificationsPanel(); else if (r.type === "wallet" && typeof openWalletPanel === "function") openWalletPanel(); else if (r.type === "store" && typeof openStore === "function") openStore();
});

function renderSidebar() {
  $("sidebarStats").innerHTML = "<div><strong>4.213</strong> " + t("forum.stats_active_users") + "</div>" + "<div><strong>" + THREADS.length + "</strong> " + t("forum.stats_active_posts") + "</div>" + "<div><strong>12</strong> " + t("forum.stats_warroom") + "</div>";
}

var ICON_MSG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-8.4 8.4H6l-3 3 .7-4A8.4 8.4 0 1 1 21 11.5z"/></svg>';

var ICON_EYE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 12S5 5 12 5s10.5 7 10.5 7-3.5 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>';

function getFiltered() {
  var list = THREADS.filter(function(t) {
    var q = state.query.trim().toLowerCase();
    var inQuery = !q || t.title.toLowerCase().indexOf(q) > -1 || t.excerpt.toLowerCase().indexOf(q) > -1;
    return inQuery;
  });
  if (state.sort === "popular") list = list.slice().sort(function(a, b) {
    return b.replies - a.replies;
  }); else if (state.sort === "unanswered") list = list.filter(function(t) {
    return t.replies < 15;
  }).sort(function(a, b) {
    return a.replies - b.replies;
  }); else list = list.slice().sort(function(a, b) {
    return new Date(b.time) - new Date(a.time);
  });
  if (state.sort === "recent") {
    list = list.filter(function(t) {
      return t.pinned;
    }).concat(list.filter(function(t) {
      return !t.pinned;
    }));
  }
  return list;
}

function renderThreadList() {
  var listEl = $("threadList");
  var items = getFiltered();
  $("emptyState").hidden = items.length > 0;
  listEl.innerHTML = items.map(function(t) {
    var images = t.coverImages && t.coverImages.length ? t.coverImages : t.coverImage ? [ t.coverImage ] : [];
    var likeState = THREAD_LIKES[t.id] || emptyReactionState();
    var isInfo = t.postType === "info";
    var imagesHtml = isInfo ? images[0] ? '<img class="post-card-info-banner" src="' + escapeHtml(images[0]) + '" alt="" loading="lazy">' : "" : images.length ? '<div class="post-image-row imgcount-' + Math.min(images.length, 3) + '">' + images.slice(0, 3).map(function(url) {
      return '<div class="post-image-cell"><img src="' + safeUrlAttr(url) + '" alt="" loading="lazy"></div>';
    }).join("") + "</div>" : "";
    return '<article class="post-card' + (isInfo ? " post-card-info" : "") + '" data-id="' + escapeHtml(t.id) + '">' + '<div class="post-card-head">' + avatarSpanHtml(t.author, t.authorAvatar, null, t.authorId) + '<div class="post-card-headtext">' + '<span class="user-link post-card-name" data-uid="' + escapeHtml(t.authorId) + '"' + (t.authorNameColor ? ' style="color:' + escapeHtml(t.authorNameColor) + '"' : "") + ">" + escapeHtml(t.author) + roleBadgeHtml(t.authorRole, t.authorVerified) + "</span>" + '<div class="post-card-headmeta">' + (t.pinned ? '<span class="tag pinned">Fijado</span>' : "") + (isInfo ? '<span class="tag info-tag">Informativa</span>' : "") + "<span>· " + timeAgo(t.time) + "</span>" + "</div>" + "</div>" + (typeof kebabMenuHtml === "function" ? kebabMenuHtml("post", t.id) : "") + "</div>" + (isInfo ? imagesHtml : "") + '<div class="post-card-body">' + '<div class="post-card-title">' + escapeHtml(t.title) + "</div>" + '<div class="post-card-text">' + escapeHtml(z3tStripLinks(t.excerpt)) + "</div>" + "</div>" + (isInfo ? "" : imagesHtml) + (t.circleName ? '<div class="thread-circle-flag">🚩 ' + escapeHtml(t.circleName) + "</div>" : "") + threadReactionPillsHtml(t.id) + '<div class="post-card-actions">' + '<button class="post-action-btn like-btn' + (likeState.likedByMe ? " active" : "") + '" data-action="like" data-id="' + escapeHtml(t.id) + '" type="button">' + (likeState.likedByMe ? escapeHtml(likeState.myEmoji || "❤️") : "🤍") + " <span>" + likeState.count + "</span></button>" + '<button class="post-action-btn" data-action="comment" type="button">' + ICON_MSG + " <span>" + Number(t.replies || 0) + "</span></button>" + '<span class="post-action-btn static">' + ICON_EYE + " <span>" + Number(t.views || 0) + "</span></span>" + "</div>" + "</article>";
  }).join("");
  qsa(".post-card", listEl).forEach(function(card) {
    card.addEventListener("click", function() {
      openThread(card.getAttribute("data-id"));
    });
  });
  qsa(".user-link", listEl).forEach(function(el) {
    el.addEventListener("click", function(e) {
      e.stopPropagation();
      openProfile(el.getAttribute("data-uid"));
    });
  });
  qsa(".like-btn", listEl).forEach(function(btn) {
    btn.addEventListener("click", function(e) {
      e.stopPropagation();
      openPostReactPicker(btn.getAttribute("data-id"), btn);
    });
  });
  qsa('[data-action="react-pill"]', listEl).forEach(function(pill) {
    pill.addEventListener("click", function(e) {
      e.stopPropagation();
      setThreadReaction(pill.getAttribute("data-id"), pill.getAttribute("data-emoji"));
    });
  });
}

function renderInfoBody(text) {
  var lines = String(text || "").replace(/\r\n/g, "\n").split("\n");
  var html = "";
  var para = [];
  var list = [];
  function flushPara() {
    if (para.length) {
      html += "<p>" + para.join("<br>") + "</p>";
      para = [];
    }
  }
  function flushList() {
    if (list.length) {
      html += "<ul>" + list.map(function(li) {
        return "<li>" + li + "</li>";
      }).join("") + "</ul>";
      list = [];
    }
  }
  lines.forEach(function(raw) {
    var line = raw.trim();
    if (!line) {
      flushPara();
      flushList();
      return;
    }
    if (/^#{1,3}\s+/.test(line)) {
      flushPara();
      flushList();
      html += "<h3>" + escapeHtml(line.replace(/^#{1,3}\s+/, "")) + "</h3>";
    } else if (/^[-•]\s+/.test(line)) {
      flushPara();
      list.push(escapeHtml(line.replace(/^[-•]\s+/, "")));
    } else {
      flushList();
      para.push(escapeHtml(line));
    }
  });
  flushPara();
  flushList();
  return html;
}

var threadOpenSeq = 0;

function openThread(id, opts) {
  opts = opts || {};
  var th = THREADS.filter(function(x) {
    return x.id === id;
  })[0];
  if (!th) {
    /* No estaba en la lista cargada (p. ej. al tocar una notificación): se pide al servidor en vez de no hacer nada */
    supabase.from("threads").select("*").eq("id", id).maybeSingle().then(function(res) {
      if (res.error || !res.data) {
        toast(t("forum.err_thread_gone"));
        return;
      }
      THREADS.push(mapThreadRow(res.data));
      loadThreadAuthors();
      openThread(id, opts);
    });
    return;
  }
  var seq = ++threadOpenSeq;
  /* Siempre se piden los comentarios al servidor: antes se reutilizaba una copia guardada (th.posts)
     y los comentarios nuevos no aparecían al volver a abrir la publicación ni desde una notificación. */
  var loadPosts = loadThreadPosts(id).then(function(posts) {
    if (seq !== threadOpenSeq) return null; /* llegó una respuesta más nueva: ésta ya no vale */
    if (posts === null) return null;
    th.posts = posts;
    if (posts.length && th.replies !== posts.length - 1) {
      th.replies = posts.length - 1;
      if (typeof renderThreadList === "function") renderThreadList();
    }
    return posts;
  });
  loadPosts.then(function(posts) {
    if (seq !== threadOpenSeq) return;
    if (posts === null) {
      if (opts.silent) return;
      toast(t("forum.err_replies"));
      $("threadDetail").innerHTML = '<p class="empty-state">No se pudieron cargar los comentarios. <button type="button" class="link-btn" id="btnRetryThread">Reintentar</button></p>';
      $("btnRetryThread").addEventListener("click", function() {
        openThread(id);
      });
      activatePanel("panel-thread");
      return;
    }
    var scrollKeep = opts.silent ? window.scrollY : null;
    var isThreadOwner = !!(currentUser && currentUser.id === th.authorId);
    var isInfo = th.postType === "info";
    var firstPost = posts[0];
    var headHtml;
    if (isInfo) {
      var parsedFirst = firstPost ? parseAttachments(firstPost.body) : {
        text: "",
        attachments: []
      };
      var bannerUrl = th.coverImage || th.coverImages && th.coverImages[0] || parsedFirst.attachments[0] && parsedFirst.attachments[0].url || null;
      var extraAttachments = parsedFirst.attachments.filter(function(a) {
        return a.url !== bannerUrl;
      });
      headHtml = '<div class="thread-detail-head info-post-head">' + (bannerUrl ? '<img loading=lazy decoding=async class="info-post-banner" src="' + escapeHtml(bannerUrl) + '" alt="">' : "") + '<span class="tag info-tag">Informativa</span>' + '<h1 id="threadTitleText">' + escapeHtml(th.title) + "</h1>" + '<div class="post-head">' + avatarSpanHtml(th.author, th.authorAvatar, null, th.authorId) + '<div><div class="post-author user-link" data-uid="' + escapeHtml(th.authorId) + '"' + (th.authorNameColor ? ' style="color:' + escapeHtml(th.authorNameColor) + '"' : "") + ">" + escapeHtml(th.author) + roleBadgeHtml(th.authorRole, th.authorVerified) + '</div><div class="post-time">' + timeAgo(th.time) + "</div></div>" + "</div>" + '<div class="info-post-body">' + renderInfoBody(parsedFirst.text) + "</div>" + renderAttachments(extraAttachments) + (isThreadOwner ? '<div class="post-owner-actions"><button type="button" class="link-btn" id="btnEditThread">Editar publicación</button><button type="button" class="link-btn danger" id="btnDeleteThread">Eliminar publicación</button></div>' : "") + "</div>";
    } else {
      headHtml = '<div class="thread-detail-head">' + '<h1 id="threadTitleText">' + escapeHtml(th.title) + "</h1>" + (isThreadOwner ? '<div class="post-owner-actions"><button type="button" class="link-btn" id="btnEditThread">Editar publicación</button><button type="button" class="link-btn danger" id="btnDeleteThread">Eliminar publicación</button></div>' : "") + "</div>";
    }
    var commentPosts = isInfo ? posts.slice(1) : posts;
    var html = headHtml + commentPosts.map(function(p, idx) {
      var split = forumSplitReply(p.body);
      var parsed = parseAttachments(split.body);
      var isPostOwner = !!(currentUser && currentUser.id === p.authorId);
      var canReplyPost = !!(currentUser && !isPostOwner && p.id);
      var showPostActions = isPostOwner && (isInfo || idx > 0);
      return '<div class="post-card" data-post-id="' + escapeHtml(p.id || "") + '">' + '<div class="post-head">' + avatarSpanHtml(p.author, p.authorAvatar, null, p.authorId) + '<div><div class="post-author user-link" data-uid="' + escapeHtml(p.authorId) + '"' + (p.authorNameColor ? ' style="color:' + escapeHtml(p.authorNameColor) + '"' : "") + ">" + escapeHtml(p.author) + roleBadgeHtml(p.authorRole, p.authorVerified) + '</div><div class="post-time">' + timeAgo(p.time) + "</div></div>" + (canReplyPost ? '<div class="post-owner-actions"><button type="button" class="link-btn btn-reply-post" data-post-id="' + escapeHtml(p.id) + '">Responder</button></div>' : "") + (showPostActions ? '<div class="post-owner-actions"><button type="button" class="link-btn btn-edit-post" data-post-id="' + escapeHtml(p.id || "") + '">Editar</button><button type="button" class="link-btn danger btn-delete-post" data-post-id="' + escapeHtml(p.id || "") + '">Eliminar</button></div>' : "") + (typeof kebabMenuHtml === "function" ? kebabMenuHtml("post", p.id || th.id) : "") + "</div>" + (split.reply && typeof z3tReplyQuoteHtml === "function" ? z3tReplyQuoteHtml({
        _reply: split.reply
      }) : "") + '<div class="post-body" data-post-id="' + escapeHtml(p.id || "") + '">' + z3tRichText(parsed.text, true) + "</div>" + renderAttachments(parsed.attachments) + "</div>";
    }).join("") + '<div class="replies-divider">Comentarios (' + commentPosts.length + ")</div>" + '<div class="reply-box reply-composer" id="replyAttachZone">' + '<input type="file" class="attach-input" id="replyAttachInput" accept="image/*,video/*" multiple hidden>' + '<div id="replyDraftHolder"></div><div class="composer-top-row"><input type="text" id="replyInput" placeholder="Escribe un comentario..." autocomplete="off"><button class="icon-btn composer-send-btn" id="btnPostReply" type="button" aria-label="Publicar comentario"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button></div>' + '<div class="attach-chips" id="replyAttachChips"></div>' + '<div class="composer-icons-row"><button class="icon-btn compose-icon" id="btnReplyAudio" type="button" aria-label="Audio"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><line x1="4" y1="10" x2="4" y2="14"/><line x1="8" y1="6" x2="8" y2="18"/><line x1="12" y1="3" x2="12" y2="21"/><line x1="16" y1="6" x2="16" y2="18"/><line x1="20" y1="10" x2="20" y2="14"/></svg></button><button class="icon-btn compose-icon z3t-link-btn" type="button" data-link-for="replyInput" aria-label="Insertar enlace" title="Enlace">🔗</button><button class="icon-btn compose-icon attach-trigger" id="btnReplyImage" type="button" aria-label="Imagen o video"><img loading=lazy decoding=async src="assets/icons/ic-upload.png" alt="" class="upload-icon-img"></button><div class="compose-icon-wrap"><button class="icon-btn compose-icon" id="btnReplyEmoji" type="button" aria-label="Emojis"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 14s1.2 2 3.5 2 3.5-2 3.5-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg></button><div class="chat-actions-popup" id="replyEmojiPopup"></div></div></div>' + "</div>";
    $("threadDetail").innerHTML = html;
    if (scrollKeep !== null) window.scrollTo(0, scrollKeep);
    qsa(".user-link", $("threadDetail")).forEach(function(el) {
      el.addEventListener("click", function() {
        openProfile(el.getAttribute("data-uid"));
      });
    });
    qsa(".attach-file[data-file-slug]", $("threadDetail")).forEach(function(el) {
      el.addEventListener("click", function(e) {
        e.preventDefault();
        var slug = el.getAttribute("data-file-slug");
        if (slug) openFileView(slug);
      });
    });
    if (isThreadOwner) {
      $("btnEditThread").addEventListener("click", function() {
        editThread(th, posts[0]);
      });
      $("btnDeleteThread").addEventListener("click", function() {
        deleteThread(th);
      });
    }
    qsa(".btn-edit-post", $("threadDetail")).forEach(function(btn) {
      btn.addEventListener("click", function() {
        var pid = btn.getAttribute("data-post-id");
        var post = posts.filter(function(p) {
          return p.id === pid;
        })[0];
        if (post) editPost(th, post);
      });
    });
    qsa(".btn-delete-post", $("threadDetail")).forEach(function(btn) {
      btn.addEventListener("click", function() {
        var pid = btn.getAttribute("data-post-id");
        var post = posts.filter(function(p) {
          return p.id === pid;
        })[0];
        if (post) deletePost(th, post);
      });
    });
    var replyAttach = initAttachPicker($("replyAttachZone"));
    var replyBusy = false;
    var forumReplyDraft = null;
    function clearForumReplyDraft() {
      forumReplyDraft = null;
      var holder = $("replyDraftHolder");
      if (holder) holder.innerHTML = "";
    }
    qsa(".btn-reply-post", $("threadDetail")).forEach(function(btn) {
      btn.addEventListener("click", function() {
        if (!currentUser) {
          toast(t("forum.login_comment"));
          return;
        }
        var pid = btn.getAttribute("data-post-id");
        var post = posts.filter(function(p) {
          return p.id === pid;
        })[0];
        if (!post) return;
        var plain = parseAttachments(forumSplitReply(post.body).body);
        var snippet = (plain.text || "").replace(/\s+/g, " ").trim().slice(0, 80);
        if (!snippet && plain.attachments && plain.attachments.length) snippet = "📷 Adjunto";
        forumReplyDraft = {
          id: String(post.id),
          name: post.author || "comentario",
          snippet: snippet
        };
        var holder = $("replyDraftHolder");
        if (holder) {
          holder.innerHTML = '<div class="reply-draft-bar"><div class="reply-draft-main"><div class="reply-quote-name">' + escapeHtml("Respondiendo a " + forumReplyDraft.name) + '</div><div class="reply-quote-text">' + escapeHtml(snippet) + '</div></div><button type="button" class="reply-draft-close" aria-label="Cancelar respuesta">×</button></div>';
          holder.querySelector(".reply-draft-close").addEventListener("click", clearForumReplyDraft);
        }
        var inp = $("replyInput");
        if (inp) {
          inp.scrollIntoView({
            block: "center",
            behavior: "smooth"
          });
          inp.focus();
        }
      });
    });
    qsa(".reply-quote[data-reply-id]", $("threadDetail")).forEach(function(q) {
      q.addEventListener("click", function() {
        var target = $("threadDetail").querySelector('.post-card[data-post-id="' + CSS.escape(q.getAttribute("data-reply-id")) + '"]');
        if (!target) {
          toast("El comentario original ya no está.");
          return;
        }
        target.scrollIntoView({
          block: "center",
          behavior: "smooth"
        });
        target.classList.add("flash");
        setTimeout(function() {
          target.classList.remove("flash");
        }, 1400);
      });
    });
    function submitReply(val, files) {
      if (!currentUser) {
        toast(t("forum.login_comment"));
        return;
      }
      if (replyBusy || !val && !files.length) return;
      replyBusy = true;
      var btn = $("btnPostReply");
      btn.disabled = true;
      var uploadPromise = files.length ? uploadFiles(files, "posts/" + currentUser.id) : Promise.resolve([]);
      uploadPromise.then(function(attachments) {
        var fullBody = (forumReplyDraft ? z3tReplyEncode(forumReplyDraft) : "") + val + encodeAttachments(attachments);
        return supabase.from("posts").insert({
          thread_id: id,
          author_id: currentUser.id,
          body: fullBody
        }).select().single().then(function(res) {
          if (res.error) {
            toast(t("forum.err_comment_post"));
            replyBusy = false;
            btn.disabled = false;
            return;
          }
          var postId = res.data ? res.data.id : null;
          var indexPromise = postId && attachments.length ? supabase.from("attachments").insert(attachments.map(function(a) {
            return {
              thread_id: id,
              post_id: postId,
              uploader_id: currentUser.id,
              name: a.name,
              slug: a.slug,
              url: a.url,
              type: a.type,
              size: a.size
            };
          })) : Promise.resolve();
          return indexPromise.then(function() {
            th.replies++;
            th.posts = null;
            openThread(id);
            toast(t("forum.toast_comment_posted"));
            awardAchievement(currentUser.id, "first_comment");
          });
        });
      }).catch(function() {
        toast(t("forum.err_attachments"));
        replyBusy = false;
        btn.disabled = false;
      });
    }
    $("btnPostReply").addEventListener("click", function() {
      submitReply($("replyInput").value.trim(), replyAttach.getFiles());
    });
    $("replyInput").addEventListener("keydown", function(e) {
      if (e.key === "Enter") {
        e.preventDefault();
        submitReply($("replyInput").value.trim(), replyAttach.getFiles());
      }
    });
    var replyAudioBtn = $("btnReplyAudio");
    if (replyAudioBtn) replyAudioBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      z3tToggleAudioRecording(replyAudioBtn, function(file) {
        toast("Enviando audio…");
        submitReply("", [ file ]);
      });
    });
    var replyEmojiBtn = $("btnReplyEmoji"), replyEmojiPopup = $("replyEmojiPopup");
    if (replyEmojiBtn && replyEmojiPopup) {
      replyEmojiPopup.innerHTML = '<div class="emoji-grid">' + COMMON_EMOJIS.map(function(em) {
        return '<button type="button" data-emoji="' + em + '">' + em + "</button>";
      }).join("") + "</div>";
      replyEmojiBtn.addEventListener("click", function(e) {
        e.stopPropagation();
        replyEmojiPopup.classList.toggle("open");
      });
      replyEmojiPopup.addEventListener("click", function(e) {
        e.stopPropagation();
        var eb = e.target.closest("[data-emoji]");
        if (!eb) return;
        var inp = $("replyInput");
        inp.value += eb.getAttribute("data-emoji");
        inp.focus();
        replyEmojiPopup.classList.remove("open");
      });
      document.addEventListener("click", function() {
        replyEmojiPopup.classList.remove("open");
      });
    }
  });
  if (opts.silent) return;
  activatePanel("panel-thread");
  if (th.slug && !state.suppressPush) history.pushState({
    view: "thread",
    id: th.id
  }, "", "/temas/" + encodeURIComponent(th.slug));
  state.suppressPush = false;
  window.scrollTo(0, 0);
}

function editThread(th, firstPost) {
  var parsed = parseAttachments(firstPost ? firstPost.body : "");
  var head = $("threadTitleText").closest(".thread-detail-head");
  head.innerHTML = '<div class="edit-box">' + '<label class="field"><span>Título</span><input type="text" id="editThreadTitle" value="' + escapeHtml(th.title) + '"></label>' + '<label class="field"><span>Contenido</span><textarea id="editThreadBody" rows="5">' + escapeHtml(parsed.text) + "</textarea></label>" + '<div class="edit-box-actions">' + '<button type="button" class="terminal-btn" id="btnSaveThreadEdit">Guardar</button>' + '<button type="button" class="link-btn" id="btnCancelThreadEdit">Cancelar</button>' + "</div>" + "</div>";
  $("btnCancelThreadEdit").addEventListener("click", function() {
    openThread(th.id);
  });
  $("btnSaveThreadEdit").addEventListener("click", function() {
    var newTitle = $("editThreadTitle").value.trim();
    var newBody = $("editThreadBody").value.trim();
    if (!newTitle || !newBody) return;
    var fullBody = newBody + encodeAttachments(parsed.attachments);
    var btn = $("btnSaveThreadEdit");
    btn.disabled = true;
    btn.textContent = "Guardando...";
    supabase.from("threads").update({
      title: newTitle,
      excerpt: newBody.slice(0, 140)
    }).eq("id", th.id).then(function(res) {
      if (res.error) {
        toast(t("forum.err_thread_save"));
        btn.disabled = false;
        btn.textContent = t("forum.btn_save");
        return;
      }
      if (firstPost) {
        return supabase.from("posts").update({
          body: fullBody
        }).eq("id", firstPost.id).then(function(res2) {
          if (res2.error) {
            toast(t("forum.err_content_save"));
            btn.disabled = false;
            btn.textContent = t("forum.btn_save");
            return;
          }
          th.title = newTitle;
          th.excerpt = newBody.slice(0, 140);
          firstPost.body = fullBody;
          toast(t("forum.toast_thread_updated"));
          openThread(th.id);
        });
      }
      th.title = newTitle;
      th.excerpt = newBody.slice(0, 140);
      toast(t("forum.toast_thread_updated"));
      openThread(th.id);
    });
  });
}

/* Respuestas a comentarios: se guardan como prefijo [[re|id|nombre|texto]] en el body (igual que en los chats) */
function forumSplitReply(body) {
  var out = {
    reply: null,
    prefix: "",
    body: body || ""
  };
  if (typeof Z3T_REPLY_RE === "undefined" || typeof body !== "string") return out;
  var mt = body.match(Z3T_REPLY_RE);
  if (!mt) return out;
  try {
    out.reply = {
      id: decodeURIComponent(mt[2]),
      name: decodeURIComponent(mt[3]),
      snippet: decodeURIComponent(mt[4])
    };
  } catch (_e) {
    return out;
  }
  out.prefix = mt[0];
  out.body = body.slice(mt[0].length);
  return out;
}

function deleteThread(th) {
  if (!confirm("¿Eliminar esta publicación por completo? Esta acción no se puede deshacer.")) return;
  supabase.from("threads").delete().eq("id", th.id).then(function(res) {
    if (res.error) {
      toast(t("forum.err_thread_delete"));
      return;
    }
    THREADS = THREADS.filter(function(x) {
      return x.id !== th.id;
    });
    if (currentUser) currentUser.threadsCount = Math.max((currentUser.threadsCount || 1) - 1, 0);
    toast(t("forum.toast_thread_deleted"));
    activatePanel("panel-list");
    history.pushState({
      view: "list"
    }, "", "/");
    renderSidebar();
    renderThreadList();
  });
}

function editPost(th, post) {
  var editSplit = forumSplitReply(post.body);
  var parsed = parseAttachments(editSplit.body);
  var cardBody = document.querySelector('.post-body[data-post-id="' + CSS.escape(post.id) + '"]');
  if (!cardBody) return;
  cardBody.outerHTML = '<div class="edit-box" data-post-id="' + escapeHtml(post.id) + '">' + '<textarea id="editPostBody">' + escapeHtml(parsed.text) + "</textarea>" + '<div class="edit-box-link-row"><button type="button" class="attach-trigger" data-link-for="editPostBody" aria-label="Insertar enlace">🔗 Insertar enlace</button></div>' + '<div class="edit-box-actions">' + '<button type="button" class="terminal-btn" id="btnSavePostEdit">Guardar</button>' + '<button type="button" class="link-btn" id="btnCancelPostEdit">Cancelar</button>' + "</div>" + "</div>";
  $("btnCancelPostEdit").addEventListener("click", function() {
    openThread(th.id);
  });
  $("btnSavePostEdit").addEventListener("click", function() {
    var newText = $("editPostBody").value.trim();
    if (!newText) return;
    var fullBody = editSplit.prefix + newText + encodeAttachments(parsed.attachments);
    var btn = $("btnSavePostEdit");
    btn.disabled = true;
    btn.textContent = "Guardando...";
    supabase.from("posts").update({
      body: fullBody
    }).eq("id", post.id).then(function(res) {
      if (res.error) {
        toast(t("forum.err_comment_save"));
        btn.disabled = false;
        btn.textContent = t("forum.btn_save");
        return;
      }
      post.body = fullBody;
      toast(t("forum.toast_comment_updated"));
      openThread(th.id);
    });
  });
}

function deletePost(th, post) {
  if (!confirm("¿Eliminar este comentario?")) return;
  supabase.from("posts").delete().eq("id", post.id).then(function(res) {
    if (res.error) {
      toast(t("forum.err_comment_delete"));
      return;
    }
    if (th.posts) th.posts = th.posts.filter(function(p) {
      return p.id !== post.id;
    });
    th.replies = Math.max((th.replies || 1) - 1, 0);
    if (currentUser) currentUser.repliesCount = Math.max((currentUser.repliesCount || 1) - 1, 0);
    toast(t("forum.toast_comment_deleted"));
    openThread(th.id);
  });
}

$("btnBackToList").addEventListener("click", function() {
  activatePanel("panel-list");
  history.pushState({
    view: "list"
  }, "", "/");
  renderThreadList();
});

function applyChatBackground(el) {
  if (!el) return;
  var shell = el.closest ? el.closest(".conversation-shell, .community-shell") : null;
  var target = shell || el;
  if (currentUser && currentUser.chatBackgroundUrl) {
    target.style.backgroundImage = 'linear-gradient(rgba(7,6,10,.72), rgba(7,6,10,.82)), url("' + currentUser.chatBackgroundUrl + '")';
    target.style.backgroundSize = "cover";
    target.style.backgroundPosition = "center";
    target.classList.add("has-chat-bg");
    if (target !== el) el.style.backgroundImage = "";
  } else {
    target.style.backgroundImage = "";
    target.classList.remove("has-chat-bg");
    if (target !== el) el.style.backgroundImage = "";
  }
}

$("btnMessagesSettings").addEventListener("click", function() {
  $("chatBgBackdrop").classList.add("open");
});

$("chatBgClose").addEventListener("click", function() {
  $("chatBgBackdrop").classList.remove("open");
});

$("btnPickChatBg").addEventListener("click", function() {
  openBackgroundPicker("chatBgInput");
});

$("chatBgBackdrop").addEventListener("click", function(e) {
  if (e.target === this) $("chatBgBackdrop").classList.remove("open");
});

$("btnChatBgSave").addEventListener("click", function() {
  if (!currentUser) return;
  var file = $("chatBgInput").files[0];
  if (!file) {
    toast(t("forum.pick_image_first"));
    return;
  }
  var btn = $("btnChatBgSave");
  btn.disabled = true;
  btn.textContent = "Guardando...";
  uploadFiles([ file ], "chat-backgrounds/" + currentUser.id).then(function(results) {
    var url = results[0] ? results[0].url : null;
    btn.disabled = false;
    btn.textContent = "Guardar";
    if (!url) {
      toast(t("forum.err_image_upload"));
      return;
    }
    return supabase.from("profiles").update({
      chat_background_url: url
    }).eq("id", currentUser.id).then(function(res) {
      if (res.error) {
        toast("No se pudo guardar: " + res.error.message);
        return;
      }
      currentUser.chatBackgroundUrl = url;
      applyChatBackground($("conversationMessages"));
      applyChatBackground($("groupChat"));
      toast(t("forum.toast_bg_updated"));
      $("chatBgBackdrop").classList.remove("open");
    });
  });
});

$("btnChatBgRemove").addEventListener("click", function() {
  if (!currentUser) return;
  supabase.from("profiles").update({
    chat_background_url: null
  }).eq("id", currentUser.id).then(function(res) {
    if (res.error) {
      toast("No se pudo quitar: " + res.error.message);
      return;
    }
    currentUser.chatBackgroundUrl = null;
    applyChatBackground($("conversationMessages"));
    applyChatBackground($("groupChat"));
    toast(t("forum.toast_bg_removed"));
    $("chatBgBackdrop").classList.remove("open");
  });
});

qsa(".tab", $("tabs")).forEach(function(tab) {
  tab.addEventListener("click", function() {
    qsa(".tab", $("tabs")).forEach(function(x) {
      x.classList.remove("active");
    });
    tab.classList.add("active");
    state.sort = tab.getAttribute("data-sort");
    state.threadLimit = 30;
    loadThreads().then(function() {
      renderThreadList();
    });
  });
});

var threadSearchDebounce = null;

$("searchInput").addEventListener("input", function() {
  state.query = this.value;
  renderThreadList();
  if (threadSearchDebounce) clearTimeout(threadSearchDebounce);
  threadSearchDebounce = setTimeout(function() {
    state.threadLimit = 30;
    loadThreads().then(function() {
      renderThreadList();
    });
  }, 350);
});

var globalSearchDebounce = null;

function openGlobalSearchPanel() {
  minimizeActiveContexts();
  exitAllImmersive();
  activatePanel("panel-search");
  if (location.pathname !== "/buscar") history.pushState({
    view: "search"
  }, "", "/buscar");
  $("globalSearchInput").value = "";
  $("globalSearchResults").innerHTML = "";
  $("globalSearchEmptyState").hidden = true;
  $("globalSearchHint").hidden = false;
  setTimeout(function() {
    $("globalSearchInput").focus();
  }, 50);
}

$("btnGlobalSearch").addEventListener("click", openGlobalSearchPanel);

$("btnSearchBack").addEventListener("click", function() {
  goBack("panel-list");
});

$("globalSearchInput").addEventListener("input", function() {
  var q = this.value.trim();
  clearTimeout(globalSearchDebounce);
  if (!q) {
    $("globalSearchResults").innerHTML = "";
    $("globalSearchEmptyState").hidden = true;
    $("globalSearchHint").hidden = false;
    return;
  }
  $("globalSearchHint").hidden = true;
  globalSearchDebounce = setTimeout(function() {
    runGlobalSearch(q);
  }, 300);
});

function searchResultRowHtml(name, thumbUrl, sub) {
  return '<article class="dm-card">' + avatarSpanHtml(name, thumbUrl) + '<div class="dm-card-main"><div class="dm-card-top"><span class="dm-card-name">' + escapeHtml(name) + "</span></div>" + (sub ? '<div class="dm-card-preview">' + escapeHtml(sub) + "</div>" : "") + "</div></article>";
}

function runGlobalSearch(q) {
  var like = "%" + q.replace(/[%_]/g, "") + "%";
  Promise.all([ supabase.from("profiles").select("id, username, name, avatar_url").ilike("username", like).limit(8), supabase.from("profiles").select("id, username, name, avatar_url").ilike("name", like).limit(8), supabase.from("threads").select("id, title, slug").ilike("title", like).limit(8), supabase.from("circles").select("id, slug, name, icon_url").ilike("name", like).limit(8), supabase.from("communities").select("id, slug, name, thumbnail_url, banner_url").ilike("name", like).limit(8), supabase.from("frames").select("id, name, thumbnail_url").eq("status", "published").ilike("name", like).limit(8), supabase.from("chat_bubbles").select("id, name, thumbnail_url").eq("status", "published").ilike("name", like).limit(8) ]).then(function(results) {
    var usersById = {};
    [ results[0], results[1] ].forEach(function(r) {
      (r.error ? [] : r.data || []).forEach(function(u) {
        usersById[u.id] = u;
      });
    });
    var users = Object.keys(usersById).map(function(k) {
      return usersById[k];
    });
    var threads = results[2].error ? [] : results[2].data || [];
    var circles = results[3].error ? [] : results[3].data || [];
    var communities = results[4].error ? [] : results[4].data || [];
    var frames = results[5].error ? [] : results[5].data || [];
    var bubbles = results[6].error ? [] : results[6].data || [];
    var total = users.length + threads.length + circles.length + communities.length + frames.length + bubbles.length;
    var out = $("globalSearchResults");
    $("globalSearchEmptyState").hidden = total > 0;
    if (!total) {
      out.innerHTML = "";
      return;
    }
    var html = "";
    function group(title, itemsHtml) {
      if (!itemsHtml) return;
      html += '<div class="search-result-group"><h4>' + escapeHtml(title) + '</h4><div class="thread-list">' + itemsHtml + "</div></div>";
    }
    group("Usuarios", users.map(function(u) {
      return '<div class="search-result-click" data-kind="user" data-id="' + escapeHtml(u.id) + '">' + searchResultRowHtml(u.name || u.username, u.avatar_url, "@" + u.username) + "</div>";
    }).join(""));
    group("Publicaciones", threads.map(function(t) {
      return '<div class="search-result-click" data-kind="thread" data-id="' + escapeHtml(t.id) + '">' + searchResultRowHtml(t.title, null, null) + "</div>";
    }).join(""));
    group("Círculos", circles.map(function(c) {
      return '<div class="search-result-click" data-kind="circle" data-slug="' + escapeHtml(c.slug) + '">' + searchResultRowHtml(c.name, c.icon_url, null) + "</div>";
    }).join(""));
    group("Comunidades", communities.map(function(c) {
      return '<div class="search-result-click" data-kind="community" data-slug="' + escapeHtml(c.slug) + '">' + searchResultRowHtml(c.name, c.thumbnail_url || c.banner_url, null) + "</div>";
    }).join(""));
    group("Marcos", frames.map(function(f) {
      return '<div class="search-result-click" data-kind="frame" data-id="' + escapeHtml(f.id) + '">' + searchResultRowHtml(f.name, f.thumbnail_url, null) + "</div>";
    }).join(""));
    group("Burbujas", bubbles.map(function(b) {
      return '<div class="search-result-click" data-kind="bubble" data-id="' + escapeHtml(b.id) + '">' + searchResultRowHtml(b.name, b.thumbnail_url, null) + "</div>";
    }).join(""));
    out.innerHTML = html;
    qsa(".search-result-click", out).forEach(function(row) {
      row.addEventListener("click", function() {
        var kind = row.getAttribute("data-kind");
        if (kind === "user") openProfile(row.getAttribute("data-id")); else if (kind === "thread") openThread(row.getAttribute("data-id")); else if (kind === "circle") openCircle(row.getAttribute("data-slug")); else if (kind === "community") openCommunity(row.getAttribute("data-slug")); else if (kind === "frame") openStoreFrameById(row.getAttribute("data-id")); else if (kind === "bubble") openStoreBubbleById(row.getAttribute("data-id"));
      });
    });
  });
}

function openDrawer() {
  $("sidebar").classList.add("open");
  $("sidebarBackdrop").classList.add("open");
}

function closeDrawer() {
  $("sidebar").classList.remove("open");
  $("sidebarBackdrop").classList.remove("open");
}

$("btnDrawer").addEventListener("click", openDrawer);

$("sidebarBackdrop").addEventListener("click", closeDrawer);

function goHome() {
  minimizeActiveContexts();
  exitAllImmersive();
  if (communityCinemaPollTimer) {
    clearInterval(communityCinemaPollTimer);
    communityCinemaPollTimer = null;
  }
  if (meetOrbitTimer) {
    clearInterval(meetOrbitTimer);
    meetOrbitTimer = null;
  }
  if (typeof exitCircleSelectionMode === "function") exitCircleSelectionMode();
  activatePanel("panel-list");
  if (location.pathname !== "/") history.pushState({
    view: "list"
  }, "", "/");
  state.query = "";
  $("searchInput").value = "";
  renderSidebar();
  renderThreadList();
  loadMeetOrbit();
}

qsa(".bottom-nav button").forEach(function(btn) {
  btn.addEventListener("click", function() {
    var action = btn.getAttribute("data-action");
    qsa(".bottom-nav button").forEach(function(b) {
      b.classList.remove("bn-active");
    });
    if (action === "home") {
      btn.classList.add("bn-active");
      goHome();
    } else if (action === "categories") {
      btn.classList.add("bn-active");
      showCirclesList();
    } else if (action === "new") {
      $("createChooseBackdrop").classList.add("open");
    } else if (action === "messages") {
      btn.classList.add("bn-active");
      showMessagesList();
    } else if (action === "store") {
      btn.classList.add("bn-active");
      openStore();
    }
  });
});

$("createChooseBackdrop").addEventListener("click", function(e) {
  if (e.target === this) $("createChooseBackdrop").classList.remove("open");
});

$("createChooseClose").addEventListener("click", function() {
  $("createChooseBackdrop").classList.remove("open");
});

$("btnChoosePost").addEventListener("click", function() {
  $("createChooseBackdrop").classList.remove("open");
  openCompose();
});

$("btnChooseCommunity").addEventListener("click", function() {
  $("createChooseBackdrop").classList.remove("open");
  if (!currentUser) {
    toast(t("forum.login_create_community"));
    return;
  }
  openCreateCommunityModal();
});

$("btnChooseCircle").addEventListener("click", function() {
  $("createChooseBackdrop").classList.remove("open");
  if (!currentUser) {
    toast(t("forum.login_create_circle"));
    return;
  }
  if (typeof refreshFlagOptionsList === "function") refreshFlagOptionsList();
  $("circleCreateBackdrop").classList.add("open");
});

var composeAttach = initAttachPicker($("composeAttachZone"));

var composeState = {
  type: "normal"
};

function applyComposeType(type) {
  composeState.type = type;
  qsa(".compose-type-tab", $("composeTypeTabs")).forEach(function(tab) {
    tab.classList.toggle("active", tab.getAttribute("data-type") === type);
  });
  var isInfo = type === "info";
  $("composeTypeHintNormal").hidden = isInfo;
  $("composeTypeHintInfo").hidden = !isInfo;
  $("composeModalTitle").textContent = isInfo ? "Nueva publicación informativa" : "Nueva publicación";
  $("composeTitleLabel").textContent = isInfo ? "Título del comunicado" : "Título";
  $("composeBodyLabel").textContent = isInfo ? 'Contenido (usa "## " para subtítulos y "- " para listas)' : "Contenido";
  $("composeBody").placeholder = isInfo ? "Escribe el comunicado completo aquí..." : "Comparte tu write-up, pregunta o hallazgo...";
  $("composeAttachHint").textContent = isInfo ? "La primera imagen será el banner de portada · máx 5 · 50MB c/u" : "Capturas, PDFs, write-ups... máx 5 · 50MB c/u";
  $("composeSubmitBtn").textContent = "Publicar";
}

qsa(".compose-type-tab", $("composeTypeTabs")).forEach(function(tab) {
  tab.addEventListener("click", function() {
    applyComposeType(tab.getAttribute("data-type"));
  });
});

function openCompose(type) {
  $("composeBackdrop").classList.add("open");
  applyComposeType(type === "info" ? "info" : "normal");
  $("composeTitle").focus();
  if (typeof refreshFlagOptionsList === "function") refreshFlagOptionsList();
  var sel = $("composeCircle");
  if (sel && sel.options.length <= 1) {
    supabase.from("circles").select("id,name").order("name").then(function(res) {
      if (res.error) return;
      (res.data || []).forEach(function(c) {
        var opt = document.createElement("option");
        opt.value = c.id;
        opt.textContent = c.name;
        sel.appendChild(opt);
      });
    });
  }
}

function closeCompose() {
  $("composeBackdrop").classList.remove("open");
  $("composeForm").reset();
  if (typeof flagFieldSet === "function") flagFieldSet("composeFlag", []);
  composeAttach.reset();
  applyComposeType("normal");
}

$("btnNewThread").addEventListener("click", function() {
  openCompose("normal");
});

$("composeClose").addEventListener("click", closeCompose);

$("composeBackdrop").addEventListener("click", function(e) {
  if (e.target === this) closeCompose();
});

function publishThreadNow(payload, opts) {
  opts = opts || {};
  var files = payload.files || [];
  var uploadPromise = files.length ? uploadFiles(files, "threads/" + payload.authorId) : Promise.resolve([]);
  return uploadPromise.then(function(attachments) {
    var fullBody = payload.body + encodeAttachments(attachments);
    var slug = slugify(payload.title);
    var images = attachments.filter(function(a) {
      return a.type && a.type.indexOf("image/") === 0;
    });
    var firstImage = images[0];
    return supabase.from("threads").insert({
      author_id: payload.authorId,
      title: payload.title,
      slug: slug,
      excerpt: payload.body.slice(0, 140),
      tags: [ "Nuevo" ],
      pinned: false,
      views: 1,
      cover_image_url: firstImage ? firstImage.url : null,
      cover_images: images.slice(0, 3).map(function(a) {
        return a.url;
      }),
      circle_id: payload.circleId || null,
      post_type: payload.isInfo ? "info" : "normal",
      region: currentUser && currentUser.region || "LATAM"
    }).select().single().then(function(res) {
      if (res.error) throw res.error;
      var threadId = res.data.id;
      if (payload.flagTexts && payload.flagTexts.length && typeof tagEntityWithFlags === "function") tagEntityWithFlags(payload.flagTexts, "publication", threadId);
      return supabase.from("posts").insert({
        thread_id: threadId,
        author_id: payload.authorId,
        body: fullBody
      }).select().single().then(function(postRes) {
        var postId = postRes.data ? postRes.data.id : null;
        var indexPromise = postId && attachments.length ? supabase.from("attachments").insert(attachments.map(function(a) {
          return {
            thread_id: threadId,
            post_id: postId,
            uploader_id: payload.authorId,
            name: a.name,
            slug: a.slug,
            url: a.url,
            type: a.type,
            size: a.size
          };
        })) : Promise.resolve();
        return indexPromise.then(function() {
          if (currentUser && currentUser.id === payload.authorId) currentUser.threadsCount = (currentUser.threadsCount || 0) + 1;
          if (!opts.fromQueue) {
            closeCompose();
            return loadThreads().then(function() {
              renderSidebar();
              renderThreadList();
              openThread(threadId);
              toast(t("forum.toast_published"));
            });
          }
          toast('"' + payload.title + '" ' + t("forum.toast_offline_queued"));
          return loadThreads().then(function() {
            renderSidebar();
            renderThreadList();
          });
        });
      });
    });
  });
}

if (typeof OfflineQueue !== "undefined") {
  OfflineQueue.registerHandler("create_thread", function(payload) {
    return publishThreadNow(payload, {
      fromQueue: true
    });
  });
}

$("composeForm").addEventListener("submit", function(e) {
  e.preventDefault();
  if (!currentUser) {
    toast(t("forum.login_publish"));
    return;
  }
  var isInfo = composeState.type === "info";
  var title = $("composeTitle").value.trim();
  var body = $("composeBody").value.trim();
  if (!title || !body) return;
  var files = composeAttach.getFiles();
  var hasImage = files.some(function(f) {
    return f.type && f.type.indexOf("image/") === 0;
  });
  if (isInfo && !hasImage) {
    toast(t("forum.info_needs_image"));
    return;
  }
  var payload = {
    authorId: currentUser.id,
    title: title,
    body: body,
    isInfo: isInfo,
    circleId: $("composeCircle").value || null,
    flagTexts: typeof flagFieldGet === "function" ? flagFieldGet("composeFlag") : [],
    files: files
  };
  if (OfflineQueue.isOffline()) {
    OfflineQueue.enqueue("create_thread", payload);
    closeCompose();
    toast(t("forum.toast_offline_publish"));
    return;
  }
  var btn = $("composeSubmitBtn");
  if (btn) {
    btn.disabled = true;
    btn.textContent = files.length ? t("forum.uploading_attachments") : t("forum.publishing");
  }
  publishThreadNow(payload).catch(function(err) {
    if (OfflineQueue.isNetworkError(err)) {
      OfflineQueue.enqueue("create_thread", payload);
      closeCompose();
      toast(t("forum.toast_offline_publish"));
    } else {
      toast(t("forum.err_publish"));
    }
    if (btn) {
      btn.disabled = false;
      btn.textContent = t("forum.btn_publish");
    }
  });
});

/* Refresco automático del hilo abierto: los comentarios de otras personas aparecen solos.
   No toca nada si estás escribiendo un comentario o tienes archivos adjuntos. */
var threadAutoSig = {};

function threadPostsSig(posts) {
  return (posts || []).map(function(p) {
    return p.id + ":" + (p.body ? p.body.length : 0);
  }).join("|");
}

function threadAutoRefresh() {
  if (document.hidden || !currentUser) return;
  var panel = document.getElementById("panel-thread");
  if (!panel || !panel.classList.contains("active")) return;
  var openId = null;
  THREADS.forEach(function(x) {
    if (x.posts && history.state && history.state.id === x.id) openId = x.id;
  });
  if (!openId) {
    var m = location.pathname.match(/^\/temas\/([^\/]+)\/?$/);
    if (m) {
      var slug = decodeURIComponent(m[1]);
      THREADS.forEach(function(x) {
        if (x.slug === slug) openId = x.id;
      });
    }
  }
  if (!openId) return;
  var th = THREADS.filter(function(x) {
    return x.id === openId;
  })[0];
  if (!th || !th.posts) return;
  var inp = document.getElementById("replyInput");
  if (inp && (inp.value.trim() || document.activeElement === inp)) return;
  var before = threadPostsSig(th.posts);
  loadThreadPosts(openId).then(function(posts) {
    if (!posts || threadPostsSig(posts) === before) return;
    var again = document.getElementById("replyInput");
    if (again && (again.value.trim() || document.activeElement === again)) return;
    openThread(openId, {
      silent: true
    });
  });
}

setInterval(threadAutoRefresh, 8000);

document.addEventListener("visibilitychange", function() {
  if (!document.hidden) threadAutoRefresh();
});
