"use strict";

var OfflineQueue = function() {
  var DB_NAME = "hs_offline_v1";
  var STORE = "outbox";
  var dbPromise = null;
  var HANDLERS = {};
  var flushing = false;
  function openDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function(resolve, reject) {
      if (!("indexedDB" in window)) {
        reject(new Error("IndexedDB no disponible"));
        return;
      }
      var req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = function() {
        var db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, {
            keyPath: "id",
            autoIncrement: true
          });
        }
      };
      req.onsuccess = function() {
        resolve(req.result);
      };
      req.onerror = function() {
        reject(req.error);
      };
    });
    return dbPromise;
  }
  function registerHandler(type, fn) {
    HANDLERS[type] = fn;
  }
  function isOffline() {
    return !navigator.onLine;
  }
  function isNetworkError(err) {
    return !!err && err instanceof TypeError && /fetch|network/i.test(err.message || "");
  }
  function enqueue(type, payload) {
    return openDb().then(function(db) {
      return new Promise(function(resolve, reject) {
        var tx = db.transaction(STORE, "readwrite");
        var item = {
          type: type,
          payload: payload,
          createdAt: Date.now()
        };
        var req = tx.objectStore(STORE).add(item);
        req.onsuccess = function() {
          item.id = req.result;
          resolve(item);
        };
        req.onerror = function() {
          reject(req.error);
        };
      });
    }).then(function(item) {
      updateBadge();
      return item;
    });
  }
  function removeItem(id) {
    return openDb().then(function(db) {
      return new Promise(function(resolve) {
        var tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE)["delete"](id);
        tx.oncomplete = function() {
          resolve();
        };
      });
    });
  }
  function getAll() {
    return openDb().then(function(db) {
      return new Promise(function(resolve, reject) {
        var tx = db.transaction(STORE, "readonly");
        var req = tx.objectStore(STORE).getAll();
        req.onsuccess = function() {
          resolve(req.result || []);
        };
        req.onerror = function() {
          reject(req.error);
        };
      });
    });
  }
  function flush() {
    if (flushing || isOffline()) return Promise.resolve();
    flushing = true;
    return getAll().then(function(items) {
      return items.reduce(function(chain, item) {
        return chain.then(function() {
          var handler = HANDLERS[item.type];
          if (!handler) {
            return removeItem(item.id);
          }
          return handler(item.payload).then(function() {
            return removeItem(item.id);
          })["catch"](function(err) {
            console.warn("[offline] no se pudo reenviar todavía:", item.type, err);
          });
        });
      }, Promise.resolve());
    }).then(function() {
      flushing = false;
      updateBadge();
    })["catch"](function() {
      flushing = false;
    });
  }
  function updateBadge() {
    getAll().then(function(items) {
      window.dispatchEvent(new CustomEvent("offline-queue-change", {
        detail: {
          count: items.length,
          items: items
        }
      }));
    })["catch"](function() {});
  }
  window.addEventListener("online", flush);
  document.addEventListener("visibilitychange", function() {
    if (document.visibilityState === "visible") flush();
  });
  window.addEventListener("load", function() {
    setTimeout(flush, 1500);
  });
  return {
    enqueue: enqueue,
    registerHandler: registerHandler,
    isOffline: isOffline,
    isNetworkError: isNetworkError,
    flush: flush,
    getAll: getAll
  };
}();