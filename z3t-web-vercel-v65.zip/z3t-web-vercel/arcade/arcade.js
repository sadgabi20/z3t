const A=p=>(window.ASSETS&&ASSETS[p])||'assets/'+p;
/* ===== CONFIGURACIÓN: monedas e imágenes ===== */
const CONFIG={
  // Se llama cada vez que el jugador gana monedas. Conéctalo aquí con tu app/API.
  onReward:(tier,amount,game)=>{/* TODO: enviar a tu backend */},
  // Valor por nivel: zeta = el más bajo, diamante = el más alto
  tiers:{zeta:1,bronce:5,oro:25,diamante:100},
  // Premios por puesto (el 1.º usa winBonus): [nivel, cantidad]
  place:{2:['bronce',5],3:['zeta',10]},
  // Tienda de canje: cost = lo que se gasta; get = [moneda de la app, cantidad]
  exchange:[{id:'coins',n:'Z-Coins',icon:'coins',cost:{zeta:10,bronce:5,oro:25},get:['coins',100]},{id:'diamantes',n:'Diamantes',icon:'diamante',cost:{diamante:100},get:['diamantes',100]}],
  onExchange:(id,amount,cost)=>{/* TODO: acreditar en tu app/API */},
  logo:{zeta:'/assets/icons/coin-z.png',diamante:'/assets/currency/coin-diamante.png',coins:'/assets/currency/coin-zcoin.png'}, // logos de tu app (URL o data:)
  // Matchmaking: devuelve jugadores reales [{name}]; vacío = se completan con bots
  net:{wait:3000,find:async(game,n)=>[]},
  // Bonus al ganar cada juego: [nivel, cantidad]
  winBonus:{carreras:['oro',1],naves:['oro',2],guerra:['oro',3],vuelo:['diamante',1]},
  // Imágenes tuyas (data: URI o ruta propia). Vacío = icono emoji.
  img:{carreras:A('images/car.png'),naves:A('images/ship.png'),guerra:A('images/tank.png'),vuelo:A('images/plane.png')}
};
/* ============================================= */
const T=THREE,H=Math.PI/2,$=id=>document.getElementById(id);
const R=new T.WebGLRenderer({antialias:true});R.setPixelRatio(Math.min(devicePixelRatio,2));document.body.prepend(R.domElement);
let S,C,G,run,cur,state='menu',SH=0,ct=0,ln=0,FOC=0;const clock=new T.Clock();
const rnd=(a,b)=>a+Math.random()*(b-a),pick=a=>a[Math.random()*a.length|0],cl=(v,a,b)=>Math.max(a,Math.min(b,v));
const M=(g,c,o={})=>new T.Mesh(g,new T.MeshLambertMaterial({color:c,flatShading:true,...o}));
const B=(w,h,d,c)=>M(new T.BoxGeometry(w,h,d),c),BM=c=>new T.MeshBasicMaterial({color:c,fog:false});
function rs(){R.setSize(innerWidth,innerHeight);if(G&&G.ins)setLayout();if(C){C.aspect=innerWidth/innerHeight;C.updateProjectionMatrix()}}
addEventListener('resize',rs);
function scene(sky,f0,f1){S=new T.Scene();S.background=new T.Color(sky);S.fog=new T.Fog(sky,f0,f1);C=new T.PerspectiveCamera(65,1,.1,420);S.add(new T.HemisphereLight(0xffffff,0x334466,.95));const d=new T.DirectionalLight(0xffffff,.8);d.position.set(5,10,6);S.add(d);rs()}
/* ---- entrada ---- */
const K={};let J={x:0,y:0},F=0;
addEventListener('keydown',e=>{K[e.code]=1;if(e.code=='KeyP')pause();if(e.code=='KeyV')toggleFoc();if(/Arrow|Space/.test(e.code))e.preventDefault()});addEventListener('keyup',e=>K[e.code]=0);
const js=$('js'),kn=$('kn');
js.onpointerdown=js.onpointermove=e=>{if(e.type=='pointermove'&&!e.buttons)return;const r=js.getBoundingClientRect(),x=(e.clientX-r.left-r.width/2)/(r.width/2),y=(e.clientY-r.top-r.height/2)/(r.height/2),l=Math.hypot(x,y)||1,k=Math.min(1,l);J.x=x/l*k;J.y=y/l*k;kn.style.transform=`translate(${J.x*38}px,${J.y*38}px)`;js.setPointerCapture(e.pointerId)};
js.onpointerup=js.onpointercancel=()=>{J.x=J.y=0;kn.style.transform=''};
const fb=$('fire');fb.onpointerdown=()=>F=1;fb.onpointerup=fb.onpointerleave=fb.onpointercancel=()=>F=0;
const ax=()=>((K.ArrowRight||K.KeyD?1:0)-(K.ArrowLeft||K.KeyA?1:0))||J.x;
const ay=()=>((K.ArrowDown||K.KeyS?1:0)-(K.ArrowUp||K.KeyW?1:0))||J.y;
const fire=()=>F||K.Space;
if(matchMedia('(pointer:coarse)').matches)document.body.classList.add('touch');
const fs=()=>{const e=document.documentElement;document.fullscreenElement?document.exitFullscreen():(e.requestFullscreen||e.webkitRequestFullscreen||(()=>{})).call(e)?.catch?.(()=>{})};
$('fs').onclick=fs;
/* ---- Supabase: usuarios reales de Z3T (misma sesión que la app, mismo dominio) ---- */
const SB=window.supabase.createClient("https://pqbpeccvzycdspmfsgab.supabase.co","sb_publishable_kFQRBOv-qOxy5x_B9z3Jpw_dr7YsSpt");
let ME=null,MATCH=null,APP={coin:0,stars:0},WL0={};
let WL={zeta:0,bronce:0,oro:0,diamante:0};const svW=()=>{};
async function loadWallet(){
  const a=await SB.rpc('mg_get_wallet');if(a.error)throw a.error;if(a.data&&a.data[0])Object.assign(WL,a.data[0]);
  const b=await SB.rpc('rpc_get_my_wallet');if(!b.error&&b.data&&b.data[0])APP={coin:b.data[0].coin_balance,stars:b.data[0].stars_balance}}
/* ---- monedas ---- */
const TI={zeta:0x9aa7ff,bronce:0xcd7f32,oro:0xffd23f,diamante:0x7df9ff},EM={zeta:'🪙',bronce:'🥉',oro:'🥇',diamante:'💎',coins:'💰'};
function coin(t){const d=t=='diamante',m=d?M(new T.OctahedronGeometry(.8),TI[t],{emissive:TI[t],emissiveIntensity:.5}):M(new T.CylinderGeometry(.8,.8,.2,14),TI[t],{emissive:TI[t],emissiveIntensity:.4});if(!d)m.rotation.x=H;const g=new T.Group();g.add(m);g.userData.t=t;return g}
const roll=()=>{const r=Math.random();return r<.72?'zeta':r<.92?'bronce':r<.987?'oro':'diamante'};
function reward(t,n=1){CONFIG.onReward(t,n,cur);run[t]+=n;WL[t]=(WL[t]||0)+n;svW();const c=$('cn');c.classList.remove('pop');void c.offsetWidth;c.classList.add('pop')}
const val=()=>Object.keys(CONFIG.tiers).reduce((s,t)=>s+run[t]*CONFIG.tiers[t],0);
const hud=(hp,p,g,l)=>{$('hp').textContent='❤️'.repeat(Math.max(hp,0));$('bar').style.width=Math.min(100,p/g*100)+'%';$('lb').textContent=l+' '+Math.floor(p)+'/'+g;$('cn').textContent='🪙 '+val()};
const flash=()=>{SH=.6;const f=$('fl');f.style.transition='none';f.style.opacity=.45;requestAnimationFrame(()=>{f.style.transition='opacity .4s';f.style.opacity=0})};
/* ---- modelos ---- */
const car=(c,pl)=>{const g=new T.Group();const body=M(new T.BoxGeometry(2.05,.48,4.05),c,{metalness:.35,roughness:.3});body.position.y=.62;g.add(body);
const hood=B(1.8,.22,1.12,c);hood.position.set(0,.86,-1.18);g.add(hood);
const cabin=M(new T.BoxGeometry(1.42,.58,1.75),0x142846,{metalness:.2,roughness:.18,transparent:true,opacity:.94});cabin.position.set(0,1.05,.22);g.add(cabin);
const roof=B(1.18,.08,.82,pl?0x9ae7ff:0x7e91aa);roof.position.set(0,1.36,.18);g.add(roof);
const glass=M(new T.BoxGeometry(1.28,.25,.08),0x67eaff,{emissive:0x0b6385,emissiveIntensity:.65});glass.position.set(0,1.12,-.62);g.add(glass);
for(const[x,z]of[[-1,1.2],[1,1.2],[-1,-1.2],[1,-1.2]]){const w=M(new T.CylinderGeometry(.43,.43,.38,16),0x10131c,{metalness:.7,roughness:.4});w.rotation.z=H;w.position.set(x,.43,z);g.add(w);const rim=M(new T.CylinderGeometry(.23,.23,.395,12),0x9eafc7,{metalness:.8});rim.rotation.z=H;rim.position.set(x,.43,z);g.add(rim);for(let j=0;j<5;j++){const spoke=B(.045,.045,.28,0xd5f4ff);spoke.position.set(x+Math.cos(j*Math.PI*2/5)*.1,.43,z+Math.sin(j*Math.PI*2/5)*.1);g.add(spoke)}}
for(const x of[-.68,.68]){const lamp=M(new T.BoxGeometry(.36,.12,.06),0x8ffaff,{emissive:0x00cfff,emissiveIntensity:1.5});lamp.position.set(x,.76,-2.04);g.add(lamp);const rear=M(new T.BoxGeometry(.34,.12,.06),0xff315f,{emissive:0xff0033,emissiveIntensity:1.2});rear.position.set(x,.76,2.04);g.add(rear)}
const spoiler=B(1.55,.1,.22,0x171e35);spoiler.position.set(0,1.12,1.65);g.add(spoiler);const leg1=B(.08,.28,.08,0x9aabc0),leg2=leg1.clone();leg1.position.set(-.48,.98,1.62);leg2.position.set(.48,.98,1.62);g.add(leg1,leg2);
g.userData.wheels=g.children.filter(o=>o.geometry&&o.geometry.type==='CylinderGeometry');return g};
const ship=()=>{const g=new T.Group();const hull=M(new T.ConeGeometry(.72,3.5,8),0xdceaff,{metalness:.55,roughness:.22});hull.rotation.x=-H;g.add(hull);
const cockpit=M(new T.SphereGeometry(.34,12,8),0x00dfff,{emissive:0x006bff,emissiveIntensity:1.1,metalness:.3});cockpit.scale.set(.8,.55,1.5);cockpit.position.set(0,.18,-.28);g.add(cockpit);
for(const s of[-1,1]){const wing=M(new T.BoxGeometry(1.55,.12,1.25),s<0?0x00e5ff:0x6f5cff,{metalness:.4});wing.position.set(s*1.12,-.1,.65);wing.rotation.y=s*.16;g.add(wing);const pod=B(.38,.35,.9,0x263754);pod.position.set(s*1.55,-.12,1.05);g.add(pod);const glow=M(new T.ConeGeometry(.2,.85,8),0x00e5ff,{emissive:0x00bfff,emissiveIntensity:1.8});glow.rotation.x=H;glow.position.set(s*1.45,-.05,1.75);g.add(glow)}
const fin=B(.12,.55,.72,0xff3d81);fin.position.set(0,.28,1.12);g.add(fin);return g};
const plane=()=>{const g=new T.Group();const fus=M(new T.CylinderGeometry(.34,.48,4.4,12),0xe8f1ff,{metalness:.35,roughness:.28});fus.rotation.x=H;g.add(fus);
const nose=M(new T.ConeGeometry(.38,1.1,12),0xff3d81,{metalness:.25});nose.rotation.x=-H;nose.position.z=-2.55;g.add(nose);
for(const s of[-1,1]){const wing=M(new T.BoxGeometry(2.25,.12,1.15),0xff3d81,{metalness:.35});wing.position.set(s*1.05,.0,-.1);wing.rotation.y=s*.13;g.add(wing);const engine=M(new T.CylinderGeometry(.18,.24,.85,10),0x4a5d78);engine.rotation.x=H;engine.position.set(s*.7,-.12,1.45);g.add(engine);const flame=M(new T.ConeGeometry(.19,.85,8),0x00dfff,{emissive:0x007bff,emissiveIntensity:1.8});flame.rotation.x=H;flame.position.set(s*.7,-.12,2.05);g.add(flame)}
const tail=B(.75,.1,.65,0xff3d81);tail.position.z=1.72;g.add(tail);const fin=B(.12,.7,.65,0xff3d81);fin.position.set(0,.35,1.65);g.add(fin);
const cockpit=M(new T.SphereGeometry(.33,12,8),0x00cfff,{emissive:0x005577,emissiveIntensity:.7});cockpit.scale.set(.7,.45,1.7);cockpit.position.set(0,.28,-.5);g.add(cockpit);return g};
const TL=new T.TextureLoader(),PU={};['shield','speed','extra_life'].forEach(n=>PU[n]=TL.load(A('sprites/'+n+'.png')));
const pu=()=>{const t=pick(['shield','speed','extra_life']),m=new T.Sprite(new T.SpriteMaterial({map:PU[t],transparent:true}));m.scale.set(2.6,2.6,1);return{m,k:'pu',t,r:1.3}};
/* ---- motor de pasillo (carreras, naves, vuelo) ---- */
function scn(sky,f0,f1){const S=new T.Scene();S.background=new T.Color(sky);S.fog=new T.Fog(sky,f0,f1);S.add(new T.HemisphereLight(0xffffff,0x334466,.95));const d=new T.DirectionalLight(0xffffff,.8);d.position.set(5,10,6);S.add(d);return[S,new T.PerspectiveCamera(65,1,.1,420)]}
function runner(c){
  const[S,C]=scn(c.sky,20,c.far||160);const P=c.player(),O=[],Bs=[],Sc=[];S.add(P);P.position.y=c.ym?2:0;c.env(S,Sc);
  let hp=3,prog=0,spt=1,cd=0,sh=0,bo=0,tt=0;const Tr=[],tg=new T.BoxGeometry(.3,.3,.3),sd=M(new T.SphereGeometry(2.6,16,12),0x00e5ff,{transparent:true,opacity:.25,emissive:0x00e5ff,emissiveIntensity:.6});sd.visible=false;P.add(sd);let tm=0,stun=0;const sk=c.sk||1,sd0=Math.random()*6;
  const bot=()=>{const p=P.position;let th=null,tq=null;
    for(const o of O){const q=o.m.position;if(q.z>-1||q.z<-48*sk)continue;const near=Math.abs(q.x-p.x)<o.r+1.8&&(!c.ym||Math.abs(q.y-p.y)<o.r+1.4);
      if((o.k=='bad'||(o.k=='enemy'&&q.z>-9))&&near){if(!th||q.z>th.m.position.z)th=o}else if(o.k!='bad'){if(!tq||q.z>tq.m.position.z)tq=o}}
    let tx=p.x,ty=p.y;if(th){const q=th.m.position;tx=p.x+(q.x>p.x?-4:4);ty=p.y+(q.y>p.y?-3:3)}else if(tq){tx=tq.m.position.x;ty=tq.m.position.y}
    return{x:cl((tx-p.x)/2,-1,1)*sk,y:cl((p.y-ty)/2,-1,1)*sk,f:c.shoot?1:(Math.sin(tm*.8+sd0)>-.3?1:0)}};const bg=new T.BoxGeometry(.25,.25,1.6),bm=BM(0x00ffff);
  const kill=o=>{S.remove(o.m);O.splice(O.indexOf(o),1)};
  const spawn=()=>{const q=Math.random(),o=q<c.cr?{m:coin(roll()),k:'coin',r:1}:q<c.cr+.06?pu():c.obj(),m=o.m;m.position.set(c.lanes?pick(c.lanes):rnd(-c.W,c.W),c.ym?rnd(c.y0,c.y1):0,-140);S.add(m);O.push(o)};
  return{S,C,get prog(){return prog},update(dt){
    const I=c.bot?bot():{x:ax(),y:ay(),f:fire()};tm+=dt;stun=Math.max(0,stun-dt);sh=Math.max(0,sh-dt);bo=Math.max(0,bo-dt);sd.visible=sh>0;const v=c.speed*(c.turbo&&I.f?1.5:1)*(bo>0?1.3:1)*(stun>0?.45:1)*(1+.3*prog/c.goal),p=P.position;
    p.x=cl(p.x+I.x*c.xs*dt,-c.W,c.W);P.rotation.z=-I.x*.35;if(P.userData.wheels)P.userData.wheels.forEach(w=>w.rotation.x+=dt*12);if(P.userData.wheels)P.userData.wheels.forEach(w=>w.rotation.x+=dt*12);
    if(c.ym){p.y=cl(p.y-I.y*c.xs*dt,c.y0,c.y1);P.rotation.x=-I.y*.2}
    for(const m of Sc){m.position.z+=v*dt;if(m.position.z>12)m.position.z-=220}
    if(c.dist)prog+=v*dt;
    spt-=dt;if(spt<=0){spt=c.rate;spawn()}
    if(c.shoot){cd-=dt;if(I.f&&stun<=0&&cd<=0){cd=.2;const b=new T.Mesh(bg,bm);b.position.set(p.x,p.y,p.z-2);S.add(b);Bs.push(b)}
      for(let i=Bs.length-1;i>=0;i--){const b=Bs[i];b.position.z-=80*dt;let h=0;
        for(const o of O)if(o.k=='enemy'&&Math.abs(o.m.position.z-b.position.z)<o.r+1&&Math.hypot(o.m.position.x-b.position.x,o.m.position.y-b.position.y)<o.r+.4){h=1;if(--o.hp<=0){prog++;if(Math.random()<.5){const n={m:coin(roll()),k:'coin',r:1};n.m.position.copy(o.m.position);S.add(n.m);O.push(n)}kill(o)}break}
        if(h||b.position.z<-150){S.remove(b);Bs.splice(i,1)}}}
    for(let i=O.length-1;i>=0;i--){const o=O[i],m=o.m,q=m.position;q.z+=(v+(o.s||0))*dt;m.rotation.y+=dt*(o.sp||0)+(o.k=='coin'?dt*3:0);
      const dx=q.x-p.x,dy=c.ym?q.y-p.y:0;
      if(o.k=='ring'){if(q.z>-1&&!o.d){o.d=1;if(Math.hypot(dx,dy)<2.6){prog++;if(!c.bot)reward('zeta');kill(o);continue}}}
      else if(Math.abs(q.z)<o.r+1.2&&Math.abs(dx)<o.r+1&&Math.abs(dy)<o.r+.8){if(o.k=='coin'){if(!c.bot)reward(m.userData.t)}else if(o.k=='pu'){if(o.t=='extra_life')hp=Math.min(hp+1,5);else if(o.t=='shield')sh=6;else bo=4}else if(sh<=0){if(c.mp)stun=1.2;else hp--;if(!c.bot)flash()}kill(o);continue}
      if(q.z>10)kill(o)}
    C.position.set(p.x*.6,c.cy+(c.ym?p.y*.5:0),c.cz);C.lookAt(p.x*.4,c.ym?p.y*.4:0,-14);
    C.fov+=(((c.turbo&&I.f)||bo>0?76:65)-C.fov)*Math.min(1,dt*6);C.updateProjectionMatrix();
    tt-=dt;if(dt>0&&tt<=0&&c.trail&&!c.bot&&(c.ym||I.f)){tt=.03;const m=new T.Mesh(tg,new T.MeshBasicMaterial({color:c.trail,transparent:true,fog:false}));m.position.set(p.x+(c.tx?(Math.random()<.5?-c.tx:c.tx):rnd(-.5,.5)),p.y+(c.ym?-.1:.5),p.z+2.2);S.add(m);Tr.push({m,t:.45})}
    for(let i=Tr.length-1;i>=0;i--){const q=Tr[i];q.t-=dt;q.m.position.z+=(v+8)*dt;q.m.scale.setScalar(Math.max(.01,q.t/.45));q.m.material.opacity=Math.max(0,q.t/.45);if(q.t<=0){S.remove(q.m);q.m.material.dispose();Tr.splice(i,1)}}
    if(!c.bot)hud(c.mp?0:hp,prog,c.goal,c.lbl+(sh>0?' 🛡️':'')+(bo>0?' ⚡':''));if(!c.mp){if(hp<=0)end(false);else if(prog>=c.goal)end(true)}}}}
/* ---- guerra de tanques ---- */
function tank(P){
  scene(0x7ec8ff,50,190);const gr=B(120,.2,120,0x4f7d3a);gr.position.y=-.1;const gh=new T.GridHelper(120,30,0x3d6a2c,0x3d6a2c);gh.position.y=.02;S.add(gr,gh);
  const OB=[];for(let i=0;i<16;i++){const w=rnd(3,6),h=rnd(2,6),m=B(w,h,w,pick([0x8892a6,0x6b7488,0xa07a5a]));let x,z;do{x=rnd(-48,48);z=rnd(-48,48)}while(Math.hypot(x,z)<10);m.position.set(x,h/2,z);S.add(m);OB.push({x,z,r:w*.75})}
  const mk=c=>{const g=new T.Group(),b=M(new T.BoxGeometry(2.2,.8,3.2),c,{metalness:.25,roughness:.7});b.position.y=.72;g.add(b);for(const x of[-1.3,1.3]){const t=M(new T.BoxGeometry(.5,.82,3.5),0x20252d,{metalness:.5,roughness:.8});t.position.set(x,.42,0);g.add(t);for(let j=0;j<6;j++){const w=M(new T.CylinderGeometry(.22,.22,.54,12),0x66717d,{metalness:.65});w.rotation.z=H;w.position.set(x,.4,-1.35+j*.54);g.add(w)}const stripe=B(.08,.08,3.1,0x9ca7b5);stripe.position.set(x*1.02,.86,0);g.add(stripe)}
const top=M(new T.BoxGeometry(1.45,.58,1.55),c,{metalness:.3,roughness:.6});top.position.set(0,1.32,-.15);g.add(top);const hatch=M(new T.CylinderGeometry(.34,.34,.12,12),0x303a44);hatch.position.set(0,1.68,-.2);g.add(hatch);const tu=new T.Group(),h=M(new T.CylinderGeometry(.52,.6,.5,12),c,{metalness:.35});h.position.y=1.45;tu.add(h);const br=M(new T.CylinderGeometry(.16,.2,2.35,10),0x424c58,{metalness:.7});br.rotation.x=H;br.position.set(0,1.48,1.25);tu.add(br);const muzzle=B(.28,.28,.28,0x171c24);muzzle.position.set(0,1.48,2.42);tu.add(muzzle);g.add(tu);g.tu=tu;g.userData.tracks=g.children.filter(o=>o.geometry&&o.geometry.type==='CylinderGeometry');S.add(g);return g};
  const COL=[0x2dd4ff,0xff3d4d,0xffd23f,0xb06bff,0xff8a3d],sg=new T.SphereGeometry(.35,8,6),Bl=[],X=[],Cn=[];
  const Tk=P.map((p,i)=>{const g=mk(COL[i]),a=i/5*Math.PI*2+.5;g.position.set(Math.sin(a)*38,0,Math.cos(a)*38);return{g,hp:i?3:5,n:p.n,al:1,cd:rnd(0,1),i,rk:0}});
  let tm=0,fin=0;const al=()=>Tk.filter(t=>t.al);
  const mv=(g,dx,dz,r)=>{const p=g.position;p.x=cl(p.x+dx,-55,55);p.z=cl(p.z+dz,-55,55);for(const o of OB){const ddx=p.x-o.x,ddz=p.z-o.z,d=Math.hypot(ddx,ddz);if(d<o.r+r){p.x=o.x+ddx/d*(o.r+r);p.z=o.z+ddz/d*(o.r+r)}}};
  const shot=(g,a,own)=>{const m=new T.Mesh(sg,BM(own.i?0xff5a3d:0x00ffff)),d=new T.Vector3(Math.sin(a),0,Math.cos(a));m.position.copy(g.position).addScaledVector(d,2.6);m.position.y=1.3;S.add(m);Bl.push({m,d,own,t:1.8})};
  const boom=p=>{const m=new T.Mesh(new T.SphereGeometry(1,10,8),new T.MeshBasicMaterial({color:0xff9a3d,transparent:true}));m.position.copy(p);m.position.y=1;S.add(m);X.push({m,t:0})};
  const ang=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
  const cam=()=>{const f=Tk[0].al?Tk[0]:(al()[0]||Tk[0]);C.position.set(f.g.position.x,17,f.g.position.z+13);C.lookAt(f.g.position.x,0,f.g.position.z-1);hud(Tk[0].al?Tk[0].hp:0,5-al().length,4,Tk[0].al?'Eliminados':'👁 Espectando')};
  return{update(dt0){
    if(!dt0){cam();return}
    const dt=dt0*(Tk[0].al?1:2.5);tm+=dt;
    for(const t of Tk){if(!t.al)continue;const g=t.g;let ne=null,nd=1e9;
      for(const o of Tk)if(o!=t&&o.al){const d=g.position.distanceTo(o.g.position);if(d<nd){nd=d;ne=o}}
      const a=ne?Math.atan2(ne.g.position.x-g.position.x,ne.g.position.z-g.position.z):g.rotation.y;let dx=0,dz=0,f=0;
      if(!t.i){dx=ax();dz=ay();f=fire()}
      else if(ne){const s=t.i%2?1:-1;if(nd>15){dx=Math.sin(a);dz=Math.cos(a)}else if(nd<8){dx=-Math.sin(a);dz=-Math.cos(a)}else{dx=Math.cos(a)*s;dz=-Math.sin(a)*s}f=nd<36}
      const l=Math.hypot(dx,dz);if(l>.1){const n=Math.max(l,1),v=(t.i?7:10)*dt;dx/=n;dz/=n;mv(g,dx*v,dz*v,1.6);g.rotation.y+=ang(Math.atan2(dx,dz),g.rotation.y)*Math.min(1,dt*10)}
      g.tu.rotation.y=a-g.rotation.y;t.cd-=dt;if(f&&ne&&t.cd<=0){t.cd=t.i?rnd(.9,1.5):.4;shot(g,a+(t.i?rnd(-.12,.12):0),t)}}
    for(let i=Bl.length-1;i>=0;i--){const b=Bl[i],q=b.m.position;q.addScaledVector(b.d,28*dt);b.t-=dt;let h=b.t<=0;
      for(const o of OB)if(Math.hypot(q.x-o.x,q.z-o.z)<o.r)h=1;
      for(const t of Tk)if(t.al&&t!=b.own&&Math.hypot(q.x-t.g.position.x,q.z-t.g.position.z)<1.8){h=1;boom(q);if(!t.i)flash();
        if(--t.hp<=0){t.al=0;t.rk=al().length+1;boom(t.g.position);S.remove(t.g);if(!b.own.i&&Math.random()<.6){const m=coin(roll());m.position.set(t.g.position.x,1,t.g.position.z);S.add(m);Cn.push(m)}}break}
      if(h){S.remove(b.m);Bl.splice(i,1)}}
    for(let i=Cn.length-1;i>=0;i--){const m=Cn[i];m.rotation.y+=dt*3;if(Tk[0].al&&Math.hypot(m.position.x-Tk[0].g.position.x,m.position.z-Tk[0].g.position.z)<2.2){reward(m.userData.t);S.remove(m);Cn.splice(i,1)}}
    for(let i=X.length-1;i>=0;i--){const x=X[i];x.t+=dt;x.m.scale.setScalar(1+x.t*6);x.m.material.opacity=Math.max(0,1-x.t/.4);if(x.t>.4){S.remove(x.m);X.splice(i,1)}}
    cam();
    if(!fin&&al().length<=1){fin=1;const w=al()[0];if(w)w.rk=1;const o=[...Tk].sort((a,b)=>a.rk-b.rk);end(Tk[0].rk==1,Tk[0].rk,o.map(t=>t.rk+'. '+t.n).join('<br>'))}}}}
/* ---- partidas de 5 con pantallas divididas ---- */
function match(P,c){
  const ins=[0,1,2,3,4].map(i=>runner({...c,mp:1,bot:i>0,sk:rnd(.6,.95)})),nm=P.map(p=>p.n);let over=0,tl=0;
  return{ins,nm,update(dt){ins.forEach(x=>x.update(dt));const pr=ins.map(x=>x.prog),o=[0,1,2,3,4].sort((a,b)=>pr[b]-pr[a]);
    tl-=dt;if(tl<=0){tl=.25;$('lbd').innerHTML=o.map(i=>`<div class="lr${i?'':' me'}"><i style="width:${Math.min(100,pr[i]/c.goal*100)}%"></i><span>${nm[i]}</span></div>`).join('')}
    if(!over&&pr[o[0]]>=c.goal){over=1;end(o[0]==0,o.indexOf(0)+1,o.map((i,j)=>`${j+1}. ${nm[i]} · ${Math.floor(Math.min(1,pr[i]/c.goal)*100)}%`).join('<br>'))}}}}
function toggleFoc(){FOC=FOC?0:1;try{localStorage.zeta_focus=FOC}catch(e){}document.body.classList.toggle('foc',!!FOC);$('fv').textContent=FOC?'🙈':'👁';if(G&&G.ins)setLayout()}
function setLayout(){const W=innerWidth,H=innerHeight,r=[];
  if(W>=H){const pw=Math.round(W*.58),bw=(W-pw)/2;r.push({x:0,y:0,w:pw,h:H});for(let i=0;i<4;i++)r.push({x:pw+(i%2)*bw,y:(i>>1)*H/2,w:bw,h:H/2})}
  else{const ph=Math.round(H*.62),bh=(H-ph)/2;r.push({x:0,y:H-ph,w:W,h:ph});for(let i=0;i<4;i++)r.push({x:(i%2)*W/2,y:(i>>1)*bh,w:W/2,h:bh})}
  if(FOC){r.length=0;r.push({x:0,y:0,w:W,h:H})}
  G.rc=r;$('vw').innerHTML=r.map((c,i)=>`<div class="vb${i?'':' me'}" style="left:${c.x}px;top:${c.y}px;width:${c.w}px;height:${c.h}px"><span>${G.nm[i]}</span></div>`).join('');
  const h=$('hudw').style;h.right='auto';h.left=r[0].x+'px';h.width=r[0].w+'px';h.top=(r[0].y+VBH())+'px';$('lbd').style.top=(r[0].y+52+VBH())+'px';$('fire').style.right=(W-r[0].x-r[0].w+18)+'px'}
function drw(){const W=innerWidth,H=innerHeight;
  if(G&&G.ins&&G.rc){R.setScissorTest(true);G.ins.forEach((x,i)=>{const c=G.rc[i];if(!c)return;const y=H-c.y-c.h;R.setViewport(c.x,y,c.w,c.h);R.setScissor(c.x,y,c.w,c.h);x.C.aspect=c.w/c.h;x.C.updateProjectionMatrix();R.render(x.S,x.C)});R.setScissorTest(false)}
  else{R.setViewport(0,0,W,H);R.render(S,C)}}

/* ---- chat de voz de la partida (LiveKit) ---- */
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const VOICE={room:null,roster:[],silenced:new Set(),mic:true,spk:{},tok:0};
const VBH=()=>document.body.classList.contains('vc')?44:0;
function vEl(t,c,x){const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
function renderVbar(){const b=$('vbar');if(!b)return;b.textContent='';const rm=VOICE.room;
  for(const p of VOICE.roster){const me=p.user_id===ME.id,part=me?null:(rm&&rm.remoteParticipants&&rm.remoteParticipants.get(p.user_id));
    const c=vEl('div','vp'+(me?' me':'')+(!me&&!part?' off':'')+(VOICE.spk[p.user_id]?' spk':''));c.dataset.id=p.user_id;
    const a=vEl('div','vpa');
    if(p.avatar_url){const i=vEl('img','vpi');i.alt='';i.src=p.avatar_url;i.onerror=()=>{i.replaceWith(vEl('div','vpi',(p.name||'?')[0].toUpperCase()))};a.append(i)}else a.append(vEl('div','vpi',(p.name||'?')[0].toUpperCase()));
    if(p.frame_url){const f=vEl('img','vpf');f.alt='';f.src=p.frame_url;f.onerror=()=>f.remove();a.append(f)}
    c.append(a,vEl('span','vpn',me?'Tú':p.name));
    let badge='';if(me)badge=VOICE.mic?'🎤':'🔇';else if(VOICE.silenced.has(p.user_id))badge='🔇';else if(part&&!part.isMicrophoneEnabled)badge='🤫';
    if(badge)c.append(vEl('span','vpb',badge));
    c.title=me?(VOICE.mic?'Silenciar tu micrófono':'Activar tu micrófono'):(VOICE.silenced.has(p.user_id)?'Volver a escuchar a '+p.name:'Silenciar a '+p.name+' (solo para ti)');
    c.onmousedown=e=>e.preventDefault();
    c.onclick=()=>me?toggleMic():toggleSilence(p.user_id);
    b.append(c)}}
async function toggleMic(){const rm=VOICE.room;VOICE.mic=!VOICE.mic;
  try{if(rm)await rm.localParticipant.setMicrophoneEnabled(VOICE.mic)}catch(e){VOICE.mic=false}renderVbar()}
function toggleSilence(id){VOICE.silenced.has(id)?VOICE.silenced.delete(id):VOICE.silenced.add(id);
  document.querySelectorAll('audio[data-vid="'+id+'"]').forEach(a=>a.muted=VOICE.silenced.has(id));renderVbar()}
function voiceStop(){VOICE.tok++;const rm=VOICE.room;VOICE.room=null;VOICE.roster=[];VOICE.spk={};VOICE.silenced.clear();VOICE.mic=true;
  try{rm&&rm.disconnect()}catch(e){}document.querySelectorAll('audio[data-vid]').forEach(a=>a.remove());
  document.body.classList.remove('vc');const b=$('vbar');if(b)b.textContent=''}
/* carga los jugadores reales (con marco) y muestra la barra; la conexión de voz sigue en segundo plano */
async function voiceInit(mid){voiceStop();const tk=VOICE.tok;
  try{const r=await SB.rpc('mg_match_roster',{p_match:mid});if(r.error)throw r.error;
    if(tk!=VOICE.tok||!r.data||r.data.length<2)return;
    VOICE.roster=r.data.map(p=>({...p,name:String(p.name||'Jugador').slice(0,20)}));
    document.body.classList.add('vc');renderVbar();voiceConnect(mid,tk)}catch(e){}}
async function voiceConnect(mid,tk){
  try{if(typeof LivekitClient==='undefined')return;
    const t=await SB.rpc('mg_livekit_token',{p_match:mid});if(t.error||!t.data||tk!=VOICE.tok)return;
    const L=LivekitClient,rm=new L.Room({adaptiveStream:true,dynacast:true,audioCaptureDefaults:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});VOICE.room=rm;
    rm.on(L.RoomEvent.TrackSubscribed,(track,_p,part)=>{if(track.kind=='audio'){const a=track.attach();a.dataset.vid=part.identity;a.muted=VOICE.silenced.has(part.identity);a.style.display='none';document.body.appendChild(a)}renderVbar()});
    rm.on(L.RoomEvent.TrackUnsubscribed,track=>{track.detach().forEach(a=>a.remove());renderVbar()});
    for(const ev of['ParticipantConnected','ParticipantDisconnected','TrackMuted','TrackUnmuted','LocalTrackPublished','LocalTrackUnpublished'])rm.on(L.RoomEvent[ev],renderVbar);
    rm.on(L.RoomEvent.ActiveSpeakersChanged,sp=>{VOICE.spk={};sp.forEach(p=>VOICE.spk[p.identity]=1);
      document.querySelectorAll('#vbar .vp').forEach(c=>c.classList.toggle('spk',!!VOICE.spk[c.dataset.id]))});
    await rm.connect(t.data.url,t.data.token);if(tk!=VOICE.tok){rm.disconnect();return}
    try{await rm.localParticipant.setMicrophoneEnabled(true);VOICE.mic=true}catch(e){VOICE.mic=false}
    renderVbar()}catch(e){}}
addEventListener('pagehide',voiceStop);

/* ---- matchmaking (reales + bots) y tienda ---- */
const NM=['Nova','Rayo','Turbo','Kira','Blitz','Orion','Luna','Zeta','Astro','Vega'];let qid=0;
async function queue(){voiceStop();const id=++qid,row=(a,b)=>`<div class="mr">${a}<span>${b}</span></div>`,wt=ms=>new Promise(r=>setTimeout(r,ms));
  const dm=L=>$('mm-l').innerHTML=row('🧑 Tú','LISTO')+[0,1,2,3].map(i=>L[i]?row((L[i].bot?'🤖 ':'🧑 ')+L[i].n,L[i].bot?'BOT':'ONLINE'):row('<i class="sp"></i> Buscando…','')).join('');
  ov('mm');$('mm-t').textContent='BUSCANDO JUGADORES…';dm([]);let fd=[];MATCH=null;
  try{
    if(!ME)throw new Error('sin sesión');
    const f=await SB.rpc('mg_find_match',{p_game:cur});if(f.error)throw f.error;const mid=f.data;MATCH=mid;
    const t0=Date.now();
    while(Date.now()-t0<CONFIG.net.wait){
      await wt(700);if(id!=qid)return;
      const s=await SB.rpc('mg_match_state',{p_match:mid});if(s.error)throw s.error;
      fd=((s.data&&s.data.players)||[]).filter(p=>p.id!=ME.id).map(p=>({name:p.name}));dm(fd.map(p=>({n:esc(String(p.name||'Jugador').slice(0,20))})))}
    if(id!=qid)return;
    const st=await SB.rpc('mg_start_match',{p_match:mid});if(st.error)throw st.error;
  }catch(e){MATCH=null;fd=[];if(id==qid)$('mm-t').textContent='SIN CONEXIÓN · MODO PRÁCTICA'}
  if(id!=qid)return;const L=fd.slice(0,4).map(p=>({n:esc(String(p.name||'Jugador').slice(0,20))})),nn=[...NM].sort(()=>Math.random()-.5);
  while(L.length<4)L.push({n:nn.pop(),bot:1});
  for(let i=1;i<=4;i++){dm(L.slice(0,i));await wt(350);if(id!=qid)return}
  $('mm-t').textContent='¡PARTIDA LISTA!';if(MATCH)await voiceInit(MATCH);await wt(700);if(id!=qid)return;play([{n:'Tú'},...L])}
const lg=k=>CONFIG.logo[k]?`<img src="${CONFIG.logo[k]}" alt="" style="height:1.1em;vertical-align:-.2em">`:(EM[k]||'🪙');
async function shop(msg,keep){ov('shop');if(ME&&!keep){try{await loadWallet()}catch(e){}}$('appbal').textContent=ME?'En Z3T tienes: '+APP.coin+' Z-Coins · '+APP.stars+' Diamantes':'';$('wl').innerHTML=Object.keys(CONFIG.tiers).map(k=>`<span>${lg(k)} <b>${WL[k]}</b></span>`).join('');
  $('ex').innerHTML=CONFIG.exchange.map((x,i)=>{const ok=Object.keys(x.cost).every(k=>WL[k]>=x.cost[k]);return `<div class="xc"><div>${Object.keys(x.cost).map(k=>`<span>${lg(k)} ${WL[k]}/${x.cost[k]}</span>`).join(' ')}</div><div class="xg">→ ${lg(x.icon)} <b>${x.get[1]}</b> ${x.n}</div><button class="btn" data-i="${i}" ${ok?'':'disabled'}>CANJEAR</button></div>`}).join('')+(msg?`<p>${msg}</p>`:'');
  document.querySelectorAll('#ex .btn').forEach(b=>b.onclick=async()=>{b.disabled=true;const x=CONFIG.exchange[b.dataset.i];
    const r=await SB.rpc('mg_exchange',{p_kind:x.id});if(r.error){shop('⚠️ '+(r.error.message||'No se pudo canjear'),1);return}
    const d=r.data[0];Object.assign(WL,{zeta:d.zeta,bronce:d.bronce,oro:d.oro,diamante:d.diamante});APP={coin:d.coin_balance,stars:d.stars_balance};
    shop('¡Canje listo! +'+x.get[1]+' '+x.n+' en tu cuenta Z3T',1)})}

/* ---- juegos ---- */
const defs={
carreras:{n:'Turbo Racer',ic:'🏎️',d:'Carrera de 5 pilotos en pantalla dividida. El primero en llegar a la meta gana. Los choques te frenan.',h:'← → o A D para girar · ESPACIO = turbo',f:'TURBO',
 make:P=>match(P,{sky:0x240046,far:170,speed:38,xs:14,W:5.5,lanes:[-4.5,-1.5,1.5,4.5],cr:.18,rate:.9,goal:2600,dist:1,turbo:1,cy:4.2,cz:9,lbl:'Distancia',trail:0xff9a3d,
  player:()=>car(0x00e5ff,1),obj:()=>({m:car(pick([0xff3d81,0xffd23f,0x8aff6b,0xffffff]),0),k:'bad',r:1.3,s:-rnd(0,14)}),
  env:(S,Sc)=>{const rd=B(12,.1,400,0x1b1b2e),g=B(400,.1,400,0x2d0b5a),sun=new T.Mesh(new T.SphereGeometry(45,24,16),BM(0xff5e8a));rd.position.set(0,-.05,-150);g.position.set(0,-.15,-150);sun.position.set(0,25,-330);S.add(rd,g,sun);
   for(let i=0;i<18;i++)for(const x of[-3,0,3]){const d=B(.25,.02,3,0x00e5ff);d.position.set(x,.03,10-i*12.2);Sc.push(d);S.add(d)}
   for(let i=0;i<20;i++)for(const s of[-1,1]){const h=rnd(6,24),b=M(new T.BoxGeometry(rnd(4,8),h,rnd(4,8)),0x1a0f3d,{emissive:pick([0x2a0a5a,0x0a2a5a,0x5a0a3a]),emissiveIntensity:.7});b.position.set(s*rnd(24,46),h/2,10-i*11);Sc.push(b);S.add(b)}
   for(let i=0;i<16;i++)for(const s of[-1,1]){const k=M(new T.ConeGeometry(1.4,4,6),0xff3d81);k.position.set(s*rnd(8,16),2,10-i*13.75);Sc.push(k);S.add(k)}}})},
naves:{n:'Star Raider',ic:'🚀',d:'Duelo de 5 naves: el primero en derrotar 20 enemigos gana. Los choques te frenan.',h:'Mover: flechas / WASD / joystick · ESPACIO = disparar',f:'FUEGO',
 make:P=>match(P,{sky:0x03020d,far:400,speed:32,xs:16,W:11,ym:1,y0:-5,y1:5,cr:.1,rate:.8,goal:20,shoot:1,cy:3,cz:10,lbl:'Enemigos',trail:0x00e5ff,tx:1.45,
  player:ship,obj:()=>Math.random()<.5?{m:M(new T.OctahedronGeometry(1.3),0xff3d4d,{emissive:0x661018}),k:'enemy',r:1.3,hp:2,sp:2,s:rnd(0,12)}:{m:M(new T.DodecahedronGeometry(1.6),0x8a8fa3),k:'enemy',r:1.6,hp:3,sp:1},
  env:(S,Sc)=>{S.background=TL.load(A('backgrounds/space_nebula.jpg'));const g=new T.BoxGeometry(.15,.15,.15),m=BM(0xffffff);for(let i=0;i<160;i++){const s=new T.Mesh(g,m);s.position.set(rnd(-60,60),rnd(-35,35),rnd(-210,10));Sc.push(s);S.add(s)}
   const p=new T.Mesh(new T.SphereGeometry(30,24,16),BM(0x6a35ff)),r=new T.Mesh(new T.TorusGeometry(48,2,4,40),BM(0xff3d81));p.position.set(-70,25,-330);r.position.copy(p.position);r.rotation.x=1.2;S.add(p,r)}})},
guerra:{n:'Tank Zone',ic:'🪖',d:'Todos contra todos: 5 tanques, gana el último en pie. Si caes, quedas espectando y tu puesto da monedas.',h:'Mover: WASD / flechas / joystick · ESPACIO = disparar',f:'FUEGO',make:tank},
vuelo:{n:'Sky Rings',ic:'✈️',d:'Carrera de aros: el primero en cruzar 12 aros dorados gana. Esquiva las tormentas.',h:'Mover: flechas / WASD / joystick',f:'',
 make:P=>match(P,{sky:0x8fd3ff,far:170,speed:34,xs:14,W:10,ym:1,y0:-3,y1:7,cr:.1,rate:1.1,goal:12,cy:3.5,cz:10,lbl:'Aros',trail:0xbfefff,tx:.7,
  player:plane,obj:()=>{if(Math.random()<.6){const g=new T.Group();g.add(M(new T.TorusGeometry(2.2,.22,8,24),0xffd23f,{emissive:0xffa000,emissiveIntensity:.8}),M(new T.TorusGeometry(2.2,.55,6,24),0xfff1a0,{transparent:true,opacity:.22,emissive:0xffd23f,emissiveIntensity:.5}));return{m:g,k:'ring',r:2}}const g=new T.Group();for(let j=0;j<3;j++){const s=M(new T.SphereGeometry(1.4,8,6),0x4a4f6e);s.position.set(j*1.4-1.4,rnd(-.3,.3),0);g.add(s)}return{m:g,k:'bad',r:2.2,sp:.3}},
  env:(S,Sc)=>{const su=new T.Mesh(new T.SphereGeometry(25,16,12),BM(0xfff2a8));su.position.set(70,45,-320);S.add(su);const oc=M(new T.PlaneGeometry(500,500),0x1e88e5);oc.rotation.x=-H;oc.position.set(0,-14,-150);S.add(oc);
   for(let i=0;i<34;i++){const g=new T.Group();for(let j=0;j<3;j++){const s=M(new T.SphereGeometry(rnd(2,3.5),8,6),0xffffff);s.position.set(j*2.5-2.5,rnd(0,1),rnd(-1,1));g.add(s)}g.position.set(pick([-1,1])*rnd(14,50),rnd(-8,9),10-i*6.5);Sc.push(g);S.add(g)}
   for(let i=0;i<12;i++){const k=M(new T.ConeGeometry(rnd(4,8),3,7),0x3fae52);k.position.set(rnd(-40,40),-13,10-i*18.3);Sc.push(k);S.add(k)}}})}
};
/* ---- flujo de pantallas ---- */
const ov=id=>{for(const e of document.querySelectorAll('.ov'))e.classList.toggle('on',e.id==id)};
function icon(el,k){const im=CONFIG.img[k];el.style.setProperty('--img',im?`url(${im})`:'');el.textContent=im?'':defs[k].ic}
function menu(){state='menu';G=null;qid++;voiceStop();$('vw').innerHTML='';const h=$('hudw').style;h.right=h.left=h.width=h.top='';$('fire').style.right='';document.body.classList.remove('mp');document.body.classList.remove('play');ov('menu')}
const ACC={carreras:'#ff3d81',naves:'#00e5ff',guerra:'#8aff6b',vuelo:'#ffd23f'},best=k=>{try{return+localStorage.getItem('zeta_best_'+k)||0}catch(e){return 0}};
function pause(){if(state=='play'){state='pause';$('cd').textContent='PAUSA'}else if(state=='pause'){state='play';$('cd').textContent=''}}
$('ps').onclick=pause;addEventListener('blur',()=>state=='play'&&pause());
function confetti(){const e=$('end');for(let i=0;i<40;i++){const c=document.createElement('i');c.className='cf';c.style.cssText=`left:${rnd(0,100)}%;background:${pick(['#ffd23f','#00e5ff','#ff3d81','#8aff6b'])};animation-duration:${rnd(1.8,3.4)}s;animation-delay:${rnd(0,1.2)}s`;e.appendChild(c);setTimeout(()=>c.remove(),5500)}}
function intro(k){cur=k;document.documentElement.style.setProperty('--a',ACC[k]);$('bs').textContent='🏆 Tu mejor marcador de monedas: '+best(k);const d=defs[k];icon($('s-ic'),k);$('s-t').textContent=d.n;$('s-d').textContent=d.d;$('s-h').textContent=d.h;ov('start')}
function play(P){run={zeta:0,bronce:0,oro:0,diamante:0};WL0={...WL};$('fire').textContent=defs[cur].f;$('fire').style.visibility=defs[cur].f?'visible':'hidden';G=defs[cur].make(P);document.body.classList.toggle('mp',!!G.ins);document.body.classList.toggle('foc',!!FOC);if(G.ins)setLayout();state='count';ct=3;ln=4;document.body.classList.add('play');ov('');try{document.documentElement.requestFullscreen?.()?.catch?.(()=>{})}catch(e){}}
function end(w,rk,tbl){if(state!='play')return;state='end';F=0;const pb=rk?(rk==1?CONFIG.winBonus[cur]:CONFIG.place[rk]):(w&&CONFIG.winBonus[cur]);const picks={...run};if(pb)run[pb[0]]=(run[pb[0]]||0)+pb[1];const rank=rk||(w?1:5),mid=MATCH;
  document.body.classList.remove('play');$('cd').textContent='';icon($('e-ic'),cur);let bs=best(cur);try{if(val()>bs){bs=val();localStorage.setItem('zeta_best_'+cur,bs)}}catch(e){}if(w)confetti();const t=$('e-t');t.textContent=w?'¡GANASTE!':rk?rk+'.º LUGAR':'GAME OVER';t.className=w||(rk&&rk<4)?'w':'l';
  $('e-s').textContent=w?'¡Misión cumplida! '+defs[cur].n:'Inténtalo otra vez, ¡tú puedes!';$('e-s').textContent+='  🏆 Mejor: '+bs;if(tbl)$('e-s').innerHTML+='<br><br>'+tbl;
  $('e-c').textContent='Guardando premios…';settle(rank,picks,mid);ov('end')}
async function settle(rank,picks,mid){const el=$('e-c');
  if(!mid||!ME){WL={...WL0};el.textContent='Modo práctica · sin premios';return}
  const r=await SB.rpc('mg_finish_match',{p_match:mid,p_rank:rank,p_coins:picks});
  if(r.error){WL={...WL0};const m=r.error.message||'';el.textContent='⚠️ '+(m.includes('corta')?'Partida demasiado corta para ganar premios':m.includes('hora')?'Límite de partidas por hora alcanzado':'No se pudieron guardar los premios');return}
  const n=r.data&&r.data[0];if(!n){WL={...WL0};el.textContent='No se pudieron guardar los premios';return}const t=Object.keys(CONFIG.tiers);Object.assign(WL,n);
  el.innerHTML=t.map(k=>{const d=n[k]-(WL0[k]||0);return d>0?`${EM[k]} ${k[0].toUpperCase()+k.slice(1)} ×${d}`:''}).filter(Boolean).join(' &nbsp; ')||'Sin monedas esta vez'}
$('grid').innerHTML=Object.keys(defs).map(k=>`<button class="card" data-k="${k}" style="--a:${ACC[k]}"><div class="ico"></div><b>${defs[k].n}</b><small>${defs[k].h.split('·')[0]}</small></button>`).join('');
document.querySelectorAll('.card').forEach(b=>{icon(b.firstChild,b.dataset.k);b.onclick=()=>intro(b.dataset.k)});
try{FOC=+localStorage.zeta_focus||0}catch(e){}$('fv').textContent=FOC?'🙈':'👁';$('fv').onclick=toggleFoc;$('go').onclick=$('rt').onclick=queue;$('shopb').onclick=()=>shop();$('bk3').onclick=menu;$('mm-x').onclick=()=>{qid++;voiceStop();if(MATCH)SB.rpc('mg_leave_match',{p_match:MATCH});MATCH=null;intro(cur)};$('exitapp').onclick=()=>{location.href='/'};$('xt').onclick=()=>{if(confirm('¿Salir a Z3T? Perderás los premios de esta partida.'))location.href='/'};$('bk1').onclick=$('bk2').onclick=menu;
document.documentElement.style.setProperty('--bg',`url(${A('backgrounds/deep_space.jpg')})`);
document.querySelectorAll('.lg').forEach(e=>e.innerHTML=Object.keys(CONFIG.tiers).map(k=>`<span>${EM[k]} ${k[0].toUpperCase()+k.slice(1)} <b>${CONFIG.tiers[k]}</b></span>`).join(''));
scene(0x070a1a,50,200);
(function loop(){requestAnimationFrame(loop);const dt=Math.min(clock.getDelta(),.05);
 if(state=='play'&&G){G.update(dt);if(SH>0){const cc=G.ins?G.ins[0].C:C;cc.position.x+=rnd(-1,1)*SH;cc.position.y+=rnd(-1,1)*SH;SH=Math.max(0,SH-dt*1.6)}}
 else if(state=='count'&&G){G.update(0);ct-=dt;const n=Math.ceil(ct);if(n!=ln){ln=n;const e=$('cd');e.textContent=n>0?n:'¡YA!';e.style.animation='none';void e.offsetHeight;e.style.animation=''}if(ct<=-.5){$('cd').textContent='';state='play'}}
 drw()})();

/* ---- sesión de Z3T ---- */
(async()=>{
  try{const{data:{session}}=await SB.auth.getSession();
    if(!session){ov('gate');return}
    ME=session.user;
    const p=await SB.from('profiles').select('username,name').eq('id',ME.id).maybeSingle();
    if(p.data)$('who').textContent='Jugando como @'+(p.data.username||p.data.name||'');
    await loadWallet();
  }catch(e){$('who').textContent='Sin conexión con Z3T · modo práctica'}
})();
