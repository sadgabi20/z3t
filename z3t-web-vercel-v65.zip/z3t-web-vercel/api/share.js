/**
 * Vista previa (Open Graph) para enlaces compartidos de Z3T.
 * Solo la reciben los rastreadores de redes (WhatsApp, Telegram, Discord, Facebook, X...)
 * mediante las reglas "has: user-agent" de vercel.json. Las personas reciben siempre el index.html normal.
 *
 * Seguridad: usa la clave PUBLISHABLE (la misma que ya está en la web). Solo puede leer lo que las
 * políticas RLS de Supabase permiten al público; no hay service_role aquí. Solo se publican
 * título/descripción/imagen. Todo se escapa.
 */
const SUPABASE_URL = process.env.SUPABASE_URL || "https://pqbpeccvzycdspmfsgab.supabase.co";
const KEY = process.env.SUPABASE_PUBLISHABLE_KEY || "sb_publishable_kFQRBOv-qOxy5x_B9z3Jpw_dr7YsSpt";
const ORIGIN = "https://z3t.fun";
const DEFAULT_IMG = ORIGIN + "/og-image.png";

const TYPES = {
  thread:    { table: "threads",     key: "slug",     fields: "title,excerpt,cover_image_url", path: "/temas/" },
  profile:   { table: "profiles",    key: "username", fields: "username,name,bio,avatar_url",   path: "/perfiles/" },
  community: { table: "communities", key: "slug",     fields: "name,description,banner_url",    path: "/comunidades/" },
  circle:    { table: "circles",     key: "slug",     fields: "name,description,info,icon_url", path: "/circulos/" },
};

const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const clip = (s, n) => { s = String(s || "").replace(/\s+/g, " ").trim(); return s.length > n ? s.slice(0, n - 1) + "…" : s; };
const httpsOnly = (u) => (typeof u === "string" && /^https:\/\//i.test(u) ? u : null);

function meta(type, r) {
  if (!r) return { title: "Z3T", desc: "Z3T: comunidades, círculos, chats y salas de voz en un solo lugar.", img: null };
  if (type === "thread") return { title: r.title, desc: r.excerpt, img: r.cover_image_url };
  if (type === "profile") return { title: (r.name || r.username) + " (@" + r.username + ")", desc: r.bio, img: r.avatar_url };
  if (type === "community") return { title: r.name, desc: r.description, img: r.banner_url };
  return { title: r.name, desc: r.description || r.info, img: r.icon_url };
}

module.exports = async function handler(req, res) {
  const q = req.query || {};
  const type = String(q.type || "");
  const id = String(q.id || "").slice(0, 200);
  const conf = TYPES[type];
  let row = null;
  if (conf && id) {
    try {
      const url = SUPABASE_URL + "/rest/v1/" + conf.table + "?" + conf.key + "=eq." + encodeURIComponent(id) + "&select=" + conf.fields + "&limit=1";
      const r = await fetch(url, { headers: { apikey: KEY, Authorization: "Bearer " + KEY } });
      if (r.ok) { const arr = await r.json(); row = Array.isArray(arr) ? arr[0] || null : null; }
    } catch (_e) { row = null; }
  }
  const m = meta(type, row);
  const title = clip(m.title || "Z3T", 90) + (row ? " · Z3T" : "");
  const desc = clip(m.desc || "Z3T: comunidades, círculos, chats y salas de voz en un solo lugar.", 200);
  const img = httpsOnly(m.img) || DEFAULT_IMG;
  const canonical = conf ? ORIGIN + conf.path + encodeURIComponent(id) : ORIGIN + "/";
  const html = '<!doctype html><html lang="es"><head><meta charset="utf-8"><title>' + esc(title) + "</title>" +
    '<meta name="description" content="' + esc(desc) + '">' +
    '<link rel="canonical" href="' + esc(canonical) + '">' +
    '<meta property="og:type" content="' + (type === "profile" ? "profile" : "article") + '">' +
    '<meta property="og:site_name" content="Z3T"><meta property="og:url" content="' + esc(canonical) + '">' +
    '<meta property="og:title" content="' + esc(title) + '"><meta property="og:description" content="' + esc(desc) + '">' +
    '<meta property="og:image" content="' + esc(img) + '"><meta name="twitter:card" content="summary_large_image">' +
    '<meta name="twitter:title" content="' + esc(title) + '"><meta name="twitter:description" content="' + esc(desc) + '">' +
    '<meta name="twitter:image" content="' + esc(img) + '"></head><body><a href="' + esc(canonical) + '">' + esc(title) + "</a></body></html>";
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Cache-Control", "public, s-maxage=300, stale-while-revalidate=3600");
  res.status(200).send(html);
};
