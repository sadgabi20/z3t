const SHELL_CACHE = 'z3t-shell-v65';
const ASSETS_CACHE = 'z3t-assets-v65';
const MEDIA_CACHE  = 'z3t-media-v24';

const ALL_CACHES = [SHELL_CACHE, ASSETS_CACHE, MEDIA_CACHE];

const SHELL_FILES = [
  '/',
  '/index.html',
  '/manifest.json',
  '/assets/logo-64.png',
  '/assets/logo-128.png',
  '/assets/logo-256.png',
  '/assets/logo-512.png'
];

const SUPABASE_HOST = 'pqbpeccvzycdspmfsgab.supabase.co';

self.addEventListener('install', function(event){
  self.skipWaiting();
  event.waitUntil(
    caches.open(SHELL_CACHE).then(function(cache){
      return Promise.all(SHELL_FILES.map(function(url){
        return cache.add(url).catch(function(err){
          console.warn('[sw] no se pudo cachear', url, err);
        });
      }));
    })
  );
});

self.addEventListener('activate', function(event){
  event.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys.filter(function(k){ return ALL_CACHES.indexOf(k) === -1; })
            .map(function(k){ return caches.delete(k); })
      );
    }).then(function(){ return self.clients.claim(); })
  );
});

function networkFirst(req, cacheName){
  return fetch(req).then(function(res){
    if(res && res.ok){ var copy = res.clone(); caches.open(cacheName).then(function(c){ c.put(req, copy); }); }
    return res;
  }).catch(function(){ return caches.match(req); });
}

function staleWhileRevalidate(req, cacheName){
  return caches.open(cacheName).then(function(cache){
    return cache.match(req).then(function(cached){
      var networkFetch = fetch(req).then(function(res){
        if(res && res.ok) cache.put(req, res.clone());
        return res;
      }).catch(function(){ return cached; });
      return cached || networkFetch;
    });
  });
}

self.addEventListener('fetch', function(event){
  var req = event.request;
  if(req.method !== 'GET') return;

  var url = new URL(req.url);
  var sameOrigin = (url.origin === self.location.origin);
  var isSupabase = (url.hostname === SUPABASE_HOST);

  if(sameOrigin && SHELL_FILES.indexOf(url.pathname) !== -1){
    event.respondWith(networkFirst(req, SHELL_CACHE));
    return;
  }

  if(sameOrigin && url.pathname.indexOf('/assets/') === 0){
    event.respondWith(staleWhileRevalidate(req, ASSETS_CACHE));
    return;
  }

  if(isSupabase && url.pathname.indexOf('/storage/v1/object/public/') === 0){
    /* audio/video piden Range (206): no se pueden cachear ni servir desde cache, se dejan pasar directo */
    if(req.headers.has('range') || req.destination === 'audio' || req.destination === 'video') return;
    event.respondWith(staleWhileRevalidate(req, MEDIA_CACHE));
    return;
  }

  if(isSupabase){
    event.respondWith(fetch(new Request(req, { cache: 'no-store' })));
    return;
  }

  if(req.mode === 'navigate'){
    event.respondWith(
      fetch(req).catch(function(){
        return caches.match('/index.html').then(function(cached){
          if(!cached) console.warn('[sw] sin internet y sin index.html cacheado todavía — primera visita, no hay nada que mostrar.');
          return cached || caches.match('/');
        });
      })
    );
    return;
  }
});

self.addEventListener('notificationclick', function(event){
  event.notification.close();
  var url = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(list){
      for (var i = 0; i < list.length; i++) {
        if ('focus' in list[i]) {
          list[i].focus();
          if ('navigate' in list[i]) { try { list[i].navigate(url); } catch (e) {} }
          return;
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
    })
  );
});
